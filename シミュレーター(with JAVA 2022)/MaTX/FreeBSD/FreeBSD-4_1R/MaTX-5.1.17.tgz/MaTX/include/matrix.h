/*
 *
 * Copyright (C) 1989, 1990, 1991 Masanobu Koga
 *            All Rights Reserved.
 *
 * No part of this software may be used, copied, modified, and distributed
 * in any form or by any means, electronic, mechanical, manual, optical or
 * otherwise, without prior permission of Masanobu Koga.
 *
 */

/*
  matrix.h : 

  $Author: koga $
  $Revision: 1.5 $
  $Date: 2000/11/23 03:59:15 $
  $Log: matrix.h,v $
  Revision 1.5  2000/11/23 03:59:15  koga
  *** empty log message ***

 * Revision 1.4  1994/06/21  13:29:05  koga
 * *** empty log message ***
 *
 * Revision 1.3  1992/06/10  12:21:02  koga
 *  Optimization
 *
 * Revision 1.2  1992/04/12  09:20:56  koga
 * Several filename were changed.
 *
 * Revision 1.1  1992/03/25  12:14:13  koga
 * Initial revision
 *
*/

#ifndef matrix_header
#define matrix_header

#include <matxconf.h>
#include <stdio_my.h>

#ifdef VXWORKS
#include <stdioLib.h>
#else
#include <stdio.h>
#endif

#ifdef BSD42
#include <strings.h>
#else
#include <string.h>
#endif

#include <math.h>
#include <util.h>
#include <estring.h>
#include <complex.h>
#include <mxstring.h>

#define MATX_TMP_DESTROY	MatObjectTmpUndef

/*
 *	Module
 */
#ifdef MATX_SMALL
#undef MAT_FFT
#undef MAT_RUNGE
#undef MAT_C_RUNGE
#undef MAT_SVD
#undef MAT_C_SVD
#undef MAT_LUQR
#undef MAT_C_LUQR
#undef MAT_C_EIG
#undef MAT_EIG
#undef MAT_HEIG
#undef MAT_GEIG
#undef MAT_C_GEIG
#else
#define MAT_FFT
#define MAT_RUNGE
#define MAT_C_RUNGE
#define MAT_SVD
#define MAT_C_SVD
#define MAT_LUQR
#define MAT_C_LUQR
#define MAT_C_EIG
#define MAT_EIG
#define MAT_HEIG
#define MAT_GEIG
#define MAT_C_GEIG
#endif
/*
 *	End of Module
 */

/*
 * MatEnlarge()
 */
#define MAT_ENLARGE 1

/* Data Type */
#define	MAT_TMP					0
#define	MAT_VAR					1
#define	MAT_POLY				2
#define	MAT_LIST				3
#define MAT_MATX				4

/* Data Class */
#define MAT_REAL				0
#define MAT_COMPLEX				1
#ifdef P_MAT
#define MAT_R_POLYNOMIAL		2
#define MAT_C_POLYNOMIAL		3
#endif
#ifdef R_MAT
#define MAT_R_RATIONAL			4
#define MAT_C_RATIONAL			5
#endif

#define MAT_NULL				MatDef("", 0, 0)
#define MAT_DEF					MatSetType(MAT_NULL, MAT_VAR)
#define MAT_STC					MatSetType(MAT_NULL, MAT_MATX)
#define C_MAT_NULL				C_MatDef("", 0, 0)
#define C_MAT_DEF				MatSetType(C_MAT_NULL, MAT_VAR)
#ifdef P_MAT
#define P_MAT_NULL				P_MatDef("", 0, 0)
#define P_MAT_DEF				MatSetType(P_MAT_NULL, MAT_VAR)
#define R_P_MAT_NULL			P_MAT_NULL
#define C_P_MAT_NULL			MatSetClass(P_MAT_NULL, MAT_C_POLYNOMIAL)
#endif
#ifdef R_MAT
#define R_MAT_NULL				R_MatDef("", 0, 0)
#define R_MAT_DEF				MatSetType(R_MAT_NULL, MAT_VAR)
#define R_R_MAT_NULL			R_MAT_NULL
#define C_R_MAT_NULL			MatSetClass(R_MAT_NULL, MAT_C_RATIONAL)
#endif

#define MatConst(d)				MatSetValue(MatDef("", 1, 1), 1, 1, (d))
#define	MatValue(a, i, j)		(*MatPtr(a, i, j))
#define	MatPtr(a, i, j)			((a)->elm.r + ((i)-1)*Cols(a) + (j)-1)
#define	MatVecValue(a, i)		(*MatVecPtr(a, i))
#define	MatVecPtr(a, i)			((a)->elm.r + (i)-1)
#define C_MatConst(d)			C_MatSetValue(C_MatDef("", 1, 1), 1, 1, (d))
#define	C_MatValue(a, i, j)		ComplexValueToComp(C_MatPtr(a, i, j))
#define	C_MatPtr(a, i, j)		((a)->elm.c + ((i)-1)*Cols(a) + (j)-1)
#define	C_MatVecValue(a, i)		ComplexValeuToComp(C_MatVecPtr(a, i))
#define	C_MatVecPtr(a, i)		((a)->elm.c + (i)-1)

#ifdef P_MAT
#define	P_MatValue(a, i, j)		PolyDup(P_MatPtr(a, i, j))
#define	P_MatPtr(a, i, j)		(*((a)->elm.poly + ((i)-1)*Cols(a) + (j)-1))
#define P_MatConst(d)			P_MatSetValue(P_MatDef("", 1, 1), 1, 1, (d))
#endif
#ifdef R_MAT
#define	R_MatValue(a, i, j)		RatDup(R_MatPtr(a, i, j))
#define	R_MatPtr(a, i, j)		(*((a)->elm.rat + ((i)-1)*Cols(a) + (j)-1))
#define R_MatConst(d)			R_MatSetValue(R_MatDef("", 1, 1), 1, 1, (d))
#endif

#define	MatGetClass(a)			((a)->class)
#define	MatClass(a)				((a)->class)
#define	MatGetType(a)			((a)->type)
#define	MatGetType(a)			((a)->type)
#define	MatType(a)				((a)->type)
#define	MatGetName(a)			((a)->name)
#define	MatName(a)				((a)->name)

#define MatRows(a)				MatGetRows(a)
#define MatCols(a)				MatGetCols(a)

#ifdef SYSV
#define	CSize(a)				MatGetRows(a)
#define	RSize(a)				MatGetCols(a)
#define	Rows(a)					MatGetRows(a)
#define	Cols(a)					MatGetCols(a)
#else
#define	CSize(a)				Rows(a)
#define	RSize(a)				Cols(a)
#define	Rows(a)					((a)->rows)
#define	Cols(a)					((a)->cols)
#endif

#define	MatRand(m,n)			MatUniformRand(m,n)
#define	C_MatRand(m,n)			C_MatUniformRand(m,n)

#define MatIsReal(a)			(MatClass(a) == MAT_REAL)
#define MatIsNotReal(a)			(MatClass(a) != MAT_REAL)
#define MatIsComplex(a)			(MatClass(a) == MAT_COMPLEX)
#define MatIsNotComplex(a)		(MatClass(a) != MAT_COMPLEX)

#define MatIsRealValue2(a,b)	(MatIsRealValue(a) && MatIsRealValue(b))
#define MatIsComplexValue2(a,b)	(MatIsComplexValue(a) || MatIsComplexValue(b))

#ifdef P_MAT
#define MatIsR_Polynomial(a)	(MatClass(a) == MAT_R_POLYNOMIAL)
#define MatIsR_Polynomial2(a,b)	(MatIsR_Polynomial(a) && MatIsR_Polynomial(b))
#define MatIsC_Polynomial(a)	(MatClass(a) == MAT_C_POLYNOMIAL)
#define MatIsC_Polynomial2(a,b)	(MatIsC_Polynomial(a) || MatIsC_Polynomial(b))
#define MatIsPolynomial(a)		(MatIsR_Polynomial(a) || MatIsC_Polynomial(a))
#define MatIsPolynomial2(a,b)	(MatIsPolynomial(a) || MatIsPolynomial(b))
#endif

#ifdef R_MAT
#define MatIsR_Rational(a)		(MatClass(a) == MAT_R_RATIONAL)
#define MatIsR_Rational2(a,b)	(MatIsR_Rational(a) && MatIsC_Rational(b))
#define MatIsC_Rational(a)		(MatClass(a) == MAT_C_RATIONAL)
#define MatIsC_Rational2(a,b)	(MatIsC_Rational(a) || MatIsC_Rational(b))
#define MatIsRational(a)		(MatIsR_Rational(a) || MatIsC_Rational(a))
#define MatIsRational2(a,b)		(MatIsRational(a) || MatIsRational(b))
#endif

#define MatIsTmp(a)				(MatType(a) == MAT_TMP)
#define MatIsVar(a)				(MatType(a) == MAT_VAR)
#define MatIsPoly(a)			(MatType(a) == MAT_POLY)
#define MatIsList(a)			(MatType(a) == MAT_LIST)

#define MatIsColumnLong(a)		(Rows(a) > Cols(a))
#define MatIsRowLong(a)			(Rows(a) < Cols(a))
#define MatIsSquare(a)			(Rows(a) == Cols(a))
#define MatIsNonSquare(a)		(Rows(a) != Cols(a))
#define MatIsNonSquare2(a,b)	(MatIsNonSquare(a) || MatIsNonSquare(b))
#define MatIsRowVec(a)			(Rows(a) == 1)
#define MatIsColumnVec(a)		(Cols(a) == 1)
#define MatIsVector(a)			(MatIsRowVec(a) || MatIsColumnVec(a))
#define MatIsScalar(a)			(Rows(a) == 1 && Cols(a) == 1)
#define MatIsZeroSize(a)		(Rows(a) == 0 || Cols(a) == 0)
#define MatIsNotZeroSize(a)		(Rows(a) != 0 && Cols(a) != 0)
#define MatIsZeroSize2(a,b)		(MatIsZeroSize(a) || MatIsZeroSize(b))
#define MatIsEmpty(a)			MatIsZeroSize(a)
#define MatIsNotEmpty(a)		MatIsNotZeroSize(a)
#define MatIsSameClass(a,b)		(MatClass(a) == MatClass(b))
#define MatIsNotSameClass(a,b)	(MatClass(a) != MatClass(b))
#define MatIsSameSize(a,b)		(Rows(a) == Rows(b) && Cols(a) == Cols(b))
#define MatIsNotSameSize(a,b)	(Rows(a) != Rows(b) || Cols(a) != Cols(b))
#define ErrorName(a)			(a)->name, Rows(a), Cols(a)

typedef union __Element {
	double	              *r;		/* Real Element       */
	struct __ComplexValue *c;		/* Complex Elemen     */
#ifdef P_MAT
	struct __Polynomial   **poly;	/* Polynomial Element */
#endif
#ifdef R_MAT
	struct __Rational     **rat;	/* Rational Element   */
#endif
} Element;

typedef struct __Matrix _Matrix, *Matrix;

struct __Matrix {	/* Matrix                  */
	char	*name;	/* Name of Matrix          */	
	int		type;	/* Data Type               */
	int		class;	/* Data Class              */
	int		rows;	/* Row Dimension           */
	int		cols;	/* Column Dimension        */
	Element elm;	/* Element                 */
	Matrix  prev;	/* Link to previous Matrix */
	Matrix  next;	/* Link to next Matrix     */
};

/*
  Data Type : {VAR, TMP, POLY, RAT}
  Data Class: {REAL, COMPLEX, POLYNOMIAL, RATIONAL}
*/

#define MAT_ERR_LENGTH 256

extern char *mat_err_src;			/* Error source code */

#ifdef P_MAT
#ifdef HAVE_SHORT_FILENAME
#include <poly.h>
#else
#include <polynomial.h>
#endif
#endif

#ifdef R_MAT
#include <rational.h>
#endif

/* ------------------------------------------------------------------------- */
void	MatInit(void);
void	MatFree(Matrix a);
void	MatFrees(Matrix a);
void	MatInstall(Matrix a);
void	MatDestroy(Matrix a);
void	MatUndef(Matrix a);
void	MatElementDestroy(Matrix a);
void	MatUndefs(Matrix a);
#ifdef HAVE_STDARG
void	MatMultiUndefs(int n, ...);
#else
void	MatMultiUndefs();
#endif
void	MatTmpUndef(void);
#ifdef MATX_RT
void	MatTmpUndefs(Matrix a);
#endif
void	MatObjectTmpUndef(void);

void	MatPrint(Matrix a);
void	MatPrintArray(Matrix a);
void	MatPrintIndex(Matrix a);
void	MatAllPrint(void);
void	MatError(char *func, char *mess, Matrix a);
void	MatError2(char *func, char *mess, Matrix a, Matrix b);
void	MatWarning(char *func, char *mess, Matrix a);
void	MatWarning2(char *func, char *mess, Matrix a, Matrix b);
void	MatErrorNotRealNorComplex(Matrix a, char *name);
void	MatErrorNotRealNorComplex2(Matrix a, Matrix b, char *name);
void	MatSwap(Matrix b, Matrix a);
void	MatSameSizeCheck(Matrix a, Matrix b, char *name);
void	MatSameClassCheck(Matrix a, Matrix b, char *name);
void	MatZeroSizeCheck(Matrix a, char *name);
void	MatZeroSizeCheck2(Matrix a, Matrix b, char *name);
void	MatNotRealCheck(Matrix a, char *name);
void	MatNotComplexCheck(Matrix a, char *name);
void	MatNotPolynomialCheck(Matrix a, char *name);
void	MatNotRationalCheck(Matrix a, char *name);
void	MatNonSquareCheck(Matrix a, char *name);
void	MatNonSquareCheck2(Matrix a, Matrix b, char *name);

int		MatGetRows(Matrix a);
int		MatGetCols(Matrix a);
int		MatLength(Matrix a);

Matrix	MatAssign(Matrix b, Matrix a);
Matrix	MatAssignOnly(Matrix b, Matrix a);
Matrix	MatChangeColumn(Matrix a, int i, int j);
Matrix	MatChangeRow(Matrix a, int i, int j);
Matrix	MatPermutate(Matrix a, int *piv, int rk, int left);
Matrix 	MatCopy(Matrix b, Matrix a);
Matrix	MatElementCopy(Matrix b, Matrix a);
Matrix 	MatElementChange(Matrix b, Matrix a);
Matrix 	MatMove(Matrix b, Matrix a);
Matrix 	MatDup(Matrix a);
Matrix	MatInput(char *name);
Matrix	MatFileRead(char *filename);
Matrix	MatFileWrite(Matrix a, char *filename);
Matrix	MatFileSave(Matrix a, char *filename, int append, int cr, char *cast);
Matrix	MatWrite(Matrix mm, FILE *fp, unsigned long mat_type);
Matrix	MatRead(Matrix ma, FILE *fp, unsigned long mat_type);
int		MatReadContent(Matrix ma, FILE *fp, MatrixData *data);
int		MatReadContentV5(Matrix ma, FILE *fp, MatrixData *data);
int		MatFwrite(FILE *fp, Matrix mm, char *type);
Matrix	MatFread(FILE *fp, int num, char *type, int flip);

Matrix	MatEdit(Matrix mat);
Matrix	MatEditComplex(Matrix mat);
Matrix	MatSetName(Matrix a, char *name);
Matrix	MatSetVar(Matrix a, char *var);
Matrix	MatSetType(Matrix a, int type);
Matrix	MatSetClass(Matrix a, int class);

Matrix	MatRequest(int size, int class);
Matrix	MatEigValDef(Matrix a);
Matrix	MatEigVecDef(Matrix a);
#ifdef HAVE_STDARG
Matrix	MatDiagDef(int n, ...);
#else
Matrix	MatDiagDef();
#endif
Matrix	MatVecToDiag(Matrix a);
Matrix	MatVecToDiag2(Matrix a, int k);
Matrix	MatDiagToVec(Matrix a);
Matrix	MatDiagToVec2(Matrix a, int k);
#ifdef HAVE_STDARG
Matrix	MatVander(int n, ...);
#else
Matrix	MatVander();
#endif
Matrix	MatMulDef(Matrix a, Matrix b);
Matrix	MatSameDef(Matrix a);
Matrix	MatSameZDef(Matrix a);
Matrix	MatSameClassDef(Matrix a, int m, int n);
Matrix	MatSameClassZDef(Matrix a, int m, int n);
Matrix	MatTransDef(Matrix a);
#ifdef HAVE_STDARG
Matrix	MatColumnVec(int n, ...);
Matrix	MatRowVec(int n, ...);
#else
Matrix	MatColumnVec();
Matrix	MatRowVec();
#endif
Matrix	MatColumnVector(Matrix a, int i);
Matrix	MatRowVector(Matrix a, int i);
#ifdef HAVE_STDARG
Matrix	MatBlockDiag(int n, ...);
#else
Matrix	MatBlockDiag();
#endif
Matrix	MatCompanion(Matrix a);
Matrix	MatCompanion2(Matrix a);
Matrix	MatNormalRand(int m, int n);
Matrix	MatUniformRand(int m, int n);

Matrix	MatSeries(double from, double to, double by);
Matrix	MatReshape(Matrix a, int column, int row);
Matrix	MatString2Mat(char str[]);
char	*MatMat2String(Matrix a);
Matrix	MatGetTime(void);
Matrix	mxStringCompareElem(mxString a, mxString b, char *op);

Matrix	MatAdd(Matrix a, Matrix b);
Matrix	MatAdd_double(Matrix a, double sc);
Matrix	MatAdd_Complex(Matrix a, Complex sc);
Matrix	MatAdd_Polynomial(Matrix a, Polynomial sc);
Matrix	MatAdd_Rational(Matrix a, Rational sc);
Matrix	MatSub(Matrix a, Matrix b);
Matrix	MatSub_double(Matrix a, double sc, int flag);
Matrix	MatSub_Complex(Matrix a, Complex sc, int flag);
Matrix	MatSub_Polynomial(Matrix a, Polynomial sc, int flag);
Matrix	MatSub_Rational(Matrix a, Rational sc, int flag);
Matrix	MatMul(Matrix a, Matrix b);
Matrix	MatMulElem(Matrix a, Matrix b);
Matrix	MatDivElem(Matrix a, Matrix b);
Matrix	MatInv(Matrix a, double tol);
Matrix	MatInvElem(Matrix a);
Matrix	MatPseudoInv(Matrix a, double tol);
Matrix	MatTrans(Matrix a);
Matrix	MatFlipLR(Matrix a);
Matrix	MatFlipUD(Matrix a);
Matrix	MatShiftLeft(Matrix a, int m);
Matrix	MatShiftRight(Matrix a, int m);
Matrix	MatShiftUp(Matrix a, int m);
Matrix	MatShiftDown(Matrix a, int m);
Matrix	MatRotateLeft(Matrix a, int m);
Matrix	MatRotateRight(Matrix a, int m);
Matrix	MatRotateUp(Matrix a, int m);
Matrix	MatRotateDown(Matrix a, int m);
Matrix	MatSort(Matrix a, Matrix idx, int row_col_all);
Matrix	MatNegate(Matrix a);
Matrix	MatIncrement(Matrix a);
Matrix	MatDecrement(Matrix a);
Matrix	MatSetZero(Matrix a);
Matrix	MatRoundToZero(Matrix a, double tol);
Matrix	MatExp(Matrix a);
Matrix	MatExpElem(Matrix a);
Matrix	MatConj(Matrix a);
Matrix	MatConjTrans(Matrix a);
Matrix	MatPow(Matrix a, int m);
Matrix	MatPowElem(Matrix a, int m);
Matrix	MatPowElemToReal(Matrix a, double dd);
Matrix	MatPowElemToComp(Matrix a, Complex cc);
Matrix	MatPowElemEach(Matrix a, Matrix b);
Matrix	MatRemElem(Matrix a, double dd);
Matrix	MatRemElemEach(Matrix a, Matrix b);

Matrix	MatApply(Matrix a, double (*func)());
Matrix	MatApplyPolyFunc(Matrix a, Polynomial poly);
Matrix	MatApplyRatFunc(Matrix a, Rational rat);
Matrix	MatAbsElem(Matrix a);
Matrix	MatArgElem(Matrix a);
Matrix	MatCeilElem(Matrix a);
Matrix	MatFloorElem(Matrix a);
Matrix	MatFixToZeroElem(Matrix a);
Matrix	MatRintElem(Matrix a);
Matrix	MatSinElem(Matrix a);
Matrix	MatAsinElem(Matrix a);
Matrix	MatSinhElem(Matrix a);
Matrix	MatAsinhElem(Matrix a);
Matrix	MatCosElem(Matrix a);
Matrix	MatAcosElem(Matrix a);
Matrix	MatCoshElem(Matrix a);
Matrix	MatAcoshElem(Matrix a);
Matrix	MatTanElem(Matrix a);
Matrix	MatAtanElem(Matrix a);
Matrix	MatAtan2Elem(Matrix a, Matrix b);
Matrix	MatBitAndElem(Matrix a, Matrix b);
Matrix	MatBitComplementElem(Matrix a);
Matrix	MatBitOrElem(Matrix a, Matrix b);
Matrix	MatBitLShiftElem(Matrix a, int ii);
Matrix	MatBitRShiftElem(Matrix a, int ii);
Matrix	MatBitXorElem(Matrix a, Matrix b);
Matrix	MatTanhElem(Matrix a);
Matrix	MatAtanhElem(Matrix a);
Matrix	MatLog(Matrix a);
Matrix	MatLogElem(Matrix a);
Matrix	MatLog10Elem(Matrix a);
Matrix	MatSgnElem(Matrix a);
Matrix	MatCompareElem(Matrix a, Matrix b, char *operator);
Matrix	MatCompareElemD(Matrix a, double data, char *operator);
Matrix	MatCompareElemC(Matrix a, Complex data, char *operator);
Matrix	MatCompareElemP(Matrix a, Polynomial data, char *operator);
Matrix	MatCompareElemR(Matrix a, Rational data, char *operator);
Matrix	MatNotElem(Matrix a);
Matrix	MatFiniteElem(Matrix a);
Matrix	MatNaNElem(Matrix a);
Matrix	MatInfElem(Matrix a);
Matrix	MatFindNonZeroElem(Matrix a);
Matrix	MatIndexOneElem(Matrix a);

Matrix	MatScale(Matrix a, double scale);
Matrix	MatScaleSelf(Matrix a, double scale);
Matrix	MatScaleC(Matrix a, Complex scale);

#ifdef P_MAT
Matrix	MatScaleP(Matrix	a, Polynomial scale);
Matrix	MatEval(Matrix a, double d);
Matrix	MatEvalC(Matrix a, Complex c);
Matrix	MatEvalP(Matrix a, Polynomial p);
Matrix	MatEvalM(Matrix a, Matrix mm);
Matrix	MatEvalMElem(Matrix a, Matrix mm);
#endif

#ifdef R_MAT
Matrix	MatScaleR(Matrix a, Rational scale);
Matrix	MatEvalR(Matrix a, Rational r);
#endif

Matrix	MatRealPart(Matrix a);
Matrix	MatImagPart(Matrix a);
Matrix	MatNumeElem(Matrix a);
Matrix	MatDenoElem(Matrix a);
Matrix	MatCatColumn(Matrix a, Matrix b);
Matrix	MatCatRow(Matrix a, Matrix b);
#ifdef HAVE_STDARG
Matrix	MatCatColumns(int n, ...);
Matrix	MatCatRows(int n, ...);
#else
Matrix	MatCatColumns();
Matrix	MatCatRows();
#endif
Matrix	MatCat4(Matrix a11, Matrix a12, Matrix a21, Matrix a22);
Matrix	MatCut(Matrix a, int sc, int sr, int ec, int er);
Matrix	MatPut(Matrix a, int sr, int sc, Matrix b);
Matrix	MatEnlarge(Matrix a, int m, int n);
Matrix	MatEnlargeClass(Matrix a, int m, int n, Matrix b);
Matrix	MatSetSubMatrix(Matrix a, Matrix rows, Matrix columns, Matrix b);
Matrix	MatSetRowVecs(Matrix a, Matrix rows, int from_c, Matrix b);
Matrix	MatSetColVecs(Matrix a, int from_r, Matrix columns, Matrix b);
Matrix	MatSetSubMatrix2(Matrix a, int from_r, int to_r, int by_r,
						 int from_c, int to_c, int by_c, Matrix b);
Matrix	MatSetRowVecs2(Matrix a, int from_r, int to_r, int by_r,
					   int from_c, Matrix b);
Matrix	MatSetColVecs2(Matrix a, int from_r, int from_c,
					   int to_c, int by_c, Matrix b);
Matrix	MatSetSubVec(Matrix a, int from_r, Matrix b);
Matrix	MatSetVecSubMatrix2(Matrix a, int from_r, int to_r,
							int by_r, Matrix b);
Matrix	MatSetVecSubMatrix(Matrix a, Matrix rows, Matrix b);
Matrix	MatGetSubMatrix(Matrix a, Matrix	rows, Matrix columns);
Matrix	MatGetSubMatrix2(Matrix a, int from_r, int to_r, int by_r,
						 int from_c, int to_c, int by_c);
Matrix	MatGetVecSubMatrix(Matrix a, Matrix rows);
Matrix	MatGetVecSubMatrix2(Matrix a, int from_r, int to_r, int by_r);
Matrix	MatSetBlockSubMatrix(Matrix a, Matrix rows, Matrix columns,
							 int pr, int pc, Matrix b);
Matrix	MatSetBlockRowVecs(Matrix a, Matrix rows, int from_c,
						   int pr, int pc, Matrix b);
Matrix	MatSetBlockColVecs(Matrix a, int from_r, Matrix columns,
						   int pr, int pc, Matrix b);
Matrix	MatPutBlock(Matrix a, int from_r, int from_c,
					int pr, int pc, Matrix b);
Matrix	MatGetBlockSubMatrix(Matrix a, Matrix rows, Matrix columns,
							 int pr, int pc);
Matrix	MatAreaCopy(Matrix a, int ar, int ac,
					Matrix b, int br1, int bc1, int br2, int bc2);
Matrix	MatRealAndImag(Matrix a, Matrix b);

Matrix	MatRealToComp(Matrix a);

#ifdef P_MAT
Matrix	MatRealToPoly(Matrix a);
Matrix	MatCompToPoly(Matrix a);
#endif

#ifdef R_MAT
Matrix	MatRealToRat(Matrix a);
Matrix	MatCompToRat(Matrix a);
Matrix	MatPolyToRat(Matrix a);
#endif

Matrix	MatVectorProduct(Matrix a, Matrix b);
Matrix	MatVectorSquare(Matrix a);
Matrix	MatSingVal(Matrix a);
Matrix	MatSingVec(Matrix a);
Matrix	MatSingValVec(Matrix a);
Matrix	MatSingLeftVec(Matrix a);
Matrix	MatSingRightVec(Matrix a);
Matrix	MatFunc(Matrix a, Complex (*func)(), char *name);
Matrix	MatSqrt(Matrix a);
Matrix	MatSqrtElem(Matrix a);
Matrix	MatEigVal(Matrix a);
Matrix	MatEigVec(Matrix a);
Matrix	MatEigValVec(Matrix a);
Matrix	MatGEigVal(Matrix a, Matrix b);
Matrix	MatGEigVec(Matrix a, Matrix b);
Matrix	MatGEigValVec(Matrix a, Matrix b);
Matrix	MatKernel(Matrix a, double tol);
Matrix	MatDerivative(Matrix a, int m);
Matrix	MatIntegral(Matrix a, int m);
Matrix	MatLowerShift(Matrix	a, int m);
Matrix	MatHigherShift(Matrix	a, int m);

Matrix	MatForSub(Matrix b, Matrix l, double tol);
Matrix	MatBackSub(Matrix b, Matrix u, double tol);
Matrix	MatLUSolve(Matrix a, Matrix b, double tol);
Matrix	MatLeastSquare(Matrix a, Matrix b, double tol);
Matrix	MatLinearEQ(Matrix a, Matrix b, double tol);
Matrix	MatLinearEQ2(Matrix a, Matrix b, double tol);
Matrix	MatFFT(Matrix a, int datanum, int row_col);
Matrix	MatIFFT(Matrix a, int datanum, int row_col);
Matrix	MatFrobNorms(Matrix a, int row_col);

Matrix	MatAll(Matrix a, int row_col);
Matrix	MatAny(Matrix a, int row_col);
Matrix	MatMax(Matrix a, int row_col);
Matrix	MatMin(Matrix a, int row_col);
Matrix	MatSum(Matrix a, int row_col);
Matrix	MatProd(Matrix a, int row_col);
Matrix	MatCumSum(Matrix a, int row_col);
Matrix	MatCumSumElem(Matrix a);
Matrix	MatCumProd(Matrix a, int row_col);
Matrix	MatCumProdElem(Matrix a);
Matrix	MatMean(Matrix a, int row_col);
Matrix	MatStdDev(Matrix a, int row_col);
Matrix	MatMaximum(Matrix a, Matrix *idx, int row_col);
Matrix	MatMinimum(Matrix a, Matrix *idx, int row_col);
double	MatMaxSingVal(Matrix a);
double	MatMinSingVal(Matrix a);

int		MatIsSingular(Matrix a, double tol);
int		MatIsNonSingular(Matrix a, double tol);
int		MatIsFullRank(Matrix a, double tol);
int		MatIsAnyZero(Matrix a);
int		MatRank(Matrix a, double tol);

int		MatIsPositive(Matrix a);
int		MatIsPositiveSemi(Matrix a);
int		MatIsNonPositive(Matrix a);
int		MatIsNegative(Matrix a);
int		MatIsNegativeSemi(Matrix a);
int		MatIsNonNegative(Matrix a);
int		MatIsZero(Matrix a);
int		MatIsNonZero(Matrix a);
int		MatIsEqual(Matrix a, Matrix b);
int		MatIsNotEqual(Matrix a, Matrix b);
int		MatIsRealValue(Matrix a);
int		MatIsComplexValue(Matrix a);

void	MatEig(Matrix a, Matrix *val, Matrix *vec);
void	MatGEig(Matrix a, Matrix b, Matrix *val, Matrix *vec);
void	MatHermitEig(Matrix a, Matrix *val, Matrix *vec);
void	MatSVD(Matrix a, Matrix *val, Matrix *lvec, Matrix *rvec);
void	MatLU(Matrix a, Matrix *l, Matrix *u, Matrix *p);
void	MatHessenberg(Matrix a, Matrix *h, Matrix *q);
void	MatSchur(Matrix a, Matrix *t, Matrix *u);
void	MatQR(Matrix a, Matrix *q, Matrix *r, Matrix *p, int pflag);
void	MatQZ(Matrix a, Matrix b, Matrix *aa, Matrix *bb,
			  Matrix *q, Matrix *z, Matrix *vec);
void	MatBalance(Matrix a, Matrix *d, Matrix *b);

#ifdef MAT_RUNGE
Matrix	MatRungeKutta4();
Matrix	MatRungeKutta4Link();
Matrix	MatRKF45();
Matrix	MatRKF45Link();
void	MatOde();
void	MatOde45();
void	MatOdeHybrid();
void	MatOde45Hybrid();
void	MatOdeStop(void);
/*
void	ode_int_link(Matrix u, double t, Matrix x);
*/

/*
Matrix	MatRungeKutta4(double t, Matrix x, Matrix (*diff)(), Matrix u,
					   double h, int void_flag);
Matrix	MatRungeKutta4Link(double t, Matrix x, Matrix (*diff)(),
						   Matrix (*link)(), double h, int void_flag);
Matrix	MatRKF45(double t, Matrix x, Matrix (*diff)(),
				 Matrix u, double h, int void_flag);
Matrix	MatRKF45Link(double t, Matrix x, Matrix (*diff)(),
					 Matrix (*link)(), double h, int void_flag);

void	MatOde(Matrix t_out, Matrix x_out, Matrix u_out, double t1, double t2,
			   Matrix x, Matrix (*diff)(), Matrix (*link)(), double eps_h,
			   double dtmin, double dtmax, double dtsav, int auto_step,
			   int void_flag);
void	MatOde45(Matrix t_out, Matrix x_out, Matrix u_out, double t1,
				 double t2, Matrix x, Matrix (*diff)(), Matrix (*link)(),
				 double eps_h, double dtmin, double dtmax, double dtsav,
				 int auto_step, int void_flag);
void	MatOdeHybrid(Matrix t_out, Matrix x_out, Matrix u_out, double t1,
					 double t2, double dt, Matrix x, Matrix (*diff)(),
					 Matrix (*link)(), double eps_h, double dtmin,
					 double dtmax, double dtsav, int auto_step, int void_flag);
void	MatOde45Hybrid(Matrix t_out, Matrix x_out, Matrix u_out, double t1,
					   double t2, double dt, Matrix x, Matrix (*diff)(),
					   Matrix (*link)(), double eps_h, double dtmin,
					   double dtmax, double dtsav, int auto_step,
*/
#endif

mxString mxStringGetSubString(mxString a, int from, int to, int by);
mxString mxStringGetSubString2(mxString a, Matrix idx);
mxString mxStringSetSubString(mxString a, int from, int to, int by, 
							  mxString b);
mxString mxStringSetSubString2(mxString a, Matrix idx, mxString b);

#include <re_mat.h>
#include <co_mat.h>

#ifdef P_MAT
#include <po_mat.h>
#endif

#ifdef R_MAT
#include <ra_mat.h>
#endif

#endif
