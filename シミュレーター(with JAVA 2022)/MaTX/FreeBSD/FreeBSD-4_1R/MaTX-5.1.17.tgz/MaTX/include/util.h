
/*
 *
 * Copyright (C) 1989, 1990, 1991 Masanobu Koga
 *            All Rights Reserved.
 *
 * No part of this software may be used, copied, modified, and distributed
 * in any form or by any means, electronic, mechanical, manual, optical or
 * otherwise, without prior permission of Masanobu Koga.
 *
 */

/*
  util.h : 

  $Author: koga $
  $Revision: 1.5 $
  $Date: 2000/11/23 04:13:47 $
  $Log: util.h,v $
  Revision 1.5  2000/11/23 04:13:47  koga
  *** empty log message ***

 * Revision 1.4  1994/06/21  13:21:43  koga
 * *** empty log message ***
 *
 * Revision 1.3  1992/03/25  12:20:17  koga
 * Optimization
 *
*/

#ifndef util_header
#define util_header

#include <datafile.h>

#ifdef MSC60
#pragma optimize( "t", off )
#endif

#ifdef MACINTOSH
#define MATX_RINT
#define MATX_ASINH
#define MATX_ACOSH
#define MATX_ATANH
#define MATX_LOG2
#define MATX_DRAND48
#endif

#ifdef LINUX
#define MATX_LOG2
#endif

#ifdef NEWS_OS_421
#define MATX_LOG2
#define MATX_DRAND48
#endif

#ifdef X68K
#define MATX_LOG2
#define MATX_RINT
#define MATX_DRAND48
#define MATX_ASINH
#define MATX_ACOSH
#define MATX_ATANH
#endif

#ifdef BSD44
#define MATX_LOG2
#define MATX_DRAND48
#endif

#ifdef NEWS
#define	MATX_LOG2
#define MATX_EXP10
#define MATX_DRAND48
#endif

#ifdef MIPS
#define MATX_LOG2
#define MATX_DRAND48
#endif

#ifdef BSD42
#define	MATX_LOG2
#define MATX_ASINH
#define MATX_ACOSH
#define MATX_ATANH
#define MATX_RINT
#endif

#ifdef SOLARIS
#define	MATX_LOG2
#endif

#ifdef IRIX
#define	MATX_LOG2
#endif

#ifdef SYSV
#define MATX_EXP10
#define MATX_LOG2
#define MATX_DRAND48
#define MATX_ASINH
#define MATX_ACOSH
#define MATX_ATANH
#endif

#ifdef TRC15
#define	MATX_LOG2
#define MATX_EXP10
#define MATX_DRAND48
#define MATX_ASINH
#define MATX_ACOSH
#define MATX_ATANH
#define MATX_RINT
#endif

#ifdef BRC20
#define	MATX_LOG2
#define MATX_DRAND48
#define MATX_ASINH
#define MATX_ACOSH
#define MATX_ATANH
#define MATX_RINT
#endif

#ifdef MSC40
#define	MATX_LOG2
#define MATX_EXP10
#define MATX_DRAND48
#define MATX_ASINH
#define MATX_ACOSH
#define MATX_ATANH
#define MATX_RINT
#endif

#ifdef MSC60
#define	MATX_LOG2
#define MATX_DRAND48
#define MATX_ASINH
#define MATX_ACOSH
#define MATX_ATANH
#define MATX_RINT
#endif

#ifdef VXWORKS
#define MATX_RAND
#define MATX_DRAND48
#define MATX_ASINH
#define MATX_ACOSH
#define MATX_ATANH
#define MATX_RINT
#define MATX_ATOI
#define MATX_ATOF
#endif

#ifdef WATCOM
#define MATX_RINT
#define MATX_DRAND48
#endif

#ifdef MSVC
#define MATX_RINT
#define MATX_ASINH
#define MATX_ACOSH
#define MATX_ATANH
#define MATX_LOG2
#define MATX_DRAND48
#endif

#ifdef BCC
#define MATX_RINT
#define MATX_ASINH
#define MATX_ACOSH
#define MATX_ATANH
#define MATX_LOG2
#define MATX_DRAND48
#endif

#ifdef __DJGPP__
#define MATX_RINT
#define MATX_DRAND48
#endif

#ifdef	EPS
#undef	EPS
#endif
#define EPS			MATX_EPS

#define MATX_EPS	matx_eps

#ifdef NaN
#undef NaN
#endif
#define	NaN			(get_nan())

#ifdef Inf
#undef Inf
#endif
#define	Inf			(get_infinity())

#ifndef HAVE_NO_PID
#define	PID			(getpid())
#else
#define	PID			0
#endif

#ifdef PI
#undef PI
#endif
#define PI			3.14159265358979323846

#ifndef max
#define max(a,b)	((a) > (b) ? (a) : (b))
#endif
#ifndef min
#define min(a,b)	((a) < (b) ? (a) : (b))
#endif

extern volatile double matx_eps;

void	*emalloc(unsigned int n);
void	*erealloc(char *ptr, unsigned int n);
void	efree(char *ptr);

void	matx_bell(void);
void	print_time(FILE *fp);

#ifdef MATX_EXP10
double	exp10(double d);
#endif
#ifdef MATX_LOG2
double	log2(double d);
#endif
#ifdef MATX_DRAND48
double	drand48(void);
#endif
double	randu(void);
double	randn(void);
#ifdef MATX_RINT
double	rint(double d);
#endif
double	factorial(double d);
int		int_factorial(int i);
#ifdef MATX_ASINH
double	asinh(double d);
#endif
#ifdef MATX_ACOSH
double	acosh(double d);
#endif
#ifdef MATX_ATANH
double	atanh(double d);
#endif
double	fix_to_zero(double d);
double	round_to_zero(double d, double tol);
double	get_infinity(void);
double	get_nan(void);

long	randu_seed(void);
long	randn_seed(void);
long	srandu(long seedval);
long	srandn(long seedval);

int		isFinite(double d);
int		isNaN(double d);
int		isInf(double d);
double	matxPower(double x, double y);
int		echo2(int sw);
void	echo2_die(int signo);
int		one_getch(void);
void	kbhit_init(void);
void	kbhit_term(void);
#ifndef HAVE_HBKIT
int		kbhit(void);
#endif

int		get_int(int d, int cr);
double	get_double(double d, int cr);
void	pause_sleep(char *mess, double sec);
char	*matx_itoa(int i);
char	*ftoa(double d);
double	real_sgn(double d);
int		int_sgn(int d);
int		IntegerFileSave(int a, char *filename, char *name, int append, int cr);
int		IntegerWrite(int in, FILE *fp, char *name);
int		IntegerRead(int *in, FILE *fp, char *name);
int		IntegerReadContent(int *in, FILE *fp, int flip);
int		IntegerInput(char *name);
int		IntegerEdit(int a, char *name);
void	RealPrint(double a, char *name);
char	*RealToString(double a, char *str, char *fmt);
int		RealFileSave(double a, char *filename, char *name, int append, int cr);
double	RealInput(char *name);
double	RealEdit(double a, char *name);
double	RealWrite(double rn, FILE *fp, char *name);
int		RealRead(double *rn, FILE *fp, char *name);
int		RealReadContent(double *dd, FILE *fp, int flip);
int		ReadDataHead(MatrixData *mx, FILE *fp, int *ver);
void	WriteDataHead(FILE *fp);
#ifdef HAVE_STDARG
int		aFilePrintf(char *filename, ...);
#else
int		aFilePrintf();
#endif
int		FileOpen(char *path, char *mode);
int		FileClose(int fd);
int		FileIsOpen(int fd);
void	FileFlush(int fd);
int		FileEOF(int fd);
#ifndef WATCOM
FILE	*FilePointer(int fd, int rw);
#endif
#ifdef HAVE_STDARG
int		FilePrintf(int fd, ...);
#else
int		FilePrintf();
#endif

int		FileAccess(char *file, char *mode);

#ifdef HAVE_PIPE
int		ProcessOpen(char *command);
int		ProcessClose(int fd);
#ifdef MSVC
int		WindowFind(char *name);
#endif
#endif

int		set_string(char *str);
char	*get_string(void);
char	*get_next_string(void);
int		sgetc(void);
int		unsgetc(void);

void	util_settimer(void);
double	util_gettimer(void);

void	util_disp_move(int y, int x);

unsigned long machine_type_get(void);
int		machine_endian_get(void);
int		machine_type_check(unsigned long type);
short	flip_short_byte_order(unsigned short *a);
long	flip_long_byte_order(unsigned long *a);		
double	flip_double_byte_order(double *a);
float	flip_float_byte_order(float *a);

int		system_matx(char *cmd_line);

#ifdef MATX_ATOF
double	atof(char *str);
#endif

double	matx_version(double v);

int matx_remove(char *path);
int matx_mkdir(char *path);

#endif

void mxUtilError(char *func, char *statement, int err_warn);

#ifdef HAVE_DOSFILE
void get_short_path_name(char *filename);
#endif

#ifdef HAVE_FPU_ROUND
void fpu_round_down(void);
void fpu_round_near(void);
void fpu_round_up(void);
void fpu_round_zero(void);
#endif
