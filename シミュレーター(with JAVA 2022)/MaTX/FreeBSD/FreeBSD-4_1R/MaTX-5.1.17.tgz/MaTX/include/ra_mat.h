Matrix	R_MatDef(char *name, int m, int n);
Matrix	R_MatNonNameDef(int m, int n);
Matrix	R_MatSameDef(Matrix a);
Matrix	R_MatTransDef(Matrix a);
Matrix	R_MatMulDef(Matrix a, Matrix b);
Matrix	R_MatIDef(int n);
Matrix	R_MatIDef2(int m, int n);
Matrix	R_MatOneDef(int m, int n);
Matrix	R_MatSameSizeFillDef(Matrix a, Rational r);
Matrix	R_MatFillDef(int m, int n, Rational r);
Matrix	R_MatZDef(int n);
Matrix	R_MatZDef2(int m, int n);
#ifdef HAVE_STDARG
Matrix	R_MatDiagDef(int n, ...);
#else
Matrix	R_MatDiagDef();
#endif
#ifdef HAVE_STDARG
Matrix	R_MatVander(int n, ...);
#else
Matrix	R_MatVander();
#endif

Matrix	R_MatCopy(Matrix b, Matrix a);
Matrix	R_MatEdit(Matrix a);
Matrix	R_MatInput(char *name);
Matrix	R_MatSetValue(Matrix a, int row, int column, Rational r);
Matrix	R_MatFillValue(Matrix a, Rational r);
Matrix	R_MatSetVecValue(Matrix a, int number, Rational r);
Matrix	R_MatSetVar(Matrix a, char *var);
Matrix	R_Mat_ChangeRow(Matrix a, int i, int j);
Matrix	R_Mat_ChangeColumn(Matrix a, int i, int j);
void	R_MatSwap(Matrix b, Matrix a);

Rational R_MatDeterm(Matrix a);
Rational R_MatScalarProduct(Matrix a, Matrix b);
Rational R_MatTrace(Matrix a);
Rational R_MatSumElem(Matrix a);
Rational R_MatProdElem(Matrix a);
Rational R_MatMeanElem(Matrix a);

Rational R_MatGetValue(Matrix a, int row, int column);
Rational R_MatGetValueOne(Matrix a, int row, int column);
Rational R_MatGetPtr(Matrix a, int row, int column);
Rational R_MatGetVecValue(Matrix a, int number);
Rational R_MatGetVecPtr(Matrix a, int number);

void	R_Mat_Print(Matrix a);

Matrix	R_MatRealPart(Matrix a);
Matrix	R_MatImagPart(Matrix a);
#ifdef HAVE_STDARG
Matrix	R_MatColumnVec(int n, ...);
Matrix	R_MatRowVec(int n, ...);
#else
Matrix	R_MatColumnVec();
Matrix	R_MatRowVec();
#endif

Matrix	R_Mat_Add(Matrix c, Matrix a, Matrix b);
Matrix	R_Mat_Add_double(Matrix c, Matrix a, double sc);
Matrix	R_Mat_Add_Complex(Matrix c, Matrix a, Complex sc);
Matrix	R_Mat_Add_Polynomial(Matrix c, Matrix a, Polynomial sc);
Matrix	R_Mat_Add_Rational(Matrix c, Matrix a, Rational sc);
Matrix	R_Mat_Sub(Matrix c, Matrix a, Matrix b);
Matrix	R_Mat_Sub_double(Matrix c, Matrix a, double sc, int flag);
Matrix	R_Mat_Sub_Complex(Matrix c, Matrix a, Complex sc, int flag);
Matrix	R_Mat_Sub_Polynomial(Matrix c, Matrix a, Polynomial sc, int flag);
Matrix	R_Mat_Sub_Rational(Matrix c, Matrix a, Rational sc, int flag);
Matrix	R_Mat_Mul(Matrix c, Matrix a, Matrix b);
Matrix	R_Mat_MulElem(Matrix c, Matrix a, Matrix b);
Matrix	R_Mat_DivElem(Matrix c, Matrix a, Matrix b);
Matrix	R_Mat_InvElem(Matrix b, Matrix a);
Matrix	R_Mat_Trans(Matrix b, Matrix a);
Matrix	R_Mat_FlipLR(Matrix b, Matrix a);
Matrix	R_Mat_FlipUD(Matrix b, Matrix a);
Matrix	R_Mat_ShiftLeft(Matrix b, Matrix a, int m);
Matrix	R_Mat_ShiftRight(Matrix b, Matrix a, int m);
Matrix	R_Mat_ShiftUp(Matrix b, Matrix a, int m);
Matrix	R_Mat_ShiftDown(Matrix b, Matrix a, int m);
Matrix	R_Mat_RotateLeft(Matrix b, Matrix a, int m);
Matrix	R_Mat_RotateRight(Matrix b, Matrix a, int m);
Matrix	R_Mat_RotateUp(Matrix b, Matrix a, int m);
Matrix	R_Mat_RotateDown(Matrix b, Matrix a, int m);
Matrix	R_Mat_Negate(Matrix b, Matrix a);
Matrix	R_Mat_SetZero(Matrix a);
Matrix	R_Mat_RoundToZero(Matrix b, Matrix a, double tol);
Matrix	R_Mat_Conj(Matrix b, Matrix a);
Matrix	R_Mat_ConjTrans(Matrix b, Matrix a);
Matrix	R_Mat_Pow(Matrix b, Matrix a, int m);
Matrix	R_Mat_PowElem(Matrix b, Matrix a, int m);
Matrix	R_Mat_PowElemEach(Matrix c, Matrix a, Matrix b);
Matrix	R_Mat_CompareElem(Matrix c, Matrix a, Matrix b, char *opt);
Matrix	R_Mat_Scale(Matrix b, Matrix a, double scale);
Matrix	R_Mat_ScaleSelf(Matrix a, double scale);
Matrix	R_Mat_ScaleC(Matrix b, Matrix a, Complex scale);
Matrix	R_Mat_ScaleP(Matrix b, Matrix a, Polynomial scale);
Matrix	R_Mat_ScaleR(Matrix b, Matrix a, Rational scale);
Matrix	R_Mat_Eval(Matrix b, Matrix a, double d);
Matrix	R_Mat_EvalC(Matrix b, Matrix a, Complex c);
Matrix	R_Mat_EvalP(Matrix b, Matrix a, Polynomial p);
Matrix	R_Mat_EvalR(Matrix b, Matrix a, Rational r);
Matrix	R_Mat_EvalM(Matrix c, Matrix a, Matrix b);
Matrix	R_Mat_EvalMElem(Matrix c, Matrix a, Matrix b);
Matrix	R_Mat_Apply(Matrix b, Matrix a, Rational (*func)());
Matrix	R_Mat_ApplyPolyFunc(Matrix b, Matrix a, Polynomial poly);
Matrix	R_Mat_ApplyRatFunc(Matrix b, Matrix a, Rational rat);
Matrix	R_Mat_Put(Matrix a, int sr, int sc, Matrix b);
Matrix	R_Mat_Cut(Matrix b, Matrix a, int sr, int sc, int er, int ec);
Matrix  R_Mat_GetSubMatrix(Matrix a, Matrix rows, Matrix columns, Matrix c);
Matrix  R_Mat_GetVecSubMatrix(Matrix a, Matrix cols, Matrix c);
Matrix	R_Mat_SetSubMatrix(Matrix a, Matrix rows, Matrix columns, Matrix c);
Matrix	R_Mat_SetVecSubMatrix(Matrix a, Matrix cols, Matrix c);
Matrix  R_Mat_GetBlockSubMatrix(Matrix a, Matrix rows, Matrix columns,
								int pr, int pc, Matrix c);
Matrix	R_Mat_SetBlockSubMatrix(Matrix a, Matrix rows, Matrix columns,
								int pr, int pc, Matrix c);
Matrix	R_Mat_AreaCopy(Matrix a, int ar, int ac,
					   Matrix b, int br1, int bc1, int br2, int bc2);
Matrix	R_Mat_RealPart(Matrix b, Matrix a);
Matrix	R_Mat_ImagPart(Matrix b, Matrix a);
Matrix	R_Mat_NumeElem(Matrix b, Matrix a);
Matrix	R_Mat_DenoElem(Matrix b, Matrix a);
Matrix	R_Mat_RealAndImag(Matrix c, Matrix a, Matrix b);
Matrix	R_Mat_RealToComp(Matrix b, Matrix a);
Matrix	R_Mat_RealToRat(Matrix b, Matrix a);
Matrix	R_Mat_CompToRat(Matrix b, Matrix a);
Matrix	R_Mat_PolyToRat(Matrix b, Matrix a);
Matrix	R_Mat_CatColumn(Matrix c, Matrix a, Matrix b);
Matrix	R_Mat_CatRow(Matrix c, Matrix a, Matrix b);
Matrix	R_Mat_VectorProduct(Matrix c, Matrix a, Matrix b);
Matrix	R_Mat_VectorSquare(Matrix c, Matrix a);
Matrix	R_Mat_Derivative(Matrix c, Matrix a, int m);
Matrix	R_Mat_LowerShift(Matrix c, Matrix a, int m);
Matrix	R_Mat_HigherShift(Matrix c, Matrix a, int m);
Matrix	R_Mat_Sum(Matrix b, Matrix a);
Matrix	R_Mat_Prod(Matrix b, Matrix a);
Matrix	R_Mat_CumSum(Matrix b, Matrix a);
Matrix	R_Mat_CumSumElem(Matrix b, Matrix a);
Matrix	R_Mat_CumProd(Matrix b, Matrix a);
Matrix	R_Mat_CumProdElem(Matrix b, Matrix a);
Matrix	R_Mat_Mean(Matrix b, Matrix a);
