
/* -*- MaTX -*-
 *
 *  NAME
 *      fir2() - FIR filter design using the window method - 
 *               arbitrary filter shape
 *
 *  SYNOPSIS
 *      b = fir2(nn, ff, aa)
 *         Matrix b;
 *         Integer nn;
 *         Matrix ff, aa;
 *
 *      b = fir2(nn, ff, aa, npt)
 *         Matrix b;
 *         Integer nn;
 *         Matrix ff, aa;
 *         Integer npt;
 *
 *      b = fir2(nn, ff, aa, npt, lap)
 *         Matrix b;
 *         Integer nn;
 *         Matrix ff, aa;
 *         Integer npt;
 *         Integer lap;
 *
 *      b = fir2(nn, ff, aa, npt, lap, wind)
 *         Matrix b;
 *         Integer nn;
 *         Matrix ff, aa;
 *         Integer npt;
 *         Integer lap;
 *         Array Wind;
 *
 *  DESCRIPTION
 *      fir2(N,F,M) designs an N-th order FIR digital filter with the
 *      frequency response specified by vectors F and M, and returns the
 *      filter coefficients in length N+1 vector B.  Vectors F and M specify
 *      the frequency and magnitude break;points for the filter such that
 *      gplot(F,M) would show a plot of the desired frequency response.
 *      The frequencies in F must be between 0.0 < F < 1.0, with 1.0
 *      corresponding to half the sample rate. They must be in increasing
 *      order and start with 0.0 and end with 1.0. 
 *
 *	    npt : number for interpolation
 *	    lap : the number of points for jumps in amplitude
 *
 *      By default fir2() uses a Hamming window.  Other available windows,
 *      including Boxcar, Hanning, Bartlett, Blackman, Kaiser and Chebwin
 *      can be specified with an optional trailing argument.  For example,
 *
 *      fir2(N,F,M,ntp,lap,bartlett(N+1)) uses a Bartlett window.
 *
 *      fir2(N,F,M,ntp,lap,chebwin(N+1,R)) uses a Chebyshev window.
 *
 *  SEE ALSO
 *      fir1(), butter(), cheby1(), cheby2(), yulewalk(), freqz() and filter().
 *
 */

Func Matrix fir2(nn, ff, aa, npt, lap, wind, ...)
	Integer nn;
	Matrix ff;
	Matrix aa;
	Integer npt;
	Integer lap;
	Array Wind;
{
	Matrix b,wind,j,inc;
	Integer i,ma,mf,n,na,nb,ne,nf,nint,nbrk,nn2;
	Array H,df,ht;

	error(nargchk(3, 6, nargs, "fir2"));

	nn = nn + 1;

	if (nargs > 3) {
		if (nargs == 4) {
			if (Integer(2^(log(npt)/log(2))) != npt) {
				// NPT is not an even power of two
				npt = Integer(2^ceil(log(npt)/log(2)));
			} 
			lap = Integer(fix(npt/25.0));
			wind = hamming(nn);
		} else if (nargs == 5) {
			if (Integer(2^(log(npt)/log(2))) != npt) {
				// NPT is not an even power of two
				npt = Integer(2^ceil(log(npt)/log(2)));
			} 
			wind = hamming(nn);
		} else {
			wind = Wind;
		}
	} else {
		npt = 512;
		wind = hamming(nn);
		lap = Integer(fix(npt/25.0));
	}

	if (nn != length(wind)) {
		error("fir2(): The specified window must be the same as the filter length\n");
	}
   
	{mf,nf} = size(ff);
	{ma,na} = size(aa);
	if (ma != mf || na != nf) {
		error("fir2(): You must specify the same number of frequencies and amplitudes\n");
	}
	nbrk = max(mf,nf);
	if (mf > nf) {
		ff = ff#;
		aa = aa#;
	}

	if (abs(ff(1)) > EPS || abs(ff(nbrk) - 1) > EPS) {
		error("fir2(): The first frequency must be 0 and the last 1\n");
	}

	// interpolate break;points onto large grid(1)
  
	H = Z(1,npt);
	nint = nbrk - 1;
	df = diff(ff#);
	if (any(df < 0.0)) {
		error("fir2(): Frequencies must be non-decreasing\n");
	}

	nb = 1;
	H(1) = aa(1);
	for (i = 1; i <= nint; i++) {
		if (df(i) == 0.0) {
			nb = nb - lap/2;
			ne = nb + lap;
		} else {
			ne = Integer(fix(ff(i+1)*npt));
		}
		if (nb < 0 || ne > npt) {
			error("fir2(): Too abrupt an amplitude change near } of frequency interval\n");
		}
		j = [nb:ne];
		if (nb == ne) {
			inc = [0];
		} else {
			inc = (j .- nb)/(ne - nb);
		}
		H(nb:ne) = inc*aa(i+1) + (1 .- inc)*aa(i);
		nb = ne + 1;
	}
	
	H = [H fliplr(H)];
	ht = ifft(H);
	nn2 = Integer(fix((nn + 1)/2.0));
	n = max(Cols(H), Rows(H));
	ne = nn2 - rem(nn,2);
	b = Re([ht((n-nn2+1):n), ht(1:ne)] .* wind);
	return b;
}
