
/*  -*- MaTX -*-
 *
 *  NAME
 *	    sig_demo() - Demonstrations of signal toolbox
 *
 *  SYNOPSIS
 *      sig_demo()
 *
 *  DESCRIPTION
 *      sig_demo() brings up a menu of the available demonstrations.
 *
 *  NOTE
 *      gnuplot is required to display graphs
 *      gnuplot is availabel by ftp from ftp.matx.org.
 *
 */

Func void sig_demo()
{
	Integer n;
	List demos;

	void fftdemo(),filtdemo();

	demos = {"Demo of Signal Toolbox",
			 "Spectral analysis using FFTs",
			 "Design recursive digital filters",
			 "E N D"};

	n = 1;
	while (1) {
		n = menu(demos, n);
		switch (n) {
		  case 1:
			fftdemo();
			break;
		  case 2:
			filtdemo();
			break;
		  default:
			return;
		}
		n++;
	}
}

/*  -*- MaTX -*-
 *
 *  NAME
 *      fftdemo() - Demonstration of fft() 
 *
 *  SYNOPSIS
 *      fftdemo()
 *
 */

Func void fftdemo()
{
	Integer win;
	Array Y, x, y, Pyy, f, t;

	win = mgplot_cur_win();

	clear;
	printf("\n");
	printf("This example shows the use of the FFT function for spectral\n");
	printf("analysis.  A common use of FFT's is to find the frequency\n");
	printf("components of a signal buried in a noisy time domain signal.\n");
	printf("\n");
	pause;

	printf("First we need to create some data.  Consider data sampled at\n");
	printf("1000 Hz. We start by forming a time axis for our data, running\n");
	printf("from t=0 until t=0.25 in steps of 1 millisecond:\n\n");
	printf("\tt = [0:0.001:0.25];\n");
	pause;
	t = [0:0.001:0.25];

	printf("\n");
	printf("Next we can form a signal containing 50 Hz and 120 Hz:\n\n");
	printf("\tx = sin(2*PI*50*t) + sin(2*PI*120*t);\n");
	pause;
	x = sin(2*PI*50*t) + sin(2*PI*120*t);

	printf("\n");
	printf("and add some random noise with a standard deviation of 2 to \n");
	printf("produce a noisy signal y:\n\n");
	printf("\ty = x + 2*randn(t);\n");
	pause;
	y = x + 2*randn(t);

	printf("\n");
	printf("Let's take a look at our noisy signal y by plotting it.\n\n");
	printf("\tmgplot_title(win,\"Noisy time domain signal\");\n");
	printf("\tmgplot(win,y(1:50));\n\n");
	pause;

	mgplot_reset(win);
	mgplot_title(win,"Noisy time domain signal");
	mgplot(win,y(1:50));

	printf("Clearly, it is difficult to identify the frequency components\n");
	printf("from looking at the original signal; that's why spectral\n");
	printf("analysis is so popular.\n\n");

	printf("Finding the discrete Fourier transform of the noisy signal y\n");
	printf("is easy; we just take the fast-Fourier transform (FFT) :\n\n");
	printf("\tY = fft(y,256);\n");
	pause;
	Y = fft(y,256);

	printf("\n");
	printf("The power spectral density, a measurement of the energy at\n");
	printf("various frequencies, is found with:\n\n");
	printf("\tPyy = Re(Y .* conj(Y));\n");
	pause;
	Pyy = Re(Y .* conj(Y));

	printf("\n");
	printf("To plot the power spectral density, we must first form a \n");
	printf("frequency axis:\n\n");
	printf("\tf = 1000*[0:127]/256;\n");
	pause;
	f = 1000*[0:127]/256;

	printf("\n");
	printf("which we do for the first 127 points. (The remainder of the 256\n");
	printf("points are symmetric.)  We can now plot the power spectral\n");
	printf("density:\n\n");
	printf("\tmgplot_title(win,\"Power spectral density\");\n");
	printf("\tmgplot_xlabel(win,\"Frequency (Hz)\");\n");
	printf("\tmgplot(win,f,Pyy(1:128));\n");
	pause;

	mgplot_reset(win);
	mgplot_title(win,"Power spectral density");
	mgplot_xlabel(win,"Frequency (Hz)");
	mgplot(win,f,Pyy(1:128));

	printf("\n");
	printf("Let's zoom in and plot only up to 200 Hz:\n\n");
	printf("\tmgplot_title(win,\"Power spectral density\");\n");
	printf("\tmgplot_xlabel(win,\"Frequency (Hz)\");\n");
	printf("\tmgplot(f(1:50),Pyy(1:50));\n");
	pause;

	mgplot_reset(win);
	mgplot_title(win,"Power spectral density");
	mgplot_xlabel(win,"Frequency (Hz)");
	mgplot(win,f(1:50),Pyy(1:50));
	mgplot_reset(win);
}


/*  -*- MaTX -*-
 *
 *  NAME
 *      filtdemo() - Demonstration of filter
 *
 *  SYNOPSIS
 *      filtdemo()
 *
 *  DESCRIPTION
 *      This example demonstrates the use of the yulewalk(), butter() and
 *      cheby1() functions to design bandpass filters.  A sampling rate
 *      of 1000 Hz is assumed.
 */

Func void filtdemo()
{
	Integer i,N,win,n;
	Real ripple,fs;
	Matrix f,fhz,ff,h,H,hb,hc,hh;
	Matrix Ab,Ac,Ah,Bb,Bc,Bh,hy;
	Matrix passband;

	win = mgplot_cur_win();

	clear;
	print "\n";
	print "The YULEWALK function allows you to specify a piecewise shape\n";
	print "for the desired frequency response magnitude.  YULEWALK then\n";
	print "finds an infinite-impulse response filter of the desired order\n";
	print "that fits the frequency response in a least-squares sense.\n";
	print "\n";
	print "We start by specifying the desired frequency response,\n";
	print "point-wise, with 1.0 corresponding to half the sample rate:\n";
	print "\n";
	print "\tf = [0.0 0.4 0.4 0.6 0.6 1.0];\n";
	print "\tH = [0.0 0.0 1.0 1.0 0.0 0.0];\n";
	print "\n";
	pause;

	f = [0.0 0.4 0.4 0.6 0.6 1.0];
	H = [0.0 0.0 1.0 1.0 0.0 0.0];

	clear;
	print "\n";
	print "Next we plot the desired frequency response to make sure it is\n";
	print "what we want.  To plot the frequency response, we can scale the\n";
	print "normalized frequency axis:\n";
	print "\n";
	print "\tfs = 1000;     // sampling rate\n";
	print "\tfhz = f*fs/2;\n";
	print "\n";
	print "Now we are ready to plot.\n\n";
	pause "Strike any key for plot.";

	fs = 1000;		// sampling rate
	fhz = f*fs/2;

	mgplot_reset(win);
	mgplot(win,fhz,H,{"Desired"});
	mgplot_title(win,"Desired Frequency Response");
	mgplot_xlabel(win,"Frequency (Hz)");
	mgplot_ylabel(win,"Magnitude");

	clear;
	print "\n";
	print "If the desired frequency response did not look right, \n";
	print "we would go back and change H. However, in this case\n";
	print "everything looks OK so we perform the design:\n";
	print "\n";
	print "\tN = 8;  // Order of the filter (number of poles and zeros).\n";
	print "\t{Bh,Ah} = yulewalk(N,f,H);\n";
	print "\n";

	print "Working, please wait";
	N = 8;  // Order of the filter (number of poles and zeros).
	{Bh,Ah} = yulewalk(N,f,H);
	print "\r";

	print "The design is complete and we can look";
	print " at the filter coefficients.\n\n";
	pause;

	clear;
	print "\n";
	print Ah,"\n",Bh,"\n";	// Here are the filter coefficients:
	pause;

	clear;
	print "\n";
	print "Of course it is impossible to know by looking at the\n";
	print "coefficients whether the design is good or bad. Let's compute\n";
	print "the frequency response of the filter:\n";
	print "\n";
	print "\tn = 256;\n";
	print "\t{hh} = freqz(Bh,Ah,n); // compute complex frequency response\n";
	print "\thy = abs(Array(hh));   // compute magnitude\n";
	print "\n";
	print "Now we can plot the frequency response magnitude\n";
	print "and compare it to the desired response:\n\n";
	pause "Strike any key for plot.";

	n = 256;
	{hh} = freqz(Bh,Ah,n); // compute complex frequency response
	hy = abs(Array(hh));   // compute magnitude

	ff = fs/(2*n) * [0:n-1];

	mgplot_reset(win);
	mgplot(win,fhz,H,{"Desired"});
	mgreplot(win,ff,hy,{"Designed"});
	mgplot_title(win,"Actual vs. Desired Frequency Response");
	mgplot_xlabel(win,"Frequency (Hz)");
	mgplot_ylabel(win,"Magnitude");

	clear;
	print "\n";
	print "Now let's design Butterworth and Chebyshev bandpass filters\n";
	print "with the same passband (defined between 0.0 and 1.0).\n";
	print "\n";
	print "\tN = 4;                 // Filter order\n";
	print "\tpassband = [0.4 0.6];  // Passband specification\n";
	print "\t{Bb,Ab} = butter(N, passband);\n";
	print "\n";
	print "\tripple = 0.1;          // Allowable ripple, in decibels\n";
	print "\t{Bc,Ac} = cheby1(N, ripple, passband);\n\n";

	print "Working, please wait";

	N = 4;                 // Filter order
	passband = [0.4 0.6];  // Passband specification
	{Bb,Ab} = butter(N, passband);

	ripple = 0.1;          // Allowable ripple, in decibels
	{Bc,Ac} = cheby1(N, ripple, passband);

	print "\r";

	print "Now find the frequency responses:\n";
	print "\n";
	print "\t{hb} = freqz(Bb,Ab,n);\n";
	print "\t{hc} = freqz(Bc,Ac,n);\n";
	print "\th = [[abs(Array(hh))][abs(Array(hb))][abs(Array(hc))]];\n";

	{hb} = freqz(Bb,Ab,n);
	{hc} = freqz(Bc,Ac,n);
	h = [[abs(Array(hh))][abs(Array(hb))][abs(Array(hc))]];

	print "\n";
	pause "Strike any key for plot.";

	mgplot_reset(win);
	mgplot(win,fhz,H,{"Desired"});
	mgreplot(win,ff,abs(Array(h)),{"YuleWalk","Butterworth","Chebyshev"});
	mgplot_title(win,"YuleWalk, Butterworth, Chebyshev filters");
	mgplot_xlabel(win,"Frequency (Hz)");
	mgplot_ylabel(win,"Magnitude");

	clear;
	print "\n";
	print "Often it is useful to look at the frequency response on\n";
	print "logarithmic (dB) scales.\n";
	print "\n";
	pause "Strike any key for plot.";

	mgplot_reset(win);
	mgplot(win,ff(2:n),20*log10(abs(Array(h(:,2:n)))),
		   {"YuleWalk","Butterworth","Chebyshev"});
	mgplot_title(win,"YuleWalk, Butterworth, Chebyshev filters");
	mgplot_xlabel(win,"Frequency (Hz)");
	mgplot_ylabel(win,"Mag. in dB");
	clear;
}

