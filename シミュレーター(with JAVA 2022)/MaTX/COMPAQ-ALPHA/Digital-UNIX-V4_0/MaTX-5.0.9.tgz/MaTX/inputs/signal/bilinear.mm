
/* -*- MaTX -*-
 *
 *  NAME
 *      bilinear() - Bilinear transformation
 *
 *  SYNOPSIS
 *      {Ad,Bd,Cd,Dd} = bilinear(A,B,C,D,fs)
 *         Matrix Ad,Bd,Cd,Dd;
 *         Matrix A,B,C,D;
 *         Real fs;
 *
 *      {Ad,Bd,Cd,Dd} = bilinear(A,B,C,D,fs,fp)
 *         Matrix Ad,Bd,Cd,Dd;
 *         Matrix A,B,C,D;
 *         Real fs;
 *         Real fp;
 *
 *  DESCRIPTION
 *      bilinear() converts the s-domain transfer function specified by
 *      A, B, C, and D to a z-transform discrete equivalent obtained from
 *      the bilinear transformation:
 *
 *        H(z) = H(s) |
 *                    | s = 2*Fs*(z-1)/(z+1)
 *
 *      fs is the sample frequency in Hz.
 *
 *      bilinear() accepts an optional additional input argument that
 *      specifies prewarping.  For example, bilinear(...,fp) applies
 *      prewarping before the bilinear transformation so that the 
 *      frequency responses before and after mapping match exactly at
 *      frequency point fp (match point fp is specified in Hz).
 *
 *  SEE ALSO
 *      c2d() and d2c()
 */

Func List bilinear(A, B, C, D, fs, fp, ...)
	Matrix A, B, C, D;
	Real fs, fp;
{
	Matrix Ad,Bd,Cd,Dd,T1,T2;
	Integer n;
	Real r,t;

	error(nargchk(5, 6, nargs, "bilinear"));
	
	// Prewarp
	if (nargs == 6) {
		fp = 2*PI*fp;
		fs = fp/tan(fp/fs/2)/2;
	}

	// Now do state-space version of bilinear transformation
	n = Rows(A);
	t = 1/fs;
	r = sqrt(t);
	T1 = I(n) + A*t/2;
	T2 = I(n) - A*t/2;
	Ad = T2\T1;
	Bd = t/r*(T2\B);
	Cd = r*C/T2;
	Dd = C/T2*B*t/2 + D;

	return {Ad,Bd,Cd,Dd};
}
