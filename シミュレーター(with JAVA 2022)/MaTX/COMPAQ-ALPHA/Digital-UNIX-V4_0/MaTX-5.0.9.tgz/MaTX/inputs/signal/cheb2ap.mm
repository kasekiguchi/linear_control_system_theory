
/* -*- MaTX -*-
 *
 *  NAME
 *      cheb2ap() - Chebyshev type II analog lowpass filter prototype
 *
 *  SYNOPSIS
 *      {z,p,k} = cheb2ap(n,rs)
 *         CoMatrix z,p;
 *         Matrix k;
 *         Integer n;
 *         Real rs;
 *
 *  DESCRIPTION
 *      cheb2ap() returns the zeros, poles, and gain of an n-th order
 *      normalized prototype type II Chebyshev analog lowpass filter with
 *      Rs decibels of ripple in the stopband.
 *      Type II Chebyshev filters are maximally flat in the passband.
 *
 *  SEE ALSO
 *      cheby2(), cheb2ord(), buttap() and cheb1ap().
 */

Func List cheb2ap(n, rs)
	Integer n;
	Real rs;
{
	Real mu,delta;
	CoMatrix z,p;
	Matrix k;
	Integer m;
	Complex j;
	Array t,i;

	j = (0,1);
	delta = 1/sqrt(10^(0.1*rs)-1);
	mu = asinh(1/delta)/n;
	if (rem(n,2)) {
		m = n - 1;
		z = j / cos(Array([[1:2:n-2], [n+2:2:2*n-1]])*PI/(2*n))';
	} else {
		m = n;
		z = j / cos([1:2:2*n-1]*PI/(2*n))';
	}

	// Organize zeros in complex pairs:
	i = [[1:m/2][m:-1:m/2+1]];
	z = z(reshape(i,length(i),1));

	t = [1:2:2*n-1];
	p = trans(exp(j*(PI*t/(2*n) + PI*t/2)));
	p = sinh(mu)*Re(p) + j*cosh(mu)*Im(p);
	p = p.~;
	k = Re(prod_row(-p)/prod_row(-z));

	return {z,p,k};
}
