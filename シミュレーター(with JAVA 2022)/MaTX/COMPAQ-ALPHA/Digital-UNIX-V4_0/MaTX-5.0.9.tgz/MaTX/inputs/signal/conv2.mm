
/* -*- MaTX -*-
 *
 *  NAME
 *      conv2() - Two dimensional convolution
 *
 *  SYNOPSIS
 *     c = conv2(a,b)
 *        Array c;
 *        Array a,b;
 *
 *  DESCRIPTION
 *      conv2() performs the 2-D convolution of matrices A and B. 
 *      If {ma,na} = size(A) and {mb,nb} = size(B), then 
 *      size(C) = {ma+mb-1,na+nb-1}. 
 *
 *	 SEE ALSO
 *      xcorr2(), conv(), xcorr() and deconv().
 */

Func Array conv2(a,b)
	Array a,b;
{
	Array c,apad,y;
	Integer i,k,ma,mb,na,nb,starta,startb,count;

	{ma,na} = size(a);
	{mb,nb} = size(b);

	apad = [[a][Z(mb-1,na)]];
	c = Z(ma+mb-1,na+nb-1);

	for (k = 1; k <= (na+nb-1); k++) {
		count = k*(k<min(na,nb)) + 
			min(na,nb)*(k >= min(na,nb))*(k <= max(na,nb)) +
			(na+nb-k)*(k > max(na,nb));

		starta = 1*(k <= nb) + (k-nb+1)*(k > nb);
		startb = k*(k <= nb) + nb*(k > nb);

		for (i = 0; i <= (count-1); i++) {
			{y} = filter(b(:,startb-i),1,apad(:,starta+i));
			c(:,k) = c(:,k) + y;
		}
	}
	return c;
}
