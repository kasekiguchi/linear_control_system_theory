
/* -*- MaTX -*-
 *
 *  NAME
 *      lp2hp() - Lowpass to highpass analog filter transformation
 *
 *  SYNOPSIS  
 *      {At,Bt,Ct,Dt} = lp2hp(A,B,C,D,wo)
 *          Matrix At,Bt,Ct,Dt;
 *          Matrix A,B,C,D;
 *          Real wo;
 *
 *  DESCRIPTION
 *      lp2hp() transforms the lowpass filter with unity cutoff frequency
 *      to a highpass filter with cutoff frequency wo. Filter is described
 *      in state-space form.
 *
 *  SEE ALSO
 *      lp2bp(), lp2bs() and lp2hp()
 */

Func List lp2hp(A,B,C,D,wo)
	Matrix A,B,C,D;
	Real wo;
{
	Matrix At,Bt,Ct,Dt;

	// Transform lowpass to highpass
	At =  wo*A~;
	Bt = -wo*(A\B);
	Ct = C/A;
	Dt = D - C/A*B;

	return {At,Bt,Ct,Dt};
}
