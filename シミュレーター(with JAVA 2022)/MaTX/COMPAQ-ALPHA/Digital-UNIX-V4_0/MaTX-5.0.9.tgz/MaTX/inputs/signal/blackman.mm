
/* -*- MaTX -*-
 *
 *  NAME
 *      blackman() - Blackman window
 *
 *  SYNOPSIS
 *      w = blackman(n)
 *         Matrix w;
 *         Integer n;
 *
 *  DESCRIPTION
 *      blackman() returns the N-point Blackman window
 *
 *  SEE ALSO
 *      bartlett() and boxcar()
 */

Func Array blackman(n)
	Integer n;
{
	Array nn, win;

	nn = [0:n-1]/(n-1);
	win = 0.42 .- 0.5*cos(2*PI*nn) + 0.08*cos(4*PI*nn);
	return win;
}
