
/*  -*- MaTX -*- 
 *
 *  NAME
 *      xcorr2() - Two-dimensional cross-correlation
 *
 *  SYNOPSIS
 *      c = xcorr2(a)
 *         Array c;
 *         Array a;
 *
 *      c = xcorr2(a, b)
 *         Array c;
 *         Array a;
 *         Array b;
 *
 *  DESCRIPTION
 *      xcorr2(A,B) computes the crosscorrelation of matrices A and B.
 *
 *      xcorr2(A) is the autocorrelation function.
 *
 *	SEE ALSO
 *      xcorr() and conv2().
 */

Func Array xcorr2(a, b_, ...)
	Array a, b_;
{
	Array b,c,cc,apad;
	Integer count,i,k,ma,mb,na,nb,starta,startb;

	error(nargchk(1, 2, nargs, "xcorr2"));
	
	if (nargs == 1) {
		b = a;
	} else {
		b = b_;
	}

	{ma,na} = size(a);
	{mb,nb} = size(b);
	b = conj(b(mb:-1:1,:));
	apad = [[a][Z(mb-1,na)]];
	c = Z(ma+mb-1,na+nb-1);

	for (k = 1; k <= (na+nb-1); k++) {
		count = k*(k<min(na,nb)) +
			min(na,nb)*(k>=min(na,nb))*(k<=max(na,nb)) +
			(na+nb-k)*(k>max(na,nb));
		
		starta = 1*(k<=nb) + (k-nb+1)*(k>nb);
		startb = (nb-k+1)*(k<=nb) + 1*(k>nb);

		for (i = 0; i <= (count-1); i++) {
			{cc} = filter(b(:,startb+i), [1], apad(:,starta+i)); 
			c(:,k) = c(:,k) + cc';
		}
	}

	return c;
}
