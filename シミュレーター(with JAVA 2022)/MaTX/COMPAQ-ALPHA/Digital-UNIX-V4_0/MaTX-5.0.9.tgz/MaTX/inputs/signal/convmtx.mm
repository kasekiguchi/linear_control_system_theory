
/* -*- MaTX -*-
 *
 *  NAME
 *      convmtx() - Convolution matrix
 *
 *  SYNOPSIS
 *      m = convmtx(cv,n)
 *         Array m;
 *         Array cv;
 *         Integer n;
 *
 *  DESCRIPTION
 *      convmtx() returns the convolution matrix for vector cv.
 *      If cv is a column vector and x is a column vector of length N,
 *      then convmtx(cv,N)*x is the same as conv(cv,x).
 *      If rv is a row vector and x is a row vector of length N,
 *      then x*convmtx(rv,N) is the same as conv(rv,x).
 *
 *	SEE ALSO
 *      conv().
 */

Func Array convmtx(v_,n)
	Array v_;
	Integer n;
{
	Array v,m;
	Integer mv,nv,lv,mn;

	{mv,nv} = size(v_);
	lv = max(mv,nv);
	v = makecolv(v_);                      // make v a column vector
	mn = lv + n - 1;                       // mn = number of rows of M
	                                       // n  = number of columns
	m = toeplitz([[v][Z(n-1,1)]],Z(n,1));
	if (mv < nv) {
		m = trans(m);
	}

	return m;
}
