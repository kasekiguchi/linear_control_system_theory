
/* -*- MaTX -*-
 *
 *  NAME
 *      butter() - Butterworth digital filter design
 *
 *  SYNOPSIS
 *      {Bp,Ap} = butter(n,Wn)
 *          Matrix Bp,Ap;
 *          Inteter n;
 *          Matrix Wn;
 *
 *      {Bp,Ap} = butter(n,Wn,ftype)
 *          Matrix Bp,Ap;
 *          Inteter n;
 *          Matrix Wn;
 *          Strint ftype;
 *
 *  DESCRIPTION
 *      butter() designs an n-th order lowpass digital Butterworth filter
 *      and returns the filter coefficients in length n+1 vectors Bp and Ap.
 *      The cut-off frequency Wn must be 0.0 < Wn < 1.0, with 1.0 
 *      corresponding to half the sample rate.
 *
 *      If Wn is a two-element vector, Wn = [w1 w2], butter() returns
 *      an order 2n bandpass filter with passband  w1 < w < w2.
 *
 *      butter(..., "high") designs a highpass filter.
 *      butter(..., "stop") is a bandstop filter if Wn = [w1 w2].
 *	
 *  SEE ALSO
 *       buttord(), cheby1(), cheby2(), freqz() and filter().
 *
 *  REFERENCES
 *       [1] T. W. Parks and C. S. Burrus, Digital Filter Design,
 *           John Wiley & Sons, 1987, chapter 7, section 7.3.3.
 */

Func List butter(n,Wn_,ftype, ...)
	Integer n;
	Matrix Wn_;
	String ftype;
{
	Integer btype;
	Real fs,Bw;
	Matrix k,u,Wn,A,B,C,D,Ap,Bp;
	CoMatrix z,p;

	error(nargchk(2, 3, nargs, "butter"));
	
	Wn = Wn_;

	btype = 1;
	if (nargs == 3) {
		btype = 3;
	}
	if (length(Wn) == 2) {
		btype = btype + 1;
	}

	// Get analog, pre-warped frequencies
	fs = 2.0;
	u = 2*fs*tan(PI*Array(Wn)/fs);

	// Convert to low-pass prototype estimate
	switch (btype) {
	  case 1:	// lowpass
		Wn = u;
		break;
	  case 2:	// bandpass
		Bw = u(2) - u(1);
		Wn = [sqrt(u(1)*u(2))];	// center frequency
		break;
	  case 3:	// highpass
		Wn = u;
		break;
	  case 4:	// bandstop
		Bw = u(2) - u(1);
		Wn = [sqrt(u(1)*u(2))];	// center frequency
		break;
	}

	// Get n-th order Butterworth analog lowpass prototype
	{z,p,k} = buttap(n);

	// Transform to state-space
	{A,B,C,D} = zp2ss(z,p,k);

	// Transform to lowpass, bandpass, highpass, or bandstop of desired Wn
	switch (btype) {
	  case 1:	// Lowpass
		{A,B,C,D} = lp2lp(A,B,C,D,Wn(1));
		break;
	  case 2:	// Bandpass
		{A,B,C,D} = lp2bp(A,B,C,D,Wn(1),Bw);
		break;
	  case 3:	// Highpass
		{A,B,C,D} = lp2hp(A,B,C,D,Wn(1));
		break;
	  case 4:	// Bandstop
		{A,B,C,D} = lp2bs(A,B,C,D,Wn(1),Bw);
		break;
	}

	 // Use Bilinear transformation to find discrete equivalent:
	{A,B,C,D} = bilinear(A,B,C,D,fs);
	{Bp,Ap} = ss2tf(A,B,C,D,1);

	return {Bp,Ap};
}
