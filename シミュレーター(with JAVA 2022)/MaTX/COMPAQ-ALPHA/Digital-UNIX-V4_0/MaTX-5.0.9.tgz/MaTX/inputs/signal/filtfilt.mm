
/* -*- MaTX -*-
 *
 *  NAME
 *      filtfilt() - Zero-phase forward and reverse digital filtering
 *
 *  SYNOPSIS
 *      y = filtfilt(b,a,x)
 *         Matrix y;
 *         Matrix b, a;
 *         Matrix x;
 *
 *  DESCRIPTION
 *      filtfilt() Zero-phase forward and reverse digital filtering.
 *      Y = filtfilt(B, A, X) filters the data in vector X with the
 *      filter described by vectors A and B to create the filtered
 *      data Y.  The filter is described by the difference equation:
 *
 *      y(n) = b(1)*x(n) + b(2)*x(n-1) + ... + b(nb+1)*x(n-nb)
 *                       - a(2)*y(n-1) - ... - a(na+1)*y(n-na)
 *
 *      After filtering in the forward direction, the filtered
 *      sequence is then reversed and run back through the filter.
 *      The resulting sequence has precisely zero-phase distortion
 *      and double the filter order.  Care is taken to minimize
 *      startup and ending transients by matching initial conditions.
 *
 *      The length of the input x must be more than three times
 *      the filter order, defined as max(length(b)-1,length(a)-1).
 *
 *  SEE ALSO
 *      filter()
 */

Func Matrix filtfilt(b_, a_, x_)
	Matrix b_;
	Matrix a_;
	Matrix x_;
{
	Matrix a,b,x,y,zi;
	Integer len,m,n,na,nb,nfact,nfilt;

	b = b_;
	a = a_;
	x = x_;

    if (isempty(b) || isempty(a) || isempty(x)) {
        y = [];
        return y;
    }

    {m,n} = size(x);
    if (n > 1 && m > 1) {
        error("filtfilt(): Only works for vector input.\n");
    }
    if (m == 1) {
        x = makecolv(x); // convert row to column
    }
    len = Rows(x);       // length of input
    b = makerowv(b);
    a = makerowv(a);
    nb = length(b);
    na = length(a);
    nfilt = max(nb,na);

    nfact = 3*(nfilt-1);  // length of edge transients

    if (len <= nfact) { // input data too short!
        error("filtfilt(): Data must have length more than 3 times filter order.\n");
    }

	/*
	 * Set up filter's initial conditions to remove dc offset
	 * problems at the beginning and end of the sequence
	 */
	// zero-pad if necessary
    if (nb < nfilt) {
		b(nfilt) = 0;
	}
    if (na < nfilt) {
		a(nfilt) = 0;
	}
	zi = (I(nfilt-1) - [-a(2:nfilt)', [[I(nfilt-2)][Z(1,nfilt-2)]]]) \ 
		(b(2:nfilt)' - a(2:nfilt)'*b(1));

	/*
	 * Extrapolate beginning and end of data sequence using a "reflection
	 * method".  Slopes of original and extrapolated sequences match at
	 * the end points.
	 * This reduces end effects.
	 */
    y = [[2*x(1) .- x((nfact+1):-1:2)        ]
		 [   x                               ]
		 [2*x(len) .- x((len-1):-1:len-nfact)]];

	// filter, reverse data, filter again, and reverse data again
    {y} = filter(b,a,y,zi*y(1));
    y = y(length(y):-1:1);
    {y} = filter(b,a,y,zi*y(1));
    y = y(length(y):-1:1);

	// remove extrapolated pieces of y
    y(Index([[1:nfact], [(len+nfact) .+ [1:nfact]]])) = [];

	// convert back to row if necessary
    if (m == 1) {
        y = y';
    }

	return y;
}
