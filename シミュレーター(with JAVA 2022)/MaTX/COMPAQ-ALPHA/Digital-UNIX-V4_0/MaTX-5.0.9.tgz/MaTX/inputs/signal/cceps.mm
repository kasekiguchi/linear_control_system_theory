
/*  -*- MaTX -*-
 *
 *  NAME
 *      cceps() - Complex cepstrum
 *
 *  SYNOPSIS
 *      xhat = cceps(x)
 *         Array xhat;
 *         Array x;
 *
 *  DESCRIPTION
 *      cceps() returns the complex cepstrum of the sequence x.
 *
 *	SEE ALSO
 *       rceps(), hilbert() and fft().
 *
 */

Func Array cceps(x)
	Array x;
{
	Array xhat;
	CoArray h, logh;

	Array rcunwrap();

	h = fft(x);
	logh = log(abs(h)) + (0,1)*rcunwrap(angle(h));
	xhat = Re(ifft(logh));
	return xhat;
}

/* -*- MaTX -*-
 *
 *  NAME
 *      rcunwrap() - Phase unwrap utility used by cceps()
 *
 *  SYNOPSIS
 *     y = rcunwrap(x)
 *        Array y;
 *        Array x;
 *
 *  DESCRIPTION
 *   	 rcunwrap(X) unwraps the phase and removes phase corresponding
 *   	 to integer lag.
 *
 *  SEE ALSO
 *      unwrap(), cceps().
 */

Func Array rcunwrap(x)
	Array x;
{
	Array y;
	Integer n,nh;

	n = max(Cols(x), Rows(x));
	y = unwrap(x);
	nh = Integer(fix((n+1)/2.0));
	y = y - PI*fix(y(nh+1)/PI)*[0:(n-1)]/(nh+1);
	
	return y;
}

