
/*  -*- MaTX -*-
 *
 *  NAME
 *      comb() - Plot discrete sequence data
 *
 *  SYNOPSIS
 *      comb(x,y)
 *       Array x, y;
 *
 *      comb(x,y,linetype)
 *       Array x, y;
 *       Integer linetype;
 *
 *  DESCRIPTION
 *      comb(y) plots the data sequence y as stems from the x-axis
 *      terminated with circles for the data value.
 *
 *      comb(x,y) plots the data sequence y at the values specfied in x.
 *      There is an optional final string argument to specify a line-type
 *      for the stems of the data sequence.  
 */

Func void comb(x_, y_, linetype,...)
	Array x_, y_;
	Integer linetype;
{
	Array x, y, xx, yy;
	Integer n,win;

	error(nargchk(2, 3, nargs, "comb"));

	n = length(x_);
	if (nargs == 1) {
		y = makerowv(x_);
		x = [1:n];
		linetype = 1;
	} else if (nargs == 2) {
		y = makerowv(y_);
		x = makerowv(x_);
		linetype = 1;
	} else if (nargs == 3) {
		y = makerowv(y_);
		x = makerowv(x_);
	}

	xx = [[x][x]];
	yy = [[Z(1,n)][y]];

	win = mgplot_cur_win();
	mgplot(win,x,y,{""});
 	mgreplot(win,xx,yy,{"",""});
}

