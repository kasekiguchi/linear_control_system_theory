
/* -*- MaTX -*_
 *
 *  NAME
 *      chebwin() - Chebyshev window with R decibels of ripple
 *
 *  SYNOPSIS
 *      win = chebwin(nf, ripple)
 *         Array win;
 *         Integer nf;
 *         Real ripple;
 *
 *  DESCRIPTION
 *      chebwin() returns the N-point Chebyshev window with R decibels
 *      of ripple.  N must be odd.  If N is even, an odd N+1 length window
 *      is returned.
 *
 *  SEE ALSO
 *      blackman(), boxcar() and hamming()
 */

Func Array chebwin(nf, ripple)
	Integer nf;
	Real ripple;
{
	Integer odd,n,nm,xn,xn2;
	Real dp,c1,c2,df,x0,alpha,beta;
	Array xi,f,x,x1,x2,tmp1,tmp2,win;
	CoArray p;
	Complex j;
	Index idx1,idx2;

	dp = 10^(-ripple/20);
	odd = rem(nf,2);

	if (odd == 0) {
		warning("chebwin(): N must be odd - N is being increased by 1.\n");
		odd = 1;
		nf = nf + 1;
	}

	n = Integer(fix((nf + 1)/2.0));
	nm = Integer(fix(nf/2.0 + 1));
	xn = nf - 1;
	c1 = acosh((1 + dp)/dp);
	c2 = cosh(c1/xn);
	df = acos(1/c2)/PI;
	x0 = (3 - cos(2*PI*df))/(1 + cos(2*PI*df));
	alpha = (1 + x0)/2;
	beta = (x0 - 1)/2;
	xn2 = xn/2;
	xi = [0:nf-1];
	f = xi/nf;
	x = alpha*cos(2*PI*f) .+ beta;
	j = (0,1);
	tmp1 = abs(x) > 1;
	tmp2 = abs(x) <= 1;
	idx1 = find(tmp1);
	idx2 = find(tmp2);
	x1 = x;
	x2 = x;
	x1(idx2) = ONE(1,length(idx2));
	x2(idx1) = Z(1,length(idx1));
	
	p = dp*(tmp1*(cosh(xn2*acosh(x1))) + tmp2*cos(xn2*acos(x2)))
		+ j*Array(Z(1,nf));

	if (odd == 0) {
		p = Re(p)*exp(-j*PI*f);
		p(nm+1:nf) = -p(nm+1:nf);
	}
	
	if (Integer(2^(log(Cols(p))/log(2))) == Cols(p)) {
		win = Re(fft(p));
	} else {
		win = Re(DFT(p));
	}
	win = win(1:n)/win(1);
	win = [win(n:-1:odd+1), win];
	return win;
}
