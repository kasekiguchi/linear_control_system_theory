
/*  -*- MaTX -*-
 *
 *  NAME
 *      specplot() - Plot the output of the spectrum function
 *
 *  SYNOPSIS
 *      specplot(P)
 *         Array P;
 *
 *      specplot(P,Fs)
 *         Array P;
 *         Real Fs;
 *
 *  DESCRIPTION
 *      specplot() uses P, the output of spectrum(), and Fs, the
 *      sample frequency, to successively plot:
 *
 *   		Pxx        : X Power Spectral Density & confidence.
 *   		Pyy        : Y Power Spectral Density & confidence.
 *   		abs(Txy)   : Transfer Function Magnitude.
 *   		angle(Txy) : Transfer Function Phase.
 *   		Cxy        : Coherence Function.
 *
 *   	The 95% confidence intervals are displayed on the power
 *   	spectral density curves.
 *
 *   	specplot(P) uses normalized frequency, Fs = 2, so that 1.0 on
 *   	the frequency axis is half the sample rate (the Nyquist 
 *   	frequency).
 *
 */

Func void specplot(P,Fs,...)
	Array P;
	Real Fs;
{
	Integer m, n, win;
	Array f,c;

	error(nargchk(1, 2, nargs, "specplot"));

	{n,m} = size(P);
	if (nargs < 2) {
		Fs = 1.0;
	}
	f = [1:n-1]/n*Fs/2;

	if (m == 2) {
		c = [P(2:n,1)+P(2:n,2), P(2:n,1)-P(2:n,2)];
	} else {
		c = [P(2:n,1)+P(2:n,6), P(2:n,1)-P(2:n,6)];
	}
	c = c .* (c > 0.0);

	win = mgplot_cur_win();
	mgplot_semilogy(win,f,P(2:n,1));
	mgreplot_semilogy(win,f,c(:,1));
	mgreplot_semilogy(win,f,c(:,2));
	mgplot_title(win, "Pxx - X Power Spectral Density");
	mgplot_xlabel(win, "Frequency");

	if (m == 2) {
		return;
	}

	pause;

	c = [P(2:n,2)+P(2:n,7), P(2:n,2)-P(2:n,7)];
	c = c .* (c > 0);

	mgplot_semilogy(win,f,P(2:n,2));
	mgreplot_semilogy(win,f,c(:,1));
	mgreplot_semilogy(win,f,c(:,2));
	mgplot_title(win,"Pyy - Y Power Spectral Density");
	mgplot_xlabel(win,"Frequency");
	pause;

	mgplot_semilogy(win,f,abs(P(2:n,4)));
	mgplot_title(win,"Txy - Transfer function magnitude");
	mgplot_xlabel(win,"Frequency");
	pause;

	mgplot(f,180/PI*angle(P(2:n,4)));
	mgplot_title("Txy - Transfer function phase");
	mgplot_xlabel("Frequency");
	mgplot_ylabel("Degrees");
	pause;

	mgplot(win,f,abs(P(2:n,5)));
	mgplot_title(win,"Cxy - Coherence");
	mgplot_xlabel(win,"Frequency");
	pause;
}
