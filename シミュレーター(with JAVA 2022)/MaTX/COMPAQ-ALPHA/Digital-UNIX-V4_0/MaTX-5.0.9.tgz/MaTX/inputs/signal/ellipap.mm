
/*  -*- MaTX -*-
 *
 *  NAME
 *      ellipap() - Elliptic analog lowpass filter prototype
 *
 *  SYNOPSIS
 *      {z,p,k} = ellipap(n,rp,rs)
  *         CoMatrix z,p;
 *          Matrix k;
 *          Integer n;
 *          Real rp, rs;
 *
 *  DESCRIPTION
 *      ellipap() returns the zeros, poles, and gain of an N-th order
 *      normalized prototype elliptic analog lowpass filter with Rp decibels
 *      of ripple in the passband and a stopband Rs decibels down.
 *
 */

Real ellipap_global_variable2, ellipap_global_variable3;

Func List ellipap(n, rp, rs)
	Integer n;
	Real rp, rs;
{
	Matrix k,s,c,d,capk1,j,sv,cv,dv,M,r,v0,capk;
	CoMatrix p,z;
	Integer ij,jj,pm,pn;
	Complex i;
	Index ip,is,pp;
	Real epsilon,k1,k1p,m,m1,mp,krat,ws,wp;

	Real kratio(), vratio();

	epsilon = sqrt(10^(0.1*rp)-1);    // rp, dB of passband ripple
	k1 = epsilon/sqrt(10^(0.1*rs)-1); // rs, dB of stopband ripple
	k1p = sqrt(1-k1^2);
	wp = 1;	// passband edge - normalized

	if (abs(1-k1p^2) < EPS) {
		krat = 0;
	} else {
		capk1 = ellipk(1, [k1^2,k1p^2]);
		krat = n*capk1(1)/capk1(2);
		// krat = K(k)/K#(k) -- need to find relevant k
	}

	/*
	 * Put krat into ellipap_global_variable2, so kratio() can access it
	 * try to find m, elliptic parameter, so that K(m)/K'(m) = krat -- K,
	 * complete elliptic integral of first kind
	 */
	ellipap_global_variable2 = krat;
	{M} = fmins(kratio, [0.5]);
	m = M(1);

	capk = ellipk(1,[m]);
	ws = wp/sqrt(m); // stopband edge (=> transition band is ws-wp in width)
	m1 = 1 - m;
	i = (0,1);

	// Find zeros; they are purely imaginary and paired in complex conjugates
	j = [(1-rem(n,2)):2:n-1];
	{ij,jj} = size(j);

	// s is Jacobi elliptic function sn(u)
	{s,c,d} = ellipj(j*capk(1)/n, m*ONE(ij,jj));
	is = find(abs(Array(s)) > EPS);
	z = (sqrt(m)*s(is)).~;
	z = i*makecolv(z);	// make column vector
	z = [[z][conj(z)]];
	// Order the zeros for convenience later on
	z = cplxpair(z);

	/*
	 * poles; one purely real if n is odd - the remainder are complex
	 * conjugate pairs put 1/epsilon, mp into global variables for 
	 * calculating v0
	 */
	ellipap_global_variable2 = 1/epsilon;
	mp = k1p^2;
	ellipap_global_variable3 = mp;

	/*
	 * calculate v0, a "fundamental" parameter for the poles related
	 * to inverse sc function . I.e. find r so sn(r)/cn(r) = 1/epsilon
	 * for the given parameter mp
	 */
	{r} = fmins(vratio, ellipk(1,[1-m]));

	v0 = capk*r/(n*capk1(1));
	{sv,cv,dv} = ellipj(v0, [1-m]);
	p = -(c.*d*sv(1)*cv(1) + i*s*dv(1)) ./ (1 .- (d*sv(1)).^2);
	p = makecolv(p);   // make column vector

	// check to see if there is a real pole
	if (rem(n,2)) {
		ip = find(abs(Array(Im(p))) < EPS*norm(p));
		{pm,pn} = size(p);
		pp = [1:pm];
		pp(ip) = Index([]);
		if ( ! isempty(p(pp))) {
			p = [[p][conj(p(pp))]];
		}
	} else {
		if ( ! isempty(conj(p))) {
			p = [[p][conj(p)]];
		}
	}
	p = cplxpair(p);	// order poles for later use

	// gain
	k = [Re(prod(-p)/prod(-z))];
	if (! rem(n,2)) {	// n is even order so patch gain
		k = k/sqrt((1 + epsilon^2));
	}
	return {z,p,k};
}


/*  -*- MaTX -*-
 *
 *  NAME
 *      kratio() - Utility function for use with ellip()
 *
 *  SYNOPSIS
 *      a = kratio(m)
 *         Real a;
 *         Matrix m;
 *
 *  DESCRIPTION
 *      kratio() is a function used to calculate the zeros of an
 *      elliptic filter.  It is used with fmins() to find a
 *      parameter m satisfying ellipk(m)/ellipk(1-m) = krat.
 */

Func Real kratio(m_)
	Matrix m_;
{
	Integer ri;
	Real a,krat,r;
	Matrix can,k,m;

	m = m_;

	/*
	 * global_variable is used to pass in global information,
	 * krat, the requested value for K/K', and eps.
	 */
	krat = ellipap_global_variable2;

	/*
	 * To ensure we don't call ellipk(1,1) which is Inf on non-ieee
	 * machines and that we only call with positive m.
	 */
	m = [min(1.0,max(m(1),0.0))];

	if (abs(m(1)) > EPS && abs(m(1)) + EPS < 1.0) {
		k = ellipk(1,[m(1),1-m(1)]);
		r = k(1)/k(2) - krat;
	} else if (abs(m(1)) <= EPS) { // m == 0
		r = -krat;
	} else {	// m==1 => r == Inf, but can't for non-ieee machines
		r = 1e20;
	}
	a = abs(r);
	return a;
}


/*  -*- MaTX -*-
 *
 *  NAME
 *      vratio() - Utility function for use with ellip()
 *
 *  SYNOPSIS
 *      v = vratio(u)
 *         Real v;
 *         Matrix u;
 *
 *  DESCRIPTION
 *      vratio() is a function used to calculate the poles of an elliptic
 *      filter.  It finds a u so sn(u)/cn(u) = 1/epsilon, with parameter mp.
 */

Func Real vratio(u)
	Matrix u;
{
	Real v,ineps,mp;
	Matrix c,s;

	/*
	 * global_variable is used for passing in global information 
     * - 1/epsilon, the value s/c should attain with parameter mp.
	 */

	mp = ellipap_global_variable3;
	ineps = ellipap_global_variable2;
	{s,c} = ellipj(u,[mp]);
	v = abs(ineps - [s./c](1));
	return v;
}
