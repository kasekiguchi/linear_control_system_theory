
/*  -*- MaTX -*-
 *
 *  NAME
 *      interp() - Resample data at a higher rate using lowpass interpolation
 *
 *  SYNOPSIS
 *      {odata,b} = interp(idata,r)
 *          Array odata;
 *          Matrix b;
 *          Array idata;
 *          Integer r;
 *
 *      {odata,b} = interp(idata,r,l)
 *          Array odata;
 *          Matrix b;
 *          Array idata;
 *          Integer r;
 *          Integer l;
 *
 *      {odata,b} = interp(idata,r,l,alpha)
 *          Array odata;
 *          Matrix b;
 *          Array idata;
 *          Integer r;
 *          Integer l;
 *          Real alpha;
 *
 *  DESCRIPTION
 *      interp(X,R) resamples the sequence in vector X at R times
 *      the original sample rate.  The resulting resampled vector Y is
 *      R times longer, length(Y) = R*length(X).
 *
 *      A symmetric filter, B, allows the original data to pass through
 *      unchanged and interpolates between so that the mean square error
 *      between them and their ideal values is minimized.
 *
 *      interp(X,R,L,ALPHA) allows specification of arguments
 *      L and ALPHA which otherwise default to 4 and .5 respectively.
 *      2*L is the number of original sample values used to perform the
 *      interpolation.  Ideally L should be less than or equal to 10.
 *      The length of B is 2*L*R+1. The signal is assumed to be band
 *      limited with cutoff frequency 0 < ALPHA <= 1.0. 
 *
 *      interp(X,R,L,ALPHA) returns the coefficients of the
 *      interpolation filter B.
 *
 *  SEE ALSO
 *      decimate().
 *
 */

Func List interp(idata,r,l,alpha, ...)
	Matrix idata;
	Integer r;
	Integer l;
	Real alpha;
{
	Integer m,n,nn;
	Matrix X,XX,am,ap,b,d,h,s1,x,y,s2,s2p,od,odata,zi,zf;

	error(nargchk(2, 4, nargs, "interp"));
	
	if (nargs < 3) {
		l = 4;
	}
	if (nargs < 4) {
		alpha = 0.5;
	}
	if (l < 1 || r < 1 || alpha <= 0.0 || alpha > 1.0) {
		error("interp(): Input parameters are out of range.\n");
	}
	if (2*l+1 > length(idata)) {
		printf("Length of data sequence must be at least %d 10\n", 2*l+1);
		error("interp(): You either need more data or a shorter filter (L).");
	}

	/*
	 * ALL occurrences of sin()/() are using the sinc function for the
	 * autocorrelation for the input data.  They should all be changed 
	 * consistently if they are changed at all.
	 */

	// Calculate AP and AM matrices for inversion
	s1 = toeplitz([0:l-1]) .+ EPS;
	s2 = hankel([2*l-1:-1:l]);
	s2p = hankel([[1:l-1], [0]]);
	s2 = s2 .+ EPS + s2p(l:-1:1,l:-1:1);
	s1 = sin(alpha*PI*Array(s1))/(alpha*PI*Array(s1));
	s2 = sin(alpha*PI*Array(s2))/(alpha*PI*Array(s2));
	ap = s1 + s2;
	am = s1 - s2;
	ap = ap~;
	am = am~;

	// Now calculate D based on inv(AM) and inv(AP)
	d = Z(2*l,l);
	d(1:2:2*l-1,:) = ap + am;
	d(2:2:2*l,:) = ap - am;

	// Set up arrays to calculate interpolating filter B
	x = [0:r-1]/r;
	y = Z(2*l,1);
	y(1:2:2*l-1) = [l:-1:1];
	y(2:2:2*l) = [l-1:-1:0];
	X = ONE(2*l,1);
	X(1:2:2*l-1) = -ONE(l,1);
	XX = EPS .+ y*ONE(1,r) + X*x;
	y = X + y .+ EPS;
	h = 0.5*d#*Matrix(sin(PI*alpha*Array(XX))/(alpha*PI*Array(XX)));
	b = Z(2*l*r+1,1);
	b(1:l*r) = h#;
	b(l*r+1) = [0.5*d(:,l)#*Matrix(sin(PI*alpha*Array(y))/(PI*alpha*Array(y)))](1);
	b(l*r+2:2*l*r+1) = b(l*r:-1:1);

	// Use the filter B to perform the interpolation
	{m,n} = size(idata);
	nn = max(m,n);
	if (nn == m) {
		odata = Z(r*nn,1);
	} else {
		odata = Z(1,r*nn);
	}
	odata(1:r:nn*r) = idata;

	/*
	 * Filter a fabricated section of data first (match initial values
	 * and frst derivatives by rotating the first data points by 180 
	 * degrees) to get guess of good initial conditions. Filter length 
	 * is 2*l*r+1 so need that many points; can't duplicate first point 
	 * orguarantee a zero slope at beginning of sequence.
	 */
	od = Z(2*l*r,1);
	od(1:r:(2*l*r)) = 2*idata(1) .- idata((2*l+1):-1:2);
	{od,zi} = filter(b,[1],od);
	{odata,zf} = filter(b,[1],odata,Matrix(zi));
	odata(1:(nn-l)*r) = odata(l*r+1:nn*r);

	/*
	 * Make sure right hand points of data have been correctly interpolated
	 * and get rid of transients by again matching end values and derivatives
	 * of the original data
	 */
	if (nn == m) {
		od = Z(2*l*r,1);
	} else {
		od = Z(1,2*l*r);
	}
	od(1:r:(2*l)*r) = 2*idata(nn) .- idata((nn-1):-1:(nn-2*l));
	{od} = filter(b,[1],od,Matrix(zf));
	odata(nn*r-l*r+1:nn*r) = od(1:l*r);
	return {odata,b};
}
