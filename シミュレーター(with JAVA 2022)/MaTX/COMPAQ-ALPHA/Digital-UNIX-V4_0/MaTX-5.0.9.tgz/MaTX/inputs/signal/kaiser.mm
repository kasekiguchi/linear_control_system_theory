
/*  -*- MaTX -*-
 *
 *  NAME
 *      kaiser() - BETA-valued N-point Kaiser window
 *
 *  SYNOPSIS
 *      win = kaiser(nw,beta)
 *         Array win;
 *         Integer nw;
 *         Real beta;
 *
 *  DESCRIPTION
 *      kaiser() returns the BETA-valued N-point Kaiser window.
 *
 *  SEE ALSO
 *      blakman() and boxcar()
 */

Func Array kaiser(nw,beta)
	Integer nw;
	Real beta;
{
	Array win,xi,bes;
	Integer odd,xind,n;
	Complex j;

	j = (0,1);
	bes = abs(besseln(0, [j*beta]));
	odd = rem(nw,2);
	xind = (nw-1)^2;
	n = Integer(fix((nw+1)/2.0));
	xi = [0:n-1] .+ 0.5*(1-odd);
	xi = 4*xi^2;
	win = bessel(0.0, j*(beta*sqrt(1 .- xi/xind)))/bes(1);
	win = abs(Array([win(n:-1:odd+1), win]));
	return win;
}
