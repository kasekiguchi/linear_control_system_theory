
/* -*- MaTX -*-
 *
 *  NAME
 *      filtic() - Make initial conditions for filter() function
 *
 *  SYNOPSIS
 *     vinit = filtic(b,a,ypast)
 *        Matrix vinit;
 *        Matrix b,a;
 *        Array ypast;
 *
 *     vinit = filtic(b,a,ypast,xpast)
 *        Matrix vinit;
 *        Matrix b,a;
 *        Array ypast;
 *        Array xpast;
 *
 *  DESCRIPTION
 *       filtic() converts past values of x[n] & y[n] into initial conditions
 *       for the state variables v_i[n] needed in the transposed direct
 *       form II filter structure.  filtic() assumes that x[n] = 0 in 
 *       the past.  The vector of  past inputs & outputs stored as:
 *
 *            xpast = [ x[-1] x[-2] x[-3] ... x[-nb] ]
 *            ypast = [ y[-1] y[-2] y[-3] ... y[-na] ]
 *
 *      If not enough past values are given, then zeropad x[n] or y[n]
 *      as needed.
 *
 */

Func Matrix filtic(b, a, ypast_, xpast_, ...)
	Matrix  b, a;
	Array ypast_, xpast_;
{
	Matrix vinit,vx;
	Integer Lx,Ly,na,nb,m;
	Array xpast, ypast, y;
	
	error(nargchk(3, 4, nargs, "filtic"));

	if (nargs == 3) {
		xpast_ = [0];   // this is the zero input condition
	}

	xpast = xpast_;
	ypast = ypast_;

	na = length(a);
	nb = length(b);
	m = max(na,nb) - 1;
	if (m < 1) {
		vinit = [];
		return vinit;
	}

	Lx = length(xpast);
	Ly = length(ypast);

	if (Lx < nb-1) {
		xpast(nb-1) = 0;
    }   // zero pad
	if (Ly < na-1) {
		ypast(na-1) = 0;
    }
	vinit = Z(1,m);
	vx = vinit;

	// use filter() to do convolution
	if (na-1 > 0) {
		{y} = filter(-a(na:-1:2)/a(1), [1], ypast(1:na-1));
		vinit(na-1:-1:1) = y;
	}
	if (nb-1 > 0) {
		{y} = filter(b(nb:-1:2)/a(1), [1], xpast(1:nb-1));
		vx(nb-1:-1:1) = y;
	}
	vinit = vinit + vx;
	return vinit;
}
