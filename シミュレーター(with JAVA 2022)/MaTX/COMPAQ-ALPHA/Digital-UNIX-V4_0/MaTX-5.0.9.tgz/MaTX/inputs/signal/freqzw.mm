
/* -*- MaTX -*-
 *
 *  NAME
 *      freqzw() - Z-transform digital filter frequency response
 *
 *  SYNOPSIS
 *      {h, w} = freqzw(b, a, w)
 *         CoArray h;
 *         Array w;
 *         Matrix b, a;
 *         Array w;
 *
 *      {h, w} = freqzw(b, a, w, opt)
 *         CoArray h;
 *         Array w;
 *         Matrix b, a;
 *         Array w;
 *
 *  DESCRIPTION
 *      freqzw() returns the complex frequency response vector G, 
 *      at frequencies designated in vector w of the filter b/a:
 *                                -1                -nb 
 *         jw   B(z)   b(1) + b(2)z + .... + b(nb+1)z
 *       H(e) = ---- = ----------------------------
 *   	                       -1                -na
 *              A(z)    1   + a(2)z + .... + a(na+1)z
 *
 *      given numerator and denominator coefficients in vectors b and a.
 *      To plot magnitude and phase of a filter:
 *
 *       {h,w} = freqzw(b,a,w);
 *       mag = abs(h); 
 *       phase = angle(h);
 *       mgplot_semilogx(1,w,mag);
 *       mgplot_semilogx(2,w,phase)
 *
 *  SEE ALSO
 *      yulewalk(), filter(), fft(), invfreqz(), and freqs().
 */

Func List freqzw(b_, a_, w, opt, ...)
	Matrix b_, a_;
	Array w;
	String opt;
{
	Matrix a, b;
	CoArray h,ejw;
	Complex j;
	Integer na,nb,nn,s,n;

	error(nargchk(3, 4, nargs, "freqzw"));
	
	j = (0,1);

	a = makerowv(a_);
	b = makerowv(b_);
	na = max(Cols(a), Rows(a));
	nb = max(Cols(b), Rows(b));
	nn = max(Cols(w), Rows(w));
	s = 2;
	if (nargs == 4) {
		s = 1;
	}

	n = nn;

	a = [a Z(1,nb-na)];  // Make sure a and b have the same length
	b = [b Z(1,na-nb)];
	ejw = exp(j*w);
	if (version() == 4) {
		h = eval(Polynomial(fliplr(b)),ejw) / eval(Polynomial(fliplr(a)),ejw);
	} else {
		h = eval(Polynomial(b),ejw) / eval(Polynomial(a),ejw);
	}
	return {h, w};
}
