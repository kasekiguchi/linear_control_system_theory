
/*  -*- MaTX -*-
 *
 *  NAME
 *      triang() - N-point triangular window
 *
 *  SYNOPSIS
 *      win = triang(n)
 *         Array win;
 *         Integer n;
 *
 *  DESCRIPTION
 *      triang() returns the N-point triangular window.
 *
 *  SEE ALSO
 *      blackman() and boxcar()
 */

Func Array triang(n)
	Integer n;
{
	Array win;

	if (rem(n,2)) {
		// Odd length sequence
		win = 2*[1:(n+1)/2]/(n+1);
		win = [win, win((n-1)/2:-1:1)];
	} else {
		// Even length sequence
		win = (2*[1:(n+1)/2] .- 1)/n;
		win = [win, win(n/2:-1:1)];
	}

	return win;
}
