
/* -*- MaTX -*-
 *
 *  NAME
 *      square() - Square wave generation
 *
 *  SYNOPSIS
 *      s = square(t)
 *         Array s;
 *         Array t;
 *
 *      s = square(t, duty)
 *         Array s;
 *         Array t;
 *         Real duty;
 *
 *  DESCRIPTION
 *      square(t) generates a square wave with period 2*Pi for the
 *      elements of time vector t.  square(t) is like sin(t), only
 *      it creates a square wave with peaks of +1 to -1 instead of
 *      a sine wave.
 *   
 *      square(t,duty) generates a square wave with specified duty
 *      cycle. The duty cycle, duty, is the percent of the period
 *      in which the signal is positive.
 *
 *      For example, generate a 30 Hz square wave:
 *
 *        t = [0:0.001:2.5];
 *        y = square(2*PI*30*t);
 *        gplot(t,y)
 */

Func Array square(t, duty, ...)
	Array t;
	Real duty;
{
	Array s,tmp,nodd,neg;
	Real w0;

	error(nargchk(1, 2, nargs, "square"));
	
	// If no duty specified, make duty cycle 50%.
	if (nargs < 2) {
		duty = 50.0;
	}

	// Compute normalized frequency for break;ing up the interval (0,2*PI)
	w0 = 2*PI*duty/100;

	// Compute values of t normalized to (-2*PI,2*PI)
	tmp = rem(t,2*PI);

	// Assign 0 values to normalized t between (0,w0) and (-2*PI,w0-2*PI),
	// 1 elsewhere
	nodd = (tmp > w0) || (tmp < w0 - 2*PI);

	// Vector with 1s where t < 0, 0s for t >= 0
	neg = (t < 0);

	// The actual square wave computation
	s = 2*rem(neg+nodd+ONE(t),2) .- 1;

	return s;
}
