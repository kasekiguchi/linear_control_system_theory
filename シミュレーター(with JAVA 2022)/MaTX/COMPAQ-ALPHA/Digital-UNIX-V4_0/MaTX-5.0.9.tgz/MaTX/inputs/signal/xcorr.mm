
/*  -*- MaTX -*-
 *
 *  NAME
 *      xcorr() - Cross-correlation function estimates
 *
 *  SYNOPSIS
 *      c = xcorr(a, b)
 *         Array c;
 *         Array a,b;
 *
 *      c = xcorr(a, b, option)
 *         Array c;
 *         Array a,b;
 *         String option;
 *
 *  DESCRIPTION
 *      xcorr(A,B), where A and B are length M vectors, returns the
 *      length 2*M-1 cross-correlation sequence in a column vector.
 *
 *      xcorr(A), when A is a vector, is the auto-correlation sequence.
 *      xcorr(A), when A is an M-by-N matrix, is a large matrix with
 *      2*M-1 rows whose N^2 columns contain the cross-correlation
 *      sequences for all combinations of the columns of A.
 *      The zeroth lag of the output correlation is in the middle of the 
 *      sequence, at element or row M.
 *      By default, xcorr() computes a raw correlation with no normalization.
 *
 *      xcorr(A,"biased") or xcorr(A,B,"biased") returns the "biased"
 *      estimate of the cross-correlation function.  The biased estimate
 *      scales the raw cross-correlation by 1/M.
 *
 *      xcorr(...,"unbiased") returns the "unbiased" estimate of the
 *      cross-correlation function.  The unbiased estimate scales the raw
 *      correlation by 1/(M-abs(k)), where k is the index into the result.
 *
 *      xcorr(...,"coeff") normalizes the sequence so that the
 *      correlations at zero lag are identically 1.0.
 *
 *	SEE ALSO
 *      xcov(), corrcoef(), conv() and xcorr2().
 *
 */

Func Array xcorr(a_, b_, option, ...)
	Array a_, b_;
	String option;
{
	Array a,b,c,cc;
	Integer B_i,am,an,i,j,m,mr,n,na,nb,nc,nopt,nr,nsq,onearray;
	Integer ar,ac,br,bc,col, colaux;
	Matrix atmpi,cdiv;
	Index ci,cj,cii,cjj;

	error(nargchk(1, 3, nargs, "xcorr"));

	a = a_;
	if (1 < nargs) {
		b = b_;
	}

	onearray = 1;
	if (nargs == 1) {
		option = "none";
		if (min(Cols(a), Rows(a)) == 1) { // a is a vector
			a = [makecolv(a) makecolv(a)];
		} else {
			onearray = 0;
		}
	} else if (nargs == 2) {
		if (min(Cols(a), Rows(a)) != 1 && min(Cols(b), Rows(b)) != 1) {
			error("xcorr(): You may only specify 2 vector arrays.\n");
		}
		option = "none";
		onearray = 2;
	} else {
		if (max(Cols(a), Rows(a)) != max(Cols(b), Rows(b)) &&
			option != "none") {
			error("xcorr(): OPTION must be none for different length vectors A and B");
		}
		onearray = 2;
	}

	// check validity of option
	if (option == "none") {
		nopt = 0;
	} else if (option == "coeff") {
		nopt = 1;
	} else if (option == "biased") {
		nopt = 2;
	} else if (option == "unbiased") {
		nopt = 3;
	} else {
		error("xcorr(): Unknown OPTION\n");
	}

	if (onearray == 2) {
		{ar,ac} = size(a);
		{br,bc} = size(b);
		na = max(ar,ac);
		nb = max(br,bc);
		if (na > nb) {
			b(na) = 0;
		} else if (na < nb) {
			a(nb) = 0;
		}
		a = [makecolv(a) makecolv(b)];
	}
	{nr, nc} = size(a);
	nsq = nc^2;
	mr = 2 * nr - 1;
	c = Z(mr,nsq);
	ci = Z(1,nsq);
	cj = ci;
	for (i = 1; i <= nc; i++) {
		atmpi = conj(a(nr:-1:1,i));
		if (length(atmpi) < mr) {
			atmpi = [[atmpi][Z(mr-length(atmpi),1)]];
		} else {
			atmpi(mr) = 0;
		}
		for (j = 1; j <= i; j++) {
			col = (i-1)*nc + j;
			colaux = (j-1)*nc + i;
			{cc} = filter(a(:,j),[1],Array(atmpi));
			c(:,colaux) = cc';
			ci(col) = i;
			cj(col) = j;
			ci(colaux) = j;
			cj(colaux) = i;
			if (i != j) {
				c(:,col) = conj(c(mr:-1:1,colaux));
			}
		}
	}
	if (nopt == 1) {
		// return normalized by sqrt of each autocorrelation at 0 lag
		// do column arithmetic to get correct autocorrelations
		cii = 1 .+ (ci .- 1)*(nc+1);
		cjj = 1 .+ (cj .- 1)*(nc+1);
		cdiv = ONE(mr,1)*Matrix(sqrt(Array(c(nr,cii).*c(nr,cjj))));
		c = c ./ Array(cdiv);
	} else if (nopt == 2) {
		// biased result i.e. divide by nr for each element
		c = c / nr;
	} else if (nopt == 3) {
		// unbiased result, i.e. divide by nr-abs(lag)
		c = c ./ Array([[1:nr], [(nr-1):-1:1]]' * ONE(1,nsq));
	}
	if (onearray == 1) {
		c = c(:,1);            // just want the autocorrelation
		{am, an} = size(a);
		if (am == 1) {
			c = c#;
		}
	} else if (onearray == 2) { // produce only cross-correlation
		c = c(:,2);
		if (ar == 1) {
			c = c#;
		}
	}

	return c;
}
