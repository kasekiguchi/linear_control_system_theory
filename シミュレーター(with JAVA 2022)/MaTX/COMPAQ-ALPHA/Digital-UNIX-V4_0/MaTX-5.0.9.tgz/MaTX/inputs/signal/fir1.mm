
/* -*- MaTX -*-
 *
 *  NAME
 *      fir1() - FIR filter design using the window method
 *
 *  SYNOPSIS
 *      b = fir1(N,Wn)
 *         Matrix b;
 *         Integer N;
 *         Matrix Wn;
 *               
 *      b = fir1(N,Wn,Ftype)
 *         Matrix b;
 *         Integer N;
 *         Matrix Wn;
 *         String Ftype;
 *               
 *      b = fir1(N,Wn,Ftype,Wind)
 *         Matrix b;
 *         Integer N;
 *         Matrix Wn;
 *         String Ftype;
 *         Array Wind;
 *               
 *  DESCRIPTION
 *      fir1(N,Wn) designs an N'th order lowpass FIR digital filter
 *      and returns the filter coefficients in length N+1 vector B.
 *      The cut-off frequency Wn must be between 0 < Wn < 1.0, with 1.0 
 *      corresponding to half the sample rate.
 *
 *      If Wn is a two-element vector, Wn = [W1 W2], fir1() returns an
 *      order N bandpass filter with passband  W1 < W < W2.
 *
 *      fir1(..., "high") designs a highpass filter.
 *      fir1(..., "stop") is a bandstop filter if Wn = [W1 W2].
 *      For highpass and bandstop filters, N must be even.
 *	
 *      By default fir1() uses a Hamming window.  Other available windows,
 *      including Boxcar, Hanning, Bartlett, Blackman, Kaiser and Chebwin
 *      can be specified with an optional trailing argument. For example,
 *
 *      fir1(N,Wn,"",bartlett(N+1)) uses a Bartlett window.
 *
 *      fir1(N,Wn,"high",chebwin(N+1,R)) uses a Chebyshev window.
 *
 *  SEE ALSO
 *      fir2(), butter(), cheby1(), cheby2(), yulewalk(),
 *      freqz() and filter().
 *
 */

Func Matrix fir1(N,Wn,Ftype,Wind, ...)
	Integer N;
	Matrix Wn;
	String Ftype;
	Array Wind;
{
	Matrix b,wind;
	Integer Btype,i1,nw,odd,nhlf;
	Real c1,att,fh,fl,gain;
	Array xn,c,c3;

	error(nargchk(2, 4, nargs, "fir1"));

	nw = 0;
	if (nargs == 3) {
		nw = 0;
	} else if (nargs == 4) {
		nw = length(Wind);
	} else {
		Ftype = "";
	}

	Btype = 1;
	if (nargs > 2 && length(Ftype) > 0) {
		Btype = 3;
	}
	if (length(Wn) == 2) {
		Btype = Btype + 1;
	}

	N = N + 1;
	odd = rem(N, 2);
	if (Btype == 3 || Btype == 4) {
		if ( ! odd) {
			print "For highpass and bandstop filters, order must be even.\n";
			print "Order is being increased by 1.\n";
			N = N + 1;
			odd = 1;
		}
	}
	if (nw != 0 && nw != N) {
		error("fir1(): The window length must be the same as the filter length.\n");
	}
	if (nw > 0) {
		wind = Wind;
	} else { // replace the following with the default window of your choice.
		wind = hamming(N);
	}

	/*
	 * To use Chebyshev window, you must specify ripple
	 * ripple = 60;
	 * wind = chebwin(N, ripple);
	 *
	 * to use Kaiser window, beta must be supplied
	 * att = 60; // dB of attenuation desired in sidelobe
	 * beta = .1102*(att-8.7);
	 * wind = kaiser(N,beta);
	 */

	fl = Wn(1)/2;
	if (Btype == 2 || Btype == 4) {
		fh = Wn(2)/2;
		if (fl >= 0.5 || fl <= 0.0 || fh >= 0.5 || fh <= 0.0) {
			error("fir1(): Frequencies must fall in range between 0 and 1.\n");
		}
		c1 = fh - fl;
		if (c1 <= 0.0) {
			error("fir1(): Wn(1) must be less than Wn(2).\n");
		}
	} else {
		c1 = fl;
		if (fl >= 0.5 || fl <= 0.0) {
			error("fir1(): Frequency must lie between 0 and 1\n");
		} 
	}

	nhlf = Integer(fix((N + 1)/2.0));
	i1 = 1 + odd;

	if (Btype == 1) {        // lowpass
		b = Z(1,nhlf);
		if (odd) {
			b(1) = 2*c1;
		}
		xn = [odd:nhlf-1] .+ 0.5*(1-odd);
		c = PI*xn;
		c3 = 2*c1*c;
		b(i1:nhlf) = sin(c3)/c;
		b = Re([b(nhlf:-1:i1), b(1:nhlf)] .* wind);
		if (version() == 4) {
			gain = abs(eval(Polynomial(fliplr(b)), 1.0));
		} else {
			gain = abs(eval(Polynomial(b), 1.0));
		}
		b = b/gain;
		return b;
	} else if (Btype == 2) { // bandpass
		b = Z(1,nhlf);
		b(1) = 2*c1;
		xn = [odd:nhlf-1] .+ 0.5*(1-odd);
		c = PI*xn;
		c3 = c*c1;
		b(i1:nhlf) = 2*sin(c3)*cos(c*(fl+fh))/c;
		b = Re([b(nhlf:-1:i1) b(1:nhlf)] .* wind);
		if (version() == 4) {
			gain = abs(eval(Polynomial(fliplr(b)), exp((0,1)*PI*(fl+fh))));
		} else {
			gain = abs(eval(Polynomial(b), exp((0,1)*PI*(fl+fh))));
		}
		b = b/gain;
		return b;
	} else if (Btype == 3) { // highpass
		b = Z(1,max(nhlf,N));
		b(1) = 2*c1;
		xn = [odd:nhlf-1];
		c = PI*xn;
		c3 = 2*c1*c;
		b(i1:nhlf) = sin(c3)/c;
		att = 60.0;
		b = Re([b(nhlf:-1:i1), b(1:nhlf)] .* wind);
		b(nhlf) = 1 - b(nhlf);
		b(1:nhlf-1) = -b(1:nhlf-1);
		b(nhlf+1:N) = -b(nhlf+1:N);
		if (version() == 4) {
			gain = abs(eval(Polynomial(fliplr(b)), -1.0));
		} else {
			gain = abs(eval(Polynomial(b), -1.0));
		}
		b = b/gain;
		return b;
	} else if (Btype == 4) { // bandstop
		b = Z(1,max(nhlf,N));
		b(1) = 2*c1;
		xn = [odd:nhlf-1] .+ 0.5*(1-odd);
		c = PI*xn;
		c3 = c*c1;
		b(i1:nhlf) = 2*sin(c3)*cos(c*(fl+fh))/c;
		b = Re([b(nhlf:-1:i1), b(1:nhlf)] .* wind);
		b(nhlf) = 1 - b(nhlf);
		b(1:nhlf-1) = -b(1:nhlf-1);
		b(nhlf+1:N) = -b(nhlf+1:N);
		if (version() == 4) {
			gain = abs(eval(Polynomial(fliplr(b)), 1.0));
		} else {
			gain = abs(eval(Polynomial(b), 1.0));
		}
		b = b/gain;
		return b;
	}

	return b;
}
