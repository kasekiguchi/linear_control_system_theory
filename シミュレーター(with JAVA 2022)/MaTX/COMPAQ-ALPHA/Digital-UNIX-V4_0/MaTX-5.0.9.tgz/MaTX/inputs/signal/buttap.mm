
/* -*- MaTX -*-
 *
 *  NAME
 *      buttap() - Butterworth analog lowpass filter prototype
 *
 *  SYNOPSIS
 *      {z,p,k} = buttap(n)
 *         CoMatrix z,p;
 *         Matrix k;
 *         Integer n;
 *
 *  DESCRIPTION
 *      buttap() returns the zeros, poles, and gain for an n-th order
 *      normalized prototype Butterworth analog lowpass filter.  The
 *      resulting filter has n poles around the unit circle in the left
 *      half plane, and no zeros. Poles are on the unit circle in the
 *      left-half plane.
 *
 *   SEE ALSO
 *      butter(), cheb1ap() and cheb2ap().
 */

Func List buttap(n)
	Integer n;
{
	Complex j;
	CoMatrix z, p;
	Matrix k;

	j = (0,1);

	z = [];
	p = trans(exp(j*(PI*[1:2:2*n-1]/(2*n) .+ PI/2)));
	k = Re(prod_row(-p));

	return {z,p,k};
}
