
/*  -*- MaTX -*-
 *
 *  NAME
 *      xcov() - Cross-covariance function estimates
 *
 *  SYNOPSIS
 *      c = xcov(x)
 *         Array c;
 *         Array x;
 *
 *      c = xcov(x,y)
 *         Array c;
 *         Array x;
 *         Array y;
 *
 *      c = xcov(x,y,option)
 *         Array c;
 *         Array x;
 *         Array y;
 *         String options;
 *
 *  DESCRIPTION
 *      The cross-covariance is the cross-correlation function of
 *      two sequences with their means removed.
 *
 *      xcov(A,B), where A and B are length M vectors, returns the
 *      length 2*M-1 cross-covariance sequence in a column vector.
 *
 *      xcov(A), when A is a vector, is the auto-covariance sequence.
 *      xcov(A), when A is an M-by-N matrix, is a large matrix with
 *      2*M-1 rows whose N^2 columns contain the cross-covariance
 *      sequences for all combinations of the columns of A.
 *      The zeroth lag of the output covariance is in the middle of the 
 *      sequence, at element or row M.
 *      By default, XCOV computes a raw covariance with no normalization.
 *
 *      xcov(A,"biased") or xcov(A,B,"biased") returns the "biased"
 *      estimate of the cross-covariance function.  The biased estimate
 *      scales the raw cross-covariance by 1/M.
 *
 *      xcov(...,"unbiased") returns the "unbiased" estimate of the
 *      cross-covariance function.  The unbiased estimate scales the raw
 *      covariance by 1/(M-abs(k)), where k is the index into the result.
 *
 *      xcov(...,"coeff") normalizes the sequence so that the
 *      covariances at zero lag are identically 1.0.
 *
 *	SEE ALSO
 *      xcorr(), corrcoef(), conv() and xcorr2().
 *
 */

Func Array xcov(x, y, option, ...)
	Array x, y;
	String option;
{
	Array xycov, onex, oney;
	Integer mx,my,nx,ny;

	error(nargchk(1, 3, nargs, "xcov"));

	{mx,nx} = size(x);
	onex = ONE(mx,1);
	
	if (nargs == 1) {
		xycov = xcorr(x - onex*mean_row(trans(x)));
	} else if (nargs == 2) {
		{my,ny} = size(y);
		oney = ONE(my,1);
		xycov = xcorr(x - onex*mean_row(trans(x)),
					  y - oney*mean_row(trans(y)));
	} else {
		oney = ONE(my,1);
		{my,ny} = size(y);
		xycov = xcorr(x - onex*mean_row(trans(x)),
					  y - oney*mean_row(trans(y)), option);
	}

	return xycov;
}
