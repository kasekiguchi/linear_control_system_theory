
/*  -*- MaTX -*-
 *
 *	NAME
 *      bartlett() - N-point Bartlett window in a row vector
 *
 *	SYNOPSIS
 *      win = bartlett(n)
 *       Matrix win;
 *       Integer n;
 *
 *  SEE ALSO
 *    blackman() and boxcar()
 */

Func Array bartlett(n)
	Integer n;
{
	Array win;

	win = 2*[0:(n-1)/2]/(n-1);

	if (rem(n,2)) {
		win = [win, win((n-1)/2:-1:1)];	// An odd length sequence
	} else {
		win = [win, win(n/2:-1:1)];		// An even length sequence
	}

	return win;
}
