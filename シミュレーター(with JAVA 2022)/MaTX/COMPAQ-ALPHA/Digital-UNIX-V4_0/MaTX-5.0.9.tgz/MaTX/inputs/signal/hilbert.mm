
/* -*- MaTX -*-
 *
 *  NAME
 *      hilbert() - Hilbert transform
 *
 *  SYNOPSIS
 *      y = hilbert(x)
 *         CoArray y;
 *         Array x;
 *
 *  DESCRIPTION
 *      hilbert() is the Hilbert transform of the real part of vector X.
 *      The real part of the result is the original real data, and the 
 *      imaginary part is the actual Hilbert transform.
 *
 *  SEE ALSO
 *      fft() and ifft().
 *
 */

Func CoArray hilbert(x)
	Array x;
{
	CoArray y,h;
	Integer m;

	y = fft(Re(x));
	m = length(y);

	if (m != 1) {
		h = [[1],[2*ONE(1,(m-1)/2)],[ONE(1,1-rem(m,2))],[Z(1,(m-1)/2)]];
		y = y * h;
	}

	y = ifft(y);
	return y;
}
