
/* -*- MaTX -*-
 *
 *  NAME
 *      cheby1() - Chebyshev type I digital filter design
 *
 *  SYNOPSIS
 *      {Bp,Ap} = cheby1(n,r,Wn)
 *          Matrix Bp,Ap;
 *          Integer n;
 *          Real r;
 *          Matrix Wn;
 *
 *      {Bp,Ap} = cheby1(n,r,Wn,ftype)
 *          Matrix Bp,Ap;
 *          Integer n;
 *          Real r;
 *          Matrix Wn;
 *
 *  DESCRIPTION
 *      cheby1() designs an n-th order lowpass digital Chebyshev filter
 *      with r decibels of ripple in the passband.
 *      cheby1() returns the filter coefficients in length n+1 vectors Bp
 *      and Ap.  The cut-off frequency Wn must be 0.0 < Wn < 1.0, 
 *      with 1.0 corresponding to half the sample rate.  Use r = 0.5 as
 *      a starting point, if you are unsure about choosing r.
 *
 *      If Wn is a two-element vector, Wn = [w1 w2], cheby1() returns
 *      and order 2n bandpass filter with passband  w1 < w < w2.
 *
 *      cheby1(...,"high") designs a highpass filter.
 *      cheby1(...,"stop") is a bandstop filter if Wn = [w1 w2].
 *
 *  SEE ALSO
 *      cheb1ord(), cheby2(), butter(), freqz() and filter().
 *
 */

Func List cheby1(n,r,Wn_,ftype, ...)
	Integer n;
	Real r;
	Matrix Wn_;
	String ftype;
{
	Integer btype;
	Real fs,bw;
	CoMatrix z,p;
	Matrix A,B,C,D,Ap,Bp,Wn,k,u;

	error(nargchk(3, 4, nargs, "cheby1"));
	
	Wn = Wn_;

	btype = 1;
	if (nargs == 4) {
		btype = 3;
	}
	if (length(Wn) == 2) {
		btype = btype + 1;
	}

	// Get analog, pre-warped frequencies
	fs = 2.0;
	u = 2*fs*tan(PI*Array(Wn)/fs);

	// Convert to low-pass prototype estimate
	switch (btype) {
	  case 1:  // lowpass
		Wn = u;
		break;
	  case 2:  // bandpass
		bw = u(2) - u(1);
		Wn = [sqrt(u(1)*u(2))];	// center frequency
		break;
	  case 3:  // highpass
		Wn = u;
		break;
	  case 4:  // bandstop
		bw = u(2) - u(1);
		Wn = [sqrt(u(1)*u(2))];	// center frequency
		break;
	}

	// Get n-th order Chebyshev type-I lowpass analog prototype
	{z,p,k} = cheb1ap(n, r);

	// Transform to state-space
	{A,B,C,D} = zp2ss(z, p, k);

	// Transform to lowpass, bandpass, highpass, or bandstop of desired Wn
	switch (btype) {
	  case 1:  // Lowpass
		{A,B,C,D} = lp2lp(A,B,C,D,Wn(1));
		break;
	  case 2:  // Bandpass
		{A,B,C,D} = lp2bp(A,B,C,D,Wn(1),bw);
		break;
	  case 3:  // Highpass
		{A,B,C,D} = lp2hp(A,B,C,D,Wn(1));
		break;
	  case 4:  // Bandstop
		{A,B,C,D} = lp2bs(A,B,C,D,Wn(1),bw);
		break;
	}

	// Use Bilinear transformation to find discrete equivalent:
	{A,B,C,D} = bilinear(A,B,C,D,fs);
	{Bp,Ap} = ss2tf(A,B,C,D,1);

	return {Bp,Ap};
}
