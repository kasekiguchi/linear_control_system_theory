
/* -*- MaTX -*_
 *
 *  NAME
 *      cheb1ap() - Chebyshev type I analog lowpass filter prototype
 *
 *  SYNOPSIS
 *      {z,p,k} = cheb1ap(n,rp)
 *        CoMatrix z,p;
 *        Matrix k;
 *        Integer n;
 *        Real rp;
 *
 *  DESCRIPTION
 *      cheb1ap() returns the zeros, poles, and gain of an n-th order
 *      normalized prototype type I Chebyshev analog lowpass filter with
 *      Rp decibels of ripple in the passband.
 *      Type I Chebyshev filters are maximally flat in the stopband.
 *
 *  SEE ALSO
 *      cheby1(), cheb1ord(), buttap(), cheb2ap() and ellipap().
 */

Func List cheb1ap(n, rp)
	Integer n;
	Real rp;
{
	Complex j;
	Real epsilon,mu;
	Matrix k;
	CoMatrix z, p;
	Array t;

	j = (0,1);
	epsilon = sqrt(10^(0.1*rp) - 1);
	mu = asinh(1/epsilon)/n;
	t = [1:2:2*n-1]/(2*n);
	p = trans(exp(j*(PI*t .+ PI/2)));
	p = sinh(mu)*Re(p) + j*cosh(mu)*Im(p);
	z = [];
	k = Re(prod_row(-p));

	// n is even so patch k
	if ( ! rem(n,2)) {
		k = k/sqrt(1 + epsilon^2);
	}
	return {z,p,k};
}
