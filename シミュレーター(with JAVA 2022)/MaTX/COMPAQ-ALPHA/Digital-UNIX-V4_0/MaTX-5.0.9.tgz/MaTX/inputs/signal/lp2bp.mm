
/* -*- MaTX -*-
 *
 *  NAME
 *      lp2bp() - Lowpass to bandpass analog filter transformation
 *
 *  SYNOPSIS
 *      {At,Bt,Ct,Dt} = lp2bp(A,B,C,D,wo,bw) 
 *          Matrix At,Bt,Ct,Dt;
 *          Matrix A,B,C,D;
 *          Real w0, bw;
 *
 *  DESCRIPTION
 *      lp2bp() transforms the lowpass filter with unity cutoff frequency
 *      to a bandpass filter with center frequency wo and bandwidth bw.
 *      Filter is described in state-space form.
 *
 *  SEE ALSO
 *      lp2bs(), lp2hp() and lp2lp()
 */

Func List lp2bp(A,B,C,D,wo,bw)
	Matrix A,B,C,D;
	Real wo,bw;
{
	Matrix At,Bt,Ct,Dt;
	Integer ma,mc,nb;
	Real q;

	{ma,nb} = size(B);
	{mc,ma} = size(C);

	// Transform lowpass to bandpass
	q = wo/bw;
	At = wo*[[   A/q, I(ma)]
			 [-I(ma), Z(ma)]];
	Bt = wo*[[  B/q   ]
			 [Z(ma,nb)]];
	Ct = [C, Z(mc,ma)];
	Dt = D;

	return {At,Bt,Ct,Dt};
}
