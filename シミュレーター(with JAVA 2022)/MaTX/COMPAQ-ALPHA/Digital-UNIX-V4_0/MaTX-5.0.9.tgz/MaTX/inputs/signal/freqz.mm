
/* -*- MaTX -*-
 *
 *  NAME
 *      freqz() - Z-transform digital filter frequency response
 *
 *  SYNOPSIS
 *     {h, w} = freqz(b, a, n)
 *        CoArray h;
 *        Array w;
 *        Matrix b, a;
 *        Integer n;
 *
 *     {h, w} = freqz(b, a, n, opt)
 *        CoArray h;
 *        Array w;
 *        Matrix b, a;
 *        Integer n;
 *        String opt
 *
 *  DESCRIPTION
 *      When N is an integer, freqz() returns the n-point frequency 
 *      vector w and the n-point complex frequency response vector 
 *      G of the filter b/a:
 *                                 -1                -nb 
 *          jw   B(z)   b(1) + b(2)z + .... + b(nb+1)z
 *       H(e) = ---- = ----------------------------
 *                                 -1                -na
 *               A(z)    1   + a(2)z + .... + a(na+1)z
 *
 *      given numerator and denominator coefficients in vectors b and a. The
 *      frequency response is evaluated at n points equally spaced around the
 *      upper half of the unit circle.
 *
 *      To plot magnitude and phase of a filter:
 *
 *        {h,w} = freqz(b,a,n);
 *        mag = abs(h);
 *        phase = angle(h);
 *        mgplot_semilogx(1,w,mag); 
 *        mgplot_semilogx(2,w,phase)
 *
 *      freqz(...,"whole") uses n points around the whole unit circle.
 *
 *  SEE ALSO
 *      freqzw(), yulewalk(), filter(), fft(), invfreqz(), and freqs().
 *
 */

Func List freqz(b_, a_, n, opt, ...)
	Matrix b_, a_;
	Integer n;
	String opt;
{
	Integer na,nb,nn,s,N;
	Matrix a, b;
	CoArray h;
	Array w;

	error(nargchk(3, 4, nargs, "freqz"));

	na = length(a_);
	nb = length(b_);
	a = makerowv(a_);
	b = makerowv(b_);
	s = 2;
	if (nargs == 4) {
		s = 1;
	}

	w = 2*PI/s*[0:n-1]/n;

	h = fft(Array([b, Z(1,s*n-nb)])) / fft(Array([a, Z(1,s*n-na)]));
	h = h(1:n);

	return {h, w};
}

/* -*- MaTX -*-
 *
 *  NAME
 *      freqzp() - Plot frequency response of Z-transform digital filter
 *
 *  SYNOPSIS
 *      freqzp(b, a, n)
 *         Matrix b, a;
 *         Integer n;
 *
 *      freqzp(b, a, n, opt)
 *         Matrix b, a;
 *         Integer n;
 *         String opt
 *
 *  DESCRIPTION
 *      freqzp(b,a,n)         uses n points around the half unit circle.
 *      freqzp(b,a,n,"whole") uses n points around the whole unit circle.
 *
 *  SEE ALSO
 *      freqz()
 *
 */

Func void freqzp(b, a, n, opt, ...)
	Matrix b, a;
	Integer n;
	String opt;
{
	CoArray h;
	Array w, mag, phase;

	error(nargchk(3, 4, nargs, "freqzp"));
	
	if (nargs == 3) {
		{h, w} = freqz(b, a, n);
	} else {
		{h, w} = freqz(b, a, n, opt);
	}

    mag = 20*log10(abs(h));
	phase = unwrap(angle(h)*180/PI);
	mgplot_grid(1,1);
	mgplot_grid(2,1);
	mgplot_xlabel(1, "Frequency (rad/sec)");
	mgplot_xlabel(2, "Frequency (rad/sec)");
	mgplot_ylabel(1, "Magnitude (dB)");
	mgplot_ylabel(2, "Phase (deg)");
    mgplot(1,w,mag,{"magnitude"});
	mgplot(2,w,phase,{"phase"});
}
