
/*  -*- MaTX -*-
 *
 *  NAME
 *      nextpow2() - Next power of two
 *
 *  SYNOPSIS
 *      n2 = nextpow2(n)
 *         Integer n2;
 *         Integer n;
 *
 *  DESCRIPTION
 *      nextpow2(N) returns the first P such that 2^P >= N.  It is
 *      often useful for finding the nearest power of two sequence
 *      length for FFT operations.  
 *
 *      if X is a vector, nextpow2(X) is the same as nextpow2(length(X)).
 *      This is trickier than it might seem at first because of roundoff
 *      error.
 */

Func Integer nextpow2(n)
	Integer n;
{
	Matrix p;

	p = round(log(Real(n))/log(2.0)) .+ [-1, 0 ,1];
	p = p(Array(2 .^p) >= n);
	return Integer(p(1));
}
