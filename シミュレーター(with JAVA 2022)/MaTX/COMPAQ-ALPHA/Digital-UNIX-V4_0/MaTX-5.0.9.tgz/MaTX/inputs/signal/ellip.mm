
/*  -*- MaTX -*-
 *
 *  NAME
 *      ellip() - Elliptic or Cauer digital filter design
 *
 *  SYNOPSIS
 *      {b,a} = ellip(n, Rp, Rs, Wn)
 *          Matrix b,a;
 *          Integer n;
 *          Real Rp;
 *          Real Rs;
 *          Matrix Wn;
 *
 *      {b,a} = ellip(n, Rp, Rs, Wn, ftype)
 *          Matrix b,a;
 *          Integer n;
 *          Real Rp;
 *          Real Rs;
 *          Matrix Wn;
 *          String ftype;
 *
 *  DESCRIPTION
 *      ellip() designs an N-th order lowpass digital elliptic filter with
 *      Rp decibels of ripple in the passband and a stopband Rs decibels down.
 *
 *      ellip() returns the filter coefficients in length N+1 vectors B and A. 
 *      The cut-off frequency Wn must be 0.0 < Wn < 1.0, with 1.0 corresponding
 *      to half the sample rate.  Use Rp = 0.5 and Rs = 20 as starting
 *      points, if you are unsure about choosing them.
 *
 *      If Wn is a two-element vector, Wn = [W1 W2], ellip() returns an 
 *      order 2N bandpass filter with passband  W1 < W < W2.
 *
 *      ellip(..., "high") designs a highpass filter.
 *      ellip(..., "stop") is a bandstop filter if Wn = [W1 W2].
 *
 *	SEE ALSO
 *      ellipord(), cheby2(), butter(), freqz() and filter().
 *
 */

Func List ellip(n, Rp, Rs, Wn, ftype, ...)
	Integer n;
	Real Rp;
	Real Rs;
	Matrix Wn;
	String ftype;
{
	Matrix a,b,c,d,u,z,p,k,de,nu;
	Integer btype;
	Real Bw,fs;

	error(nargchk(4, 5, nargs, "ellip"));
	
	btype = 1;
	if (nargs == 5) {
		btype = 3;
	}
	if (max(Cols(Wn), Rows(Wn)) == 2) {
		btype = btype + 1;
	}

	// step 1: get analog, pre-warped frequencies
	fs = 2;
	u = 2*fs*tan(PI*Array(Wn)/fs);

	// step 2: convert to low-pass prototype estimate
	switch (btype) {
	  case 1: // lowpass
		Wn = u;
		break;
	  case 2: // bandpass
		Bw = u(2) - u(1);
		Wn = [sqrt(u(1)*u(2))]; // center frequency
		break;
	  case 3: // highpass
		Wn = u;
		break;
	  case 4: // bandstop
		Bw = u(2) - u(1);
		Wn = [sqrt(u(1)*u(2))]; // center frequency
		break;
	}

	// step 3: Get N-th order elliptic lowpass analog prototype
	{z,p,k} = ellipap(n, Rp, Rs);

	// Transform to state-space
	{a,b,c,d} = zp2ss(z,p,k);

	// step 4: Transform to lowpass, bandpass, highpass,
	//         or bandstop of desired Wn
	switch (btype) {
	  case 1: // Lowpass
		{a,b,c,d} = lp2lp(a,b,c,d,Wn(1));
		break;
	  case 2: // Bandpass
		{a,b,c,d} = lp2bp(a,b,c,d,Wn(1), Bw);
		break;
	  case 3: // Highpass
		{a,b,c,d} = lp2hp(a,b,c,d,Wn(1));
		break;
	  case 4: // Bandstop
		{a,b,c,d} = lp2bs(a,b,c,d,Wn(1),Bw);
		break;
	}

	// step 5: Use Bilinear transformation to find discrete equivalent:
	{a,b,c,d} = bilinear(a,b,c,d,fs);
	
	{de,nu} = ss2tf(a,b,c,d,1);
	
	return {de,nu};
}
