
/*  -*- MaTX -*-
 *
 *  NAME
 *      hamming() - Hamming window in a row vector
 *
 *	SYNOPSIS
 *     win = hamming(n)
 *       Array win;
 *       Integer n;
 *
 *  SEE ALSO
 *     boxcar(), bartlett(), blackman() and hanning()
 */

Func Array hamming(n)
	Integer n;
{
	Array win;
	
	win = 0.54 .- 0.46*cos(2*PI*[0:n-1]/(n-1));
	return win;
}
