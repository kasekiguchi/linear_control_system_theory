
/*  -*- MaTX -*-
 *
 *  NAME
 *      polystab() - Polynomial stabilization
 *
 *  SYNOPSIS
 *      b = polystab(a)
 *         Matrix b;
 *         Matrix a;
 *
 *  DESCRIPTION
 *      polystab(A), where A is a vector of polynomial coefficients,
 *      stabilizes the polynomial with respect to the unit circle
 *      roots whose magnitudes are greater than one are reflected
 *      inside the unit circle.
 */

Func Matrix polystab(a)
	Matrix a;
{
	CoMatrix v;
	Matrix b,vs;
	Index idx;
	
	if (version() == 4) {
		v = roots(Polynomial(fliplr(a)));
	} else {
		v = roots(Polynomial(a));
	}
	idx = find(Array(v) != 0);

	vs = 0.5*(sgn(abs(Array(v(idx))) .- 1) .+ 1);
	v(idx) = (1 .- vs) .* v(idx) + vs ./ conj(v(idx));
	b = a(1)*poly(v);

	// Return only real coefficients if input was real
	if (isreal(a)) {
		b = Re(b);
	}
	return b;
}
