
/* -*- MaTX -*-
 *
 *  NAME
 *      grpdelay() - Group delay of a digital filter
 *
 *  SYNOPSIS
 *      {gd,w} = grpdelay(b,a,n)
 *           Array gd, w;
 *           Matrix b, a;
 *           Integer n;
 *
 *      {gd,w} = grpdelay(b,a,n,opt)
 *           Array gd, w;
 *           Matrix b, a;
 *           Integer n;
 *           String opt;
 *
 *  DESCRIPTION
 *      grpdelay() returns length N vectors Gd and W containing
 *      the group delay and the frequencies at which it is evaluated.
 *      Group delay is -d{angle(w)}/dw.  The frequency response is 
 *      evaluated at N points equally spaced around the upper half of
 *      the unit circle.   When N is a power of two, the computation
 *      is done faster using FFTs.  
 *
 *      grpdelay(..., "whole") uses N points around the whole unit circle.
 *   
 *  SEE ALSO
 *      freqz()
 */

Func List grpdelay(b,a,n,opt, ...)
	Matrix b,a;
	Integer n;
	String opt;
{
	Array gd,w,c,cr;
	Integer na,nb,nc,nfact,s,mmax;

	error(nargchk(3, 4, nargs, "grpdelay"));

	nb = max(Cols(b), Rows(b));
	na = max(Cols(a), Rows(a));
	s = 2;
	if (nargs == 4) {
		s = 1;
	}
	w = 2*PI/s*[0:n-1]/n;

	c = conv(b, conj(a(na:-1:1)));
	c = makerowv(c);
	nc = max(Cols(c), Rows(c));
	cr = c * [0:(nc-1)];

	if (s*n >= nc)	{ // pad with zeros to get the n values needed
		gd = Re(fft(Array([cr, Z(1,s*n-nc)])) / fft(Array([c, Z(1,s*n-nc)])));
		gd = gd(1:n) .- (na-1);
	} else {         // find multiple of s*n points greater than nc
		nfact = Integer(s*ceil(Real(nc/(s*n))));
		mmax = n*nfact;
		gd = Re(fft(cr,mmax) / fft(c,mmax));
		gd = gd(1:nfact:mmax) .- (na-1);
	}
	return {gd,w};
}

