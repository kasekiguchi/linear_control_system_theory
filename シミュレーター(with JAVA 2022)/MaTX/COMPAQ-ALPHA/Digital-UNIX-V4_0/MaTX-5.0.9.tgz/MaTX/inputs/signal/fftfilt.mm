
/*  -*- MaTX -*-
 *
 *  NAME
 *      fftfilt() - Overlap-add method of filtering using FFT
 *
 *  SYNOPSIS
 *      y = fftfilt(b,x)
 *         Array y;
 *         Matrix b;
 *         Array x;
 *
 *      y = fftfilt(b,x,nfft)
 *         Array y;
 *         Matrix b;
 *         Array x;
 *         Integer nfft;
 *
 *  DESCRIPTION
 *      fftfilt() filters X with the FIR filter B using the overlap/add
 *      method.  fftfilt() uses to overlap/add method to filter X with B
 *      using an N-point FFT.
 *
 *  SEE ALSO
 *      filter().
 *
 */

Func Array fftfilt(b,x,nfft, ...)
	Matrix b;
	Array x;
	Integer nfft;
{
	Integer L,iend,istart,m,n,nb,nx,yend,powerof2;
	CoArray X,B,Y,y;

	error(nargchk(2, 3, nargs, "fftfilt"));
	
	if (nargs < 3) {
		nfft = 512;
	}

	{m,n} = size(x);
	y = (Z(m,n),:);
	nx = max(m,n);

	if (m > n) {
		b = makecolv(b);
	}

	nb = length(b);
	if (nb > nfft) {
		nfft = nb;
	}
	
	// force this to a power of 2 for speed
	nfft = Integer(2.0^(ceil(log(nfft)/log(2.0))));
	if (nx < nfft) { // see if we can make this less than 512 or nfft
		powerof2 = Integer(2.0^(ceil(log(nx)/log(2.0))));
		if (powerof2 < nfft && nargs < 3 && nb <= nx) {
			nfft = powerof2;
		}
	}

	B = fft(Array(b),nfft);
	L = nfft - nb + 1;
	istart = 1;

	while (istart <= nx) {
		iend = min(istart+L-1,nx);
		X = fft(x(istart:iend),nfft);
		Y = ifft(X.*B);
		yend = min(nx,istart+nfft-1);
		y(istart:yend) = y(istart:yend) + Y(1:(yend-istart+1));
		istart = istart + L;
	}

	return Re(y);
}
