
/*  -*- MaTX -*-
 *
 *  NAME
 *      yulewalk() - Recursive filter design using a least-squares method
 *
 *  SYNOPSIS
 *      {B,A} = yulewalk(na,ff,aa)
 *         Matrix B,A;
 *         Integer na;
 *         Matrix ff,aa;
 * 
 *      {B,A} = yulewalk(na,ff,aa,npt)
 *         Matrix B,A;
 *         Integer na;
 *         Matrix ff,aa;
 *         Integer npt;
 * 
 *      {B,A} = yulewalk(na,ff,aa,npt,lap)
 *         Matrix B,A;
 *         Integer na;
 *         Matrix ff,aa;
 *         Integer npt;
 *         Integer lap;
 * 
 *  DESCRIPTION
 *      yulewalk() finds the N-th order recursive filter coefficients 
 *      B and A such that the filter:
 *   		                      -1             -(n-1) 
 *   		   B(z)   b(1) + b(2)z + .... + b(n)z
 *   		   ---- = ---------------------------
 *   		                      -1             -(n-1)
 *   		   A(z)    1   + a(1)z + .... + a(n)z
 *   
 *      matches the magnitude frequency response given by vectors F and M.
 *      Vectors F and M specify the frequency and magnitude break points for
 *      the filter such that gplot(F,M) would show a plot of the desired
 *      frequency response. The frequencies in F must be between 0.0 and 1.0,
 *      with 1.0 corresponding to half the sample rate. They must be in
 *      increasing order and start with 0.0 and end with 1.0. 
 *
 *	SEE ALSO
 *     fir1(), butter(), cheby(), freqz() and filter().
 *
 */

Func List yulewalk(na, ff_, aa_, npt, lap, ...)
	Integer na;
	Matrix ff_;
	Matrix aa_;
	Integer npt;
	Integer lap;
{
	Matrix A,B,ff,aa,Ht,Qh,inc,j;
	Integer i,mf,mm,n,nb,ne,nf,nint,nn,nr,nbrk,n2;
	Array df,Ss,nt,R,Rwindow;
	CoArray fr,hh;

	Matrix yulewalk_numf(), yulewalk_denf();

	error(nargchk(3, 5, nargs, "yulewalk"));

	ff = ff_;
	aa = aa_;

	if (nargs > 3) {
		if (round(2^round(log(npt)/log(2))) != npt) {
			// NPT is not an even power of two
			npt = Integer(round(2^ceil(log(npt)/log(2))));
		} 
	}
	if (nargs < 4) {
		npt = 512;
	}
	if (nargs < 5) {
		lap = Integer(fix(npt/25.0));
	}
	
	{mf,nf} = size(ff);
	{mm,nn} = size(aa);
	if (mm != mf || nn != nf) {
		error("yulewalk(): You must specify the same number of frequencies and amplitudes.\n");
	}
	nbrk = max(mf,nf);
	if (mf < nf) {
		ff = ff#;
		aa = aa#;
	}

	if (abs(ff(1)) > EPS || abs(ff(nbrk) - 1) > EPS) {
		error("yulewalk(): The first frequency must be 0 and the last 1.\n");
	}

	// interpolate break points onto large grid
	Ht = Z(1,npt);
	nint = nbrk - 1;
	df = diff(ff#);
	if (any(df < 0)) {
		error("yulewalk(): Frequencies must be non-decreasing.\n");
	}

	nb = 1;
	Ht(1) = aa(1);
	for (i = 1; i <= nint; i++) {
		if (df(i) == 0) {
			nb = nb - lap/2;
			ne = nb + lap;
		} else {
			ne = Integer(fix(ff(i+1)*npt));
		}
		if (nb < 0 || ne > npt) {
			error("yulewalk(): Too abrupt an amplitude change near of frequency interval.\n");
		}
		j = [nb:ne];

		if (ne == nb) {
			inc = [0];
		} else {
			inc = (j .- nb)/(ne - nb);
		}

		Ht(nb:ne) = inc*aa(i+1) + (1 .- inc)*aa(i);
		nb = ne + 1;
	}

	Ht = [Ht fliplr(Ht)];
	n = max(Cols(Ht), Rows(Ht));
	n2 = Integer(fix((n+1)/2.0));
	nb = na;
	nr = 4*na;
	nt = [0:nr-1];

	// compute correlation function of magnitude squared response
	R = Re(ifft(Array(Ht.*Ht)));	
	R = R(1:nr) .* (0.54 .+ 0.46*cos(PI*nt/(nr-1)));  // pick NR correlations

	/*
	 * Form window to be used in extracting the right "wing"
	 * of two-sided covariance sequence.
	 */
	Rwindow = [[1.0/2.0], ONE(1,n2-1), Z(1,n-n2)]; 

	// compute denominator
	A = polystab(yulewalk_denf(R,na));

	// compute additive decomposition
	Qh = yulewalk_numf([[R(1)/2], R(2:nr)], A, na);	

	{fr} = freqz(Qh,A,n,"whole");
	Ss = 2*Re(fr);                // compute impulse response
	hh = ifft(exp(fft(Rwindow .* ifft(log((Ss,*))))));
	B  = Re(yulewalk_numf(hh(1:nr), A, nb));

	return {B,A};
}


/*  -*- MaTX -*-
 *
 *  NAME
 *      yulewalk_numf() - Find numerator B given impulse-response 
 *
 *  SYNOPSIS
 *      b = yulewalk_numf(h,a,nb)
 *         Matrix b;
 *         Array h;
 *         Matrix a;
 *         Integer nb;
 *
 *  DESCRIPTION
 *      yulewalk_numf() finds numerator B given impulse-response h of B/A and
 *      denominator A NB is the numerator order.
 */

Func Matrix yulewalk_numf(h,a,nb)
	Matrix h;
	Matrix a;
	Integer nb;
{
	Matrix b,impr;
	Integer nh;

	nh = max(Cols(h), Rows(h)); 

	{impr} = filter([1],a,[[1], Z(1,nh-1)]);
	b = h / toeplitz(impr,[[1], Z(1,nb)])#;

	return b;
}


/* -*- MaTX -*-
 *
 *  NAME
 *      yulewalk_denf() - Compute order NA denominator
 *
 *  SYNOPSIS
 *      A = yulewalk_denf(R,na)
 *         Matrix A;
 *         Matrix R;
 *         Integer na;
 *
 *  DESCRIPTION
 *      yulewalk_denf() Compute order na denominator A from covariances
 *      R(0)...R(nr) using the Modified Yule-Walker method.
 */

Func Matrix yulewalk_denf(R, na)
	Matrix R;
	Integer na;
{
	Matrix A, Rm, Rhs;
	Integer nr;

	nr = max(Cols(R), Rows(R));
	Rm = toeplitz(R(na+1:nr-1),R(na+1:-1:2));
	Rhs = - R(na+2:nr);
	A = [ONE(1) Rhs/Rm#];

	return A;
}
