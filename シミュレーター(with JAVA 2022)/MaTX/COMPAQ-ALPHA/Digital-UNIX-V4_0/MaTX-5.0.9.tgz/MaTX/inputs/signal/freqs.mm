
/* -*- MaTX -*-
 *
 *  NAME
 *      freqs() - Laplace-transform (s-domain) frequency response
 *
 *  SYNOPSIS
 *      h = freqs(b, a, w)
 *        CoArray h;
 *        Matrix b, a;
 *        Array w;
 *
 *  DESCRIPTION
 *      freqs() returns the complex frequency response vector H 
 *      of the filter B/A:
 *                         nb-1      nb-2
 *             B(s)   b(1)s  +  b(2)s   + ... +  b(nb)
 *      H(s) = ---- = --------------------------------
 *                         na-1      na-2
 *             A(s)   a(1)s  +  a(2)s   + ... +  a(na)
 *
 *      given the numerator and denominator coefficients in vectors b and a.
 *      The frequency response is evaluated at the points specified in 
 *      vector w.  The magnitude and phase can be graphed with:
 *
 *       w = logspace(d1,d2);
 *       h = freqs(b,a,w);
 *       mag = abs(h);
 *       phase = angle(h)*180/PI;
 *       mgplot_semilogx(1,w,mag);
 *       mgplot_semilogx(2,w,phase);
 *
 *  SEE ALSO
 *      logspace(), invfreqs() and freqz().
 */

Func CoArray freqs(b, a, w)
	Matrix b, a;
	Array w;
{
	CoArray s,h;

	s = (0,1)*w;
	if (version() == 4) {
		h = eval(Polynomial(fliplr(b)), s) / eval(Polynomial(fliplr(a)), s);
	} else {
		h = eval(Polynomial(b), s) / eval(Polynomial(a), s);
	}
	return h;
}

/* -*- MaTX -*-
 *
 *  NAME
 *      freqsp() - Plot frequency response of Laplace-transform analog filter
 *
 *  SYNOPSIS
 *      freqsp(b, a)
 *        Matrix b, a;
 *
 *      freqsp(b, a, w)
 *        Matrix b, a;
 *        Array w;
 *
 *  SEE ALSO
 *      logspace(), invfreqs() and freqz().
 */

Func void freqsp(b, a, w, ...)
	Matrix b, a;
	Array w;
{
	Array mag, phase;
	CoArray h;
	
	if (nargs < 2 || 3 < nargs) {
		error("freqsp(): Incorrect number of arguments.\n");
	}
	
	if (nargs == 2) {
		w = logspace(-1.0, 1.0);
	}
    h = freqs(b,a,w);
    mag = 20*log10(abs(h));
	phase = unwrap(angle(h)*180/PI);

	mgplot_grid(1,1);
	mgplot_grid(2,1);
	mgplot_xlabel(1, "Frequency (rad/sec)");
	mgplot_xlabel(2, "Frequency (rad/sec)");
	mgplot_ylabel(1, "Magnitude (dB)");
	mgplot_ylabel(2, "Phase (deg)");
    mgplot_semilogx(1,w,mag,{"magnitude"});
	mgplot_semilogx(2,w,phase,{"phase"});
}
