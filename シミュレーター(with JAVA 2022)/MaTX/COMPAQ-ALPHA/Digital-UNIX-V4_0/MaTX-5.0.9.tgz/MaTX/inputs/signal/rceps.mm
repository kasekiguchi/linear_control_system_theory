
/*  -*- MaTX -*-
 *
 *  NAME
 *      rceps() - Real cepstrum
 *
 *  SYNOPSIS
 *      {xhat, yhat} = rceps(x)
 *          Array xhat, yhat;
 *          Array x;
 *
 *  DESCRIPTION
 *      rceps(x) returns the real cepstrum of the sequence x. rceps(x)
 *      returns both the real cepstrum and a minimum phase signal 
 *      derived from x.
 *
 *  SEE ALSO
 *      cceps(), hilbert(), and fft().
 *
 */

Func List rceps(x)
	Array x;
{
	Array xhat,yhat,wn;
	Integer n,odd;

	n = max(Cols(x), Rows(x));
	xhat = Re(ifft(log(abs(fft(x)))));

	odd = rem(n,2);
	wn = [[1][2*ONE((n+odd)/2-1,1)][1][Z((n-odd)/2-1,1)]];
	yhat = Z(x);
	yhat = Re(ifft(exp(fft(wn .* Array(makecolv(xhat))))));
	return {xhat, yhat};
}
