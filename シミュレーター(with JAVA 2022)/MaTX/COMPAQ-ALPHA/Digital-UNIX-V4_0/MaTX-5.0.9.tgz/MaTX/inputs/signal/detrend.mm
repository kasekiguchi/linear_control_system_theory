
/* -*- MaTX -*-
 *
 *  NAME
 *      detrend_col() - Remove a linear trend for each column
 *      detrend_row() - Remove a linear trend for each row
 *      detrend()     - Same as detrend_row()
 *
 *  SYNOPSIS
 *      y = detrend_col(x)
 *         Array y;
 *         Array x;
 *
 *      y = detrend_col(x,o)
 *         Array y;
 *         Array x;
 *         Integer o;
 *
 *      y = detrend_row(x)
 *         Array y;
 *         Array x;
 *
 *      y = detrend_row(x,o)
 *         Array y;
 *         Array x;
 *         Integer o;
 *
 *      y = detrend(x)
 *         Array y;
 *         Array x;
 *
 *      y = detrend(x,o)
 *         Array y;
 *         Array x;
 *         Integer o;
 *
 *  DESCRIPTION
 *      detrend() removes the best straight-line fit from the data in
 *      vector X and returns it in vector Y.
 *      detrend(X,0) removes just the mean value from vector X.
 *
 *      If X is a matrix, 
 *
 *      detrend_col() removes the trend from each column of the matrix.
 *      detrend_row() removes the trend from each row of the matrix.
 *      detrend() works in the same way as detrend_row().
 */

Func Array detrend(x, o, ...)
	Array x;
	Integer o;
{
	error(nargchk(1, 2, nargs, "detrend"));

	if (nargs == 1) {
		detrend_row(x);
	} else {
		detrend_row(x, o);
	}
}

Func Array detrend_row(x, o, ...)
	Array x;
	Integer o;
{
	error(nargchk(1, 2, nargs, "detrend_row"));
	
	if (nargs == 1) {
		trans(detrend_col(trans(x)));
	} else {
		trans(detrend_col(trans(x), o));
	}
}

Func Array detrend_col(x_, o, ...)
	Array x_;
	Integer o;
{
	Matrix a,x,y;
	Integer m,mp,n,np;

	error(nargchk(1, 2, nargs, "detrend_col"));
	
	x = x_;

	if (nargs == 1) {
		o = 1;
	}
	{m,n} = size(x);
	if (m == 1) { // If a row turn into column vector
		x = makecolv(x);
	}
	{mp,np} = size(x);

	if (o == 0) { // Remove just mean from each column
		y = x - ONE(mp,1)*mean_row(trans(x));
	} else {      // Remove straight-line fit from each column
		a = [[1:mp]'/mp, ONE(mp,1)];
		y = x - a*(a\x);
	}
	if (n == 1) {
		y = y';
	}
	
	return Array(y);
}

