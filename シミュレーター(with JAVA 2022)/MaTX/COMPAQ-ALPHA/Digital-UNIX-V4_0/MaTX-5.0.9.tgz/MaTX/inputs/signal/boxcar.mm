
/* -*- MaTX -*-
 *
 *  NAME
 *      boxcar() - Rectangular window
 * 
 *  SYNOPSIS
 *      w = boxcar(n)
 *         Matrix w;
 *         Integer n;
 *
 *  DESCRIPTION
 *      boxcar() returns the N-point rectangular window
 *
 *  SEE ALSO
 *      bartlett() and blackman()
 */

Func Array boxcar(n)
	Integer n;
{
	Array win;

	win = ONE(1,n);
	return win;
}
