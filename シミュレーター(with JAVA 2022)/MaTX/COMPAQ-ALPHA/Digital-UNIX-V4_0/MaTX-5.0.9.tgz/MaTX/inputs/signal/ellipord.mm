
/*  -*- MaTX -*-
 *
 *  NAME
 *      ellipord() - Elliptic filter order selection.
 *
 *  SYNOPSIS
 *      {order,wn} = ellipord(wp, ws, rp, rs)
 *         Integer order;
 *         Matrix wn;
 *         Matrix wp,ws;
 *         Real rp,rs;
 *
 *      {order,wn} = ellipord(wp, ws, rp, rs, opt)
 *         Integer order;
 *         Matrix wn;
 *         Matrix wp,ws;
 *         Real rp,rs;
 *
 *  DESCRIPTION
 *      ellipord() returns the order N of the lowest order digital elliptic
 *      filter that loses no more than Rp dB in the passband and has at least
 *      Rs dB of attenuation in the stopband.  The passband runs from 0 to Wp
 *      and the stopband extends from Ws to 1.0, the Nyquist frequency.
 *
 *      ellipord() also returns Wn, the elliptic natural frequency to
 *      use with ellip() to achieve the specifications.
 *
 *      ellipord(..., "s") does the computation for an analog filter.
 *   
 *	SEE ALSO
 *      ellip(), buttord(), cheb1ord() and cheb2ord().
 *
 */

Func List ellipord(wp_, ws_, rp_, rs_, opt, ...)
	Matrix wp_, ws_;
	Real rp_, rs_;
	String opt;
{
	Integer order,ftype,np1,ns1;
	Matrix wp,ws,rp,rs,wn,Order,epsilon;
	Matrix capk,capk1,k,k1;

	error(nargchk(4, 5, nargs, "ellipord"));

	if (nargs == 4) {
		opt = "z";
	} else if (nargs == 5) {
		if (opt != "z" && opt != "s") {
			error("ellipord(): Invalid option for final argument.\n");
		}
	}

	wp = wp_;
	ws = ws_;

	np1 = length(wp);
	ns1 = length(ws);
	if (np1 != ns1) {
		error("ellipord(): The frequency vectors must both be the same length.\n");
	}

	ftype = 2*(np1 - 1);
	if (wp(1) < ws(1)) {
		ftype = ftype + 1;	// low (1) or reject (3)
	} else {
		ftype = ftype + 2;	// high (2) or pass (4)
	}
	if (np1 == 2) {
		rs = rs_*ONE(1,np1);
		rp = rp_*ONE(1,np1);
	} else {
		rs = [rs_];
		rp = [rp_];
	}

	// convert temporarily to low pass
	if (ftype == 2) {        // high
		wp = 1 .- wp;
		ws = 1 .- ws;
	} else if (ftype == 3) { // stop
		wp(2) = 1 - wp(2);
		ws(2) = 1 - ws(2);
	} else if (ftype == 4) { // pass
		wp(1) = 1 - wp(1);
		ws(1) = 1 - ws(1);
	}

	epsilon = sqrt(10^(0.1*Array(rp)) .- 1);
	k1 = Array(epsilon) / sqrt(10^(0.1*Array(rs)) .- 1);
	if (opt == "z") { // digital
		k = tan(PI*Array(wp)/2)./tan(PI*Array(ws)/2);
	} else {
		k = wp./ws;   // analog
	}

	capk = ellipk(1, [k.^2, 1 .- k.^2]);
	capk1 = ellipk(1, [k1.^2, 1 .- k1.^2]);
	if (ftype < 3) {
		order = Integer(ceil(capk(1)*capk1(2)/(capk(2)*capk1(1))));
	} else {
		Order = Z(1,2);
		Order(1) = Integer(ceil(capk(1)*capk1(3)/(capk(3)*capk1(1))));
		Order(2) = Integer(ceil(capk(2)*capk1(4)/(capk(4)*capk1(2))));
	}
	wn = wp;

	// reconvert from low pass
	if (ftype == 2) {        // high
		wn = 1 .- wn;
	} else if (ftype == 3) { // stop
		order = Integer(max(Order));	
		wn(2) = 1 - wn(2);
	} else if (ftype == 4) { // pass
		order = Integer(max(Order));	
		wn(1) = 1 - wn(1);
	}

	return {order,wn};
}
