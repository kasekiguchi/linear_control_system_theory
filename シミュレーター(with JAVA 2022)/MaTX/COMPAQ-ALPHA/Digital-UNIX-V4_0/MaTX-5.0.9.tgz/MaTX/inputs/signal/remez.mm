
/*  -*- MaTX -*-
 *
 *  NAME
 *      remez() - Parks-McClellan optimal equirriple FIR filter design
 *
 *  SYNOPSIS
 *      {h,ha} = remez(nfilt, ff, aa)
 *        Matrix h;
 *        Integer ha;
 *        Integer nfilt;
 *        Matrix ff, aa;
 *
 *      {h,ha} = remez(nfilt, ff, aa, wtx)
 *        Matrix h;
 *        Integer ha;
 *        Integer nfilt;
 *        Matrix ff, aa, wtx;
 *
 *      {h,ha} = remez(nfilt, ff, aa, wtx, ftype)
 *        Matrix h;
 *        Integer ha;
 *        Integer nfilt;
 *        Matrix ff, aa, wtx;
 *        String ftype;
 *
 *  DESCRIPTION
 *      remez(nfilt,ff,aa) designs an nfilt'th order FIR digital filter,
 *   	with the frequency response specified by vectors ff and aa, 
 *   	and returns the	filter coefficients in length nfilt+1 vector B.
 *   	Vectors ff and aa specify the frequency and magnitude
 *   	break points for the filter such that gplot(ff,aa) would show a
 *   	plot of the desired frequency response. The elements of aa must
 *   	appear in equal-valued pairs.  The frequencies in ff must be
 *   	between 0.0 < ff < 1.0, with 1.0 corresponding to half the
 *   	sample rate. They must be in increasing order, start with 0.0,
 *   	and end with 1.0.
 *
 *      remez(nfilt,ff,aa,W) uses vector W to specify weighting in each
 *      of the pass or stop bands in vectors ff and aa.
 *
 *      remez(nfilt,ff,aa,FTYPE) or remez(nfilt,ff,aa,W,FTYPE), where FTYPE
 *      is the string "Hilbert" or "differentiator", designs Hilbert
 *      transformers or differentiators, respectively.  For the Hilbert
 *      case, the lowest frequency should not be 0.
 *	
 *	SEE ALSO
 *      fir1(), fir2(), butter(), cheby1(), cheby2(), yulewalk(), freqz()
 *	    and filter().
 *
 */

Func List remez(nfilt, ff_, aa_, wtx_, ftype, ...)
	Integer nfilt;
	Matrix ff_, aa_, wtx_;
	String ftype;
{
	Integer i,j,flag,flag34,itrmax,jb,jchnge,jend,jm1,jp1,ha;
	Integer jtype,k,kkk,klow,l,lband,lenh,luck,ma,mf,na,nbands,neg;
	Integer nf,niter,nn,nodd,nu,nut,nut1,cn,ngrid_,lgrid,nsel,nzz,nz;
	Integer nfcns,kup,k1,knz,nm1,jet;
	Real ft,gtemp,small,xe,fsh,dtemp,xt;
	Real temp,delf,fup,dnum,dden,dev,devl,comp,y1,err,ynz;
	Matrix a,ad,add,alpha,c,edge,fx,p,q,x,h;
	Matrix bb,y,ff,aa,wtx;
	Array daa,df,grids,one,des,wt,jj;
	Index sel,ll,iext;

	Real remezdd();

	error(nargchk(3, 5, nargs, "remez"));

	lgrid = 16;	// Grid density (should be greater than 16)
	nfilt = nfilt + 1;
	
	if (nargs < 3 || nargs > 5) {
		error("remez(): Incorrect number of input arguments.\n");
	}

	ff = ff_;
	aa = aa_;
	if (4 <= nargs) {
		wtx = wtx_;
	}
	if (nfilt < 4) {
		error("remez(): Filter order must be 3 or more.\n");
	}
	if (nargs == 4) {
		ftype = "f";
	}
	if (nargs < 4) {
		ftype = "f";
		wtx = ONE(Integer(fix((1 + max(Cols(aa), Rows(aa)))/2.0)),1);
	}
	if (rem(length(ff),2)) {
		error("remez(): Frequencies must be specified in bands.\n");
	}
	daa = diff(aa');
	if (any(daa(1:2:length(daa))) > 0) {
		error("remez(): Bands must be specified with constant magnitudes.\n");
	}
	
	if (ftype(1) == "h" || ftype(1) == "H") {
		jtype = 3;	// Hilbert transformer
	} else if (ftype(1) == "d" || ftype(1) == "D") {
		jtype = 2;	// Differentiator
	} else {
		jtype = 1;	// Regular filter
	}
	if (nargs > 3 && (max(Cols(wtx), Rows(wtx)) != 
					  Integer(fix((1+max(Cols(aa), Rows(aa)))/2.0)))) {
		error("remez(): There should be one weight per band.\n");
	}
	ha = 1;

	ff = makerowv(ff);
	aa = makerowv(aa);
	wtx = makerowv(wtx);
	{mf,nf} = size(ff);
	{ma,na} = size(aa);
	if (na != nf) {
		error("remez(): Frequency and amplitude vectors must be the same length.\n");
	}

	nbands = nf/2;
	jb = 2*nbands;
	if (jb != nf) {
		print jb, nf;
		error("remez(): The number of frequency points must be even.\n");
	}
	/*
	 * The following constraint is not necessary:
	 * if jtype != 3 && (abs(ff(1)) > EPS || abs(ff(jb) - 1) > EPS)
	 * error("The first frequency must be 0 and the last 1.\n");
	 * end
	 */
	if (jtype == 3 && ff(1) == 0.0) {
		error("remez(): The first frequency for a Hilbert transformer must not be 0.\n");
	}

	// interpolate break;points onto large grids(1)
	edge = ff;
	fx = aa(2:2:jb);

	df = diff(ff');
	if (any(df < 0)) {
		error("remez(): Frequencies must be non-decreasing.\n");
	}
	small = 0.05;		// Default minimum frequency transition
	for (k = 2; k <= jb-2; k = k + (2)) {
		if (edge(k) == edge(k+1)) {
			edge(k) = edge(k) - small;
			edge(k+1) = edge(k+1) + small;
		}
	}
	edge = edge/2;

	neg = 1 - (jtype == 1);
	nodd = rem(nfilt,2);
	nfcns = Integer(fix(nfilt/2.0));
	if (nodd == 1 && neg == 0) {
		nfcns = nfcns + 1;
	}

	grids = Z(1);
	grids(1) = edge(1);
	delf = 0.5/(lgrid*nfcns);
	if (neg != 0 && edge(1) < delf) {
		grids(1) = delf;
	}
	j = 1;
	l = 1;
	lband = 1;
	des = [];
	wt = [];
	while (lband <= nbands) {
		fup = edge(l+1);
		grids = [grids, [(grids(j)+delf):delf:(fup+delf)]];
		jend = max(Cols(grids), Rows(grids));
		grids(jend-1) = fup;
		sel = [j:jend-1];

		nsel = length(sel);
		one = ONE(1,nsel);
		if (length(des) < max(sel)) {
			des = [des, Z(1,max(sel)-length(des))];
		}
		if (length(wt) < max(sel)) {
			wt = [wt, Z(1,max(sel)-length(wt))];
		}
		des(sel) = fx(lband)*((grids(sel) .- 1)*(jtype == 2) .+ 1);
      	wt(sel) = wtx(lband)*one ./ (1 .+ ((jtype == 2) && fx(lband) >= .0001)*(grids(sel) .- 1));
		j = jend;
		lband = lband + 1;
		l = l + 2;
		if (lband <= nbands) {
			grids(j) = edge(l);
		}
	}
	ngrid_ = j - 1;
	if (neg == nodd && grids(ngrid_) > 0.5-delf) {
		ngrid_ = ngrid_ - 1;
	}
	if (neg <= 0) {
		if (nodd != 1) {
			des = des(1:ngrid_) ./ cos(PI*grids(1:ngrid_));
			wt = wt(1:ngrid_) .* cos(PI*grids(1:ngrid_));
		}
	} else if (nodd != 1) {
		des = des(1:ngrid_) ./ sin(PI*grids(1:ngrid_));
		wt = wt(1:ngrid_) .* sin(PI*grids(1:ngrid_));
	} else {
		des = des(1:ngrid_) ./ sin(2*PI*grids(1:ngrid_));
		wt = wt(1:ngrid_) .* sin(2*PI*grids(1:ngrid_));
	}
	temp = (ngrid_-1)/nfcns;
	jj = [1:nfcns];
	iext = fix(Array([[temp*(jj .- 1) .+ 1], [ngrid_]]))#;
	nm1 = nfcns - 1;
	nz = nfcns + 1;
	
	// Remez exchange loop
	itrmax = 25;
	devl = -1.0;
	nzz = nz + 1;
	niter = 0;
	jchnge = 1;
	jet = Integer(fix((nfcns - 1)/15.0)) + 1;

	iext = Z(1,nzz);
	ad = [];
	comp = 0.0;
	while (jchnge > 0) {
		iext(nzz) = ngrid_ + 1;
		niter = niter + 1;
		if (niter > itrmax) {
			break;
		}
		ll = iext(1:nz);
		x = cos(2*PI*grids(Array(ll)));
		
		if (length(ad) == 0) {
			ad = Z(1,nz);
		}
		for (nn = 1; nn <= nz; nn++) {
			ad(nn) = remezdd(nn, nz, jet, x);
		}
		add = ONE(ad);
		add(2:2:nz) = -add(2:2:nz);
		dnum = [ad*Matrix(des(ll))#](1);
		dden = [add*(ad ./ Matrix(wt(ll)))#](1);
		dev = dnum/dden;
		nu = 1;
		if (dev > 0.0) {
			nu = -1;
		}
		dev = -nu*dev;
		y = [des(ll) + Array(nu*dev*add) ./ wt(ll)];
		if (dev <= devl) {
			print "-- Failure to Converge --\n";
			print "Probable cause is machine rounding error.\n";
			if (niter > 3) {
				print "The number of iterations exceeds 3 but the design may be correct.\n";
				print "The design may be verified by looking at the frequency response.\n";
			}
			break;
		}
		devl = dev;
		jchnge = 0;
		k1 = iext(1);
		knz = iext(nz);
		klow = 0;
		nut = -nu;
		j = 1;
		flag34 = 1;

		while (j < nzz) {
			kup = iext(j+1);
			l = iext(j) + 1;
			nut = -nut;
			if (j == 2) {
				y1 = comp;
			}
			comp = dev;
			flag = 1;
			if (l < kup) {
				/* gee */
				c = ad ./ (cos(2*PI*grids(l)) .- x);  
				err = ([c*y#/sum(c)](1) - des(l))*wt(l);
				dtemp = nut*err - comp;
				if (dtemp > 0.0) {
					comp = nut*err;
					l = l + 1;
					while (l < kup) {
						/* gee */
						c = ad ./ (cos(2*PI*grids(l)) .- x);  
						err = ([c*y# / sum(c)](1) - des(l))*wt(l);
						dtemp = nut*err - comp;
						if (dtemp > 0.0) {
							comp = nut*err;
							l = l + 1;
						} else {
							break;
						}
					}    
					iext(j) = l - 1;
					j = j + 1;
					klow = l - 1;
					jchnge = jchnge + 1;
					flag = 0;
				}
			}
			if (flag) {
				l = l - 2;
				while (l > klow) {
					/* gee */
					c = ad ./ (cos(2*PI*grids(l)) .- x);  
					err = ([c*y# / sum(c)](1) - des(l))*wt(l);
					dtemp = nut*err - comp;
					if (dtemp > 0.0 || jchnge > 0) {
						break;
					}
					l = l - 1;
				}
				if (l <= klow) {
					l = iext(j) + 1;
					if (jchnge > 0) {
						iext(j) = l - 1;
						j = j + 1;
						klow = l - 1;
						jchnge = jchnge + 1;
					} else {
						l = l + 1;
						while (l < kup) {
							/* gee */
							c = ad ./ (cos(2*PI*grids(l)) .- x);  
							err = ([c*y# / sum(c)](1) - des(l))*wt(l);
							dtemp = nut*err - comp;
							if (dtemp > 0.0) {
								break;
							}
							l = l + 1;
						}
						if (l < kup && dtemp > 0.0) {
							comp = nut*err;
							l = l + 1;
							while (l < kup) {
								/* gee */
								c = ad ./ (cos(2*PI*grids(l)) .- x);  
								err = ([c*y# / sum(c)](1) - des(l))*wt(l);
								dtemp = nut*err - comp;
								if (dtemp > 0.0) {
									comp = nut*err;
									l = l + 1;
								} else {
									break;
								}
							}    
							iext(j) = l - 1;
							j = j + 1;	
							klow = l - 1;
							jchnge = jchnge + 1;
						} else {
							klow = iext(j);
							j = j + 1;
						}
					}
				} else if (dtemp > 0.0) {
					comp = nut*err;
					l = l - 1;
					while (l > klow) {
						/* gee */
						c = ad ./ (cos(2*PI*grids(l)) .- x);  
						err = ([c*y# / sum(c)](1) - des(l))*wt(l);
						dtemp = nut*err - comp;
						if (dtemp > 0.0) {
							comp = nut*err;
							l = l - 1;
						} else {
							break;
						}
					}
					klow = iext(j);
					iext(j) = l + 1;
					j = j + 1;
					jchnge = jchnge + 1;
				} else {
					klow = iext(j);
					j = j + 1;
				}
			}
		}
		while (j == nzz) {
			ynz = comp;
			k1 = Integer(min([k1, iext(1)]));
			knz = Integer(max([knz, iext(nz)]));
			nut1 = nut;
			nut = -nu;
			l = 0;
			kup = k1;
			comp = ynz*1.00001;
			luck = 1;
			flag = 1;
			l = l + 1;
			while (l < kup) {
				/* gee */
				c = ad ./ (cos(2*PI*grids(l)) .- x);  
				err = ([c*y# / sum(c)](1) - des(l))*wt(l);
				dtemp = err*nut - comp;
				if (dtemp > 0.0) {
					comp = nut*err;
					j = nzz;
					l = l + 1;
					while (l < kup) {
						/* gee */
						c = ad ./ (cos(2*PI*grids(l)) .- x);  
						err = ([c*y# / sum(c)](1) - des(l))*wt(l);
						dtemp = nut*err - comp;
						if (dtemp > 0.0) {
							comp = nut*err;
							l = l + 1;
						} else {
							break;
						}
					}    
					iext(j) = l - 1;
					j = j + 1;
					klow = l - 1;
					jchnge = jchnge + 1;
					flag = 0;
					break;
				}
				l = l + 1;
			}
			if (flag) {
				luck = 6;
				l = ngrid_ + 1;
				klow = knz;
				nut = -nut1;
				comp = y1*1.00001;
				l = l - 1;
				while (l > klow) {
					/* gee */
					c = ad ./ (cos(2*PI*grids(l)) .- x);  
					err = ([c*y# / sum(c)](1) - des(l))*wt(l);
					dtemp = err*nut - comp;
					if (dtemp > 0.0) {
						j = nzz;
						comp = nut*err;
						luck = luck + 10;
						l = l - 1;
						while (l > klow) {
							/* gee */
							c = ad ./ (cos(2*PI*grids(l)) .- x);  
							err = ([c*y# / sum(c)](1) - des(l))*wt(l);
							dtemp = nut*err - comp;
							if (dtemp > 0.0) {
								comp = nut*err;
								l = l - 1;
							} else {
								break;
							}
						}
						klow = iext(j);
						iext(j) = l + 1;
						j = j + 1;
						jchnge = jchnge + 1;
						flag = 0;
						break;
					}
					l = l - 1;
				}
				if (flag) {
					flag34 = 0;
					if (luck != 6) {
						iext = [[k1],iext(2:nz-nfcns),iext(nz-nfcns:nz-1)];
						jchnge = jchnge + 1;
					}
					break;
				}
			}
		}
		if (flag34 && j > nzz) { 
			if (luck > 9) {
				iext = [iext(2:nfcns+1),iext(nfcns+1:nz-1),[iext(nzz)],[iext(nzz)]];
				jchnge = jchnge + 1;
			} else {
				y1 = max([y1 comp]);
				k1 = iext(nzz);
				l = ngrid_ + 1;
				klow = knz;
				nut = -nut1;
				comp = y1*1.00001;
				l = l - 1;
				while (l > klow) {
					/* gee */
					c = ad ./ (cos(2*PI*grids(l)) .- x);  
					err = ([c*y#/sum(c)](1) - des(l))*wt(l);
					dtemp = err*nut - comp;
					if (dtemp > 0.0) {
						j = nzz;
						comp = nut*err;
						luck = luck + 10;
						l = l - 1;
						while (l > klow) {
							/* gee */
							c = ad ./ (cos(2*PI*grids(l)) .- x);  
							err = ([c*y#/sum(c)](1) - des(l))*wt(l);
							dtemp = nut*err - comp;
							if (dtemp > 0.0) {
								comp = nut*err;
								l = l - 1;
							} else {
								break;
							}
						}
						klow = iext(j);
						iext(j) = l + 1;
						j = j + 1;
						jchnge = jchnge + 1;
						iext = [iext(2:nfcns+1),iext(nfcns+1:nz-1),[iext(nzz)],[iext(nzz)]];
						break;
					}
					l = l - 1;
				}
				if (luck != 6) {
					iext = [[k1],iext(2:nz-nfcns),iext(nz-nfcns:nz-1)];
					jchnge = jchnge + 1;
				}
			}  
		}
	}
	
	// Inverse Fourier transformation
	nm1 = nfcns - 1;
	fsh = 1.0e-6;
	gtemp = grids(1);
	x(nzz) = -2;
	cn = 2*nfcns - 1;
	delf = 1/cn;
	l = 1;
	kkk = 0;
	if ((edge(1) == 0.0 && edge(jb) == 0.5) || nfcns <= 3) {
		kkk = 1;
	}
	if (kkk != 1) {
		dtemp = cos(2*PI*grids(1));
		dnum = cos(2*PI*grids(ngrid_));
		aa = [2/(dtemp - dnum)];
		bb = [-(dtemp+dnum)/(dtemp - dnum)];
	}
	a = [];
	for (j = 1; j <= nfcns; j++) {
		ft = (j-1)*delf;
		xt = cos(2*PI*ft);
		if (kkk != 1) {
			xt = [([xt] - bb)/aa](1);
			ft = acos(xt)/(2*PI);
		}
		xe = x(l);
		while (xt <= xe && xe-xt >= fsh) {
			l = l + 1;
			xe = x(l);
		}
		if (abs(xt-xe) < fsh) {
			a(j) = y(l);
		} else {
			grids(1) = ft;
			/* gee */
			c = ad ./ (cos(2*PI*ft) .- x(1:nz));  
			a(j) = [c*y#/sum(c)](1);
		}
		l = Integer(max([1, l-1]));
	}
	grids(1) = gtemp;
	dden = 2*PI/cn;
	alpha = [];
	for (j = 1; j <= nfcns; j++) {
		dnum = (j-1)*dden;
		if (nm1 < 1) {
			alpha(j) = a(1);
		} else {
			alpha(j) = a(1) + 2*[Matrix(cos(dnum*[1:nm1]))*a(2:nfcns)#](1);
		}
	}
	alpha = [[alpha(1)], 2*alpha(2:nfcns)]#/cn;
	p = [];
	q = [];
	if (kkk != 1) {
		p(1) = 2*alpha(nfcns)*[bb](1) + alpha(nm1);
		p(2) = 2*[aa](1)*alpha(nfcns);
		q(1) = alpha(nfcns-2) - alpha(nfcns);
		for (j = 2; j <= nm1; j++) {
			if (j == nm1) {
				aa = aa/2;
				bb = bb/2;
			}
			p(j+1) = 0;
			sel = [1:j];
			a(sel) = p(sel);
			p(sel) = 2*bb*a(sel);
			p(2) = p(2) + 2*a(1)*[aa](1);
			jm1 = j - 1;
			sel = [1:jm1];
			p(sel) = p(sel) + q(sel) + [aa](1)*a(sel .+ 1);
			jp1 = j + 1;
			sel = [3:jp1];
			p(sel) = p(sel) + aa*a(sel .- 1);
			if (j != nm1) {
				sel = [1:j];
				q(sel) = -a(sel);
				q(1) = q(1) + alpha(nfcns - 1 - j);
			}
		}
		alpha(1:nfcns) = p(1:nfcns);
	}
	if (nfcns <= 3) {
		alpha(nfcns + 1) = 0;
		alpha(nfcns + 2) = 0;
	}
	
	alpha = alpha#;

	// now that's done!

	if (neg <= 0) {
		if (nodd != 0) {
			h = [0.5*alpha(nz-1:-1:nz-nm1), [alpha(1)]];
		} else {
			h = 0.25*[[alpha(nfcns)], alpha(nz-2:-1:nz-nm1)+alpha(nfcns:-1:nfcns-nm1+2), [2*alpha(1)+alpha(2)]];
		}
	} else if (nodd != 0) {
		h = 0.25*[[alpha(nfcns)], [alpha(nm1)], alpha(nz-3:-1:nz-nm1)-alpha(nfcns:-1:nfcns-nm1+3), [2*alpha(1)-alpha(3)], [0]];
	} else {
		h = 0.25*[[alpha(nfcns)], alpha(nz-2:-1:nz-nm1)-alpha(nfcns:-1:nfcns-nm1+2), [2*alpha(1)-alpha(2)]];
	}
	lenh=max(Cols(h), Rows(h));
	h = [sgn(0.5-neg)*h(1:lenh-nodd) h(lenh:-1:1)];
	
	return {h,ha};
}


/* -*- MaTX -*-
 *
 *  NAME
 *      remezdd() - Lagrange interpolation coefficients
 *
 *  SYNOPSIS
 *      y = remezdd(k, n, m, x)
 *         Real y;
 *         Integer k,n,m;
 *         Matrix x;
 */

Func Real remezdd(k, n, m, x)
	Integer k, n, m;
	Matrix x;
{
	Integer l;
	Real y,q;
	Matrix xx,xl;
	
	if (length(x) == 0) {
		return 1.0;
	}

	y = 1.0;
	q = x(k);
	for (l = 1; l <= m; l++) {
		xl = x(l:m:n);
		xx = 2*(q .- xl);
		y = y*prod(xx(Array(xx) != 0));
	}
	y = 1.0/y;
	
	return y;
}
