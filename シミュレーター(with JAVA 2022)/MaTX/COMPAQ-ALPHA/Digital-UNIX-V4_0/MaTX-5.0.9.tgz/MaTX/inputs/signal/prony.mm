
/*  -*- MaTX -*-
 *
 *  NAME
 *      prony() - Prony's method for time-domain IIR filter design
 *
 *  SYNOPSIS
 *      {b,a} = prony(h,nb,na)
 *         Matrix b,a;
 *         Array h;
 *         Integer nb,na;
 *
 *  DESCRIPTION
 *      prony() finds a filter with numerator order NB, denominator order NA,
 *      and having the impulse response in vector H.   The IIR filter
 *      coefficients are returned in  length NB+1 and NA+1 row vectors B
 *      and A, ordered in descending powers of Z.
 *
 *	SEE ALSO
 *      butter(), cheby1(), cheby2(), ellip() and invfrez().
 *
 */

Func List prony(h,nb,na)
	Array h;
	Integer nb,na;
{
	Integer K,M,N;
	Matrix a,b,H,H1,H2,h1;

	K = length(h) - 1;
	M = nb;
	N = na;
	H = tril(toeplitz(h));	

	// K+1 by N+1
	if (K > N) {
		H(:,(N+2):(K+1)) = [];
	}

	// Partition H matrix
	H1 = H(1:(M+1),:);            // M+1 by N+1
	h1 = H((M+2):(K+1),1);        // K-M by 1
	H2 = H((M+2):(K+1),2:(N+1));  // K-M by N
	a = trans([[1][-H2\h1]]);
	b = a*trans(H1);

	return {b,a};
}
