
/* -*- MaTX -*-
 *
 *  NAME
 *      sawtooth() - Sawtooth wave generation
 *
 *  SYNOPSIS
 *      y = sawtooth(t)
 *         Array y;
 *         Array t;
 *
 *  DESCRIPTION
 *      sawtooth(t) generates a sawtooth wave with period 2*Pi for the
 *      elements of time vector t.  sawtooth(t) is like sin(t), only
 *      it creates a sawtooth wave with peaks of +1 to -1 instead of
 *      a sine wave.
 */

Func Array sawtooth(t)
	Array t;
{
	Array y;

	y = ((t < 0) + rem(t,2*PI)/2/PI .- 0.5)*2;
	return y;
}
