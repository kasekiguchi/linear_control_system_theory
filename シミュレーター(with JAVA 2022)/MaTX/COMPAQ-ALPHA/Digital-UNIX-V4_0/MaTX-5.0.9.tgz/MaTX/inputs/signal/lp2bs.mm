
/* -*- MaTX -*-
 *
 *  NAME
 *      lp2bs() - Lowpass to bandstop analog filter transformation
 *
 *  SYNOPSIS
 *     {At,Bt,Ct,Dt} = lp2bs(A,B,C,D,wo,bw)
 *        Matrix At,Bt,Ct,Dt;
 *        Matrix A,B,C,D;
 *        Real wo,bw;
 *
 *  DESCRIPTION
 *      lp2bs() transforms the lowpass filter with unity cutoff frequency
 *      to a bandstop filter with center frequency wo and bandwidth bw.
 *
 *  SEE ALSO
 *      lp2bp(), lp2hp() and lp2lop()
 */

Func List lp2bs(A,B,C,D,wo,bw)
	Matrix A,B,C,D;
	Real wo,bw;
{
	Matrix At,Bt,Ct,Dt;
	Integer ma,mc,nb;
	Real q;

	{ma,nb} = size(B);
	{mc,ma} = size(C);

	// Transform lowpass to bandstop
	q = wo/bw;
	At =  [[wo/q*A~, wo*I(ma)]
		   [-wo*I(ma),  Z(ma)]];
	Bt = -[[wo/q*(A\B)]
		   [Z(ma,nb)]];
	Ct = [C/A Z(mc,ma)];
	Dt = D - C/A*B;

	return {At,Bt,Ct,Dt};
}
