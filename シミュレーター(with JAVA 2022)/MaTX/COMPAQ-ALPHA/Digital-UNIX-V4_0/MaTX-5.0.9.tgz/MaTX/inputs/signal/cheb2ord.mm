
/* -*- MaTX -*-
 *
 *  NAME
 *      cheb2ord() - Chebyshev type II filter order selection
 *
 *  SYNOPSIS
 *      {n,Wn} =  cheb2ord(wp,ws,rp,rs)
 *          Integer n;
 *          Array Wn;
 *          Matrix wp,ws;
 *          Real rp,rs;
 *
 *      {n,Wn} =  cheb2ord(wp,ws,rp,rs,opt)
 *          Integer n;
 *          Array Wn;
 *          Matrix wp,ws;
 *          Real rp,rs;
 *          String opt;
 *
 *  DESCRIPTION
 *      cheb2ord() returns the order n of the lowest order digital Chebyshev
 *      type I filter that loses no more than Rp dB in the passband and has
 *      at least Rs dB of attenuation in the stopband.  The passband runs 
 *      from 0 to Wp and the stopband extends from Ws to 1.0, the Nyquist
 *      frequency.  cheb2ord() also returns Wn, the Chebyshev natural
 *      frequency to use with cheby2() to achieve the specifications.
 *
 *      cheb1ord(..., "s") does the computation for an analog filter.
 *
 *  SEE ALSO
 *      cheby2(), buttord(), ellipord() and cheb1ord().
 *
 */

Func List cheb2ord(wp,ws,rp,rs,opt, ...)
	Matrix wp,ws;
	Real rp,rs;
	String opt;
{
	Array Wn,Ws,Wp,Rs,Rp,epsilon,order,k,k1;
	Array alpha,denom,kk,numer,tnwp,tnws;
	Integer i,n,ftype,np1,ns1;

	error(nargchk(4, 5, nargs, "cheb2ord"));
	
	if (nargs == 4) {
		opt = "z";
	} else if (nargs == 5) {
		if (opt != "z" && opt != "s") {
			error("cheb2ord(): Invalid option for final argument.\n");
		}
	}

	np1 = length(wp);
	ns1 = length(ws);
	if (np1 != ns1) {
		error("cheb2ord(): The frequency vectors must both be the same length.\n");
	}

	// Figure out filter type
	ftype = 2*(np1 - 1);
	if (wp(1) < ws(1)) {
		ftype = ftype + 1;	// low (1) or reject (3)
	} else {
		ftype = ftype + 2;	// high (2) or pass (4)
	}
	if (np1 == 2) {
		Rs = rs*ONE(1,np1);
		Rp = rp*ONE(1,np1);
	} else {
		Rs = [rs];
		Rp = [rp];
	}

	// Convert temporarily to low pass
	Wp = wp;
	Ws = ws;

	switch (ftype) {
	  case 2: // high
		wp = 1 .- wp;
		ws = 1 .- ws;
		break;
	  case 3: // stop
		wp(2) = 1 - wp(2);
		ws(2) = 1 - ws(2);
		break;
	  case 4: // pass
		wp(1) = 1 - wp(1);
		ws(1) = 1 - ws(1);
		break;
	}

	epsilon = sqrt(10^(0.1*Rp) .- 1);
	tnws = tan(PI*Ws/2);
	tnwp = tan(PI*Wp/2);

	if (opt == "z") {  // digital
		k = tnwp/tnws;
	} else {
		k = Wp/Ws;     // analog
	}
	k1 = epsilon/sqrt(10 ^ (0.1*Rs) .- 1);
	denom = log((1 .+ sqrt(1 .- k^2))/k);
	numer = acosh(1 / k1);
	order = ceil(numer/denom);

	// Now find appropriate frequency
	alpha = exp(numer/order);
	kk = 2*alpha/(alpha^2 .+ 1);
	Wn = 2 * atan(tnwp/kk) / PI;

	// Reconvert from low pass
	switch (ftype) {
	  case 2: // high
		Wn = 1 .- Wn;
		n = Integer(order(1));
		break;
	  case 3: // stop
		{n} = maximum(order);
		Wn(2) = 1 - Wn(2);
		break;
	  case 4: // pass
		{n} = maximum(order);
		Wn(1) = 1 - Wn(1);
		break;
	  default:
		n = Integer(order(1));
		break;
	}

	return {n,Wn};
}

