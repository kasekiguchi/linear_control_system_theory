
/*  -*- MaTX -*-
 *
 *  NAME
 *      invfreqz() - The inverse operation of freqz()
 *
 *  SYNOPSIS
 *      {B,A} = invfreqz(H,F,nB,nA)
 *         Matrix B,A;
 *         CoArray H;
 *         Array F;
 *         Integer nB;
 *         Integer nA;
 *
 *      {B,A} = invfreqz(H,F,nB,nA,W)
 *         Matrix B,A;
 *         CoArray H;
 *         Array F;
 *         Integer nB;
 *         Integer nA;
 *         Array W;
 *
 *  DESCRIPTION
 *      invfreqz() converts magnitude and phase data into a
 *      discrete-time Z-transform transfer function.
 *      invfreqz() returns the numerator and denominator coefficients 
 *      in vectors B and A of the transfer function whose complex 
 *      frequency response is given in vector H at the frequency points
 *      specified in vector W.
 *      Scalars nb and na specify the desired orders of the numerator
 *      and denominator polynomials.  Frequency is specified in radians/s
 *      between zero and Pi, and length(W) = length(H).
 *
 *      invfreqs(H,W,nb,na,Wt) allows the fit-errors to be;
 *      weighted versus frequency. length(Wt) = length(W).
 *      Here is an example that converts magnitude and phase data
 *      into a transfer function and plots the actual and estimated
 *      responses:
 *
 *   	  {b,a} = invfreqz(mag.*exp((0,1)*phase),W,2,3);
 *   	  mgplot_loglog(1,w,mag);
 *        mgplot_loglog(2,w,abs(freqz(b,a,w)))
 *
 *	SEE ALSO
 *      freqz(), freqs() and invfreqs().
 *
 */

Func List invfreqz(H,F,nB,nA,W, ...)
	CoArray H;
	Array F;
	Integer nB,nA;
	Array W;
{
	Integer k,mA,mB,n,nF,m;
	Complex Hk,aHks;
	Matrix A,B,P,Pu,Py,R,Rk,Ruu,Ryu,Ryy,Theta,Zk,rRk;
	CoMatrix s;

	error(nargchk(4, 5, nargs, "invfreqz"));

	n = max(nA,nB);
	m = n + 1;
	mA = nA + 1;
	mB = nB + 1;
	nF = length(F);

	if (nF != length(H)) {
		error("invfreqz(): The length of H and F must be the same.\n");
	}
	if (nargs < 5) {
		W = ONE(1,nF);
	}

	Ruu = Z(mB,mB);
	Ryy = Z(nA,nA);
	Ryu = Z(nA,mB);
	Pu = Z(mB,1);
	Py = Z(nA,1);
	s = exp(-(0,1)*F);

	for (k = 1; k <= nF; k++) {
		Zk = (s(k)^[0:n])';
		Hk = H(k);
		aHks = Hk*conj(Hk);
		Rk = (W(k)*Zk)*Zk#;
		rRk = Re(Rk);
		Ruu = Ruu + rRk(1:mB,1:mB);
		Ryy = Ryy + aHks*rRk(2:mA,2:mA);
		Ryu = Ryu + Re(Hk*Rk(2:mA,1:mB));
		Pu = Pu + W(k)*Re(conj(Hk)*Zk(1:mB));
		Py = Py + (W(k)*aHks)*Re(Zk(2:mA));
	}

	R = [[Ruu,-Ryu#][-Ryu,Ryy]];
	P = [[Pu][-Py]];
	Theta = R \ P;
	B = Theta(1:mB)#;
	A = [[1], Theta(mB+1:mB+nA)#];

	return {Re(B),Re(A)};
}
