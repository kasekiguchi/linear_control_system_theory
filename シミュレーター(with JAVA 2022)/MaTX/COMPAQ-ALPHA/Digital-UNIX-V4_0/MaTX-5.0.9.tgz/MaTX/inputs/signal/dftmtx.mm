
/* -*- MaTX -*-
 *
 *  NAME
 *      dftmtx() - Discrete Fourier transform matrix
 *
 *  SYNOPSIS
 *      b = dftmtx(n)
 *         Array b;
 *         Integer n;
 *
 *  DESCRIPTION
 *      dftmtx(n) is the n-by-n complex matrix of values around
 *      the unit-circle whose inner product with a column vector
 *      of length n yields the discrete Fourier transform of the
 *      vector.
 *
 *      dftmtx(length(X))*X is the same as fft(X).
 *      The inverse discrete Fourier transform matrix is conj(dftmtx(N))/N.
 *
 *  SEE ALSO
 *      fft() and ifft().
 */

Func Array dftmtx(n)
	Integer n;
{
	Real f;
	Complex j;
	Array w,x,b;

	j = (0,1);
	f = 2*PI/n;              // Angular increment
	w = [0:f:2*PI-f/2] * j;  // Column
	x = [0:n-1];             // Row
	b = exp(-w*x);           // Exponentiation of outer product
	return b;
}
