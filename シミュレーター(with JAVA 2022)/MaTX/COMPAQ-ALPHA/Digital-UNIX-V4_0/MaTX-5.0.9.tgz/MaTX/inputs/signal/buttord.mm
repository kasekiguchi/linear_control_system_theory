
/* -*- MaTX -*-
 *
 *  NAME
 *      buttord() - Butterworth filter order selection
 *
 *  SYNOPSIS
 *      {n,Wn} = buttord(Wp,Ws,rp,rs)
 *          Integer n;
 *          Array Wn;
 *          Array Wp,Ws;
 *          Real rp,rs;
 *
 *      {n,Wn} = buttord(Wp,Ws,rp,rs,opt)
 *          Integer n;
 *          Array Wn;
 *          Array Wp,Ws;
 *          Real rp,rs;
 *          String opt;
 *
 *  DESCRIPTION
 *      buttord() returns the order n of the lowest order digital
 *      Butterworth filter that loses no more than Rp dB in the passband
 *      and has at least Rs dB of attenuation in the stopband.  The 
 *      passband runs from 0 to Wp and the stopband extends from Ws to
 *      1.0, the Nyquist frequency.
 *
 *      buttord() also returns  Wn, the Butterworth natural frequency to 
 *      use with butter() to achieve the specifications.  
 *      buttord(..., "s") does the computation for an analog filter.  When 
 *      Rp is chosen as 3 dB, the Wn in butter() is equal to Wp in buttord().
 *
 *   SEE ALSO
 *       butter(), cheb1ord(), ellipord(), cheb2ord() and ellipord().
 *
 */


Func List buttord(Wp_,Ws_,rp,rs,opt, ...)
	Array Wp_,Ws_;
	Real rp,rs;
 	String opt;
{
	Array Rs, Rp, Wp, Ws, Wn;
	Array k1, tnws, k, kp, lk1, lk2, order;
	Integer i,ftype,np1,ns1,io,n;

	error(nargchk(4, 5, nargs, "buttord"));
	
	if (nargs == 4) {
		opt = "z";
	} else if (nargs == 5) {
		if (opt != "z" && opt != "s") {
			error("buttord(): Invalid option for final argument.\n");
		}
	}

	Wp = Wp_;
	Ws = Ws_;

	np1 = length(Wp);
	ns1 = length(Ws);
	if (np1 != ns1) {
		error("buttord(): The frequency vectors must both be the same length.\n");
	}
	ftype = 2*(np1 - 1);
	if (Wp(1) < Ws(1)) {
		ftype = ftype + 1;	// low (1) or reject (3)
	} else {
		ftype = ftype + 2;	// high (2) or pass (4)
	}
	if (np1 == 2) {
		Rs = rs*ONE(1,np1);
		Rp = rp*ONE(1,np1);
	} else {
		Rs = [rs];
		Rp = [rp];
	}

	// convert temporarily to low pass
	Wp = Wp;
	Ws = Ws;
	if (ftype == 2)	{        // high
		Wp = 1 .- Wp;
		Ws = 1 .- Ws;
	} else if (ftype == 3) { // stop
		Wp(2) = 1 - Wp(2);
		Ws(2) = 1 - Ws(2);
	} else if (ftype == 4) { // pass
		Wp(1) = 1 - Wp(1);
		Ws(1) = 1 - Ws(1);
	}

	k1 = sqrt((10 ^ (0.1*abs(Rp)) .- 1)/(10 ^ (0.1*abs(Rs)) .- 1));
	tnws = tan(PI*Ws/2);

	if (opt == "z") {  // digital
		k = tan(PI*Wp/2)./tnws;
	} else {
		k = Wp/Ws;	   // analog
	}
	lk1 = log10(k1);
	order = ceil(lk1 / log10(k));
	lk2 = log10(sqrt((10 ^ (0.1*3) - 1)/(10 ^ (0.1*abs(Rs)) .- 1)));
	kp = 10 ^ (lk2 / order);
	Wn = 2 * atan(kp*tnws) / PI;

	// reconvert from low pass
	if (ftype == 2) {        // high
		Wn = 1 .- Wn;
		n = Integer(order(1));
	} else if (ftype == 3) { // stop
		{n,io} = maximum(order);	
		Wn(3-io) = Wp(3-io); // replace lower order Wn with Wp
		Wn(2) = 1 - Wn(2);
	} else if (ftype == 4) { // pass
		{n,io} = maximum(order);	
		Wn(3-io) = Wp(3-io); // replace lower order Wn with Wp
		Wn(1) = 1 - Wn(1);
	}
	
	return {n,Wn};
}
