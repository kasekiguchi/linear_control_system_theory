
/*  -*- MaTX -*-
 *
 *  NAME
 *      cheb1ord() - Chebyshev type I filter order selection
 *
 *  SYNOPSIS
 *      {n,Wn} =  cheb1ord(wp,ws,rp,rs)
 *          Integer n;
 *          Array Wn;
 *          Matrix wp,ws;
 *          Real rp,rs;
 *
 *      {n,Wn} =  cheb1ord(wp,ws,rp,rs,opt)
 *          Integer n;
 *          Array Wn;
 *          Matrix wp,ws;
 *          Real rp,rs;
 *          String opt;
 *
 *  DESCRIPTION
 *      cheb1ord() returns the order n of the lowest order digital Chebyshev
 *      type I filter that loses no more than rp dB in the passband and has
 *      at least rs dB of attenuation in the stopband.  The passband runs
 *      from 0 to Wp and the stopband extends from Ws to 1.0, the Nyquist
 *      frequency.
 *
 *      cheb1ord() also returns Wn, the Chebyshev natural frequency to use 
 *      with cheby1() to achieve the specifications.
 *
 *      cheb1ord(..., "s") does the computation for an analog filter.
 *
 *   SEE ALSO
 *      cheby1(), buttord(), ellipord() and cheb2ord().
 *
 */

Func List cheb1ord(wp,ws,rp,rs,opt, ...)
	Matrix wp,ws;
	Real rp,rs;
	String opt;
{
	Integer i,n,ftype,np1,ns1;
	Array Wp,Ws,Wn,Rs,Rp,k,k1,order,epsilon;

	error(nargchk(4, 5, nargs, "cheb1ord"));

	if (nargs == 4) {
		opt = "z";
	} else if (nargs == 5) {
		if (opt != "z" && opt != "s") {
			error("cheb1ord(): Invalid option for final argument.\n");
		}
	}

	np1 = length(wp);
	ns1 = length(ws);
	if (np1 != ns1) {
		error("cheb1ord(): The frequency vectors must both be the same length.\n");
	}
	ftype = 2*(np1 - 1);

	if (wp(1) < ws(1)) {
		ftype = ftype + 1;	// low (1) or reject (3)
	} else {
		ftype = ftype + 2;	// high (2) or pass (4)
	}
	if (np1 == 2) {
		Rs = rs*ONE(1,np1);
		Rp = rp*ONE(1,np1);
	} else {
		Rs = [rs];
		Rp = [rp];
	}

	// Convert temporarily to low pass
	Wp = wp;
	Ws = ws;
	
	switch (ftype) {
	  case 2: // high
		Wp = 1 .- Wp;
		Ws = 1 .- Ws;
		break;
	  case 3: // stop
		Wp(2) = 1 - Wp(2);
		Ws(2) = 1 - Ws(2);
		break;
	  case 4: // pass
		Wp(1) = 1 - Wp(1);
		Ws(1) = 1 - Ws(1);
		break;
	}

	epsilon = sqrt(10^(0.1*Rp) .- 1);
	k1 = epsilon/sqrt(10^(0.1*Rs) .- 1);

	if (opt == "z") {  // digital
		k = tan(PI*Wp/2)/tan(PI*Ws/2);
		order = ceil(acosh(1 / k1) / (log((1 .+ sqrt(1 .- k^2))/k)));
	} else {
		k = Wp/Ws;    // analog
		order = ceil(acosh(1 / k1)/(acosh(1/k)));
	}

	Wn = Wp;

	// Reconvert from low pass
	switch (ftype) {
	  case 2:  // high
		n = Integer(order(1));
		Wn = 1 .- Wn;
		break;
	  case 3: // stop
		{n} = maximum(order);	
		Wn(2) = 1 - Wn(2);
		break;
	  case 4: // pass
		{n} = maximum(order);	
		Wn(1) = 1 - Wn(1);
		break;
	  default:
		n = Integer(order(1));
		break;
	}

	return {n,Wn};
}
