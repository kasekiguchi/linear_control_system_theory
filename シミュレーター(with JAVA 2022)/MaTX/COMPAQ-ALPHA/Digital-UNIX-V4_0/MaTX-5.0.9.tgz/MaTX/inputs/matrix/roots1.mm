
/*  -*- MaTX -*-
 *
 *  NAME
 *      roots1() - Find polynomial roots using Laguerre's method
 *
 *  SYNOPSIS
 *      {xx,iterations} = roots1(aa)
 *         Matrix xx;
 *         Integer iterations;
 *         Matrix aa;
 *
 *  DESCRIPTION
 *      roots1(C) computes the roots of the polynomial whose coefficients
 *      are the elements of the vector C.  If C has N+1 components, the 
 *      polynomial is   C(1)*X^N + ... + C(N)*X + C(N+1).
 *
 *      The XX are roots of polynomial AA, found by iterative application
 *      of Laguerre's method.  Works row-wise on a matrix, and returns
 *      all roots as columns.  iterations is the number of Laguerre steps
 *      taken to extract all the roots.
 *
 *  SEE ALSO
 *      roots(), poly(), laguer() and roots().
 *
 *  REFERENCE
 *      [1] W.H. Press et al., "Numerical Recipes", Cambridge University
 *          Press, 1986.
 */

Func List roots1(aa)
	Matrix aa;
{
	Matrix xx, asave,b,bsave,xsave;
	Integer i,j,k,m,n,oldm,iter,iterations;
	Complex x;
	Index idx;

	// Initialization.
	iterations = 0;
	asave = aa#;
	{m, n} = size(asave);
	oldm = m;
	if (m == 1) {
		asave = asave#;     // Non-conjugate transpose
		{m, n} = size(asave);
	}
	xsave = (Z(m-1,n),:);

	// Loop over all columns.
	for (j = 1; j <= n; j = j + (1)) {
		b = asave(:,j:j);

		// Shift until highest-order term is non-zero.
		k = Rows(b);
		if (any(Array(b)) != 0) {
			while (b(1) == 0.0) {
				b = b(2:k);
				k = Rows(b);
			}
		} else {
			b = [];
			k = 0;
		}
		
		// Save original polynomial.
		bsave = b;
		
		// Find one root; deflate before finding next.
		k = Rows(b);
		for (i = k-1; i >= 1; i--) {
			x = Complex(0);
			if (b(2) == 0.0) {
				x = 1 + (0,1);
			}
			{x, iter} = laguer(b, x, 0.0, 0.0);
			xsave(i,j) = x;
			iterations = iterations + iter;
			{b} = deconv(b, [[1][-x]]);
		}
		
		// Polish each root, using the full polynomial.
		k = Rows(b);
		for (i = k-1; i >= 1; i--) {
			x = xsave(i,j);
			{x, iter} = laguer(b, x, 0.0, 1.0);
			xsave(i,j) = x;
			iterations = iterations + iter;
		}
	}
	{xx, idx} = sort(xsave .* conj(xsave));
	xx = xsave(idx);   // Descending sort
	return {xx, iterations};
}

