
/* -*- MaTX -*-
 *
 *  NAME
 *      kronprod() - Kronecker product
 *
 *  SYNOPSIS
 *      K = kronprod(A, B)
 *         Matrix K;
 *         Matrix A, B;
 *
 *  DESCRIPTION
 *      kronprod(A,B) is the Kronecker tensor product of A and B.
 *      The result is a large matrix formed by taking all possible
 *      products between the elements of X and those of B.
 *
 *      For example, if A is 2 by 3, then kronprod(A,B) is
 *
 *       [[A(1,1)*B  A(1,2)*B  A(1,3)*B]
 *        [A(2,1)*B  A(2,2)*B  A(2,3)*B]]
 *
 */

Func Matrix kronprod(A, B)
	Matrix A, B;
{
	Integer i, j, m, n;
	Matrix K;

	{m, n} = size(A);
	K = Z(m, n, B);
	if (version() == 4) {
		for (i = 0; i < m; i++) {
			for (j = 0; j < n; j++) {
				K(i, j, B) = A(i+1, j+1)*B;
			}
		}
	} else {
		for (i = 1; i <= m; i++) {
			for (j = 1; j <= n; j++) {
				K(i, j, B) = A(i+1, j+1)*B;
			}
		}
	}
	return K;
}
