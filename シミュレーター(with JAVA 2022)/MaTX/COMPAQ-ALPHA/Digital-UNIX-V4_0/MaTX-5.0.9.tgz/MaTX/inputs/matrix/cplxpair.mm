
/*  -*- MaTX -*-
 *
 *  NAME
 *      cplxpair() - Sort numbers into complex conjugate pairs
 *
 *  SYNOPSIS
 *      y = cplxpair(x)
 *         CoMatrix y;
 *         CoMatrix x;
 *
 *      y = cplxpair(x, tol)
 *         CoMatrix y;
 *         CoMatrix x;
 *         Real tol;
 *
 *  DESCRIPTION
 *      cplxpair(X) rearranges the elements of vector X so that
 *      complex numbers are collected into matched pairs of complex
 *      conjugates.  The pairs are ordered by increasing real part.
 *      Any purely real elements are placed after all the complex pairs.
 *
 *      cplxpair(X,tol) uses a relative tolerance of tol for
 *      comparison purposes. Default value is EPS*100.
 */

Func CoMatrix cplxpair(x0, tol, ...)
	CoMatrix x0;
	Real tol;
{
	Integer ip,m,n,nc,nn,np,nr,nz;
	Matrix xtemp,c,cc,r,xi,xtmp;
	Index cind,xind,ir,ij,ii;
	CoMatrix x,z;
	Complex j;

	error(nargchk(1, 2, nargs, "cplxpair"));

	j = (0,1);
	x = x0;

	if (nargs == 1) {
		tol = 100*EPS;	// need to give a tolerance more generous than EPS
	}

	{m,n} = size(x);
	z  = Z(x);          // return z; number in same shape vector as input
	x = reshape(x, length(x), 1);   // make sure x is a column vector
	nz = max(Cols(z), Rows(z));

	// first segregate reals
	ir = find(abs(Im(Array(x))) <= tol*abs(Array(x)));
	nr = length(ir);

	if (nr != 0) {
		{r} = sort(Re(x(ir))); // return sorted reals first
		x(ir) = [];			   // remove these values from input array
	}
	nc = max(Cols(x), Rows(x));

	if (nc == 0) { // no complex numbers
		z = r;
		return z;
	}
	if (rem(nc,2)) {
		error("cplxpair(): Complex numbers can't be paired\n");
	}

	// copy complex x to a work vector c
	c = x;
	np = nc/2;	// number of pairs supposedly
	
	// get values to upper half plane
	c = Re(c) + j*abs(Im(c));

	// ordered by real part (since sort is very sensitive to magnitudes)
	{cc, cind} = sort(Re(c));
	c = cc + j*Im(c(cind));

	// check to see if real parts are at least in pair

	if (any(abs(Array(cc(1:2:nc)-cc(2:2:nc))) > tol*abs(Array(c(1:2:nc))))) {
		error("cplxpair(): Complex numbers can't be paired\n");
	}
	x = x(cind); // reorder x the same way c has been

	/*
	 * Check real part pairs to see if imag parts are paired by conjugates
	 * be careful with multiple roots!
	 */

	ip = 1;	// initialize pair counter

	while (ip <= np) {
		/*
		 * Find indices for same real parts -
		 * but be careful because a real part can be 0
		 */
		ii = find(abs(Array(Re(c(1:2:nc)) .- Re(c(2*ip))))
				  <= tol*abs(c(2*ip)));

		if (length(ii) == 0) {
			error("cplxpair(): Complex numbers can't be paired\n");
		}
		if (length(ii) > 1) {
			/*
			 *	Multiple pairs with same real part -
			 *	sort on Im(c(ii)) for all with real part
			 *	ij below are indices with same real part
			 */

			ij = find(abs(Array(Re(c(1:nc)) .- Re(c(2*ip))))
					  <= tol*abs(c(2*ip)));

			nn = max(1,length(ij));
			xtemp = x(ij);
			{xi, xind} = sort(Im(xtemp));

			// sort on imag parts - should be paired
			xtemp = xtemp(xind);

			// check pairing
			if (any(abs(Array(xtemp-conj(xtemp(nn:-1:1)))) > tol*abs(Array(xtemp)))) {
				error("cplxpair(): Complex numbers can't be paired\n");
			} else {
				x(ij(1):2:ij(nn-1)) = xtemp(1:nn/2);
				x(ij(2):2:ij(nn)) = conj(xtemp(1:nn/2));
			}
		} else {	// only one pair with that real part
			if (Re(x(2*ip) - conj(x(2*ip-1))) > tol*abs(x(2*ip))) {
				error("cplxpair(): Complex numbers can't be paired\n");
			} else {
				xtmp = [Re(x(2*ip)) - (0,1)*abs(Im(x(2*ip)))];
				x(2*ip-1:2*ip) = [[xtmp][conj(xtmp)]];
			}
		}

		ip = ip + length(ii);	// increment pair counter
	}

	// copy complex pairs into return z vector
	if (nc) {
		z(1:nc,1) = x(1:nc);
	}

	// append reals to this
	if (nr) {
		z(nc+1:nc+nr,1) = r;
	}
	return z;
}

