
/*  -*- MaTX -*-
 *
 *  NAME
 *      gammai() - Incomplete Gamma function
 *
 *  SYNOPSIS
 *     gam = gammai(a, x)
 *       Real gam;
 *       Real a, x;
 *
 *  DESCRIPTION
 *      gammai(A,X) returns the value of the incomplete Gamma function
 *      for every element of A, integrated to scalar limit X.
 *
 *  REFERENCES
 *      [1] W.H. Press et al, Numerical Recipes, Cambridge Univ.
 *	        Press, 1986.
 */

Func Real gammai(a, x)
	Real a, x;
{
	Integer itmax,n;
	Array gg;
	Real anf,fac,g,del,epss,gln,sum_;
	Real a0,b0,ana,b,b1,gold,a1,ap;

	itmax = 100;
	epss = EPS;

	gg = gammafnc([a]);
	gln = [log(gg)](1);

	if (x < a+1) {
		if (x <= 0.0) {
			b = 0.;
			return b;
		}
		ap = a;   // Series expansion method
		sum_ = 1/a;
		del = sum_;
		for (n = 1; n <= itmax; n++) {
			ap = ap+1;
			del = del*x/ap;
			sum_ = sum_+del;
			if (abs(del) < abs(sum_)*epss) {
				break;
			}
		}
		b = sum_*exp(-x+a*log(x)-gln);
	} else {
		gold = 0.;   // Continued-fraction method
		a0 = 1.0;
		a1 = x;
		b0 = 0.0;
		b1 = 1.0;
		fac = 1.0;
		for (n = 1; n <= itmax; n++) {
			ana = n-a;
			a0 = (a1+a0*ana)*fac;
			b0 = (b1+b0*ana)*fac;
			anf = n*fac;
			a1 = x*a0+anf*a1;
			b1 = x*b0+anf*b1;
			if (anf != 0.0) {
				fac = 1/a1;
				g = b1*fac;
				if (abs(g-gold)/g < epss) {
					break;
				}
			}
		}
		b = 1 - exp(-x+a*log(x)-gln)*g;
	}
	return b;
}
