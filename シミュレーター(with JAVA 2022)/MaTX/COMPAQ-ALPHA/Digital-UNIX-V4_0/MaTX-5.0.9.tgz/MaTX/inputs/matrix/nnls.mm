
/*  -*- MaTX -*-
 *
 *  NAME
 *      nnls() - Non-negative least-squares
 *
 *  SYNOPSIS
 *      {w,x} = nnls(A,b)
 *             Matrix w,x;
 *             Matrix A,b;
 *
 *      {w,x} = nnls(A,b,tol)
 *             Matrix w,x;
 *             Matrix A,b;
 *             Real tol;
 *
 *  DESCRIPTION
 *      nnls() returns the vector x that solves A*x = b
 *      in a least squares sense, subject to x >= 0. 
 *
 *      A tolerance (tol) is used for deciding when elements of
 *      x are less than zero.
 *
 *      nnls() also returns dual vector w where w(i) < 0
 *      where x(i) = 0 and w(i) = 0 where x(i) > 0.
 *
 *  REFERENCE
 *     [1] Lawson and Hanson, "Solving Least Squares Problems",
 *         Prentice-Hall, 1974.
 */

Func List nnls(EE,f,tol, ...)
	Matrix EE,f;
	Real tol;
{
	Matrix w,x,EP,P,z;
	Integer iter,m,n,itmax,t,tt;
	Real alpha,wt;
	Index PP,QQ,ij,ZZ,Z_Z,nzz;

	error(nargchk(2, 3, nargs, "nnls"));

	// Initialize variables
	if (nargs < 3) {
		tol = 10*EPS*norm(EE,1)*length(EE);
	}
	{m,n} = size(EE);
	P = Z(1,n);
	Z_Z = [1:n];
	x = P#;
	ZZ = Z_Z;
	w = EE# * (f - EE*x);

	// Set up iteration criterion
	iter = 0;
	itmax = 3*n;

	EP = Z(m,length(ZZ));

	// Outer loop to put variables into set to hold positive coefficients
	while (any(Z_Z) && any(Array(w(ZZ)) > tol)) {
		{wt,tt,t} = maximum(w(ZZ));
		t = ZZ(t);
		P(1,t) = t;
		Z_Z(t) = 0;
		PP = find(P);
		ZZ = find(Array(Z_Z));
		nzz = Index([length(ZZ), min(1,length(ZZ))]);
		EP(1:m,PP) = EE(:,PP);
		EP(:,ZZ) = Z(m,nzz(2));
		z = pseudoinv(EP)*f;
		z(ZZ) = Z(nzz(2),nzz(1));

		// Inner loop to remove elements from the positive
		// Set which no longer belong
		while (any((Array(z(PP)) <= tol))) {
			iter = iter + 1;
			if (iter > itmax) {
				error("nnls(): Quitting because iteration count is exceeded.\nTry raising the tolerance.");
			}
			QQ = find((z .<= tol) && Array(P)#);
			alpha = min(x(QQ) ./ (x(QQ) - z(QQ)));
			x = x + alpha*(z - x);
			ij = find(abs(Array(x)) < tol && Array(P)# != 0);
			Z_Z(ij) = ij;
			P(ij) = Z(1,length(ij));
			PP = find(P);
			ZZ = find(Array(Z_Z));
			nzz = Index([length(ZZ), min(1,length(ZZ))]);
			EP(1:m,PP) = EE(:,PP);
			EP(:,ZZ) = Z(m,nzz(2));
			z = pseudoinv(EP)*f;
			z(ZZ) = Z(nzz(2),nzz(1));
		}
		x = z;
		w = EE# * (f-EE*x);
	}

	return {x,w};
}
