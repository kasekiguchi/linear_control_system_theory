
/*  -*- MaTX -*-
 *
 *  NAME
 *      interp2() - 1-D biharmonic data interpolation
 *
 *  SYNOPSIS
 *      {yi, weights} = interp2()
 *          Matrix yi, weights;
 *
 *      {yi, weights} = interp2(x,y,xi)
 *          Matrix yi, weights;
 *          Matrix x;
 *          Matrix y;
 *          Matrix xi;
 *
 *      {yi, weights} = interp2(x,y,xi,weights)
 *          Matrix yi, weights;
 *          Matrix x;
 *          Matrix y;
 *          Matrix xi;
 *          Matrix weights;
 *
 *  DESCRIPTION
 *      Given data vectors X and Y, and a new abscissa vector XI, the
 *      function YI = interp2(X,Y,XI) uses biharmonic interpolation
 *      to find a vector YI corresponding to XI.
 *
 *      Here's an example that generates a coarse sine curve, then
 *      interpolates over a finer abscissa:
 *
 *   		x = [0:10];
 *          y = sin(x);
 *   		xi = [0:.25:10];
 *   		{yi} = interp2(x,y,xi);
 *   		mgplot(win,x,y);
 *          mgreplot(win,xi,yi);
 *
 *      interp2() also returns the interpolation weights, which can
 *      be reused as follows:  interp2(...,weights) uses the given 
 *      weights vector instead of recalculating them from X and Y.
 *
 *      interp2() called with no arguments will interpolate and
 *      plot some random (x,y) values.
 *
 *  SEE ALSO
 *      spline() and interp1().
 *
 */

Func List interp2(x_,y_,xi_,weights_, ...)
	Matrix x_,y_,xi_;
	Matrix weights_;
{
	Matrix x,y,xi,weights;
	Matrix Green,xim,xm,d,g,yi;
	Integer i,im,in,m,win;

	error(nargchk(0, 4, nargs, "interp2"));

	if (1 <= nargs) {
		x = x_;
	}
	if (2 <= nargs) {
		y = y_;
	}
	if (3 <= nargs) {
		xi = xi_;
	}
	if (4 <= nargs) {
		weights = weights_;
	}

	if (nargs < 1) {  // Data for demonstration plot.
		x = rand(10,1);
		y = rand(10,1);
		x(1) = 0;
		x(2) = 1;
		xi = [0:100]/100;
	}

	x = makecolv(x);
	y = makecolv(y);
	m = length(x);

	if (nargs < 4) {
		xm = x * ONE(1,m);
		d = abs(Array(xm - xm#));
		g = d .^ 3;   // Green#s function.
		weights = g \ y;
	}

	xi = makecolv(xi);
	{im,in} = size(xi);
	xm = ONE(im,1) * x#;
	xim = xi * ONE(1,m);
	d = abs(Array(xim - xm));
	g = d .^ 3;   // Green#s function.
	yi = g * weights;
	
	if (nargs < 1) { // Demonstration plot
		win = mgplot_cur_win();
		mgplot(win,xi#,yi#);
		mgreplot(win,x#,y#);
		mgplot_title(win,"Demonstration of interp2");
		mgplot_xlabel(win,"x");
		mgplot_ylabel(win,"y");
	}

	return {yi,weights};
}
