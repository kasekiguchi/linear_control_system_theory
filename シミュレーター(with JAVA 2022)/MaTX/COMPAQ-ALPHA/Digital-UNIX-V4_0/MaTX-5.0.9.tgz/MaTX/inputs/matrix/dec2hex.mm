
/*  -*- MaTX -*-
 *
 *  NAME
 *      dec2hex() - Decimal to hexadecimal number conversion
 *
 *  SYNOPSIS
 *      h = dec2hex(d)
 *         String h;
 *         Integer d;
 *
 *  DESCRIPTION
 *      dec2hex(d) returns decimal integer d in hexadecimal form.
 *      For example, dec2hex(2748) returns "ABC".
 *
 *	SEE ALSO
 *      hex2dec(), hex2num(), Matrix()
 */

Func String dec2hex(d)
	Integer d;
{
	Integer i,n,g;
	String h,ABCDEF;
	Index s;

	if (d == 0) {
		return "0";
	}

	n = 1 + Integer(fix(log(Real(d))/log(16.0)));
	s = Index(cumprod([ONE(1), 16*ONE(1,n-1)]));

	h = "";
	ABCDEF = "ABCDEF";
	for (i = 1; i <= n; i++) {
		g = Integer(fix(Real(d)/s(n-i+1)));
		d = rem(d, s(n-i+1));

		if (g > 9) {
			h = h + ABCDEF(g - 9);
		} else {
			h = h + String(g);
		}
	}
	return h;
}
