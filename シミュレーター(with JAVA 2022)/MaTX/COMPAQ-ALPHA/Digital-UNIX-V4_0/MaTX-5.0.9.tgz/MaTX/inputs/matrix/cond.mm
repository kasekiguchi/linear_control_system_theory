
/*  -*- MaTX -*-
 *
 *  NAME
 *      cond() - Condition number in 2-norm
 *
 *  SYNOPSIS
 *     c = cond(X)
 *        Real c;
 *        Matrix X;
 *
 *  DESCRIPTION
 *      cond(X) is the ratio of the largest singular value of X
 *      to the smallest.
 *
 *  SEE ALSO
 *      singval()
 */

Func Real cond(X)
	Matrix X;
{
	Real c;
	Matrix S;

	// Handle null matrix
	if (length(X) == 0) {
		warning("cond(): Null matrix of conditional number.\n");
		c = NaN;
	} else {
		S = singval(X);
		// Handle singular matrix
		if (any(Array(S) == 0)) {
			warning("cond(): Condition is infinite.\n");
			c = Inf;
		} else {
			c = max(S)/min(S);
		}
	}
	
	return c;
}
