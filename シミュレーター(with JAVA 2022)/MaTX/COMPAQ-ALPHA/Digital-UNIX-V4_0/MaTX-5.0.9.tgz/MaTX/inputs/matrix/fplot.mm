
/*  -*- MaTX -*-
 *
 *  NAME
 *      fplot() - Plot a function
 *
 *  SYNOPSIS
 *      {x,y} = fplot(FunFcn,lims)
 *          Array x, y;
 *          Array FunFcn();
 *          Matrix lims;
 *
 *      {x,y} = fplot(FunFcn,lims,npts)
 *          Array x, y;
 *          Array FunFcn();
 *          Matrix lims;
 *          Integer npts;
 *
 *      {x,y} = fplot(FunFcn,lims,npts,angl)
 *          Array x, y;
 *          Array FunFcn();
 *          Matrix lims;
 *          Integer npts;
 *          Real angl;
 *
 *      {x,y} = fplot(FunFcn,lims,npts,angl,subdiv)
 *          Array x, y;
 *          Array FunFcn();
 *          Matrix lims;
 *          Integer npts;
 *          Real angl;
 *          Integer subdiv;
 *
 *  DESCRIPTION
 *      {x,y} = fplot() returns the abscissae and ordinates for FunFcn in
 *      the column vectors X and Y.  Plot X versus Y to see the picture.
 *
 *      fplot(FunFcn,lims) plots the function FunFcn() between the 
 *      x-axis limits specified by lims = [xmin xmax].  For example, 
 *
 *        Func Array sinm(x)
 *          Array x;
 *        {
 *          return sin(x);
 *        }
 *        {x,y} = fplot(sinm,[0 10]);
 *        mgplot(1,x,y);
 *
 *      is a plot of the sine function.
 *
 *      fplot(FunFcn,LIMS,N) plots the function with a minimum of N 
 *      samples. The default value for N is 25.
 *
 *      fplot(FunFcn,LIMS,N,ANGLE) plots the function with a minimum
 *      of N samples and samples more if contiguous segments are at an angle
 *      larger than ANGLE (in degrees).  The default for ANGLE is 10 degrees.
 *
 *      fplot(FunFcn,LIMS,N,ANGLE,SUBDIV) plots the function with a
 *      minimum of N samples, no more than ANGLE degrees bends in the curve,
 *      but no more than SUBDIV iterations to fill in the rapidly changing
 *      portions. The default for SUBDIV is 20.
 *
 */

Func List fplot(FunFcn,lims,npts,angl,subdiv, ...)
	Array FunFcn();
	Matrix lims;
	Integer npts;
	Real angl;
	Integer subdiv;
{
	Integer iter,nx,win;
	Real xmax,xmin,yscal;
	Matrix xt,yt;
	Array xi,yi,radi,x,y,num,den,ang;
	Index ii,ind;

	error(nargchk(2, 4, nargs, "fplot"));

	if (nargs < 5) {
		subdiv = 20;
		if (nargs < 4) {
			angl = 10.0;
		}
		if (nargs < 3) {
			npts = 25;
		}
	}

	iter = 0;
	angl = angl*PI/180;
	angl = abs(angl);
	ang = [angl + 1];
	xmin = min(lims);
	xmax = max(lims);
	x = xmin .+ [0:npts-1]'*(xmax-xmin)/(npts-1);
	y = FunFcn(x);
	yscal = max(abs(y));
	y = y/yscal;

	// see if need to fill in values for "smoothness"
	while (any(ang > angl) && iter <= subdiv) {
		yi = diff(y);
		xi = diff(x);
		nx = length(xi) - 1;
		radi = sqrt(xi.^2 + yi.^2);
		num = xi(1:nx).*xi(2:nx+1) + yi(1:nx).*yi(2:nx+1);
		den = radi(1:nx).*radi(2:nx+1);
		ang = abs(acos(num./den));
		iter = iter + 1;
		ii = find(ang > angl);	// need to interpolate more
		if (isempty(Matrix(ii))) {
			break;
		} else {
			xt = (x(ii) + x(ii .+ 1))/2;
			yt = Array(FunFcn(xt))/yscal;
			{x, ind} = sort([[x][xt]]);
			y = [[y][yt]];
			y = y(ind);
		}
	}

	y = y*yscal;

	if (iter >= subdiv) {
		print "Plot may be inaccurate.\n";
		warning("fplot(): Maximum number of iterations has been reached.\n");
	}

//	win = mgplot_cur_win();
//	mgplot(win,trans(x),trans(y),{""});
	return {trans(x),trans(y)};
}
