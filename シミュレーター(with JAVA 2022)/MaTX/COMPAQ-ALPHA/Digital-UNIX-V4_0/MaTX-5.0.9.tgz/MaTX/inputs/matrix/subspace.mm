
/*  -*- MaTX -*-
 *
 *  NAME
 *      subspace() - The angle between two subspaces
 *
 *  SYNOPSIS
 *      theta = subspace(A,B)
 *         Real theta;
 *         Matrix A,B;
 *
 *  DESCRIPTION
 *      subspace(A,B) finds the angle between two subspaces specified
 *      by the columns of A and B. If A and B are vectors of unit length,
 *      this is the same as acos(A#*B).
 *
 *      If the angle is small, the two spaces are nearly linearly
 *      dependent.  In a physical experiment described by some
 *      observations A, and a second realization of the experiment
 *      described by B, subspace(A,B) gives a measure of the amount
 *      of new information afforded by the second experiment not
 *      associated with statistical errors of fluctuations.
 */

Func Real subspace(A_, B_)
	Matrix A_, B_;
{
	Real theta;
	Integer ma,mb,na,nb;
	Matrix A,B,g,qa,qb,ra,rb;

	A = A_#;
	B = B_#;
	{ma,na} = size(A);
	{mb,nb} = size(B);
	if (ma != mb) {
		error("subspace(): Column dimensions of A and B must be the same.\n");
	}
	{qa,ra} = qr(A);
	{qb,rb} = qr(B);
	qa = qa(:,1:na);
	qb = qb(:,1:nb);
	g = qa# * qb;

	/*
	 * The max singular value is the correct one to choose but
	 * should have magnitude no more than 1.
	 */
	theta = acos(min(max(max(singval(g)),-1.0),1.0));
	return theta;
}



