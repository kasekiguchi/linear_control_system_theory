
/*  -*- MaTX -*-
 *
 *  NAME
 *      corrcoef_col() - Correlation coefficients for each column
 *      corrcoef_row() - Correlation coefficients for each row
 *
 *  SYNOPSIS
 *      xy = corrcoef_col(x)
 *        Matrix xy;
 *        Matrix x;
 *        Matrix y;
 *
 *      xy = corrcoef_col(x, y)
 *        Matrix xy;
 *        Matrix x;
 *        Matrix y;
 *
 *      xy = corrcoef_row(x)
 *        Matrix xy;
 *        Matrix x;
 *
 *      xy = corrcoef_row(x, y)
 *        Matrix xy;
 *        Matrix x;
 *        Matrix y;
 *
 *  DESCRIPTION
 *      corrcoef_col(X) is a matrix of correlation coefficients formed
 *      from X whose each row is an observation, and each column 
 *      is a variable.
 *      corrcoef_col(X,Y) is the same as corrcoef_col([X Y]).
 *
 *      If C is the covariance matrix, C = cov_col(X), then 
 *      corrcoef_col(X) is the matrix whose (i,j)'th element is
 *      C(i,j)/SQRT(C(i,i)*C(j,j)).
 *
 *      corrcoef_row(X) is a matrix of correlation coefficients formed
 *      from X whose each column is an observation, and each row 
 *      is a variable.
 *
 *  SEE ALSO
 *      cov() and std().
 */

Func Matrix corrcoef_col(x, y, ...)
	Matrix x, y;
{
	Matrix xy, d, c;

	error(nargchk(1, 2, nargs, "corrcoef_col"));

	if (nargs == 1) {
		c = cov_col(x);
	} else if (nargs == 2) {
		c = cov_col(x, y);
	}

	d = diag_vec(c);
	xy = Array(c) / sqrt(Array(d*d#));
	return xy;
}

Func Matrix corrcoef_row(x, y, ...)
	Matrix x, y;
{
	error(nargchk(1, 2, nargs, "corrcoef_row"));

	if (nargs == 1) {
		return trans(corrcoef_col(trans(x)));
	} else {
		return trans(corrcoef_col(trans(x), trans(y)));
	}
}

