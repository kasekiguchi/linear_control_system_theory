
/*  -*- MaTX -*-
 *
 *  NAME
 *      ode23() - Integrate a system of ODE using 2nd-3rd order 
 *                Runge-Kutta formulas
 *
 *  SYNOPSIS
 *      {tout, yout} = ode23(FunFcn, t0, tfinal, y0)
 *         Matrix tout, yout;
 *         Matrix FunFnc();
 *         Real t0, tfinal;
 *         Matrix y0;
 *
 *      {tout, yout} = ode23(FunFcn, t0, tfinal, y0, tol)
 *         Matrix tout, yout;
 *         Matrix FunFnc();
 *         Real t0, tfinal;
 *         Matrix y0;
 *         Real tol;
 *
 *      {tout, yout} = ode23(FunFcn, t0, tfinal, y0, tol, trc)
 *         Matrix tout, yout;
 *         Matrix FunFnc();
 *         Real t0, tfinal;
 *         Matrix y0;
 *         Real tol;
 *         Integer trc;
 *
 *  DESCRIPTION
 *      Integrate a system of ordinary differential equations using
 *      2nd and 3rd order Runge-Kutta formulas.
 *
 *      ode23(FunFcn, t0, tfinal, y0) integrates the system
 *      of ordinary differential equations described by the function
 *      FunFcn() over the interval t0 to tf and using initial
 *      conditions y0.
 *
 *      ode23(FunFcn, t0, tfinal, y0, tol, 1) uses tolerance tol
 *      and displays status while the integration proceeds.
 *
 *      tout : Integration time points (column-vector)
 *      yout : Solution, one solution column-vector per tout-value
 *
 *      FunFnc : Uer-supplied problem description
 *               Call: yprime = FunFcn(t,y)
 *                 t      : Time (scalar)
 *                 y      : Solution column-vector
 *                 yprime : Returned derivative column-vector
 *                          yprime(i) = dy(i)/dt
 *      t0     : Initial value of t.
 *      tfinal : Final value of t.
 *      y0     : Initial value column-vector.
 *      tol    : The desired accuracy. (Default: tol = 1.0e-3)
 *      trc    : If nonzero, each step is printed. (Default: trc = 0)
 *
 *  SEE ALSO
 *      ode45() and odedemo().
 *
 */

Func List ode23(FunFcn, t0, tfinal, y0, tol, trc, ...)
	Matrix FunFcn();
	Real t0, tfinal;
	Matrix y0;
	Real tol;
	Integer trc;
{
	Matrix yout,tout,y,s1,s2,s3;
	Real delta,tau,h,hmax,hmin,t,pw;

	error(nargchk(4, 6, nargs, "ode23"));

	// Initialization
	pw = 1.0/3.0;

	if (nargs < 5) {
		tol = 0.001;
	}
	if (nargs < 6) {
		trc = 0;
	}

	// Initialization
	t = t0;
	hmax = (tfinal - t)/5;
	hmin = (tfinal - t)/20000;
	h = (tfinal - t)/100;
	y = makecolv(y0);
	tout = [t];
	yout = y#;
	tau = tol * max(infnorm(y), 1.0);

	if (trc) {
		clear;
		print "\n", t, "\n", h, "\n", y;
	}

	// The main loop
	while (t < tfinal && h >= hmin) {
		if (t + h > tfinal) {
			h = tfinal - t;
		}

		// Compute the slopes
		s1 = FunFcn(t, y);
		s2 = FunFcn(t+h, y+h*s1);
		s3 = FunFcn(t+h/2, y+h*(s1+s2)/4);

		// Estimate the error and the acceptable error
		delta = infnorm(h*(s1 - 2*s3 + s2)/3);
		tau = tol*max(infnorm(y),1.0);

		// Update the solution only if the error is acceptable
		if (delta <= tau) {
			t = t + h;
			y = y + h*(s1 + 4*s3 + s2)/6;
			tout = [[tout][t]];
			yout = [[yout][y#]];
		}
		if (trc) {
			gotoxy(1,1);
			print "\n", t, "\n", h, "\n", y;
		}
		
		// Update the step size
		if (delta != 0.0) {
			h = min(hmax, 0.9*h*(tau/delta)^pw);
		}
	}

	if (t < tfinal) {
		warning("ode23(): Singularity likely.\n");
		print t;
	}

	return {tout, yout};
}
