
/*  -*- MaTX -*-
 *
 *  NAME
 *      diag_vec() - Exchange a vector and diagonal elements of a matrix
 *
 *  SYNOPSIS
 *      B = diag_vec(A)
 *        Matrix B;
 *        Matrix A;
 *
 *      B = diag_vec(A)
 *        Matrix B;
 *        Matrix A;
 *        Integer k;
 *
 *  DESCRIPTION
 *     If A is an n-by-n matrix, diag_vec(A) is an n-by-1 vector whose
 *     elements are the diagonal elements of A.
 *
 *     diag_vec(A,k) returns a (n-abs(k))-by-1 vector whose elements are the
 *     k-th (k > 0 ? upper:lowwer) diagonal elements of A.
 *
 *     If A is an n-by-1 or 1-by-n vector, diag_vec(A) is an n-by-n matrix,
 *     whoes diagonal elements are the elements of the vector.
 *
 *     diag_vec(A,k) returns an (n+abs(k))-by-(n+abs(k)) matrix, whose k-th
 *     (k > 0 ? upper:lowwer) diagonal elements are the elements of the vector.
 */

Func Matrix diag_vec(A_, k, ...)
	Matrix A_;
	Integer k;
{
	Integer n;
	Matrix AA, A, B;

	error(nargchk(1, 2, nargs, "diag_vec"));
	
	if (nargs == 1) {
		k = 0;
	}
	if (length(A_) == 0) {
		return [];
	}

	A = A_;
	
	if (Rows(A) == 1 || Cols(A) == 1) {
		B = vec2diag(A);
		n = length(A);
		if (k > 0) {
			AA = [[Z(n,k), B]
				  [Z(k,n+k)]];
		} else if (k < 0) {
			AA = [[Z(abs(k),n+abs(k))]
				  [B, Z(n,abs(k))]];
		} else {
			AA = B;
		}
	} else {
		if (Rows(A) < Cols(A)) {
			A = A(1:Rows(A),1:Rows(A));
		} else if (Rows(A) > Cols(A)) {
			A = A(1:Cols(A),1:Cols(A));
		}

		n = Rows(A);
		if (n-1 < abs(k)) {
			error("diag_vec():  Index is larger than size of matrix.\n");
		}
		if (k > 0) {
			B = A(1:n-k,k+1:n);
		} else if (k < 0) {
			B = A(abs(k)+1:n,1:n-abs(k));
		} else {
			B = A;
		}
		AA = diag2vec(B);
	}

	return AA;
}

