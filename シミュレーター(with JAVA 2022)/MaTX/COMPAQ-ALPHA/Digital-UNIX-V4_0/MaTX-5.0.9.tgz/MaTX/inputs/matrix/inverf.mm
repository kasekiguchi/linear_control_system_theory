
/*  -*- MaTX -*-
 *
 *  NAME
 *      inverf() - Inverse Error function
 *
 *  SYNOPSIS
 *      b = inverf(x)
 *         Array b;
 *         Array x;
 *
 *  DESCRIPTION
 *      inverf(x) returns the value of the inverse error function
 *      for every element of x, accurate to about 1E-5.  The error
 *      function is the integral of the normal probability distribution
 *      function from 0 to x:
 *
 *       erfnc(x) = 2/sqrt(PI) integral(0,x) exp(-t^2)
 *
 *  SEE ALSO
 *      erfnc().
 *
 */


Func Array inverf(x)
	Array x;
{
	Array b,bp,fd,f;
	Integer m,n;
	Real tol,tp;

	// Newton-Raphson iteration on ERF.	
	tol = 0.00001;
	tp = 1/sqrt(2*PI);
	{m,n} = size(x);
	bp = ONE(m,n);
	b = Z(m,n);

	while (any(abs(b-bp) > tol)) {
		bp = b;
		f = (erfnc(bp) - x)/2;
		fd = exp(-0.5*bp*bp)*tp;
		b = bp - f/fd;
	}
	return b;
}
