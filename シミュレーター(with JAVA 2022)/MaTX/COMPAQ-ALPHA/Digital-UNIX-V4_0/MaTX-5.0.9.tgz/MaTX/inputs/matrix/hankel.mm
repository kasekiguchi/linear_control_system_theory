
/*  -*- MaTX -*-
 *
 *  NAME
 *      hankel() - Hankel matrix
 *
 *  SYNOPSIS
 *      H = hankel(C)
 *         Matrix H;
 *         Matrix C;
 *
 *      H = hankel(C, R)
 *         Matrix H;
 *         Matrix C;
 *         Matrix R;
 *
 *  DESCRIPTION
 *      hankel(C) is a square Hankel matrix whose first column is C and
 *      whose elements are zero below the first anti-diagonal.
 *
 *      hankel(C,R) is a Hankel matrix whose first column is C and whose
 *      last row is R.
 *
 *      Hankel matrices are symmetric, constant across the anti-diagonals,
 *      and have elements H(i,j) = R(i+j-1).
 *
 *  SEE ALSO
 *     toeplitz() and vander().
 */


Func Matrix hankel(C_, R_, ...)
	Matrix C_, R_;
{
	Matrix C,R,H;
	Integer j, nc, nr;

	error(nargchk(1, 2, nargs, "hankel"));
	
	if (nargs == 1) {
		C = makecolv(C_); // Make sure C is a column vector
	} else {
		C = makecolv(C_); // Make sure C is a column vector
		R = makecolv(R_); // Make sure R is a column vector
	}

	// C = C(1,:);
	nc = max(Cols(C), Rows(C));
	if (nargs == 1) {
		H = Z(nc,nc);
		for (j = 1; j <= nc; j++) {
			H(1:nc-j+1,j) = C(j:nc);
		}
	} else {
		// R = R(1,:);
		nr = max(Cols(R), Rows(R));
		H = Z(nc,nr);
		if (C(nc) != R(1)) {
			warning("hankel(): Column wins anti-diagonal conflict.\n");
		}
		for (j = 1; j <= nr; j++) {
			if (j <= nc) {
				H(:,j) = [[C(j:nc)#][R(2:j)#]](1:nc);
			} else {
				H(:,j) = R(j-nc+1:j)#;
			}
		}
	}
	return H;
}
