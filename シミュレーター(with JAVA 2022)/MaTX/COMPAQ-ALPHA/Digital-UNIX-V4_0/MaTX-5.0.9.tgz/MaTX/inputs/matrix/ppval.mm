
/*  -*- MaTX -*-
 *
 *  NAME
 *      ppval() - pp function 
 *
 *  SYNOPSIS
 *      v = ppval(pp,xx)
 *         Matrix v;
 *         Matrix pp,xx;
 *
 *  DESCRIPTION
 *      ppval() returns the value of the pp function pp() at xx.
 *
 *  SEE ALSO
 *      spline().
 *
 */

Func Matrix ppval(pp,xx)
	Matrix pp;
	Matrix xx;
{
	Integer ihigh,ilow,ix,ixs,j,k,l,m,n,tosort;
	Matrix x,c,xs,junk,v;
	Index idx;
	Polynomial pl;

	List unmkpp();

	// if necessary, sort  xx 
	xs = xx;
	ix = length(xs);
	tosort = 0;
	
	if (ix > 1) {
		if (length(find(Array(diff(xs)) < 0.0)) > 0) {
			tosort = 1;
			{xs,idx} = sort(xs);
		}
	}

	// take apart  pp
	{x,c,l,k} = unmkpp(pp);

	ilow = 1;
	ixs = length(xs);
	{m,n} = size(xx);
	v = Z(m,n);

	while (ilow <= ixs) {
		idx = find(Array(x(2:l+1)) > xs(ilow));

		if (length(idx) == 0) {
			j = l;
		} else {
			j = idx(1);
		}
		if (j < l) {
			idx = find(Array(xs(ilow:ixs)) < x(j+1));
			ihigh = ilow - 1 + idx(length(idx));
		} else {
			ihigh = ixs;
		}
		if (version() == 4) {
			pl = Polynomial(fliplr(c(j,:)));
		} else {
			pl = Polynomial(c(j,:));
		}
		v(ilow:ihigh) = eval(pl, Array(xs(ilow:ihigh) .- x(j)));
		ilow = ihigh + 1;
	}

	if (tosort > 0) {
		{junk,idx} = sort(Matrix(idx));
		v = v(idx);
	}
	return v;
}


/*  -*- MaTX -*-
 *
 *  NAME
 *      unmkpp() - Takes apart the pp function into its pieces
 *
 *  SYNOPSIS
 *      {breaks,coefs,l,k} = unmkpp(pp)
 *         Matrix breaks, coefs;
 *         Integer l, k;
 *         Matrix pp;
 *
 *  DESCRIPTION
 *      unmkpp() takes apart the pp function into its pieces.
 *
 *  SEE ALSO
 *      ppval().
 */

Func List unmkpp(pp)
	Matrix pp;
{
	Integer l,k;
	Matrix breaks,coefs;
	
	l = Integer(pp(1));
	breaks = pp(2:l+2);
	k = Integer(pp(l+3));
	coefs = reshape(pp(l+4:l+k*l+3), l, k);

	return {breaks,coefs,l,k};
}
