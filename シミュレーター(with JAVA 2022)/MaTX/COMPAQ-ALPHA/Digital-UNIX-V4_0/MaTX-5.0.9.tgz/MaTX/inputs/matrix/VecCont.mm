
/*  -*- MaTX -*-
 *
 *  NAME
 *      VecCont() - Connect some vectors to a vector
 *
 *  SYNOPSIS
 *     {X, idx} = VecCont({x1, x2, ..., xn})
 *        Matrix X;
 *        List idx;
 *        Matrix x1, x2, ..., xn;
 *
 *  DESCRIPTION
 *      Connect some vectors to a big vector and make a list of
 *      index corresponding to those vectors.
 *
 *  EXAMPLE 
 *      {X, idx} = VecCont({[1], [1 2]', [1 2 3]', [1 2 3 4]'})
 *      {x1, x2, x3, x4} = VecChop(X, idx)
 *
 *  SEE ALSO
 *      VecChop()
 */


Func List VecCont(vectors_list)
	List vectors_list;
{
	Integer i, j, n, row;
	Matrix X, xi;
	List vectors_idx;

	n = length(vectors_list);
	vectors_idx = makelist(n);

	j = 1;
	X = [];
	for (i = 1; i <= n; i++) {
		xi = vectors_list(i, Matrix);
		row = length(xi);
		vectors_idx(i) = Index([j:j+row-1]);
		X = [[X][reshape(xi,row,1)]];
		j = j + row;
	}

	return {X, vectors_idx};
}
