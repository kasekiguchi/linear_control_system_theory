
/*  -*- MaTX -*-
 *
 *  NAME
 *      feather() - Feather plot
 *
 *  SYNOPSIS
 *      feather(x)
 *         Array x;
 *
 *      feather(x,y)
 *         Array x;
 *         Array y;
 *
 *      feather(x,y,s)
 *         Array x;
 *         Array y;
 *         Integer s;
 *
 *  DESCRIPTION
 *      feather(Z) draws a graph that displays the angle and magnitude
 *      of the complex elements of Z as arrows emanating from equally
 *      spaced points along a horizontal axis.
 *
 *      feather(X,Y) is equivalent to feather(X+i*Y).  It displays the
 *      feather plot for the angles and magnitudes of the elements of
 *      matrices X and Y.
 *
 *      feather(X,Y,S) use line style S where S is any legal linetype 
 *      as described under the mgplot() command.
 *
 *	SEE ALSO
 *      compass(), rose(), and quiver().
 */

Func void feather(x_, y, s, ...)
	Array x_, y;
	Integer s;
{
	Integer i, m, n, win;
	Matrix arrow, z;
	Array xx, yy, x, a;
	Complex j;
	Real mx;
	List name, col;

	error(nargchk(1, 3, nargs, "feather"));

	x = x_;

	j = (0,1);
	xx = [0.0, 1.0,  0.8, 1.0,   0.8]';
	yy = [0.0, 0.0, 0.08, 0.0, -0.08]';
	arrow = xx + yy*j;

	if (nargs == 2) {
		s = 1;
	} else if (nargs == 1) {
		s = 1;
		y = Im(x);
		x = Re(x);
	}

	x = makecolv(x);
	y = makecolv(y);

	if (length(x) != length(y)) {
		error("feather(): X and Y must be same length.\n");
	}
	{m,n} = size(x);

	z = x + y*j;
	a = arrow * z# + ONE(5,1)*Matrix([1:m]);
	mx = max(abs(a));

	name = makelist(Cols(a));
	col = makelist(Cols(a));
	for (i = 1; i <= Cols(a); i++) {
		name(i) = "";
		col(i) = sprintf("%d", s);
	}

	win = mgplot_cur_win();
	mgplot(win, Re(a)', Im(a)', name, col);
	mgreplot(win, Array([1 m]), Array([0 0]), {""}, {"1"});
}
