
/*  -*- MaTX -*-
 *
 *  NAME
 *      pascal() - Pascal matrix
 *
 *  SYNOPSIS
 *      P = pascal(n)
 *         Matrix P;
 *         Integer n;
 *
 *      P = pascal(n, k)
 *         Matrix P;
 *         Integer n;
 *         Integer k;
 *
 *  DESCRIPTION
 *      pascal(n) is the Pascal matrix of order n: a symmetric postive
 *      definite matrix with integer entries, made up from Pascal's
 *      triangle.  Its inverse has integer entries.
 *
 *      pascal(n,1) is the lower triangular Cholesky factor (up to signs
 *      of columns) of the Pascal matrix.  It is involutary (is its own
 *      inverse).
 *
 *      pascal(n,2) is a transposed and permuted version of pascal(n,1)
 *      which is a cube root of the identity.
 *
 */

Func Matrix pascal(n, k, ...)
	Integer n, k;
{
	Matrix P;
	Integer i, j;

	error(nargchk(1, 2, nargs, "pascal"));

	if (nargs == 1) {
		k = 0;
	}

	P = vec2diag((-1)^[0:n-1]);
	P(:,1) = ONE(n,1);

	// Generate the Pascal Cholesky factor (up to signs)
	for (j = 2; j <= n-1; j++) {
		for (i = j+1; i <= n; i++) {
			P(i,j) = P(i-1,j) - P(i-1,j-1);
		}
	}

	if (k == 0) {
		P = P*P#;
	} else if (k == 2) {
		P = P#;
		P = P(n:-1:1,:);
		for (i = 1; i <= n-1; i++) {
			P(i,:) = -P(i,:);
			P(:,i) = -P(:,i);
		}
		if (n/2.0 == round(n/2.0)) {
			P = -P;
		}
	}
	return P;
}
