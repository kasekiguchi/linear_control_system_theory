
/*  -*- MaTX -*-
 *
 *  NAME
 *      isempty() - Check if a matrix is empty matrix
 *
 *  SYNOPSIS
 *      result = isempty(x)
 *         Integer result;
 *         Matrix x;
 *
 *  DESCRIPTION
 *      isempty(X) returns 1 if X is an empty matrix and 0 otherwise.
 *      An empty matrix has size 0-by-0.
 */

Func Integer isempty(x)
	Matrix x;
{
	return (length(x) == 0);
}
