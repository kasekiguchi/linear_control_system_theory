
/*  -*- MaTX -*-
 *
 *  NAME
 *      ifft2() - Inverse 2-D FFT
 *
 *  SYNOPSIS
 *      y = ifft2(x)
 *         CoArray y;
 *         Array x;
 *
 *  DESCRIPTION
 *      ifft2(Y) is the inverse 2-D FFT of Y.  Rows or columns that
 *      are not an even power of two are padded with trailing zeros.
 *
 *  SEE ALSO
 *      fft2().
 */

Func CoArray ifft2(x)
	Array x;
{
	CoArray y;

	y = trans(conj(fft(trans(fft(conj(x))))));
	y = y/(Cols(y)*Rows(y));
	return y;
}
