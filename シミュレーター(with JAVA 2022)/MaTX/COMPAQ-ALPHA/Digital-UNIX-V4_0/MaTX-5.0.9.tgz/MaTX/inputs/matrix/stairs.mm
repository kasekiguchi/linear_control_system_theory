
/*  -*- MaTX -*-
 *
 *  NAME
 *      stairs() - Stairstep graph
 *      stairsp() - Plot Stairstep graph (bar graph)
 *
 *  SYNOPSIS
 *      {xx,yy} = stairs(x)
 *         Matrix xx,yy;
 *         Matrix x;
 *
 *      {xx,yy} = stairs(x,y)
 *         Matrix xx,yy;
 *         Matrix x;
 *         Matrix y;
 *
 *      stairsp(x)
 *         Matrix x;
 *
 *      stairsp(x,y)
 *         Matrix x;
 *         Matrix y;
 *
 *  DESCRIPTION
 *      Stairstep plots are useful for drawing time history plots of
 *      digital sampled-data systems.  The x-values must be in ascending
 *      order and evenly spaced.
 *
 *      stairs(x,y) returns vectors x and y such that  mgplot(win,xx,yy)
 *      is the stairstep graph.
 *
 *      stairsp(y) draws a stairstep graph of the elements of vector y.
 *
 *      stairsp(x,y) draws a stairstep graph of the elements in vector y
 *      at the locations specified in x.  The X-values must be in
 *      ascending order and evenly spaced.
 *
 *	SEE ALSO
 *      bar() and hist()
 *
 */

Func List stairs(x_, y_, ...)
	Matrix x_, y_;
{
	Matrix t,x,y,xx,yy,tmp;
	Integer n,nn,win;
	Real delta;

	error(nargchk(1, 2, nargs, "stairs"));

	win = mgplot_cur_win();
               
	n = length(x_);
	if (nargs == 1) {
		y = x_;
		x = [1:n];
	} else {
		x = x_;
		y = y_;
	}

	delta = (max(x) - min(x)) / (n-1);
	nn = 2*n;
	yy = Z(nn+2,1);
	xx = yy;
	tmp = makerowv(x);
	t = tmp .- 0.5*delta;
	xx(1:2:nn) = t;
	xx(2:2:nn) = t;
	xx(nn+1:nn+2) = t(n) .+ [[delta][delta]];
	yy(2:2:nn) = y;
	yy(3:2:nn+1) = y;

	return {xx,yy};
}

Func void stairsp(x, y, ...)
	Matrix x, y;
{
	Matrix xx, yy;
	Integer win;

	List stairs(...);

	error(nargchk(1, 2, nargs, "stairsp"));

	win = mgplot_cur_win();

	if (nargs == 1) {
		{xx,yy} = stairs(x);
	} else {
		{xx,yy} = stairs(x, y);
	}

	mgplot(win, xx#, yy#);
}
