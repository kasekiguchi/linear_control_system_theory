
/*  -*- MaTX -*-
 *
 *  NAME
 *      bar()  - Generate data of Bar graph
 *      barp() - Plot Bar graph
 *
 *  SYNOPSIS
 *      {xx,yy} = bar(x)
 *         Array xx, yy;
 *         Array x;
 *
 *      {xx,yy} = bar(x, y)
 *         Array xx, yy;
 *         Array x;
 *         Array y = [1:length(x)];
 *
 *      barp(x)
 *         Array x;
 *
 *      barp(x, y)
 *         Array x;
 *         Array y = [1:length(x)];
 *
 *  DESCRIPTION
 *      bar(x) generates data of a bar graph of the elements of
 *      vector x.  bar(x,y) generates data of a bar graph of the
 *      elements in vector y at the locations specified in x.
 *      The x-values must be in ascending order and evenly spaced.
 *
 *      barp(x) and barp(x,y) draw a graph.
 *
 *	SEE ALSO
 *      stairs() and hist().
 */

Func List bar(x_, y_, ...)
	Array x_, y_;
{
	Integer n,nn;
	Array x,y,xx,yy,t;
	Real delta;

	error(nargchk(1, 2, nargs, "bar"));

	n = length(x_);
	if (nargs == 1) {
		y = x_;
		x = [1:n];
	} else {
		x = x_;
		y = y_;
	}

	delta = (max(x) - min(x)) / (n-1);
	nn = 3*n;
	yy = Z(1,nn+1);
	xx = yy;
	t = reshape(x,1,n) .- 0.5*delta;

	xx(1:3:nn) = t;
	xx(2:3:nn) = t;
	xx(3:3:nn) = t .+ delta;
	yy(2:3:nn) = y;
	yy(3:3:nn) = y;
	xx(nn+1) = xx(nn);

	return {xx,yy};
}

Func void barp(x, y, ...)
	Array x, y;
{
	Integer win;
	Array xo,yo;

	error(nargchk(1, 2, nargs, "barp"));

	if (nargs == 1)  {
		{xo,yo} = bar(x);
	} else {
		{xo,yo} = bar(x,y);
	}

	win = mgplot_cur_win();
	mgplot(win,xo,yo,{""});
}
