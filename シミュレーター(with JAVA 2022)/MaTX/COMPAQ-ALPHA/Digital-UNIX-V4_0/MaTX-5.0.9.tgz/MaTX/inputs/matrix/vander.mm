
/*  -*- MaTX -*-
 *
 *  NAME
 *      vander() - Vandermonde matrix
 *
 *  SYNOPSIS
 *      A = vander(c)
 *         Matrix A;
 *         Matrix c;
 *
 *  DESCRIPTION
 *      vander(c) returns the Vandermonde matrix whose second to
 *      last column is c.  The i-th column of a Vandermonde matrix
 *      is given by  A(:,i) = c^(n-i).
 *
 *  SEE ALSO
 *      toeplitz()
 */

Func Matrix vander(c)
	Matrix c;
{
	Matrix A,C;
	Integer i,n;

	n = length(c);
	C = makecolv(c);
	A = ONE(n);
	for (i = 1; i <= n; i++) {
		A(:,i) = C .^ (n-i);
	}
	return A;
}
