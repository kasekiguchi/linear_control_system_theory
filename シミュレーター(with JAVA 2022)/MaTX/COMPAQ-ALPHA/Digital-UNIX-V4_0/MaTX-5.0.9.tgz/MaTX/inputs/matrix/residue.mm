
/*  -*- MaTX -*-
 *
 *  NAME
 *      residue() - Partial-fraction expansion or residue computation
 *
 *  SYNOPSIS
 *      {coeffs,poless,k} = residue(u,v)
 *          Matrix coeffs,poless,k;
 *          Matrix u,v;
 *
 *      {coeffs,poless,k} = residue(u,v,k)
 *          Matrix coeffs,poless,k;
 *          Matrix u,v;
 *          Matrix k;
 *
 *  DESCRIPTION
 *      residue(B,A) finds the residues, poles and direct term of a
 *      partial-fraction expansion of the ratio of two polynomials
 *      B and A
 *
 *       B(s)     r(1)     r(2)           r(n)
 *       ----  = ------ + ------ + ... + ------  +  k(s)
 *       A(s)    s-p(1)   s-p(2)         s-p(n)
 *
 *      Vectors B and A specify the coefficients of the polynomials in
 *      descending powers of s. The residues are returned in column vector
 *      R, the pole locations in column vector P, and the direct terms in
 *      row vector K.
 *
 *      residue(R,P,K) converts the partial-fraction expansion back to the
 *      B/A form.
 *
 *  WARNING
 *      residue() solving and restoration can be unstable,
 *      especially for repeated poles.
 *
 */

Func List residue(u,v,k,...)
	Matrix u,v,k;
{
	Matrix coeffs,poless,r,p,ptemp,q,temp;
	Integer desired,ii,jj,indx,j,n,next,repeated;
	Real tol;
	Index f,i;
	Complex av, pole;
	Polynomial s;

	error(nargchk(2, 3, nargs, "residue"));
	
	tol = 0.001;   // Repeated-root tolerance; adjust as needed.

	/*
	 *  This section rebuilds the U/V polynomials from residues,
	 *  poles, and remainder.  Multiple roots are those that
	 *  differ by less than tol.
	 */
	
	if (nargs > 2) {
		{p,i} = sort(-abs(Array(v)));	// Sort poles by magnitude.
		p = v(i);                       // Rearrange residues similarly.
		r = u(i);                       // Rearrange residues similarly.
		n = length(p);
		q = [[makerowv(p)][ONE(1,n)]];  // Poles and multiplicities.
		for (j = 2; j <= n; j++) {
			if (abs(p(j) - p(j-1)) < tol) {
				q(2,j) = q(2,j-1) + 1;	// Multiplicity of pole.
			}
		}
		s = Polynomial("s");
		if (version() == 4) {
			v = fliplr(Matrix(Re(det(s*I(Rows(p)) - vec2diag(p)))));
		} else {
			v = Matrix(Re(det(s*I(Rows(p)) - vec2diag(p))));
		}
		u = Z(1,n);
		for (indx = 1; indx <= n; indx++) {
			ptemp = q(1,:);
			ii = indx;
			for (j = 1; j <= Integer(q(2,indx)); j++) {
				ptemp(ii) = -1;
				ii = ii-1;
			}
			ptemp = ptemp(find(ptemp .!= -1));
			if (version() == 4) {
				temp = fliplr(Matrix(Re(det(s*I(Rows(ptemp)) - vec2diag(ptemp)))));
			} else {
				temp = Matrix(Re(det(s*I(Rows(ptemp)) - vec2diag(ptemp))));
			}
			j = length(temp);
			if (j < n) {
				temp = [Z(1,n-j) temp];
			}
			u = u + (r(indx) * temp);
		}
		if (length(k) != 0) {
			if (any(k .!= 0)) {
				u = [Z(1,length(k)), u];
				k = makerowv(k);
				temp = conv(k,v);
				u = u + temp;
			}
		}
		coeffs = u;
		poless = v;    // Rename.
		return {coeffs, poless, k};
	}
		
	// This section does the partial-fraction expansion for any order of pole
	u = makerowv(u);
	v = makerowv(v);
	k =[];
	f = find(u .!= 0);
	if (length(f)) {
		u = u(f(1):length(u));
	}
	f = find(v .!= 0);
	if (length(f)) {
		v = v(f(1):length(v));
	}
	u = u / v(1);   // Normalize
	v = v / v(1);   // Normalize
	if (length(u) >= length(v)) {
		{k,u} = deconv(u,v);
	}
	
	if (version() == 4) {
		r = roots(Polynomial(fliplr(v)));
	} else {
		r = roots(Polynomial(v));
	}
	{p,i} = sort(-abs(Array(r)));
	p = r(i);
	
	q = (Z(2,length(p)),:);   // For poles and multiplicity
	q(1,1) = p(1);
	q(2,1) = 1;
	j = 1;
	repeated = 0;
	
	for (ii = 2; ii <= length(p); ii++) {
		av = q(1,j) / q(2,j);
		if (abs(av - p(ii)) <= tol) {  // Treat as repeated root
			q(1,j) = q(1,j) + p(ii);   // Sum for average value
			q(2,j) = q(2,j) + 1;
			repeated = 1;
		} else {
			j = j + 1;
			q(1,j) = p(ii);
			q(2,j) = 1;
		}
	}
	q(1,1:j) = q(1,1:j) ./ q(2,1:j);   // Multiple root average
	
	// Set desired = 1 if you want the output multiple poles to be averaged
	desired = 1;
	if (repeated && desired) {
		indx = 0;
		for (jj = 1; jj <= j; jj++) {
			for (ii = 1; ii <= Integer(q(2,jj)); ii++) {
				indx = indx+1;
				p(indx) = q(1,jj);
			}
		}
	}
	
	poless = makecolv(p);  // Rename
	
	coeffs = (Z(length(p),1),:); 
	if (repeated) {  // Section for repeated root problem
		v = poly(p);
		next = 0;
		for (ii = 1; ii <= j; ii++) {
			pole = q(1,ii);
			n = Integer(q(2,ii));
			for (indx = 1; indx <= n; indx++) {
				next = next + 1;
				coeffs(next) = resi2(u,v,pole,n,indx);
			}
		}
	} else {   // No repeated roots
		for (ii = 1; ii <= j; ii++) {
			temp = poly(p(1:ii-1, ii+1:j));
			if (version() == 4) {
				coeffs(ii) = eval(Polynomial(fliplr(u)), p(ii)) / eval(Polynomial(fliplr(temp)), p(ii));
			} else {
				coeffs(ii) = eval(Polynomial(u), p(ii)) / eval(Polynomial(temp), p(ii));
			}
		}
	}
	return {coeffs, poless, k};
}
