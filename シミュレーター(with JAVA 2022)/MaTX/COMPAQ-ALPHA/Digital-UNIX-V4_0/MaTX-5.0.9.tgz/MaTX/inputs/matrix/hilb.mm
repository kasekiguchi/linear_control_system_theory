
/*  -*- MaTX -*-
 *
 *  NAME
 *      hilb() - Hilbert matrix
 *
 *  SYNOPSIS
 *      x = hilb(n)
 *         Matrix x;
 *         Integer n;
 *
 *  DESCRIPTION
 *      hilb(n) is the n by n matrix with elements 1/(i+j-1),
 *      which is a famous example of a badly conditioned matrix.
 *
 *  SEE ALSO
 *      invhilb() for the exact inverse.
 */

Func Matrix hilb(n)
	Integer n;
{
	Matrix x;
	Integer i, j;

	x = ONE(n);
	for (i = 1; i <= n; i++) {
		for (j = 1; j <= n; j++) {
			x(i,j) = 1.0/(i+j-1);
		}
	}
	return x;
}
