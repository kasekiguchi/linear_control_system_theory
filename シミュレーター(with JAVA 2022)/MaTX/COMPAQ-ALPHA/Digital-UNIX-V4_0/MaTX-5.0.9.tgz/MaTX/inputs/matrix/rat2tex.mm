
/*  -*- MaTX -*-
 *
 *  NAME
 *      rat2tex()  - Save a rational polynomial to a file in tex-form
 *      rat2texf() - Generate the tex-form of a rational polynomial 
 *
 *  SYNOPSIS
 *        rat2tex(r, file)
 *           Rational r;
 *           String file;
 *  
 *        rat2tex(r, file, var_name)
 *           Rational r;
 *           String file;
 *           String var_name;
 *  
 *        tf = rat2texf(r)
 *          String tf;
 *          Rational r;
 *
 *        tf = rat2texf(r, var_name)
 *          String tf;
 *          Rational r;
 *          String var_name;
 *
 *  SEE ALSO
 *        poly2tex(), poly2texf(), mat2tex() and mat2texf()
 */

Func void rat2tex(r, file, var_name, ...)
	Rational r;
	String file, var_name;
{
	String rat2texf(...);

	error(nargchk(2, 3, nargs, "rat2tex"));

	if (nargs == 2) {
		fprintf(file, "%s", rat2texf(r));
	} else if (nargs == 3) {
		fprintf(file, "%s", rat2texf(r, var_name));
	}
}

Func String rat2texf(r, var_name, ...)
	Rational r;
	String var_name;
{
	String num, den, tex;

	String poly2texf(...);

	error(nargchk(1, 2, nargs, "rat2texf"));

	if (nargs == 1) {
		num = poly2texf(Nu(r));
		den = poly2texf(De(r));
	} else {
		num = poly2texf(Nu(r), var_name);
		den = poly2texf(De(r), var_name);
	}
	
	tex = "\\frac{" + num + "}{" + den + "}";

	return tex;
}
