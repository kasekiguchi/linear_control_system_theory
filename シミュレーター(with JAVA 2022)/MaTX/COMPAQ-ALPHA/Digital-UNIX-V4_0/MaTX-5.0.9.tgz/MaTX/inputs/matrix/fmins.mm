
/*  -*- MaTX -*-
 *
 *  NAME
 *      fmins() - Minimum of a function of several variables
 *
 *  SYNOPSIS
 *      {x, cnt} = fmins(FunFcn, x0)
 *        Matrix x;
 *        Integer cnt;
 *        Real FunFcn();
 *        Matrix x0;
 *                
 *      {x, cnt} = fmins(FunFcn, x0, tol)
 *        Matrix x;
 *        Integer cnt;
 *        Real FunFcn();
 *        Matrix x0;
 *        Real tol;
 *                
 *      {x, cnt} = fmins(FunFcn, x0, tol, prnt)
 *        Matrix x;
 *        Integer cnt;
 *        Real FunFcn();
 *        Matrix x0;
 *        Real tol;
 *        Integer prnt;
 *                
 *  DESCRIPTION
 *      fmins() starts at x and produces a new vector x which
 *      minimizes f(x).  f is the function to be minimized.
 *
 *      fmins(..., tol) uses tol for the stopping tolerance. The default 
 *      tol is 1.0e-3. fmins(..., tol,1) succinctly describes each step.
 *
 *      This function uses the Nelder-Mead simplex algorithm.
 *
 *  REFERENCES
 *      [1] D. J. Woods, Report 85-5, Dept. Math. Sciences, Rice Univ.,
 *          May, 1985.
 *
 *  SEE ALSO
 *      fmin()
 *
 */

Func List fmins(FunFcn, x0, tol, prnt, ...)
	Real FunFcn();
	Matrix x0;
	Real tol;
	Integer prnt;
{
	Integer cnt,j,m,n;
	Real test;
	Matrix f,v,x,y;
	String how;
	Index jj;

	List fminstep();

	error(nargchk(2, 4, nargs, "fmins"));

	x = x0;
	{n,m} = size(x);
	if (m > n) {
		x = x#;
		n = m;
	}
	if (nargs < 3) {
		tol = 1.e-3;
	}
	if (nargs < 4) {
		prnt = 0;
	}
	cnt = 0;
	
	// Set up a simplex near the initial guess.
	v = 0.9*x;
	f = [FunFcn(v)];
	for (j = 1; j <= n; j++) {
		y = x;
		if (y(j) != 0.0) {
			y(j) = 1.1*y(j);
		} else {
			y(j) = 0.1;
		}
		v = [v y];
		f = [f, [FunFcn(y)]];
	}
	{f, jj} = sort(f);
	v = v(:,jj);
	
	if (prnt) {
		printf("cnt = %d (initial)\n", cnt);
		print v, f;
	}
	
	// Iterate until the diameter of the simplex is less than tol.
	while (1) {
		test = 0.0;
		for (j = 2; j <= n+1; j++) {
			test = max(test, norm(v(:,j)-v(:,1),1));
		}
		if (test <= tol) {
			break;
		}
		{v, f, how} = fminstep(FunFcn, v, f);
		cnt = cnt + 1;
		if (prnt) {
			printf("cnt = %d, how = %s, test = %g\n", cnt, how, test);
			print v, f;
		}
	}
	x = v(:,1);
	return {x, cnt};
}


/*  -*- MaTX -*-
 *
 *  NAME
 *      fminstep() - A function used by fmins()
 *
 *  SYNOPSIS
 *      {v, f, how} = fminstep(FunFcn, v0, f0)
 *          Matrix v0, f0;
 *          Real FunFcn();
 *          Matrix v0, f0;
 *
 *  DESCRIPTION
 *      One step of the Nelder-Mead simplex algorithm for minimizing
 *      a nonlinear function of	several variables.
 *
 *      fminstep(F,v,f) starts with a simplex V consisting of n+1
 *      points in R(n), so V is an n by n+1 matrix.  The corresponding
 *      function values are
 *
 *        f(j) = fun(V(:,j)), j = 1:n+1, with f(1) <=  ... <= f(n+1)
 *
 *      and f() = fun().
 *
 *      Returns new simplex V which includes a better minimizer.
 *      how is a string describing the type of step taken.
 *
 *  SEE ALSO
 *      fmins().
 *
 */

Func List fminstep(FunFcn, v0, f0)
	Real FunFcn();
	Matrix v0, f0;
{
	String how;
	Integer i,j,n,np1;
	Real alpha,beta,gamma,fc,fe,fk,fr,ft;
	Matrix vc,ve,vr,vk,vt,vbar,v,f;
	Index jj;

	v = v0;
	f = f0;
	alpha = 1.0;
	beta = 1.0/2.0;
	gamma = 2.0;
	{n,np1} = size(v);

	vbar = mean_row(v(:,1:n));

	vr = (1 + alpha)*vbar - alpha*v(:,n+1);
	fr = FunFcn(vr);
	vk = vr;
	fk = fr;
	how = "reflect";

	if (fr < f(n)) {
		if (fr < f(1)) {
			ve = gamma*vr + (1-gamma)*vbar;
			fe = FunFcn(ve);
			if (fe < f(1)) {
				vk = ve;
				fk = fe;
				how = "expand";
			}
		}
	} else {
		vt = v(:,n+1); ft = f(n+1);
		if (fr < ft) {
			vt = vr;
			ft = fr;
		}
		vc = beta*vt + (1-beta)*vbar;
		fc = FunFcn(vc);
		if (fc < f(n)) {
			vk = vc;
			fk = fc;
			how = "contract";
		} else {
			for (j = 2; j <= n; j++) {
				v(:,j) = (v(:,1) + v(:,j))/2;
				f(j) = FunFcn(v(:,j));
			}
			vk = (v(:,1) + v(:,n+1))/2;
			fk = FunFcn(vk);
			how = "shrink";
		}
	}
	v(:,n+1) = vk;
	f(n+1) = fk;
	{f,jj} = sort(f);
	v = v(:,jj);
	return {v, f, how};
}
