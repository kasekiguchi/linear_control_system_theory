
/*  -*- MaTX -*-
 *
 *  NAME
 *      conv() - Convolution
 *
 *  SYNOPSIS
 *      C = conv(A,B)
 *         Array C;
 *         Array A,B;
 *
 *  DESCRIPTION
 *      conv(A, B) convolves vectors A and B.  The resulting
 *      vector is length length(A)+length(B)-1.
 *
 *  SEE ALSO
 *      xcorr() and deconv().
 */

Func Array conv(A_, B_)
	Array A_, B_;
{
	if (version() == 4) {
		return fliplr(Array(Polynomial(fliplr(A_))*Polynomial(fliplr(B_))));
	} else {
		return Array(Polynomial(A_) * Polynomial(B_));
	}

	// Another implimentation
#if 0
	Array A, B, C;
	Integer na,nb;

	A = makerowv(A_);
	B = makerowv(B_);

	na = max(Cols(A), Rows(A));
	nb = max(Cols(B), Rows(B));

	if (na > nb) {
		if (nb > 1) {
			A = [A, Z(1,nb-1)];
		} else {
			A = A;
		}
		{C} = filter(B, [1], A);
	} else {
		if (na > 1) {
			B = [B, Z(1,na-1)];
		} else {
			B = B;
		}
		{C} = filter(A, [1], B);
	}

	if (Cols(A_) >= Rows(A_)) {
		return C;
	} else {
		return trans(C);
	}
#endif
}
