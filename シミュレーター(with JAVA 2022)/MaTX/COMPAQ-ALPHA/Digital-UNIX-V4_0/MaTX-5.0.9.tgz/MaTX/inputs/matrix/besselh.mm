
/*  -*- MaTX -*-
 *
 *  NAME
 *      besselh() - Integer order Hankel functions
 *
 *  SYNOPSIS
 *      H = besselh(n,x)
 *         Array H;
 *         Integer n;
 *         Array x;
 *
 *  DESCRIPTION
 *      besselh(n,X) is Hankel function, H(1)-sub-n (X).
 *      Hankel functions, also known as Bessel functions of the
 *      third kind, are complex solutions to Bessel's differential
 *      equation of order n:
 *                   2                    2   2
 *                  x * y'' +  x * y' + (x - n ) * y = 0
 *
 *      The function is evaluated for every point in the array X.
 *      The order, n, must be a nonnegative integer scalar.
 *
 *  SEE ALSO
 *       bessel(), besseln() and bessela().
 *
 *  REFERENCE
 *      [1] Abramowitz and Stegun, Handbook of Mathematical
 *          Functions, National Bureau of Standards, Applied Math.
 *          Series #55, sections 9.1.1, 9.1.89 and 9.12.
 */

Func Array besselh(n,x)
	Integer n;
	Array x;
{
	Integer k,sig,mm;
	Complex i;
	Real tiny, gamma;
	Array H,J0,J1,Jn,Y0,Yn,c,ykm1,ykm2;
	Array bk,bkp1,bkp2,bn,m,t,y,yk,z;

	gamma = 0.57721566490153286060; // Euler's Constant

	// Backwards three term recurrence for J-sub-n(x).

	// Temporarily replace x=0 with x=1
	z = (x==0);
	x = x + z;

	// Starting index for backwards recurrence.
	c = [17.1032 0.2639 0.6487, -0.0018 0.6457];
	m = round((c(1) + c(2)*n) .+ c(3)*abs(x) +
			  c(4)*n*abs(x) .+ c(5)*max([[n],[abs(x)]]));
	// Make sure rem(m,4)=0.
	m = 4*ceil(m/4);
	mm = Integer(max(makecolv(m)));

	tiny = 16.0^(-30);
	k = mm;
	bkp1 = 0*x;
	bk = tiny*(m==k);
	t = 2*bk;
	y = 2*bk/k;
	sig = 1;

	for (k = mm-1; k >= 0; k--) {
		bkp2 = bkp1;
		bkp1 = bk;
		bk = 2*(k+1)*bkp1/x - bkp2 + tiny*(m==k);

		if (k == Integer(n)) {
			bn = bk;
		}
		if ((k > 0 && rem(k,2)==0)) {
			t = t + 2*bk;
			sig = -sig;
			y = y + sig*2*bk/k;
		}
		if (k == 0) {
			t = t + bk;
		}
	}
	y = 2/PI*(log(x/2) .+ gamma)*bk - 4/PI*y;
	
	// Normalizing condition, J0(x) + 2*J2(x) + 2*J4(x) + ... = 1.
	Jn = bn/t;
	J0 = bk/t;
	J1 = bkp1/t;
	Y0 = y/t;
	
	// Forward recurrence for Yn.
	if (n > 0) {
		ykm1 = Y0;
		yk = (J1*Y0 - (2)/(PI*x))/J0;

		for (k = 2; k <= Integer(n); k++) {
			ykm2 = ykm1;
			ykm1 = yk;
			yk = 2*(k-1)*ykm1/x - ykm2;
		}

		Yn = yk;
	} else {
		Yn = Y0;
	}
	
	// Restore results for x = 0.
	// J0(0) = 1, Jn(0) = 0 for n > 0, logarithmic singularity in Y(0).
	Jn = (1 .- z)*Jn + z*(n==0);
	Yn = (1 .- z)*Yn + log(1 .- z);
	
	// Construct H from J and Y.
	i = (0,1);
	H = Jn + i*Yn;
	return H;
}
