
/* -*- MaTX -*-
 *
 *  NAME
 *      rsf2csf() - Convert real Schur form to complex Schur form
 *
 *  SYNOPSIS
 *      {U2,T2} = rsf2csf(U1,T1)
 *           Matrix U2,T2;
 *           Matrix U1,T1;
 *
 *  DESCRIPTION
 *      rsf2csf() converts a real, upper quasi-triangular
 *      Schur form to a complex, upper triangular Schur form.
 *      Find complex unitary similarities to zero subdiagonal elements.
 *
 *  SEE ALSO
 *      schur()
 */

Func List rsf2csf(U0, T0)
	Matrix U0, T0;
{
	Integer m, n;
	Real r, s;
	Complex c;
	CoMatrix T, U, G, mu;

	T = (T0,:);
	U = (U0,:);
	{m, n} = size(T);

	if (m > n) {
		n = m;
	} else {
		m = n;
	}

	while (m > 1) {
		s = abs(T(m-1,m-1)) + abs(T(m,m));
//		if (s + abs(T(m,m-1)) > s) {
		if (abs(T(m,m-1)) > EPS) {
			mu = eigval(T(m-1:m,m-1:m)) - ONE(2,1)*T(m,m);
			r = frobnorm([mu(1), T(m,m-1)]);

			if (r >= EPS) {
				c = mu(1)/r;
				s = Re(T(m,m-1))/r;
			} else {
				c = mu(1);
				s = Re(T(m,m-1));
			}

			G = [[c#, s][-s, c]];
			T(m-1:m,m-1:n) = G * T(m-1:m,m-1:n);
			T(1:m,m-1:m)   = T(1:m,m-1:m) * G#;
  			U(1:n,m-1:m)   = U(1:n,m-1:m) * G#;
		}
		T(m,m-1) = 0.0;
		m = m-1;
	}
	return {U, T};
}
