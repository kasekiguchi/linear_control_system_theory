
/*  -*- MaTX -*-
 *
 *  NAME
 *      compan() - Companion matrix of a polynomial
 *
 *  SYNOPSIS
 *      A = compan(p)
 *         Matrix A;
 *         Matrix p;
 *
 *  DESCRIPTION
 *      compan(p) is a companion matrix of the polynomial with coefficients p.
 *
 *  SEE ALSO
 *      poly(), makepoly(), Matrix() and Polynomial()
 */

Func Matrix compan(p)
	Matrix p;
{
	Matrix A, c;
	Integer m, n;

	{m, n} = size(p);
	if ((m != 1 && n != 1) || m*n == 1) {
		error("compan(): Input argument must be a vector.\n");
	}

	n = max(m, n);
	c = makerowv(p);	// make sure it's a row vector
	A = Z(n);
	A(1,1) = 1.0;

	if (n != 2) {
		A = vec2diag(ONE(1,n-2),-1);
	}

	A(1,:) = -c(2:n) / c(1);
	return A;
}
