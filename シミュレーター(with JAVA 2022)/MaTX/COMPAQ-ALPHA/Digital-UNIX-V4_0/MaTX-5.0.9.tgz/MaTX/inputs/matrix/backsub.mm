
/* -*- MaTX -*-
 *
 *  NAME
 *      backsub() - Backsubstitution to solve triangular systems of equations
 *
 *  SYNOPSIS
 *      x = backsub(LR, b)
 *         Matrix x;
 *         Matrix LR, b;
 *
 *  DESCRIPTION
 *      backsub() performs backsubstitution to solve the equation L*X = B,
 *      where L is lower triangular.  backsub() is provided for pedagogical
 *      purposes in most cases it is faster to use X = L\B.
 *
 *  SEE ALSO
 *      lu() and \
 */

Func Matrix backsub(LR_, b_)
	Matrix LR_, b_;
{
	Matrix LR, b, x;
	Integer i,lw,m,n;

	LR = LR_;
	b = b_;

	// Check if any diagonal elements are essentially 0.
	if (any(abs(diag2vec(Array(LR))) < EPS*norm(LR))) {
		error("backsub(): Matrix is singular.\n");
	}
	{m,n} = size(LR);
	if (m != n) {
		error("backsub(): Matrix must be square.\n");
	}

	// Find out if LR is L or R
	lw = 0;
	if (norm(LR - tril(LR),1) == 0.0) {
		lw = 1;
	} else if (norm(LR - triu(LR),1) == 0.0) {
		lw = 0;
	} else {
		error("backsub(): Matrix must be triangular.\n");
	}

	// Reorder rows of b and LR if system is upper triangular
	if ( ! lw) {
		b = b(n:-1:1);
		LR = LR(n:-1:1,n:-1:1);
	}
	
	// initialize x to force it to be a column vector.
	x = Z(n,1);

	// perform backsubstitution
	x(1) = b(1) / LR(1,1);
	for (i = 2; i <= n; i++) {
		x(i) = (b(i) - [LR(i,1:i-1)*x(1:i-1)](1)) / LR(i,i);
	}
	
	// reorder answer if system is upper triangular
	if ( ! lw) {
		x = x(n:-1:1);
	}
	return x;
}
