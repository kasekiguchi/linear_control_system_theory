
/* -*- MaTX -*-
 *
 *  NAME
 *      PickUp() - Pickup data every delta-data
 *
 *  SYNOPSIS
 *      B = PickUp(A,delta)
 *        Array B;
 *        Array A;
 *        Integer delta;
 */

Func Array PickUp(A, delta)
	Array A;
	Integer delta;
{
	Index idx;

	idx = Index([1:delta:Cols(A)]);
	return A(:,idx);
}

