
/*  -*- MaTX -*-
 * 
 *  NAME
 *      interp4() - 2-D bilinear interpolation (expansion) of a matrix
 *
 *  SYNOPSIS
 *      b = interp4()
 *         Matrix b;
 *
 *      b = interp4(a)
 *         Matrix b;
 *         Matrix a;
 *
 *      b = interp4(a,ntimes)
 *         Matrix b;
 *         Matrix a;
 *         Integer;
 *
 *  DESCRIPTION
 *      interp4(A,ntimes) returns matrix A expanded by interleaving
 *      bilinear interpolates between every element, working
 *      iteratively for ntimes (defaults to 1).  Matrix A must
 *      contain at least two elements.
 *
 *      interp4() called with no arguments interpolates and plots
 *      a matrix of random values.
 *
 */

Func Matrix interp4(a, ntimes, ...)
	Matrix a;
	Integer ntimes;
{
	Integer i,m,mm,n,nn,oldm,win;
	Matrix b,c;

	error(nargchk(1, 2, nargs, "interp4"));
	
	if (nargs == 0) { // Demonstration.
		a = rand(5,5);
		ntimes = 3;
	} else if (nargs == 1) {
		ntimes = 1;
	}
	
	b = a;
	{m,n} = size(a);
	if (m < 2 && n < 2) {
		return b;
	}

	if (m < 2 || n < 2) {
		oldm = m;
		for (i = 1; i <= ntimes; i++) {
			a = makecolv(b);
			{m,n} = size(a);
			b = Z(2*m-1,1);
			b(1:2:2*m-1) = a;
			b(2:2:2*m-1) = 0.5 * (a(1:m-1) + a(2:m));
		}
		if (oldm == 1) {
			b = b#;
		}
		return b;
	}

	for (i = 1; i <= ntimes; i++) {
		mm = 2*m-1;
		nn = 2*n-1;
		a = b;
		b = Z(mm,nn);
		b(1:2:mm,1:2:nn) = a;
		c = a(:,1:n-1) + a(:,2:n);
		b(1:2:mm,2:2:nn) = 0.5 * c;
		c = b(1:2:mm-2,:) + b(3:2:mm,:);
		b(2:2:mm-1,:) = 0.5 * c;
		m = mm; n = nn;
	}
	
	// Demonstration.
	if (nargs < 1) {
//		contour(b);
		win = mgplot_cur_win();
		mgplot_title(win,"Demonstration of interp4");
		mgplot_xlabel(win,"x");
		mgplot_ylabel(win,"y");
	}
	return b;
}
