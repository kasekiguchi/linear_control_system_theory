
/*  -*- MaTX -*-
 *
 *  NAME
 *      spline() - Cubic spline data interpolation
 *
 *  SYNOPSIS
 *      yy = spline(x,y)
 *         Matrix yy;
 *         Matrix x,y;
 *
 *      yy = spline(x,y,xx)
 *         Matrix yy;
 *         Matrix x,y;
 *         Matrix xx;
 *
 *  DESCRIPTION
 *      Given data vectors x and y, and a new abscissa vector xx, the
 *      function yy = spline(x,y,xx) uses cubic spline interpolation
 *      to find a vector yy corresponding to xx.
 *
 *      spline(x,y) returns the pp-form of the cubic spline interpolant
 *      instead, for later use with  ppval, etc.
 *
 *      Generate the cubic spline interpolant in pp form, depending on
 *      the number of data points.  (using the not-a-knot end condition).
 *
 *  EXAMPLE
 *      Here's an example that generates a coarse sine curve, then
 *      interpolates over a finer abscissa:
 *
 *   		x = [0:10];
 *          y = sin(x);
 *   		xx = [0:.25:10];
 *   		yy = spline(x,y,xx);
 *   		mgplot(win,x,y);
 *          mregplot(win,xx,yy);
 * 
 *  SEE ALSO
 *      mkpp() and ppval()
 */

Func Matrix spline(x,y,xx, ...)
	Matrix x,y,xx;
{
	Matrix yy,pp,b,c,c3,c4,s,xi,yi,divdif,dx;
	Integer n;
	Real xi31,xin;
	Index idx;

	Matrix mkpp(...);

	error(nargchk(2, 3, nargs, "spline"));

	n = length(x);
	{xi,idx} = sort(x);
	xi = makecolv(xi);

	yy = [];
	if (n < 2) {
		print "There should be at least two data points!\n";
	} else if (all(diff(xi)) == 0) {
		print "The data abscissae should be distinct!\n";
	} else if (n != length(y)) {
		print "Abscissa and ordinate vector should be of the same length!\n";
	} else {   
		yi = y(idx);
		yi = makecolv(yi);

		if (n == 2) { // the interpolant is a straight line
			pp = mkpp(xi#, [diff(yi)./diff(xi), [yi(1)]]);
		} else if (n == 3) { // the interpolant is a parabola
			yi(2:3) = diff(yi) ./ diff(xi);
			yi(3) = (yi(3)-yi(2))/(xi(3)-xi(1));
			yi(2) = yi(2) - yi(3)*(xi(2)-xi(1));
			pp = mkpp([xi(1),xi(3)],yi(Index([3 2 1]))#);
		} else { // set up the linear system for solving for the slopes at xi
			dx = diff(xi);
			divdif = diff(yi) ./ dx;
			xi31 = xi(3) - xi(1);
			xin = xi(n) - xi(n-2);

			c = diag_vec([[dx(2:n-1)][0]],-1) +
				2*diag_vec([[0][dx(2:n-1)+dx(1:n-2)][0]]) +
				diag_vec([[0][dx(1:n-2)]],1);
			
			c(1,1:2) = [dx(2), xi31];
			c(n,n-1:n) = [xin, dx(n-2)];

			b = Z(n,1);
			b(1) = ((dx(1) + 2*xi31)*dx(2)*divdif(1) + dx(1)^2*divdif(2))/xi31;
			b(2:n-1) = 3*(dx(2:n-1) .* divdif(1:n-2) +
						  dx(1:n-2) .* divdif(2:n-1));
			b(n) = (dx(n-1)^2*divdif(n-2) +
					(2*xin+dx(n-1))*dx(n-2)*divdif(n-1))/xin;
			// Solve for the slopes and convert to pp form
			s = c \ b;

			c4 = (s(1:n-1) + s(2:n) - 2*divdif(1:n-1)) ./ dx;
			c3 = (divdif(1:n-1) - s(1:n-1)) ./ dx - c4;
			pp = mkpp(xi#, [c4./dx, c3, s(1:n-1), yi(1:n-1)]);
		}
		if (nargs == 2) {
			yy = pp;
		} else {
			yy = ppval(pp,xx);
		}
	}
	return yy;
}


/*  -*- MaTX -*-
 *
 *  NAME
 *      mkpp() - Make piece-wise polynomial
 *
 *  SYNOPSIS
 *      p = mkpp()
 *         Matrix p;
 *
 *      p = mkpp(breaks, coefs)
 *         Matrix p;
 *         Matrix breaks;
 *         Matrix coefs;
 *
 *  DESCRIPTION
 *      mkpp() puts together a pp function from the breaks and coefficients
 *      input or requested. The number l of polynomial pieces is determined as
 *
 *           l := length(breaks) - 1
 *
 *      The  order  k  of the pp is obtained as
 *
 *           k := length(coefs)/l
 *
 *      and this ratio had better be an integer. 
 * 
 *  SEE ALSO
 *      ppval() and spline().
 */

Func Matrix mkpp(breaks, coefs, ...)
	Matrix breaks, coefs;
{
	Matrix pp;
	Integer l, lk, k;

	error(nargchk(0, 2, nargs, "mkpp"));
	
	if (nargs != 0 && nargs != 2) {
		error("mkpp(): Incorrect number of arguments.\n");
	}

	if (nargs == 0) {
		pause "\n\tGive the (l+1)-vector of breaks > ";
		breaks = Z(1);
		read breaks;
		pause "\n\tGive the (l by k) matrix of local pol. coefficients > ";
		coefs = Z(1);
		read coefs;
	}

	coefs = makerowv(coefs);
	lk = length(coefs);
	l = length(breaks) - 1;
	k = Integer(fix(Real(lk)/Real(l) + 100*EPS));

	if (k <= 0 || l*k != lk) {
		printf("The given number %d of polynomial pieces is incompatible", l);
		printf(" with the total number %d of coefficients supplied!\n", lk);
		pp = [];   
	} else {
		pp = [[l], makerowv(breaks), [k], coefs];
	}

	return pp;
}
