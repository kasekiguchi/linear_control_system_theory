
/*  -*- MaTX -*-
 *
 *  NAME
 *      fzero() - Zero of a function of one variable
 *
 *  SYNOPSIS
 *      b = fzero(FunFcn, x)
 *         Real b;
 *         Real FunFcn();
 *         Real x;
 *
 *      b = fzero(FunFcn, x, tol)
 *         Real b;
 *         Real FunFcn();
 *         Real x;
 *         Real tol;
 *
 *      b = fzero(FunFcn, x, tol, tr)
 *         Real b;
 *         Real FunFcn();
 *         Real x;
 *         Real tol;
 *         Integer tr;
 *
 *  DESCRIPTION
 *      fzero(F,X) finds a zero of f(x). f() is a real-valued function of
 *      a single real variable.   x is a starting guess.  The value returned
 *      is near a point where f(x) changes sign.
 *      For example, fzero(sinf, 3.0) is PI.
 *
 *      An optional third argument sets the relative tolerance for the
 *      convergence test.   The presence of an nonzero optional fourth
 *      argument triggers a printing trace of the steps.
 */

Func Real fzero(FunFcn, x, tol, tr, ...)
	Real FunFcn();
	Real x;
	Real tol;
	Integer tr;
{
	Real fa,fb,fc;
	Real a,b,c,d,dx,e,m,p,q,r,s,toler;
	Matrix init,c_sign,stepm;

	error(nargchk(2, 4, nargs, "fzero"));

	//	Initialization
	if (nargs < 3) {
		tr = 0;
		tol = EPS;
	}
	if (nargs == 3) {
		tr = 0;
	}

	if (x != 0.0) {
		dx = x/20;
	} else {
		dx = 1.0/20.0;
	}

	a = x - dx;
	fa = FunFcn(a);
	if (tr) {
		clear;
		init = [a fa];
	}
	b = x + dx;
	fb = FunFcn(b);
	if (tr) {
		init = [b fb];
	}
	
	// Find change of sign.
	while (fa > 0.0 == fb > 0.0) {
		dx = 2*dx;
		a = x - dx;
		fa = FunFcn(a);
		if (tr) {
			c_sign = [a fa];
		}
		if (fa > 0.0 != fb > 0.0) {
			break;
		}
		b = x + dx;
		fb = FunFcn(b);
		if (tr) {
			c_sign = [b fb];
		}
	}
	
	fc = fb;

	// Main loop, exit from middle of the loop
	while (fb != 0.0) {
		/*
		 *	Insure that b is the best result so far, a is the previous
		 *	value of b, and c is on the opposite of the zero from b.
		 */
		if (fb > 0.0 == fc > 0.0) {
			c = a;
			fc = fa;
			d = b - a;
			e = d;
		}
		if (abs(fc) < abs(fb)) {
			a = b;    b = c;    c = a;
			fa = fb;  fb = fc;  fc = fa;
		}
		
		// Convergence test and possible exit
		m = 0.5*(c - b);
		toler = 2.0*tol*max(abs(b),1.0);
		if ((abs(m) <= toler) + (fb == 0.0)) {
			break;
		}
		
		// Choose bisection or interpolation
		if ((abs(e) < toler) + (abs(fa) <= abs(fb))) {
			// Bisection
			d = m;
			e = m;
		} else {
			// Interpolation
			s = fb/fa;
			if (a == c) {
				// Linear interpolation
				p = 2.0*m*s;
				q = 1.0 - s;
			} else {
				// Inverse quadratic interpolation
				q = fa/fc;
				r = fb/fc;
				p = s*(2.0*m*q*(q - r) - (b - a)*(r - 1.0));
				q = (q - 1.0)*(r - 1.0)*(s - 1.0);
			}
			if (p > 0.0) { q = -q; } else { p = -p; }
			// Is interpolated point acceptable
			if ((2.0*p < 3.0*m*q - abs(toler*q)) * (p < abs(0.5*e*q))) {
				e = d;
				d = p/q;
			} else {
				d = m;
				e = m;
			}
		} // Interpolation
		
		// Next point
		a = b;
		fa = fb;
		if (abs(d) > toler) {
			b = b + d;
		} else {
			if (b > c) {
				b = b - toler;
			} else {
				b = b + toler;
			}
		}
		fb = FunFcn(b);
		if (tr) {
			stepm = [b fb];
			gotoxy(1,1);
			print "\n";
			print stepm;
		}
	} // Main loop
	return b;
}
