
/* -*- MaTX -*-
 *
 *  NAME
 *      kronsum() - Kronecker sum
 *
 *  SYNOPSIS
 *      K = kronsum(A, B)
 *         Matrix K;
 *         Matrix A, B;
 *
 *  DESCRIPTION
 *      kronsum(A,B) is the Kronecker tensor sum of A and Y.
 *
 */

Func Matrix kronsum(A, B)
	Matrix A, B;
{
	return kronprod(I(B), A) + kronprod(B, I(A));
}
