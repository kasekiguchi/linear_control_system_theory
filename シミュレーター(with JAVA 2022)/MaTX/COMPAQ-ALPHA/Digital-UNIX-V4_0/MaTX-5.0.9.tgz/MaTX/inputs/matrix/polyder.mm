
/*  -*- MaTX -*-
 *
 *  NAME
 *      polyder() - Polynomial derivatives
 *
 *  SYNOPSIS
 *      {a,b} = polyder(u)
 *          Matrix a,b;
 *          Matrix u;
 *
 *      {a,b} = polyder(u, v)
 *          Matrix a,b;
 *          Matrix u;
 *          Matrix v;
 *
 *  DESCRIPTION
 *      polyder(P) returns the derivative of the polynomial whose
 *      coefficients are the elements of vector P.
 *
 *      polyder(A,B) returns the derivative of polynomial A*B.
 *      polyder(B,A) returns the derivative of the polynomial
 *      ratio B/A, represented as Q/D.
 *
 *  SEE ALSO
 *      diff()
 */

Func List polyder(u, v, ...)
	Matrix u, v;
{
	Integer i,j,nu,nv;
	Matrix a,b,a1,a2,z,up,vp;
	Index f;

	error(nargchk(1, 2, nargs, "polyder"));

	if (nargs == 1) {
		v = [1];
	}

	u = makerowv(u);
	v = makerowv(v);
	nu = length(u);
	nv = length(v);
	if (nu < 2) {
		up = [0];
	} else {
		up = u(1:nu-1) .* Matrix([nu-1:-1:1]);
	}
	if (nv < 2) {
		vp = [0];
	} else {
		vp = v(1:nv-1) .* Matrix([nv-1:-1:1]);
	}
	a1 = conv(up,v);
	a2 = conv(u,vp);
	i = length(a1);
	j = length(a2);
	z = Z(1,abs(i-j));
	if (i > j) {
		a2 = [z a2];
	} else if (i < j) {
		a1 = [z a1];
	}
/*
	if (nargout < 2) {
		a = a1 + a2;
	} else {
		a = a1 - a2;
	}
*/
	a = a1 - a2;

	f = find(Array(a) != 0);
	if (any(Array(f))) {
		a = a(f(1):length(a));
	} else {
		a = [0];
	}
	b = conv(v,v);
	f = find(Array(b) != 0);
	if (any(Array(f))) {
		b = b(f(1):length(b));
	} else {
		b = [0];
	}
	return {a, b};
}
