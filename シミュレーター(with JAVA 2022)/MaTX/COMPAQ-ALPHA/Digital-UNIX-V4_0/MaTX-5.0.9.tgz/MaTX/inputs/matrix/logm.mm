
/*  -*- MaTX -*-
 *
 *  NAME
 *      logm() - Matrix natural logarithm
 *
 *  SYNOPSIS
 *      B = logm(A)
 *         Matrix B;
 *         Matrix A;
 *
 *  DESCRIPTION
 *      logm(X) is the matrix natural logarithm of X.  Complex
 *      results are produced if X has nonpositive eigenvalues.
 *
 *      logm() can be thought of as being computed using eigenvalues
 *      D and eigenvectors V,  such that if {V, D} = eig(X) then  
 *      logm(X) = V*log(D)/V.  
 * 
 *  SEE AlSO
 *      exp()
 */

Func Matrix logm(A)
	Matrix A;
{
	Complex log_comp();
	Matrix funm();

	return funm(A, log_comp);
}

Func Complex log_comp(d)
	Complex d;
{
	return log(d);
}
