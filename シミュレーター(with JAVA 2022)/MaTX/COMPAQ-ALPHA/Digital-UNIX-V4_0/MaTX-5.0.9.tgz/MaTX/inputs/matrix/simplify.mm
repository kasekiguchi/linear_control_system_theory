
/* -*- MaTX -*-
 *  
 *  NAME
 *      simplify() - Simplify a rational polynomial matrix
 *
 *  SYNOPSIS
 *      GG = simplify(G)
 *        RaMatrix GG;
 *        RaMatrix G;
 *
 *      GG = simplify(G, tol)
 *        RaMatrix GG;
 *        RaMatrix G;
 *        Real tol;
 *
 *  DESCRIPTION
 *      simplify(G) simplifies the elements of the given matrix G
 *      by using minreal().  tol is passed to minreal().
 *
 *  SEE ALSO
 *      minreal()
 */

Func RaMatrix simplify(G, tol, ...)
	RaMatrix G;
	Real tol;
{
	Integer i, j;
	Matrix A,B,C,D,q,r;
	RaMatrix GG;
	Polynomial n,d;
	Rational g;

	error(nargchk(1, 2, nargs, "simplify"));

	GG = Z(G);

	for (i = 1; i <= Rows(G); i++) {
		for (j = 1; j <= Cols(G); j++) {
			g = G(i,j);
			n = Nu(g);
			d = De(g);
			if (degree(n) > degree(d)) {
				if (version() == 4) {
					{q,r} = deconv(fliplr(Matrix(n)), fliplr(Matrix(d)));
				} else {
					{q,r} = deconv(Matrix(n), Matrix(d));
				}
				if (version() == 4) {
					g = Polynomial(fliplr(r))/d;
				} else {
					g = Polynomial(r)/d;
				}
				if (nargs == 2) {
					{A,B,C,D} = tfm2ss([g],1,tol);
				} else {
					{A,B,C,D} = tfm2ss([g]);
				}
				if (version() == 4) {
					GG(i,j) = Polynomial(fliplr(q)) + [ss2tfm(A,B,C,D)](1,1);
				} else {
					GG(i,j) = Polynomial(q) + [ss2tfm(A,B,C,D)](1,1);
				}
			} else {
				if (nargs == 2) {
					{A,B,C,D} = tfm2ss([g],1,tol);
				} else {
					{A,B,C,D} = tfm2ss([g]);
				}
				GG(i,j) = [ss2tfm(A,B,C,D)](1,1);
			}
		}
	}

	return GG;
}

