
/*  -*- MaTX -*-
 *
 *  NAME
 *      VecChop() - Chop a vector to some vectors
 *
 *  SYNOPSIS
 *      {x1, x2, ..., xn} = VecChop(X, idx)
 *         Matrix x1, x2, ..., xn;
 *         Matrix X;
 *         List idx;
 *
 *  DESCRIPTION
 *      Chop a long state vector to some states vectors according to the
 *      given list of index.
 *
 *  EXAMPLE
 *      {X, idx} = VecCont({[1], [1 2]', [1 2 3]', [1 2 3 4]'});
 *      {x1, x2, x3, x4} = VecChop(X, idx);
 *
 *  SEE ALSO
 *      VecCont().
 */


Func List VecChop(X, states_idx)
	Matrix X;
	List states_idx;
{
	Integer i, n;
	List states;

	n = length(states_idx);
	states = makelist(n);

	for (i = 1; i <= n; i++) {
		states(i) = X(states_idx(i,Index));
	}

	return states;
}
