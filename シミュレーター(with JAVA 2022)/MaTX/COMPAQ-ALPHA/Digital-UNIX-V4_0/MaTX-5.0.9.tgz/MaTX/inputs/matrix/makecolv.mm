
/* -*- MaTX -*-
 *
 *  NAME
 *      makecolv() - Make a column vector
 *
 *  SYNOPSIS
 *      v = makecolv(A)
 *         Matrix v;
 *         Matrix A;
 *
 *  SEE ALSO
 *      makerowv()
 */

Func Matrix makecolv(A)
	Matrix A;
{
	Integer m, n;
	
	{m,n} = size(A);
	if (m == 1 || n == 1) {
		return reshape(A, m*n, 1);
	} else {
		return reshape(trans(A), m*n, 1);
	}
}
