
/*  -*- MaTX -*-
 *
 *  NAME
 *      laguer() - Laguerre root finder
 *
 *  SYNOPSIS
 *      {x,iter} = laguer(aa,xx,myeps,polish)
 *           Complex x;
 *           Integer iter;
 *           Matrix aa;
 *           Complex xx;
 *           Real myeps, polish; 
 *
 *  DESCRIPTION
 *      Laguerre root finder for vector polynomial AA, given starting scalar
 *      value XX, typically 0.0.  The first root encountered is returned as X.
 *      If the polish flag is 0, then the fractional resolution will be myeps
 *      otherwise, it will be EPS.  If myeps is 0.0, a default value of 1e-8
 *      is assumed. iter is the number of Laguer iterates used to achieve 
 *      the root.
 *
 *  SEE ALSO
 *     roots()
 *
 *  REFERENCE:
 *      [1] W.H. Press et al., "Numerical Recipes", p. 263-266, 1986.  
 *          The present routine is nearly a direct transcription of the
 *          "Numerical Recipes" procedure.
 *
 */

Func List laguer(aa, xx, myeps, polish)
	Matrix aa;
	Complex xx;
	Real myeps, polish;
{
	Integer iter,m,maxit,mf,mm1,mp1,n;
	Real b,d,dx,f,g,g2,gm,gp,h,dxold;
	Real err, epss, eps1, sq, cdx;
	Matrix a,bb,dd,xpad,ord,ff,absbb;
	Array y;
	Complex x, x1;

	iter = 0;

	if (aa == []) {
		x = (0,0);
		return {x, iter};
	}

	a = [aa];

	// Initialization.
	{m, n} = size(a);
	m = m - 1;   // Actual order of polynomial.
	x = xx;
	dxold = abs(x);
	eps1 = myeps;
	if (myeps == 0.0) {
		eps1 = 1.0e-8;
	}
	epss = EPS;
	maxit = 100;
	
	mm1 = m - 1;
	mp1 = m + 1;
	
	bb = a;				// Polynomial
	
	ord = [m:-1:0]';
	dd = ord.*bb;
	dd = dd(1:m);		// First derivative
	
	ff = Z(1);
	mf = 1;
	if (m > 1) {
		mf = mm1;
		ord = [mf:-1:0]';
		ff = ord .* dd;
		ff = ff(1:mf);  // Second derivative
	}

	absbb = abs(Array(bb));    // For error estimation
	
	for (iter = 1; iter <= maxit; iter++) {
		xpad = [[1][-x]];
		
		{y} = filter(1,xpad,ff);
		f = y(mf);
		{y} = filter(1,xpad,dd);
		d = y(m);
		
		{y} = filter(1,xpad,bb);   // Need y below
		b = y(mp1);
		
		absbb = abs(y);
		
		{y} = filter(1,[1, -abs(x)],absbb);
		err = epss*y(mp1);
		
		if (abs(b) <= err) {
			dx = 0.0;
			return {x, iter};
		} else {
			g = d/b;
			g2 = g*g;
			h = g2 - f/b;   // Note no factor of 2 on f
			sq = sqrt(mm1*(m*h-g2));
			gp = g + sq;
			gm = g - sq;
			dx = m/max(gp, gm);
		}
		x1 = x - dx;
		if (x == x1) {
			return {x, iter};
		}
		x = x1;
		cdx = abs(dx);
		if (iter > 6 && cdx >= dxold) {
			return {x, iter};
		}
		dxold = cdx;
		if (polish == 0.0) {
			if (abs(dx) <= eps1*abs(x)) {
				return {x, iter};
			}
		}
	}
	return {x, iter};
}
