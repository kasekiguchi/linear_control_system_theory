
/*  -*- MaTX -*-
 *
 *  NAME
 *      meshdom() - Generate X and Y arrays for 3-d plots
 *
 *  SYNOPSIS
 *      {x,y} = meshdom(x, y)
 *          Matrix x,y;
 *          Matrix x, y;
 *
 *  DESCRIPTION
 *      meshdom(X,Y)  transforms the domain specified by vectors
 *      X and Y into arrays XX and YY that can be used for the evaluation
 *      of functions of two variables with 3-d mesh plots.
 *
 *      For example, to evaluate the function  x*exp(-x^2-y^2) over the 
 *      range  -2 < x < 2,  -2 < y < 2,
 *
 *        {x,y} = meshdom([-2:.2:2], [-2:.2:2]);
 *        z = x .* exp(-x^2 - y^2);
 *        mesh(z);
 *
 */

Func List meshdom(x_, y_)
	Matrix x_, y_;
{
	Matrix x, y;
	Integer nx, ny;

	x = x_;
	y = y_;

	nx = Cols(x);
	ny = Cols(y);
	x = ONE(ny, 1) * x;
	y = y(ny:-1:1);
	y = y# * ONE(1, nx);
	return {x, y};
}
