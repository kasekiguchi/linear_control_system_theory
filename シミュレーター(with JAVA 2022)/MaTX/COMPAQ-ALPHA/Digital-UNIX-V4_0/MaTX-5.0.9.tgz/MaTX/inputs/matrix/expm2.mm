
/*  -*- MaTX -*-
 *
 *  NAME
 *      expm2() - Matrix exponential via Taylor series.
 *
 *  SYNOPSIS
 *      EX = expm2(A)
 *         Matrix EX;
 *         Matrix A;
 *
 *  DESCRIPTION
 *      Scale A by power of 2 so that its norm is < 1/2 .
 *
 *  SEE ALSO
 *      exp1(), exp3() and exp()
 */

Func Matrix expm2(aa)
	Matrix aa;
{
	Matrix a,e,f;
	Integer k,s;

	a = aa;

	s = Integer(round(log(norm(a,1))/log(2.0) + 1.5));
	if (s < 0) {
		s = 0;
	}
	a = a/2^s;

	// Taylor series for exp(A)
	e = Z(a);
	f = I(a);
	k = 1;

	while (norm(e+f-e,1) > 0) {
		e = e + f;
		f = a*f/k;
		k = k + 1;
	}

	// Undo scaling by repeated squaring
	for (k = 1; k <= s; k++) {
		e = e*e;
	}

	return e;
}
