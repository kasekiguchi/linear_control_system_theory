
/*  -*- MaTX -*-
 *
 *  NAME
 *      mat_demo() - Demonstrations of matrix toolbox
 *
 *  SYNOPSIS
 *      mat_dem()
 *
 *  DESCRIPTION
 *   	mat_demo() brings up a menu of the available demonstrations
 *      for matrix toolbox.
 *
 *     gnuplot is required to display graphs.
 *     gnuplot is availabel by ftp from ftp.matx.org.
 *
 *  SEE ALSO
 *     demo()
 *
 */

Func void mat_demo()
{
	Integer n;
	List demos;

	void census(),fourier(),ctheorem(),movies(),nademo();

	demos = {"Demo of Matrix Toolbox",
			 "Predict 1990 population",
			 "A square wave is the sum of odd harmonics",
			 "The convolution theorem",
			 "Reduced row echelon form and eigenvalue movies",
			 "Numerical analysis (nonlinear) demonstrations",
			 "E N D"};

	n = 1;
	while (1) {
		n = menu(demos,n);
		switch (n) {
		  case 1:
			census();
			break;
		  case 2:
			fourier();
			break;
		  case 3:
			ctheorem();
			break;
		  case 4:
			movies();
			break;
		  case 5:
			nademo();
			break;
		  default:
			return;
			return;
		}
		n++;
	}
}



/*  -*- MaTX -*-
 *
 *  NAME
 *      census() - Demonstration of prediction of census data
 *
 *  SYNOPSIS
 *       census()
 */

Func void census()
{
	Integer i,c_i,n,t_i,win,j,d;
	Real year,pop90,lambda,time,day;
	Matrix A,B,Let,S,U,V,c,doomsday,p,t,x,y;
	CoMatrix z;

	win = mgplot_cur_win();
	
	clear;
	print "\n";
	print "This demonstration uses census data from 1900-1980 to predict\n";
	print "the population of the U.S. in 1990.  The example illustrates\n";
	print "the dangers of using high order polynomial fits for extrapolation.";
	print "\n\n";
	pause;

	clear;
	print "\n";
	print "We start by forming a time vector of the years from 1900-1980.\n";
	print "One unit in t corresponds to 10 years.\n\n";
	print "\tt = [0:8]';\n\n";
	pause;

	t = [0:8]';

	clear;
	print "\n";
	print"Let p be the vector of census data.\n";
	print "One unit in p is a million people.\n\n";

	print "\tp = [  75.995  91.972 105.711 123.203 131.669\n";
	print "\t      150.697 179.323 203.212 226.505]';\n\n";

	p = [  75.995  91.972 105.711 123.203 131.669
		  150.697 179.323 203.212 226.505]';
	
	print "Let's plot the data.\n\n";

	print "\tmgplot(win,t',p',{\"p\"});\n";
	print "\tmgplot_range(win, 0.0, 10.0, 0.0, 400.0);\n";
	print "\tmgplot_title(win, \"Population of the U.S. 1900-1980\");\n";
	print "\tmgplot_xlabel(win,\"1900 - 2000\");\n";
	print "\tmgplot_ylabel(win,\"Millions\");\n\n";

	pause "Strike any key for plot.";

	mgplot(win,t',p',{"p"});
	mgplot_range(win, 0.0, 10.0, 0.0, 400.0);
	mgplot_title(win, "Population of the U.S. 1900-1980");
	mgplot_xlabel(win,"1900 - 2000");
	mgplot_ylabel(win,"Millions");

	clear;
	print "\n";
	print "A polynomial fit to the data is a function of y(t) of the form:\n";
	print "\n";
	print "\t           d      d-1\n";
	print "\ty(t) = c1*t  + c2*t    + ... + cn ,\n";
	print "\n";
	print "The degree is d and the number of coefficients is n = d+1.\n";
	print "There are 9 observations so the data can be fit exactly by \n";
	print "a polynomial with d = 8 and n = 9.  The coefficients \n";
	print "c1, c2, ... c9 are determined by solving a 9 by 9 system \n";
	print "of simultaneous linear equations:\n";
	print "\n";
	print "\tA*c = p\n";
	print "\n";
	print "The columns of A are successive powers of the t vector.\n\n";
	pause;

	clear;
	print "\n";
	print "Here is one way to form A\n\n";

	print "\tn = max(Cols(t), Rows(t));\n";
	print "\tA = Z(Rows(t),n);\n";
	print "\tfor (j = 1; j <= n; j++) {\n";
	print "\t    A(:,j) = t.^(n-j);\n";
	print "\t}\n";

	pause "\nStrike any key to see A.\n";

	n = max(Cols(t), Rows(t));
	A = Z(Rows(t),n);
	for (j = 1; j <= n; j++) {
		A(:,j) = t.^(n-j);
	}
	print A;
	pause;

	clear;
	print "\n";
	print "The solution to the system of simultaneous linear equations\n\n";
	print "\tA*c = p\n\n";
	print "is obtained with the MaTX 'matrix division' operation:\n";
	print "\n";
	print "\tc = A\p;\n";
	print "\n";
	print "Notice that the leading coefficient is negative, so for large t,\n";
	print "the polynomial y(t) is a decreasing function of t.\n\n";
	pause;

	c = (A \ p)';

	clear;
	print "\n";
	print "To find the population in 1990, evaluate the polynomial at t = 9.";
	print "\n\n";
	if (version() == 4) {
		print "\tpop90 = eval(Polynomial(fliplr(c)), 9.0);\n\n";
	} else {
		print "\tpop90 = eval(Polynomial(c), 9.0);\n\n";
	}
	print "Hopefully, this is a severe UNDERestimate.\n\n";
	pause;
	
	if (version() == 4) {
		pop90 = eval(Polynomial(fliplr(c)), 9.0);
	} else {
		pop90 = eval(Polynomial(c), 9.0);
	}

	clear;
	print "\n";
	print "Was the underestimate caused by roundoff error?\n";
	print "Check the condition number of the matrix A.\n";
	print "(This involves doing a 9 by 9 singular value decomposition.)\n\n";
	print "\tprint cond(A);\n\n";

	printf("cond(A) = %g\n\n", cond(A));

	print "This says we lost about 9 significant digits in computing the \n";
	print "coefficients in the polynomial.  But we have about 16 digits \n";
	print "to work with, so our coefficients, and our predicted population,\n";
	print "are accurate to at least the number of digits we are printing.\n";
	print "\n";
	pause; 

	clear;
	print "\n";
	print "To see what went wrong, let's plot the polynomial.\n";
	print "The vector x corresponds to all the years from 1900 to 2000 and\n";
	print "the vector y contains the values of the polynomial at those 101\n";
	print "points.\n\n";

	print "\tx = [0:0.1:10]';\n";
	if (version() == 4) {
		print "\ty = eval(Polynomial(fliplr(c')), Array(x));\n\n";
	} else {
		print "\ty = eval(Polynomial(c'), Array(x));\n\n";
	}

	print "\tmgplot(win,t',p',{\"p\"});\n";
	print "\tmgreplot(win,x',y',{\"y\"});\n";
	print "\tmgplot_title(win,\"Polynomial interpolation, degree 8\");\n";
	print "\n";

	x = [0:0.1:10]';
	if (version() == 4) {
		y = eval(Polynomial(fliplr(c')), Array(x));
	} else {
		y = eval(Polynomial(c'), Array(x));
	}

	pause "Strike any key for plot.";

	mgplot_hold(win,1);
	mgplot(win,t',p',{"p"});
	mgreplot(win,x',y',{"y"});
	mgplot_title(win,"Polynomial interpolation, degree 8");
	mgplot_hold(win,0);

	clear;
	print "\n";
	print "The values obtained from the degree 8 polynomial decrease very\n";
	print "rapidly outside the interval containing the data points.\n";
	print "\n";

	pause;
	clear;
	print "\n";
	print "The polynomial actually goes through zero.  When?\n";
	print "Find the roots of the polynomial.\n\n";
	if (version() == 4) {
		print "\tz = roots(Polynomial(fliplr(c)));\n\n";
	} else {
		print "\tz = roots(Polynomial(c));\n\n";
	}
	pause;
	
	if (version() == 4) {
		z = roots(Polynomial(fliplr(c)));
	} else {
		z = roots(Polynomial(c));
	}

	clear;
	print "\n";
	print "Most of the roots are complex.  But the first one is real\n";
	print "and positive.  That's the one we're interested in.\n";
	print "Convert to years and days.\n\n";

	print "\ttime = 10*Re(z(1));\n";
	print "\tyear = fix(time);\n";
	print "\tday = 365*floor(time);\n";
	print "\tdoomsday = [year day];\n\n";

	time = 10*Re(z(1));
	year = fix(time);
	day = 365*floor(time);
	doomsday = [year day];

	print "That's September 27, 1991!\n\n";
	pause;

	clear;
	print "\n";
	print "Reduce the degree from 8 to 6.  There are still 9 equations, \n";
	print "but now only 7 coefficients.  Drop the first two columns of A \n";
	print "and find the best fit in a least square sense.\n\n";

	print "\tB = A(:,3:9);\n";
	print "\tc = B\p;\n";

	B = A(:,3:9);
	c = (B \ p)';

	print "\nNow the leading coefficient is positive.\n\n";
	pause;

	clear;
	print "\n";
	print "Predict the 1990 population with the 6th degree polynomial.\n";
	print "\n";
	if (version() == 4) {
		print "\tpop90 = eval(Polynomial(fliplr(c)), 9.0);\n\n";
	} else {
		print "\tpop90 = eval(Polynomial(c), 9.0);\n\n";
	}
	
	if (version() == 4) {
		pop90 = eval(Polynomial(fliplr(c)), 9.0);
	} else {
		pop90 = eval(Polynomial(c), 9.0);
	}

	print "That doesn't look too bad.  Do you trust it?\n\n";

	print "Let's plot this second fit.\n\n";
	
	if (version() == 4) {
		print "\ty = eval(Polynomial(fliplr(c)), Array(x));\n";
	} else {
		print "\ty = eval(Polynomial(c), Array(x));\n";
	}
	print "\tmgplot(win,t',p',{\"p\"});\n";
	print "\tmgreplot(win,x',y',{\"y\"});\n";
	print "\tmgplot_title(win,\"Least squares polynomial, degree 6\");\n\n";

	pause "Strike any key for plot.";
	
	if (version() == 4) {
		y = eval(Polynomial(fliplr(c)), Array(x));
	} else {
		y = eval(Polynomial(c), Array(x));
	}

	mgplot_hold(win,1);
	mgplot(win,t',p',{"p"});
	mgreplot(win,x',y',{"y"});
	mgplot_title(win,"Least squares polynomial, degree 6");
	mgplot_hold(win,0);

	clear;
	print "\n";
	print "This illustrates the dangers of using polynomials of even\n";
	print "modest degree for extrapolation beyond the data interval.\n\n";

	pause;
	clear;
	print "\n";
	print "Now we'll let you do your own polynomial fits to the data.\n";
	print "First of all, we'll prompt you for the degree of the polynomial.\n";
	print "The two fits you have already seen had degree 8 and degree 6.\n\n";
	print "Then we'll prompt you for something called the Levenberg-Marquardt\n";
	print "stabilization parameter.  The previous fits had no stabilization,\n";
	print "so the parameter was zero.  Low degree polynomials don't need much\n";
	print "stabilization, but, as we've seen, higher degree polynomials need\n";
	print "more.  The high order coefficient in the 8th degree polynomial is\n";
	print "quite sensitive to the parameter.  If you choose degree 8, try\n";
	print "stabilization parameters around 0.00005.  Other than that, nobody\n";
	print "really knows how to choose the Levenberg-Marquardt parameter,\n";
	print "so you're on your own.\n\n";

	print "We use the singular value decomposition to do polynomial fits with\n";
	print "Levenberg-Marquardt stabilization. If you know what this means, you\n";
	print "might be interested in the next page of information.  Otherwise\n";
	print "ignore it and just supply input data when asked.\n\n";

	pause;
	clear;
	print "\n";
	print "Polynomial fits with Levenberg-Marquardt stabilization.\n";

	while (1) {
		print "\n";
		print "Enter polynomial degree. (Less than 9. Enter 0 to quit.) ";
		read d;
//		{d} = scanf("%d");
		if (d <= 0) {
			break;
		}
		{U, S, V} = svd(A(:,n-d:n));
		if (d > 0) {
			S = diag_vec(S);
		}
		print "Enter stabilizing parameter. (Suggest .5 or 0.) ";
		read lambda;
//		{lambda} = scanf("%lf");
		c = U(:,1:d+1)#*p;
		c = S ./ (S .* S .+ lambda) .* c;
		c = (V*c)';
		if (version() == 4) {
			pop90 = eval(Polynomial(fliplr(c)), 9.0);
			y = eval(Polynomial(fliplr(c)), Array(x));
		} else {
			pop90 = eval(Polynomial(c), 9.0);
			y = eval(Polynomial(c), Array(x));
		}
		print "\n";
		pause "Strike any key for plot";

		mgplot_hold(win,1);
		mgplot(win,t',p',{"p"});
		mgreplot(win,x',y',{"y"});
		mgplot_hold(win,0);

		pause;
		clear;
	}
	mgplot_reset(win);
}


/*  -*- MaTX -*-
 *
 *  NAME
 *      fourier() - Demonstration of Fourie series expansion
 *
 *  SYNOPSIS
 *      fourier()
 *
 */

Func void fourier()
{
	Integer win,k;
	Array t,tt,y,x;

	win = mgplot_cur_win();

	clear;
	print "\n";
	print "The Fourier series expansion for a square-wave is made up of a\n";
	print "sum of odd harmonics. We can show this graphically using MaTX.\n";
	
	print "We start by forming a time vector running from 0 to 10 in step;\n";
	print "of 0.1, and taking the sine of all the points:\n\n";
	print "\tt = [0:0.1:10];\n";
	print "\ty = sin(t);\n";
	print "\tmgplot(win,t,y,{\"\"});\n\n";
	print "Let's plot this fundamental frequency.\n\n";
	pause;

	t = [0:0.1:10];
	y = sin(t);
	mgplot(win,t,y,{""});

	print "Now add the third harmonic to the fundamental, and plot it:\n\n";
	print "\ty = sin(t) + sin(3*t)/3;\n";
	print "\tmgplot(win,t,y,{\"\"});\n\n";
	pause;

	y = sin(t) + sin(3*t)/3;
	mgplot(win,t,y,{""});

	print "Now use the first, third, fifth, seventh, and ninth harmonics:\n\n";
	print "\ty = sin(t) + sin(3*t)/3 + sin(5*t)/5 + sin(7*t)/7 + sin(9*t)/9;\n";
	print "\tmgplot(win,t,y,{\"\"});\n\n";
	pause;

	y = sin(t) + sin(3*t)/3 + sin(5*t)/5 + sin(7*t)/7 + sin(9*t)/9;
	mgplot(win,t,y,{""});

	print "For a finale, we will go from the fundamental to the 19th\n";
	print "harmonic, creating vectors of successively more harmonics, and\n";
	print "saving all intermediate steps as rows in a matrix.\n\n";

	print "\tt = [0:0.02:3.14];\n";
	print "\ty = Z(10,length(t));\n";
	print "\tx = Z(t);\n\n";

	print "\tfor (k = 1; k <= lenght(t); k = k + (2)) {\n";
	print "\t\tx = x + sin(k*t)/k;\n";
	print "\t\ty((k+1)/2,:) = x;\n";
	print "\t}\n\n";
	pause;

	t = [0:0.02:3.14];
	y = Z(10,length(t));
	x = Z(t);

	for (k = 1; k <= 19; k = k + (2)) {
		x = x + sin(k*t)/k; 
		y((k+1)/2,:) = x;
	}

	print "Let's plot these successively on an overplot, showing the\n";
	print "transition to a square wave.  Note that Gibbs' effect says\n";
	print "that it will never really get there.\n\n";

	print "\tmgplot(win,y(1:2:9,:),{\"\"});\n";
	print "\tmgplot_title(win,\"The building of a square wave: Gibbs' effect\");";
	print "\n\n";
	pause;

	tt = ONE(5,1)*Matrix(t);

	mgplot(win, tt, y(1:2:9,:), {"1st","5rd","9th","13th","17th"});
	mgplot_title(win, "The building of a square wave: Gibbs effect");

//	print "Now plot this as a 3-d mesh surface, showing, perhaps\n";
//	print "more vividly, the transition to a square wave.\n\n";
//	print "\tmesh(y);\n\n";
//	pause;
//
//	mesh(y);

	mgplot_reset(win);
}


/*  -*- MaTX -*-
 *
 *  NAME
 *      ctheorem() - Demonstration of convolution
 *
 *  SYNOPSIS
 *      ctheorem()
 */

Func void ctheorem()
{
	Array XY,X,Y,x,y,zfreq,ztime;
	
	clear;
	print "\n";
	print "  A well known fact from systems theory is that convolution in\n";
	print "the time domain is equivalent to multiplication in the frequency\n";
	print "domain.  We can show this numerically with MaTX using the fft()\n";
	print "and the conv() functions.\n\n";
	
	print "We start by forming two sequences of numbers to work with,\n";
	print "arbitrarily selecting sequences of integers:\n\n";
	print "\tx = [1 2 3 4];\n";
	print "\ty = [5 4 3 2 1];\n\n";
	pause; 
	x = [1 2 3 4];
	y = [5 4 3 2 1];

	print "Convolving them in the time domain is easy, we just use the\n";
	print "convolution operator:\n\n";
	print "\tztime = conv(x,y);\n\n";
	ztime = conv(x,y);
	pause;

	print "To multiply the sequences in the frequency domain, the \n";
	print "sequences first need to be transformed to a frequency domain\n";
	print "representation.  We use FFTs to calculate the discrete Fourier\n";
	print "transforms.  The final sequence length of z will be eight, so\n";
	print "the vectors x and y must be padded with zeros to make them\n";
	print "length eight. We can then fft() them, multiply, and inverse\n";
	print "fft():\n\n";
	
	print "\tx = [x, Z(1,4)];\n";
	print "\ty = [y, Z(1,3)];\n";
	print "\tX = fft(x);\n";
	print "\tY = fft(y);\n";
	print "\tXY = X * Y;\n";
	print "\tzfreq = Re(ifft(XY));\n\n";
	pause;
	
	x = [x, Z(1,4)];
	y = [y, Z(1,3)];
	X = fft(x);
	Y = fft(y);
	XY = X * Y;
	zfreq = Re(ifft(XY));

	print "Comparing the FFT result with the convolution result:\n\n";
	print "\tprint ztime;\n";
	print "\tprint round(zfreq);\n\n";
	print ztime, "\n", round(zfreq);

	print "\n";
	print "We see that the two are indeed the same, within roundoff error.\n";
	print "For this display, the frequency results have been rounded to\n";
	print "remove a small amount of rounding error from the FFT algorithm.\n";
	print "\n";
	pause;

	print "We can look at the error by examining the difference between the\n";
	print "convolution results and the FFT results:\n\n";
	print "\tprint ztime - zfreq(1:5);\n\n";
	print ztime - zfreq(1:5);
	
	printf("\nand the maximum residual is about %16.8E.\n\n", 
		   max(abs(ztime - zfreq(1:5))));
}
