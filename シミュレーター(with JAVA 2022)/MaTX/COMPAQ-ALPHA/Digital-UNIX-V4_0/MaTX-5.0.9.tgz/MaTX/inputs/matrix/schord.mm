
/* -*- MaTX -*-
 *
 *  NAME
 *      schord() - Ordered schur decomposition
 *
 *  SYNOPSIS
 *      {Qo,To} = schord(Qi, Ti)
 *          Matrix Qo, To;
 *          Matrix Qi, Ti;
 *
 *      {Qo,To} = schord(Qi, Ti, index)
 *          Matrix Qo, To;
 *          Matrix Qi, Ti;
 *          Matrix index;
 *
 *  DESCRIPTION
 *      Given the square (possibly complex) upper-triangular matrix Ti 
 *      and orthogonal matrix Qi (as output, for example, from the function 
 *      schur()), schord() finds an orthogonal matrix Q so that the eigenvalues
 *      appearing on the diagonal of Ti are ordered according to the
 *      increasing values of the array index where the i-th element
 *      of index corresponds to the eigenvalue appearing as the
 *      element  Ti(i,i).
 *
 *      The orthogonal matrix Q is accumulated in Qo as  Qo = Qi*Q.
 *      If Qi is not given it is set to the identity matrix.
 *
 *      schord() will not reorder REAL Schur forms.
 *
 *  SEE ALSO
 *      schur()
 */

Func List schord(Qi, Ti, index, ...)
	Matrix Qi, Ti, index;
{
	Matrix Qo,To,t;
	Integer i,j,k,l,l1,l2,move,n,nc,nr;
	Real ix;

	error(nargchk(2, 3, nargs, "schord"));

	{nr,nc} = size(Ti);
	n = nr;
	if (nr != nc) {
		error("schord(): Nonsquare Ti.\n");
	}
	if (nargs == 2) {
		index = Ti;
		To = Qi;
	} else {
		To = Ti;
	}
	if (nargs > 2) {
		Qo = Qi;
	} else {
		Qo = I(n);
	}

	for (i = 1; i <= n-1; i++) {
		// find following element with smaller value of index
		move = 0;
		k = i;
		for (j = i+1; j <= n; j++) {
			if (index(j) < index(k)) {
				k = j;
				move = 1;
			}
		}
		// propagate eigenvalue up the diagonal from k-th to i-th entry
		if (move) {
			for (l = k; l >= i+1; l = l-1) {
				l1 = l - 1;
				l2 = l;
				t = givens(To(l1,l1)-To(l2,l2), To(l1,l2));
				t = [[t(2,:)][t(1,:)]];
				To(:,l1:l2) = To(:,l1:l2)*t;
				To(l1:l2,:) = t#*To(l1:l2,:);
				Qo(:,l1:l2) = Qo(:,l1:l2)*t;
				ix = index(l1);
				index(l1) = index(l2);
				index(l2) = ix;
			}
		}
	}

	return {Qo, To};
}
