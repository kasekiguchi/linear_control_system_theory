
/*  -*- MaTX -*-
 *
 *	NAME
 *      embrane() -  Eigenfunction of the L-shaped membrane
 *
 *  SYNOPSIS
 *      L = membrane(k,M,N)
 *         Matrix L;
 *         Integer k,M,N;
 *
 *      L = membrane(k,M,N,NP)
 *         Matrix L;
 *         Integer k,M,N,NP;
 *
 *  DESCRIPTION
 *      membrane(k,M,N,NP) returns the k-th eigenfunction of the L-shaped
 *      membrane, k <= 12.
 *
 *   	  M  : number of points on 1/3 of boundary, recommend M = 15.
 *   	  N  : number of terms in sum_, recommend N = 9.
 *   	  NP : number of terms in partial sum_, recommend NP = N.
 *
 */

Func Matrix membrane(k,M,N,NP, ...)
	Integer k;
	Integer M,N,NP;
{
	Integer MM,sym,del,j;
	Real lambda;
	Matrix L,A,Q,EE,R,alfa,c,tmp;
	Array theta,r,t,J,x,y,S;
	Index kidx;

	error(nargchk(3, 4, nargs, "membrane"));
	
	if (nargs < 4) {
		NP = N;  // Number of terms in partial sum_.
	}

	lambda = [9.6397238445, 15.19725192, 2*PI^2, 29.5214811,
			  31.9126360, 41.4745099, 44.948488, 5*PI^2, 5*PI^2,
			  56.709610, 65.376535, 71.057755](k);
	sym = Integer([1 2 3 2 1 1 2 3 3 1 2 1](k));

	// Part of the boundary in polar coordinates
	theta = [1:3*M]#/M * PI/4;
	r = [[  Array(ONE(M,1))./    cos(theta(1:M))]
		 [Array(ONE(2*M,1))./sin(theta(M+1:3*M))]];

	/*
	 * if sym = 1,
	 *      alfa = [1 5 7 11 13 17 19 ... ]*2/3, (odd, not divisible by 3)
	 * if sym = 2,
	 *      alfa = [2 4 8 10 14 16 20 ... ]*2/3, (even, not divisible by 3)
	 * if sym = 3,
	 *      alfa = [3 6 9 12 15 18 21 ... ]*2/3, (multiples of 3)
	 */

	alfa = [[sym], Z(1,N-1)];
	del = sym + 3*(sym == 1);
	for (j = 2; j <= N; j++) {
		alfa(j) = alfa(j-1) + del;
		del = 6 - del;
	}
	alfa = alfa# * 2.0/3.0;

	// Build up the matrix of fundamental solutions evaluated on the boundary.
	t = sqrt(lambda)*r;
	A = Z(length(t),N);
	for (j = 1; j <= N; j++) {
		{J} = bessela(alfa(j),t);
		A(:,j) = J .* sin(alfa(j)*theta);
	}

	/*
	 * The desired coefficients are the null vector.
	 * (lambda was chosen so that the matrix is rank deficient).  
	 */
	{Q,R,EE} = qr_p(A);
	kidx = [1:N-1];
	c = -R(kidx,kidx)\R(kidx,N);
	c = [[c][1]];
//	c(N) = 1;
	c = EE*makecolv(c);
	if (c(1) < 0.0) {
		c = -c;
	}

	/*
	 * The residual should be small.
	 * res = norm(A*c,Inf)/norm(abs(A)*abs(c),Inf)
	 */

	// Now evaluate the eigenfunction on a rectangular mesh in the interior.
	MM = 2*M+1;
	x = ONE(M+1,1)*Matrix([-M:M])/M;
	y = Matrix([M:-1:0])#/M*ONE(1,MM);
	r = sqrt(x*x + y*y);

	x(M+1,M+1) = 1.0;   //  singular value
	y(M+1,M+1) = 1.0;   //  singular value
	theta = atan2(y,x);
	theta(M+1,M+1) = 0; //  set 0 

	S = Z(M+1,MM);
	r = sqrt(lambda)*r;

	for (j = 1; j <= NP; j++) {
		{J} = bessela(alfa(j),r);
		S = S + c(j) * J * sin(alfa(j)*theta);
		L = Z(MM,MM);
		tmp = triu(S);
		L(1:M+1,:) = tmp;
		if (sym == 1) {
			L = L + L# - diag_vec(diag_vec(L));
		} else if (sym == 2) {
			L = L - L#;
		} else if (sym == 3) {
			L = L + L# - diag_vec(diag_vec(L));
		}

//		mesh(L);
	}

	/*
	 * The following two lines are commented out. They zero the edges.
	 * edge = Z(MM,1);
	 * L(:,1) = edge; L(:,MM) = edge; L(1,:) = edge#; L(MM,:) = edge#;
	 */

	L = rot90(L,2);
	return L;
}
