
/* -*- MaTX -*-
 *
 *  NAME
 *      funm() - Evaluate matrix functions
 *
 *  SYNOPSIS
 *      F = funm(A, fun)
 *         Matrix F;
 *         Matrix A;
 *         Complex fun();
 *
 *  DESCRIPTION
 *      For matrix arguments A, funm(A, fun) evaluates the matrix function
 *      specified by fun().   For example, funm(A, exp_f) calculates the 
 *      matrix exponential, and funm(A, log_f) the matrix logarithm, 
 *      and funm(A, sqrt_f) the matrix square root.
 *
 *        Func Complex exp_f(a) {
 *          Complex a;
 *        {
 *          return exp(a);
 *        }
 *
 *        Func Complex log_f(a) {
 *          Complex a;
 *        {
 *          return log(a);
 *        }
 *
 *        Func Complex sqrt_f(a) {
 *          Complex a;
 *        {
 *          return sqrt(a);
 *        }
 *
 *  REFERENCES
 *      [1] Parlett's method. Golub and VanLoan (1983), p. 384.
 */

Func Matrix funm(A, fun)
	Matrix A;
	Complex fun();
{
	Matrix F, Qr, Tr;
	CoMatrix Q, T, tmp;
	Integer i, j, p, m, n;
	Real tol, eps;
	Complex d, s;

	eps = EPS;

	m = Rows(A);
	n = Cols(A);

	if (m > n) {
		n = m;
	}

	{Qr, Tr} = schur(A);
	{Q, T} = rsf2csf(Qr, Tr);

	F = (Z(n),:);
	for (i = 1; i <= n; i++) {
		F(i,i) = fun(T(i,i));
	}

	tol = eps * norm(T, 1);

	for (p = 1; p <= n-1; p++) {
		for (i = 1; i <= n-p; i++) {
			j = i + p;
			s = T(i,j) * (F(j,j) - F(i,i));
			if (p > 1) {
				tmp = T(i,i+1:j-1)*F(i+1:j-1,j) - F(i,i+1:j-1)*T(i+1:j-1,j);
				s = s + tmp(1);
			}
			d = T(j,j) - T(i,i);

			if (abs(d) <= tol) {
				warning("funm(): Result is probably inaccurate.\n");
				d = (tol,0);
			}
			F(i,j) = s / d;
		}
	}

	F = Q * F * Q#;
	return F;
}
