
/*  -*- MaTX -*-
 *
 *  NAME
 *      fftshift() - Shift FFT
 *
 *  SYNOPSIS
 *      y = fftshift(x)
 *         Array y;
 *         Array x;
 *
 *  DESCRIPTION
 *      For vectors fftshift(X) returns a vector with the left and
 *      right halves swapped.
 *
 *      For matrices, fftshift(X) swaps the first and third quadrants 
 *      and the second and fourth quadrants.
 *
 *      fftshift() is useful for FFT processing, moving the zeroth
 *      lag to the center of the spectrum.
 *
 *  SEE ALSO
 *      fft()
 */

Func Array fftshift(x)
	Array x;
{
	Integer m, n;
	Index m1, n1, m2, n2;
	Array y;

	{m, n} = size(x);

	m1 = [1:ceil(m/2.0)];
	m2 = [ceil(m/2.0)+1:m];
	n1 = [1:ceil(n/2.0)];
	n2 = [ceil(n/2.0+1.0):n];

	//	Note: Can remove the first two cases when null handling is fixed.
	if (m == 1) {
		y = [x(n2), x(n1)];
	} else if (n == 1) {
		y = [[x(m2)]
			 [x(m1)]];
	} else {
		y = [[x(m2,n2), x(m2,n1)]
			 [x(m1,n2), x(m1,n1)]];
	}

	return y;
}
