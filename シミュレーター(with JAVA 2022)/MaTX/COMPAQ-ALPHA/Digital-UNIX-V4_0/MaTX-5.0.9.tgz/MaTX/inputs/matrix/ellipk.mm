
/*  -*- MaTX -*-
 *
 *  NAME
 *      ellipk() - Complete elliptic integrals
 *
 *  SYNOPSIS
 *      k = ellipk(kind, m)
 *         Matrix k;
 *         Integer kind;
 *         Matrix m;
 *
 *  DESCRIPTION
 *      ellipk(kind,m) returns the value of the complete elliptic
 *      integral of the kind kind, evaluated at m.
 *
 *      As currently implemented, m is limited to 0 < m < 1 and kind 
 *      must be 1. The accuracy of ellipk(kind,m) is EPS.
 *
 *      Be sure you don't confuse the modulus k with the parameter m -
 *      they are related in the following way:  m = k^2
 *
 *      ellipk() uses the method of the arithmetic-geometric mean
 *      described in [1].
 *
 *  REFERENCES
 *      [1] M. Abramowitz and I.A. Stegun, "Handbook of Mathematical
 *          Functions" Dover Publications, 1965, 17.6.
 *
 */

Func Matrix ellipk(kind, m_)
	Integer kind;
	Matrix m_;
{
	Matrix a,a0,b,b0,c,c0,k,m;
	Integer mm,mmax,nn;
	Real tol;
	Index im;

	m = m_;

	if (kind != 1) {
		error("ellipk(): currently does complete elliptic integrals of the first kind only.\n");
	}

	tol = EPS;
	{mm,nn} = size(m);
	im = find(Array(m) >= 1-tol);
	k = Z(mm,nn);
	m = makerowv(m);	// make row vector
	mmax = mm*nn;
	a0 = ONE(1,mmax);
	c0 = sqrt(Array(m));
	b0 = sqrt(Array(1 .- m));
	a = a0;
	b = b0;
	c = c0;

	while (any(abs(Array(c)) > tol)) {
		a0 = a;
		b0 = b;
		c0 = c;
		a = 0.5*(a0 + b0);
		b = sqrt(Array(a0 .* b0));
		c = 0.5*(a0 - b0);
	}

	k = reshape(PI*(2*a).~, Rows(k), Cols(k));

	if (length(im) != 0) {
		error("ellipk(): ellipk(1) is infinite.\n");
	}
	return k;
}
