
/*  -*- MaTX -*-
 *
 *  NAME
 *      toeplitz() - Toeplitz matrix
 *
 *  SYNOPSIS
 *      T = toeplitz(C)
 *        Matrix T;
 *        Matrix C;
 *
 *      T = toeplitz(C, R)
 *        Matrix T;
 *        Matrix C;
 *        Matrix R;
 *
 *  DESCRIPTION
 *      toeplitz(C,R) is a non-symmetric Toeplitz matrix having C as its
 *      first column and R as its first row.
 *
 *      toeplitz(C) is a symmetric (or Hermitian) Toeplitz matrix.
 *
 *  SEE ALSO
 *      hankel() and vander().
 *
 */

Func Matrix toeplitz(C_, R_, ...)
	Matrix C_, R_;
{
	Matrix C,R,T;
	Integer i, k, m, n;

	error(nargchk(1, 2, nargs, "toeplitz"));

	T = [];
	if (nargs == 1) {
		{m, n} = size(C_);
		if (n == 1) {
			R = C_#;
		} else {
			R = C_;
			C = C_#;
			if (n) {
				C(1) = R(1);
			}
		}
	} else if (nargs == 2) {
		C = C_;
		R = R_;
		if (all(Array([Cols(R) Rows(R)]) && Array([Cols(C) Rows(R)]))) {
			if (R(1) != C(1)) {
				warning("toeplitz(): Column wins diagonal conflict.\n");
			}
		}
	}

	n = max(Cols(R), Rows(R));
	m = max(Cols(C), Rows(C));
	C = makecolv(C);	// Make sure C is a column vector
	R = makerowv(R);	// Make sure R is a row vector
	T = ONE(m,n);			// Allocate T
	k = min(m,n);

	for (i = 1; i <= k; i++) {	 // Fill in the matrix
		 T(i,i:n) = R(1:n-i+1); // ith row, upper triangle
		 T(i:m,i) = C(1:m-i+1); // ith col, lower triangle
	 }
	return T;
}



