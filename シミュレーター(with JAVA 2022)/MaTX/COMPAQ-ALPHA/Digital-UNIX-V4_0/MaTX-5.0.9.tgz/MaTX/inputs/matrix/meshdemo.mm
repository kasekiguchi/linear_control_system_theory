
/*  -*- MaTX -*-
 *
 *  NAME
 *      meshdemo() - Demonstration of mesh()
 *
 *  SYNOPSIS
 *      meshdemo()
 *
 */

Func void meshdemo()
{
	Integer win;
	Matrix x,y,R,z;

	win = mgplot_cur_win();

	clear;
	print "\n";
	print "The classic 'sombrero' or  sin(x)/x   3-d perspective surface \n";
	print "can be created using the 'mesh' command. \n";
	print "\n";
	print "First we form a radius matrix R that contains elements whose\n";
	print "values are the 'distance' from the center of the matrix.\n\n";

	x = [-8: .5: 8];
	y = x#;
	x = ONE(y) * x;
	y = x#;
	R = sqrt(Array(x.^2 + y.^2)) .+ EPS;

	print "Now we form a matrix of  sin(r)/r and plot it using 'mesh':\n\n";

	z = sin(Array(R))./Array(R);

	pause;
//	mesh(z);
	mgplot_title(win,"sin(r)/r");

	pause;
//	contour(z);
	mgplot_title(win,"Contour Plot");

	pause;
	clear;
	print "\n";
	print "Here is a second example, a cosine function, obtained by\n";
	print "applying the cosine to the radius matrix R:\n\n";

	pause "Strike any key to plot.";
//	mesh(cos(R));
	pause;

	mgplot_reset(win);
}
