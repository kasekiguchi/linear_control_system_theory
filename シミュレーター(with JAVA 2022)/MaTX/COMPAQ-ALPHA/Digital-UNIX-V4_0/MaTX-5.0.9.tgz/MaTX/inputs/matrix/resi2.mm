
/*  -*- MaTX -*-
 *
 *  NAME
 *      resi2() - Reside of a repeated pole
 *
 *  SYNOPSIS
 *      coeff = resi2(u,v,pole)
 *         Complex coeff;
 *         Matrix u,v;
 *         Complex pole;
 *
 *      coeff = resi2(u,v,pole,n)
 *         Complex coeff;
 *         Matrix u,v;
 *         Complex pole;
 *         Integer n;
 *
 *      coeff = resi2(u,v,pole,n,k)
 *         Complex coeff;
 *         Matrix u,v;
 *         Complex pole;
 *         Integer n;
 *         Integer k;
 *
 *  DESCRIPTION
 *      resi2(u,v,pole,n,k) returns the residue of a repeated pole
 *      of order n and the k-th power denominator of [1, -pole], where
 *      u and v represent the original polynomial ratio u/v.
 *
 *      For example, if p is a pole of multiplicity 2,
 *      then this routine should be called twice with n = 2,
 *      first using k = 1, then k = 2.  If k is not provided,
 *      it defaults to n.  If n is not provided, it defaults to 1.
 * 
 *  SEE ALSO
 *      residue() and polyder()
 *
 */

Func Complex resi2(u, v, pole, n, k, ...)
	Matrix u, v;
	Complex pole;
	Integer n, k;
{
	Complex coeff;
	Integer j;
	Real c;
	Matrix p;

	error(nargchk(3, 5, nargs, "resi2"));

	if (nargs == 3) {
		n = 1;
		k = n;
	} else if (nargs == 4) {
		k = n;
	}

	u = makerowv(u);
	v = makerowv(v);
	p = [1, -pole];
	for (j = 1; j <= n; j++) {
		{v} = deconv(v,p);
	}
	for (j = 1; j <= n-k; j++) {
		{u, v} = polyder(u,v);
	}
	c = 1.0;
	if (k < n) {
		c = prod([1:n-k]);
	}
	if (version() == 4) {
		coeff = (eval(Polynomial(fliplr(u)), pole) / eval(Polynomial(fliplr(v)), pole)) / c;
	} else {
		coeff = (eval(Polynomial(u), pole) / eval(Polynomial(v), pole)) / c;
	}
	return coeff;
}
