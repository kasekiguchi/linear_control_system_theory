
/*  -*- MaTX -*-
 *
 *	NAME
 *      gammac() - Complete Gamma function
 *
 *  SYNOPSIS
 *      gam = gammac(x)
 *         Real gam;
 *         Real x; 
 *
 *  DESCRIPTION
 *     gammac(X) returns the value of the complete Gamma function
 *     for real scalar argument x.
 *
 *     Computation is based on an algorithm outlined in W. J. Cody,
 *     "An Overview of Software Development for Special Functions",
 *     Lecture Notes in Mathematics, 506, Numerical Analysis Dundee,
 *     1975, G. A. Watson (ed.), Springer Verlag, Berlin, 1976.
 *
 */

Func Real gammac(x)
	Real x;
{
	Real gam,y,y1,ysq,z,sum_,xbig,factt;
	Integer i,n,sign,xden,xnum,res;
	Matrix c,p,q;

	xbig = 171.4584;

	p = [-1.71618513886549492533811e+0,	2.47656508055759199108314e+1,
		 -3.79804256470945635097577e+2,  6.29331155312818442661052e+2,
          8.66966202790413211295064e+2, -3.14512729688483675254357e+4,
		 -3.61444134186911729807069e+4,  6.64561438202405440627855e+4]';

	q = [-3.08402300119738975254353e+1,  3.15350626979604161529144e+2,
		 -1.01515636749021914166146e+3, -3.10777167157231109440444e+3,
          2.25381184209801510330112e+4,  4.75584627752788110767815e+3,
		 -1.34659959864969306392456e+5, -1.15132259675553483497211e+5]';

	//  coefficients for minimax approximation over (12, (2.0^1023)).
	c = [-1.910444077728e-03, 	 	   8.4171387781295e-04,
		 -5.952379913043012e-04, 	   7.93650793500350248e-04,
		 -2.777777777777681622553e-03, 8.333333333333333331554247e-02,
          5.7083835261e-03]';

	sign = 1;
	factt = 1.0;
	y = x;
	
	// Negative x
	if (y <= 0.0) {
		y = -x;
		if (rem(Integer(fix(y)),2) != 0) {
			sign = -1;
		}
		res = rem(Integer(y),1);
		if (res != 0) {
			factt = -PI/sin(PI*res);
		} else {
			// Pole at negative integers
			error("gammac(): gammac(" + String(x) + ") is infinite.");
		}
		y = y + 1;
	}

	// Small x
	if (y < EPS) {
		gam = 1/y;
		// EPS < x <= 12
	} else if (y <= 12.0) {
		y1 = y;
		if (y < 1.0) {
			n = 0;
			z = y;
			y = y + 1;
		} else {
			n = Integer(fix(y)) - 1;
			y = y - n;
			z = y - 1;
		}
		
		// Rational approximation for 1.0 < x < 2.0
		xnum = 0;
		xden = 1;
		for (i = 1; i <= 8; i++) {
			xnum = Integer((xnum + p(i)) * z);
			xden = Integer(xden * z + q(i));
		}
		gam = Real(xnum / xden + 1);
		if (y > y1) {
			// Adjust result for 0.0 < x < 1.0
			gam = gam / y1;
		} else if (y < y1) {
			// Adjust result for 2.0 < x < 12.0
			for (i = 1; i <= n; i++) {
				gam = gam * y;
				y = y + 1;
			}
		}
		// Different rational approximation for 12 < x < xbig
	} else if (y <= xbig) {
		ysq = y * y;
		sum_ = c(7);
		for (i = 1; i <= 6; i++) {
			sum_ = sum_/ysq + c(i);
		}
		sum_ = sum_/y - y + log(2*PI)/2 + (y-0.5)*log(y);
		gam = exp(sum_);
		//  Large x
	} else {
		gam = 2.0^1023;
	}
	
	// Final adjustments
	gam = sign*gam;
	if (factt != 1.0) {
		gam = factt/gam;
	}
	if (x == round(x)) {
		gam = round(gam);
	}
	return gam;
}

