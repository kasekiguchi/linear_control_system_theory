
/* -*- MaTX -*-
 *
 *  NAME
 *      chol() - Cholesky factorization
 *
 *  SYNOPSIS
 *      R = chol(X)
 *         Matrix R;
 *         Matrix X;
 *
 *  DESCRIPTION
 *     chol(X) computs the Cholesky factorization of a symmetric matrix.
 *     If X is positive definite, then
 *
 *       R = chol(X)
 *
 *     produces an upper triangular R so that R' * R = X. chol() uses only
 *     the diagonal and upper triangle of X; the lower triangular is assumed
 *     to be the (complex-conjugate) transpose of the uuper.
 *
 */

Func Matrix chol(X)
	Matrix X;
{
	Matrix R;
	Integer n, j;
	Real eps;

	eps = frobnorm(X)*EPS;
	n = Cols(X);

	if (max(abs(Array(X - X#))) > eps) {
		printf("max(abs(Array(X - X#))) = %g\n", max(abs(Array(X - X#))));
		warning("chol(): Matrix must be symmetric or Hermitian.\n");
	}

	R = X;
	for (j = 1; j <= n; j++) {
		if (j > 1) {
			R(j:n,j) = R(j:n,j) - R(j:n,1:j-1)*R(j,1:j-1)#;
		}
		if (R(j,j) < 0.0) {
			error("chol(): Matrix must be positive definite.\n");
		}
		R(j:n,j) = R(j:n,j)/sqrt(R(j,j));
	}

	for (j = 1; j <= n-1; j++) {
		R(j,j+1:*) = Z(1,n-j);
	}
	
	if (max(abs(Array(R*R# - X))) > eps) {
		printf("max(abs(R*R# - X)) = %g\n", max(abs(Array(R*R# - X))));
		warning("chol(): Decompostion may be incorrect.\n");
	}

	return R#;
}
