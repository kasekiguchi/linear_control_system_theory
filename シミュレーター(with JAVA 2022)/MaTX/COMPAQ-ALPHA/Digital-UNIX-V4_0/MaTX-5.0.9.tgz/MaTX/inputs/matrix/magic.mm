
/* -*- MaTX -*-
 *
 *  NAME
 *      magic() - Magic Square
 *
 *  SYNOPSIS
 *      M = magic(N)
 *         Matrix M;
 *         Integer n;
 *
 *  DESCRIPTION
 *      magic() Computs the Magic Square
 */

Func Matrix magic(N)
	Integer N;
{
	Integer i, j, k;
	Matrix A, M;

	A = Z(N);
	M = Z(N);
	if (rem(N,2) == 0) {
		// Make a seed matrix of magic square of even-order
		for (i = 1; i <= N/2; i++) {
			for (j = 1; j <= N; j++) {
				if (rem(i,2) == 1) {
					A(i,j) = j;
					A(N-i+1,j) = j;
				} else {
					A(i,j) = N - j + 1;
					A(N-i+1,j) = N - j + 1;
				}
			}
		}

		// 4m + 2 order
		if (rem(N-2,4) == 0) {
			A(N/2,:) = fliplr(A(N/2,:));
			A(N/2,Index([N/2,N/2+1])) = A(N/2,Index([N/2+1,N/2]));
			A(N,Index([N/2,N/2+1])) = A(N,Index([N/2+1,N/2]));
		}

		for (i = 1; i <= N; i++) {
			for (j = 1; j <= N; j++) {
				M(i,j) = A(i,j) + N*(A(j,i) - 1);
			}
		}
	} else {
		// odd order
		k = 0;
		for (i = -N/2; i <= N/2; i++) {
			for (j = 0; j < N; j++) {
				M(rem(j-i+N,N)+1,rem(j+i+N,N)+1) = ++k;
			}
		}
	}

	return M;
}
