
/*  -*- MaTX -*-
 *
 *  NAME
 *      fmin() - Minimum of a function of one variable
 *
 *  SYNOPSIS
 *      x = fmin(FunFcn, ax, bx)
 *        Real x;
 *        Real FunFcn();
 *        Real ax, bx;
 *
 *      x = fmin(FunFcn, ax, bx, tol)
 *        Real x;
 *        Real FunFcn();
 *        Real ax, bx;
 *        Real tol;
 *
 *      x = fmin(FunFcn, ax, bx, tol, pr_flag)
 *        Real x;
 *        Real FunFcn();
 *        Real ax, bx;
 *        Real tol;
 *        Integer pr_fla;
 *
 *  DESCRIPTION
 *      fmin() returns the value of x that minimimizes F(x) in the interval
 *      x1 < x < x2.  The value of x is accurate to within a relative error
 *      of 1e-3.  F is a function to be minimized.
 *
 *      fmin(..., tol) returns x to a relative error of tol.
 *      fmin(..., tol,1) displays a trace of the algorithm steps.
 *
 *  REFERENCES
 *      [1] "Computer Methods for Mathematical Computations", Forsythe,
 *           Malcolm, and Moler, Prentice-Hall, 1976.
 */

Func Real fmin(FunFcn, ax, bx, tol, pr_flag, ...)
	Real FunFcn();
	Real ax, bx, tol;
	Integer pr_flag;
{
	Integer gs,num;
	Matrix fmin_data;
	Real seps,si,tol1,tol2,fx,fv,fu,fw;
	Real a,b,c,d,e,p,q,r,u,v,w,x,xm;
	String step_str;

	error(nargchk(3, 5, nargs, "fmin"));
	
	// initialization
	if (nargs <= 4) {
		pr_flag = 0;
	}
	if (nargs <= 3) {
		tol = (bx-ax)/1000;
	}

	num = 1;
	seps = sqrt(EPS);
	c = 0.5*(3.0 - sqrt(5.0));
	a = ax;
	b = bx;
	v = a + c*(b-a);
	w = v;
	x = v;
	d = 0.0;
	e = 0.0;
	fx = FunFcn(x);
	if (pr_flag) {
		printf("%3d:  %16.8E  %16.8E\n", 1, x, fx);
		printf("num:          x                  fx       \n");
	}
	fv = fx;
	fw = fx;
	xm = 0.5*(a+b);
	tol1 = seps*abs(x) + tol/3.0;
	tol2 = 2.0*tol1;
	
	//	main loop
	while (abs(x-xm) > tol2 - 0.5*(b-a)) {
        num = num+1;
		gs = 1;
		
        // is parabolic fit possible
        if (abs(e) > tol1) {	// yes so fit parabola
			gs = 0;
			r = (x-w)*(fx-fv);
			q = (x-v)*(fx-fw);
			p = (x-v)*q-(x-w)*r;
			q = 2.0*(q-r);
			if (q > 0.0) {
				p = -p;
			}
			q = abs(q);
			r = e;  e = d;
			
			// is parabola acceptable
			if (abs(p) < abs(0.5*q*r) || p > q*(a-x) || p < q*(b-x)) {
				
				// yes, parabolic interpolation step
				d = p/q;
				u = x+d;
				step_str = "num:          x                  fx       parabolic";
				
				// f must not be evaluated too close to ax or bx
				if (u-a < tol2 || b-u < tol2) {
					si = sgn(xm-x) + ((xm-x) == 0.0);
					d = tol1*si;
				}
			} else {    // not acceptable, must do a golden section step
				gs = 1;
			}
        }
        if (gs) {	// a golden-section step is required
			if (x >= xm) {
				e = a-x;
			} else {
				e = b-x;
			}
			d = c*e;
			step_str = "num:          x                  fx       golden   ";
        }
		
        // func must not be evaluated too close to x
        si = sgn(d) + (d == 0.0);
        u = x + si * max(abs(d), tol1);
        fu = FunFcn(u);
        if (pr_flag) {
			printf("%3d:  %16.8E  %16.8E\n", num, u, fu);
			printf("%s\n", step_str);
		}

        // update a, b, v, w, x, xm, tol1, tol2
        if (fu <= fx) {
			if (u >= x) {
				a = x;
			} else {
				b = x;
			}
			v = w; fv = fw;
			w = x; fw = fx;
			x = u; fx = fu;
        } else { // fu > fx
			if (u < x) {
				a = u;
			} else {
				b = u;
			}
			if (fu <= fw || w == x) {
				v = w; fv = fw;
				w = u; fw = fu;
			} else if (fu <= fv || v == x || v == w) {
				v = u; fv = fu;
			}
        }
		xm = 0.5*(a+b);
		tol1 = seps*abs(x) + tol/3.0;
		tol2 = 2.0*tol1;
	}
	return x;
}
