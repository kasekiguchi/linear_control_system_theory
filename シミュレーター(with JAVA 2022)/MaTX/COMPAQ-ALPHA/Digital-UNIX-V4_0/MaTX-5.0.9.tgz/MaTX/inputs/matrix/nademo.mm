
/* -*- MaTX -*-
 *
 *  NAME
 *      nademo() - Numerical Analysis Toolbox Demonstrations
 *
 *  SYNOPSIS
 *      nademo()
 *
 *  DESCRIPTION
 *       1) Ordinary differential equations.
 *       2) Adaptive quadrature.
 *       3) Zerofinding with fzero.
 *       4) Nonlinear minimization with Nelder-Meade search.
 *  
 */

Func void nademo()
{
	Integer n;
	List demos;

	void odedemo(), quaddemo(), zerodemo(), fitdemo();

	clear;
	print "\n";
	print "MaTX itself handles the linear side of numerical analysis.  A\n";
	print "collection of MM-files we call the Numerical Analysis Toolbox\n";
	print "extends the capabilities of MaTX into the nonlinear aspects of\n";
	print "numerical analysis.  The primary tools in the first release ";
	print "include:\n\n";

	print "* Numerical solution of ordinary differential equations using\n";
	print "  automatic step size Runge-Kutta methods based on the Fehlberg\n";
    print "  4th and 5th order pair of formulas for high accuracy and \n";
	print "  a simple 2nd and 3rd order pair for medium accuracy.\n";
    print "  (ODE45 and ODE23)\n";
	print "\n";
	print "* Numerical evaluation of integrals using a recursive, adaptive\n";
	print "  Simpson's rule. (QUAD)\n";
	print "\n";
	print "* Finding a zero of a function of one variable using the 'fzero'\n";
	print "  algorithm of Dekker, Brent and Forsythe, Malcolm and Moler.\n";
	print "  (FZERO)\n";
	print "\n";
	print "* Finding a minimum of a function of several variables using the\n";
	print "  Nelder-Meade simplex algorithm for nonlinear optimization.\n";
	print "  (FMINS)\n\n";
	pause;

	clear;
	print "\n";
	print "All the tools provide for the graphical monitoring of the\n";
	print "progress of the algorithm.  For example, the adaptive\n";
	print "quadrature can plot the integrand as it is being sampled. \n";
	print "All the tools require the specification of a nonlinear\n";
	print "function of one or several variables.  These functions\n";
	print "are defined by M-files whose names are passed as text\n";
	print "arguments to the tools.  For example, QUAD(foo,a,b)\n";
	print "finds the numerical value of the integral of foo(x) over\n";
	print "the interval [a,b].\n\n";
	pause;

	demos = {"Numerical Analysis Toolbox Demonstrations",
			 "Ordinary differential equations.",
			 "Adaptive quadrature.",
			 "Zerofinding with fzero.",
#ifndef VC40
#ifndef DJGPP
			 "Nonlinear minimization with Nelder-Meade search.",
#endif
#endif
			 "Quit."};
	
	n = 1;
	while (1) {
		n = menu(demos,n);
		switch (n) {
		  case 1:
			odedemo();
			break;
		  case 2:
			quaddemo();
			break;
		  case 3:
			zerodemo();
			break;
#ifndef VC40
#ifndef DJGPP
		  case 4:
			fitdemo();
			break;
#endif
#endif
		  default:
			return;
		}
		n++;
	}
}


/*  -*- MaTX -*-
 *
 *  NAME
 *      odedemo() - Demonstration of ode23() and ode45()
 *
 *  SYNOPSIS
 *      odedemo()
 *
 */

Func void odedemo()
{
	Integer trc,win;
	Real t0,tfinal,tol;
	Matrix y0,T,Y,y,t;

	List ode23(...),ode45(...);
	Matrix vdpol();

	win = mgplot_cur_win();

	clear;
	print "\n";
	print "ODE23 and ODE45 are functions for the numerical solution of\n";
	print "ordinary differential equations.  They employ automatic step\n";
	print "size Runge-Kutta-Fehlberg integration methods.  ODE23 uses a\n";
	print "simple 2nd and 3rd order pair of formulas for medium accuracy\n";
	print "and ODE45 uses a 4th and 5th order pair for higher accuracy.\n";
	print "This demo shows their use on a simple differential equation.\n";
	print "\n";
	pause;

	clear;
	print "\n";
	print "Consider the second order differential equation known as the\n";
	print "van der Pol equation\n";
	print "\n";
	print "\ty'' + (y^2 - 1)y' + y = 0\n";
	print "\n";

	print "where the prime ' denotes the derivative operator.  We can\n";
	print "rewrite this as a system of first order differential equations:\n";
	print "\n";
	print "\ty1' = y1(1 - y2^2) - y2\n";
	print "\ty2' = y1\n\n";
	pause;

	clear;
	print "\n";
	print "To simulate a system, we create a function MM-file that returns\n";
	print "state derivatives, given state and time values.  For this\n";
	print "example, we've created a file called VDPOL.MM.  Here's what it\n";
	print "looks like:\n\n";

	print "Func Matrix vdpol(t,y)\n";
    print "    Real t;\n";
    print "    Matrix y;\n";
	print "{\n";
    print "    Matrix yprime;\n";
	print "\n";
    print "    yprime = [[y(1)*(1-y(2)^2) - y(2)]\n";
	print "              [         y(1)         ]];\n";
    print "\n";
    print "    return yprime;\n";
	print "}\n";
	print "\n";
	pause;

	clear;
	print "\n";
	print "To simulate the differential equation defined in VDPOL over\n";
	print "the interval  0 < t < 20, we invoke ODE23:\n";
	print "\n";
	print "\tt0 = 0;\n";
	print "\ttfinal = 15;\n";
	print "\ty0 = [0 0.25]';    // Define initial conditions.\n";
	print "\ttol = 1.e-3;       // Accuracy\n";
	print "\ttrc = 1;\n";
	print "\t{t,y} = ode23(vdpol,t0,tfinal,y0,tol,trc);\n\n";
	pause "Strike any key to start ODE23 solution.";

	t0 = 0;
	tfinal = 15;
	y0 = [0 0.25]';
	tol = 1.e-3;		// Accuracy
	trc = 1;
	{t,y} = ode23(vdpol,t0,tfinal,y0,tol,trc);

	mgplot_title(win,"van der Pol equation time history");
	mgplot_xlabel(win, "time");
	mgplot(win,t',y',{"y1","y2"});
	print "\n";
	pause;

	mgplot_title(win,"van der Pol equation - phase plane plot");
	mgplot_xlabel(win, "y1");
	mgplot_ylabel(win, "y2");
	mgplot(win,y(:,1)',y(:,2)',{""});
	pause;
	clear;

	print "\n";
	print "We will now simulate VDPOL using ODE45, instead of ODE23.\n";
	print "ODE45 takes longer at each step, but also takes larger steps.\n";
	print "\n";
	print "\t{T,Y} = ode45(vdpol,t0,tfinal,y0,tol,trc);\n\n";
	pause "Strike any key to start ODE45 solution.";

	{T,Y} = ode45(vdpol,t0,tfinal,y0,tol,trc);

	mgplot_hold(win,1);
	mgplot(win,T',Y(:,1)',{"ODE45"});
	mgreplot(win,t',y(:,1)',{"ODE23"});
	mgplot_title(win,"ODE23 and ODE45");
	mgplot_xlabel(win,"ODE45 steps are larger than ODE23 steps");
	mgplot_hold(win,0);
	mgplot_reset(win);
	clear;
}

/*  -*- MaTX -*-
 *
 *  NAME
 *      vdpol(t,y) - State derivatives of the Van der Pol
 *
 *  SYNOPSIS
 *      yprime = vdpol(t,y)
 *         Matrix yprime;
 *         Real t;
 *         Matrix y; 
 *
 *  DESCRIPTION
 *   	vdpol(t,y) returns the state derivatives of the Van der Pol
 *   	equation.  Used by odedemo().
 *
 */

Func Matrix vdpol(t,y)
	Real t;
	Matrix y;
{
	Matrix yprime;

	yprime = [[y(1)*(1-y(2)^2) - y(2)]
			  [         y(1)         ]];
	return yprime;
}


/*  -*- MaTX -*-
 *
 *  NAME
 *      quaddemo() - Demonstration of quadrature
 *
 *  SYNOPSIS
 *      quaddemo()
 *
 *  DESCRIPTION
 *     This demo illustrates the use of quadrature.
 */

Func void quaddemo()
{
	Integer win;
	Matrix x,y;
	Real Q;
	Matrix humps();

	win = mgplot_cur_win();

	clear;
	print "\n";
	print "Quadrature is a technique used to numerically evaluate\n";
	print "integrals, i.e. to calculate definite integrals. In MaTX\n";
	print "a function called QUAD implements quadrature using a\n";
	print "recursive adaptive Simpson's rule.\n\n";
	pause;

	clear;
	print "\n";
	print "Consider a function called humps(x) that we've defined ";
	print "in an MM-file on disk,\n\n";

	print "Func Matrix humps(x)\n";
	print "    Matrix x;\n";
	print "{\n";
	print "    Matrix y;\n";
	print "\n";
	print "    y = ((x .- 0.3).^2 .+ 0.01).~ + ((x .- 0.9).^2 .+ 0.04).~ .- 6";
	print "\n";
	print "    return y;\n";
	print "}\n";
	print "\n\n";
	pause;

	clear;
	print "\n";
	print "Let's plot this function on the interval from 0 to 1,\n\n";

	print "\tx = [0:.02:1];\n";
	print "\ty = humps(x);\n";
	print "\tmgplot(win,x,y,{\"\"});\n";
	print "\tmgplot_title(win,\"Plot of the function humps(x)\");\n";
	print "\n";
	pause "Strike any key for plot.";

	x = [0:.02:1];
	y = humps(x);
	mgplot(win,x,y,{""});
	mgplot_title(win,"Plot of the function humps(x)");
	pause;

	clear;
	print "\n";
	print "To integrate this function over the interval  0 < x < 1 , ";
	print "we invoke QUAD:\n";
	print "\n";
	pause "Strike any key to start plot of iterations.";

	mgplot_hold(win,1);
	{Q} = quadf(humps, 0.0, 1.0, 1e-3, 1);
	mgplot_title(win, sprintf("Area is %g", Q));
	mgplot_hold(win,0);
}

/*  -*- MaTX -*-
 *
 *  NAME
 *      zerodemo() - Demonstration of fzero()
 *
 *  SYNOPSIS
 *      zerodemo()
 *
 *  DESCRIPTION
 *      This demo shows how to find the zero of a function.
 */

Func void zerodemo()
{
	Integer win;
	Real z;
	Matrix x,y;

	Matrix humps();
	Real hump();

	win = mgplot_cur_win();

	clear;
	print "\n";
	print "A function called FZERO is used to find a zero of a function.\n";
	print "\n";

	print "Consider a function called hump(x) that we've defined in ";
	print "an MM-file on disk,\n\n";

	print "Func Real hump(x)\n";
	print "    Real x;\n";
	print "{\n";
	print "    Real y;\n";
	print "\n";
	print "    y = ((x - 0.3)^2 + 0.01)~ + ((x - 0.9)^2 + 0.04)~ - 6";
	print "\n";
	print "    return y;\n";
	print "}\n";
	print "\n";
	pause;

	clear;
	print "\n";
	print "Let's plot this function on the interval from 0 to 2,\n\n";

	print "\tx = [0:.02:2];\n";
	print "\ty = humps(x);\n";
	print "\tmgplot(win,x,y,{\"\"});\n";
	print "\tmgplot_title(win,\"Plot of the function humps(x)\");\n";
	print "\n";
	pause "Strike any key for plot.";

	x = [0:.02:2];
	y = humps(x);
	mgplot(win,x,y,{""});
	mgplot_title(win,"Notice the zero near x = 1.2");

	clear;
	print "\n";
	print "To find a zero of this function near x = 1, we invoke FZERO:\n";
	print "\n";
	print "\tz = fzero(hump,1.0,EPS,1)\n\n";

	pause "Strike any key to start iterations.";

	z = fzero(hump,1.0,EPS,1);
	print "\n\n";
	print z, "\n";
	print "And the value above is the zero near 1.0.\n\n";

	pause "Strike any key for plot.";

	x = [0.4:.02:1.6];
	y = humps(x);
	mgplot(win,x,y,{""});
	mgreplot(win,[z z],[hump(z) hump(z)],{""},{"w points 3"});
	mgplot_title(win,"Zero of hump(x)");
	mgplot_grid(win,1);
}

/*  -*- MaTX -*-
 *
 *	NAME
 *      humps() - A function used by quaddemo() and zerodemo()
 *
 *  SYNOPSIS
 *      y = humps(x)
 *         Matrix y;
 *         Matrix x;
 */

Func Matrix humps(x)
	Matrix x;
{
	Matrix y;

	y = ((x .- 0.3).^2 .+ 0.01).~ +	((x .- 0.9).^2 .+ 0.04).~ .- 6;
	return y;
}

/*  -*- MaTX -*-
 *
 *	NAME
 *      hump() - A function used by quaddemo() and zerodemo()
 *
 *  SYNOPSIS
 *      y = hump(x)
 *         Real y;
 *         Real x;
 */

Func Real hump(x)
	Real x;
{
	Real y;

	y = ((x - 0.3)^2 + 0.01)~ +	((x - 0.9)^2 + 0.04)~ - 6;
	return y;
}


/*  -*- MaTX -*-
 *
 *  NAME
 *      fitdemo() - Demonstration of nolinear fitting algorithm
 *
 *  SYNOPSIS
 *      fitdemo()
 */

Func void fitdemo()
{
	Integer win;
	Array t,y;
	Matrix lam;
	extern Matrix Data;
	Real fitfun();

	clear;
	print "\n";
	print "This example demonstrates fitting a nonlinear function to a set\n";
	print "of data.  We'll use a function called fmins() that implements\n";
	print "the Nelder-Mead simplex algorithm for minimizing a nonlinear\n";
	print "function of several variables.\n\n";
	pause;

	Data = [[0.0000    5.8955]
			[0.1000    3.5639]
			[0.2000    2.5173]
			[0.3000    1.9790]
			[0.4000    1.8990]
			[0.5000    1.3938]
			[0.6000    1.1359]
			[0.7000    1.0096]
			[0.8000    1.0343]
			[0.9000    0.8435]
			[1.0000    0.6856]
			[1.1000    0.6100]
			[1.2000    0.5392]
			[1.3000    0.3946]
			[1.4000    0.3903]
			[1.5000    0.5474]
			[1.6000    0.3459]
			[1.7000    0.1370]
			[1.8000    0.2211]
			[1.9000    0.1704]
			[2.0000    0.2636]];

	print "Consider the following data:\n\n";
	print Data;

	print "\nLet's plot this data.\n\n";
	print "\tt = Data(:,1);\n";
	print "\ty = Data(:,2);\n";
	print "\twin = mgplot_cur_win();\n";
	print "\tmgplot(win, t', y',{\"\"}, {\"w points 3\"});\n";
	print "\tmgplot_title(win,\"Input data\");\n";
	print "\n";
	pause;

	t = Data(:,1);
	y = Data(:,2);
	win = mgplot_cur_win();
	mgplot(win, t', y',{""}, {"w points 3"});
	mgplot_cmd(win, sprintf("set xrange [%g:%g]", min(t), max(t)));
   	mgplot_cmd(win, sprintf("set yrange [%g:%g]", min(y), max(y)));
	mgplot_title(win,"Input data");

	print "We would like to fit the function\n\n";
	print "\ty = c(1)*exp(-lam(1)*t) + c(2)*exp(-lam(2)*t)\n\n";
	print "to the data.  This function has 2 linear parameters\n";
	print "and 2 nonlinear parameters.\n\n";
	pause;

	print "To fit this function to the data, we write a function, called\n";
	print "say fitfun(), that, given the nonlinear parameters lam and the\n";
	print "data, returns the error in the fit.  We can then guess for\n";
	print "initial estimates of the nonlinear parameters, and invoke fmins():";
	print "\n\n";

	print "\tlam = [1 0]';\n";
	print "\t{lam} = fmins(fitfun, lam);\n";
	print "\tprint lam;\n\n";
	pause;

	lam = [1 0]'; 
	{lam} = fmins(fitfun, lam, 0.1);
	print lam;

	print "\nAnd the above are the nonlinear parameters.\n\n";
	mgplot_reset(win);
}


/*  -*- MaTX -*-
 *
 *	NAME
 *      fitfun() - This function is used by fitdemo()
 *
 *  SYNOPSIS
 *      f = fitfun(lam)
 *         Real f;
 *         Matrix lam;
 *
 *  DESCRIPTION
 *      fitfun(lam) returns the error between the data and the values 
 *      computed by the current function of lam.  fitfun assumes a 
 *      function of the form
 *
 *   	  y =  c(1)*exp(-lam(1)*t) + ... + c(n)*exp(-lam(n)*t)
 *
 *   	with n linear parameters and n nonlinear parameters.
 *
 */

Func Real fitfun(lam)
	Matrix lam;
{
	Integer j,win;
	Real f,xt,yt;
	Matrix A,c;
	Array t,y,z;
	extern Matrix Data;

	// Global Data
	t = Data(:,1);
	y = Data(:,2);
	A = Z(length(t),length(lam));
	for (j = 1; j <= length(lam); j++) {
		A(:,j) = exp(-lam(j)*t);
	}
	c = A\Matrix(y);
	z = A*c;
	f = norm(z - y);

	// Statements to plot progress of fitting:
	win = mgplot_cur_win();
	xt = max(t)/2;
	yt = max(y)/2;

	mgplot_cmd(win, "set nolabel");
	mgplot_text(win,sprintf("lambda = [%g  %g]", lam(1), lam(2)),xt,1.1*yt);
	mgplot_text(win,sprintf("err norm = %g", f),xt,1.0*yt);
	mgplot(win, t', y', {""}, {"w points 3"});
	mgreplot(win, t', z', {""}, {"1"});
	pause(0.3);
	return f;
}
