
/*  -*- MaTX -*-
 *
 *  movies()  Show the running progress of matrix computation
 *
 *  SYNOPSIS
 *      movies()
 *
 */

void ratprnt();
 
Func void movies()
{
	Matrix A,Q,T,e,a,R;
	Real c;
	List aa;

	Matrix rrefmovi(...), ratmovie(...), eigmovie();

	clear;
	print "\n";
	print "It is possible to make 'movies' showing the running progress\n";
	print "of matrix computations.  There is an MM-file on disk called\n";
	print "rref that computes the reduced row echelon form of a matrix.\n";
	print "We have copied it to rrefmovie and inserted some commands to\n";
	print "display the intermediate results.\n\n";
	
	pause;
	clear;
	print "\n";
	print "Suppose we start with a random square of order 6:\n\n";
	print "\ta = fix(Array(rand(6))*10)\n\n";
	print "Suppose we start with a magic square of order 6:\n";
	a = magic(6);
	print a;
	print "\n";

	pause;
	clear;
	print "\n";
	print "This matrix of order 6 has a rank of:\n\n";
	print "\trank(a)\n\n";
	print rank(a), "\n";

	pause;
	clear;
	print "\n";
	print "Now let's start a movie showing the progress of the RREF algorithm.\n";
	print "Watch as the matrix is cleared out using row and column operations.\n";

	pause "\nStrike any to start movie.";
	
	rrefmovi(a);

	pause;
	clear;
	print "\n";
	print "This completes the RREF 'movie'.  The next movie we'll show you\n";
	print "illustrates an algorithm for finding the eigenvalues of a\n";
	print "symmetric matrix.\n\n";
	pause;

	clear;
	print "\n";
	print "Consider the following matrix, whose eigenvalues are\n";
	print "approximately the diagonal elements:\n\n";
	print "\te = ONE(6,1); T = vec2diag(e,1) + diag_vec(e,-1);\n";
	print "\tA = T + 10*Matrix(vec2diag(abs([-3:3])))\n\n";

	e = ONE(6,1);
	T = vec2diag(e,1) + diag_vec(e,-1);
	A = T + 10*Matrix(vec2diag(abs([-3:3])));

	print A, "\n";

	pause;
	clear;
	print "\n";
	print "We now 'hide' the eigenvalues, by giving the matrix a random \n";
	print "orthogonal similarity transformation:\n\n";
	print "\tQ = orth(rand(A));\n";
	print "\tA = Q#*A*Q\n\n";

	Q = orth(rand(A));
	A = Q#*A*Q;
	print A, "\n";

	pause;
	clear;
	print "\n";
	print "Now let's start a movie showing the progress of an ";
	print "eigenvalue algorithm:\n\n";
	print "\te = eigmovie(A);\n";
	print "\te = diag_vec(e)\n\n";
	pause;

	e = eigmovie(A);
	e = diag_vec(e);
	print e, "\n";

	pause;
	clear;
	print "\n";
	print "Consider the Hilbert matrix of order 5:\n\n";
	print "\tA = hilb(5)\n\n";

	A = hilb(5);
	print A, "\n";

	pause;
	clear;
	print "\n";
	print "The Hilbert matrix is a famous example of a badly\n";
	print "conditioned matrix.  This 5x5 example has condition ";
	print "number\n\n";
	print "\tc = cond(A)\n\n";

	c = cond(A);
	print c, "\n";

	pause;
	clear;
	print "\n";
	print "A Hilbert matrix has elements a(i,j) = 1/(i+j-1).  We\n";
	print "can see this more clearly using MaTX's rational output ";
	print "format:\n\n";
	print "\t{aa} = rat(A,\"s\");\n";
	print "\tratprnt(aa);\n\n";
	pause;	

	{aa} = rat(A,"s");
	ratprnt(aa);
	print "\n\n";
	pause;

	clear;
	print "\n";
	print "Let's start a movie that computes the reduced row-echelon\n";
	print "form of this Hilbert matrix, all in rational format:\n\n";
	print "\tR = ratmovie(A)\n\n";

	pause "Strike any to start movie.";

	R = ratmovie(A);
	print R, "\n";
	pause;
	clear;
}


/*  -*- MaTX -*-
 *
 *  NAME
 *      rrefmovi() - Reduced row echelon form
 *
 *  SYNOPSIS
 *      R = rrefmovi(A)
 *         Matrix R;
 *         Matrix A;
 *
 *      R = rrefmovi(A,tol)
 *         Matrix R;
 *         Matrix A;
 *         Real tol;
 *
 *  DESCRIPTION
 *     This function is equivalent to RREF, except it has been
 *     made into a "movie" to show the progress of the calculation.
 *
 *     rref(A) produces the reduced row echelon form of A.
 *     rref(A,tol) uses the given tolerance in the rank tests.
 *
 */

Func Matrix rrefmovi(A_,tol, ...)
	Matrix A_;
	Real tol;
{
	Integer i,j,k,m,n,rats;
	Matrix A;
	Real p;
	Matrix den,num;

	List rat(...);
	
	if (nargs < 1 || 2 < nargs) {
		error("rrefmovi(): Incorrect number of arguments.\n");
	}

	A = A_;

	{m,n} = size(A);

	//  Does it appear that elements of A are ratios of small integers?
	{num,den} = rat(A);
	rats = all(Array(A) == Array(num./den));

	// Compute the default tolerance if none was provided.
	if (nargs < 2) {
		tol = length(A)*EPS*infnorm(A);
	}

	// Loop over the entire matrix.

	clear;
	gotoxy(1,1);
	print "Original matrix\n\n";
	print A;
	pause(0.3);

	i = 1;
	j = 1;
	k = 0;
	while (i <= m && j <= n) {
		// Find value and index of largest element
		// in the remainder of column j.
		{p,k} = maximum(abs(Array(A(i:m,j))));
		k = k+i-1;
		if (p <= tol) {
			// The column is negligible, zero it out.
			gotoxy(1,1);
			printf("column %d is negligible\n\n", j);
			pause(0.3);

			A(i:m,j) = Z(m-i+1,1);
			print A;
			pause(0.3);
			j = j + 1;
		} else {
			if (i != k) {
				// Swap i-th and k-th rows.
				gotoxy(1,1);
				printf("swap rows %d and %d          \n\n", i, k);
				pause(0.3);
				A(Index([i k]),j:n) = A(Index([k i]),j:n);
				print A;
				pause(0.3);
			}
			// Divide the pivot row by the pivot element.
			gotoxy(1,1);
			printf("pivot = A(%d,%d)          \n\n",i , j);
			pause(0.3);
			A(i,j:n) = A(i,j:n)/A(i,j);
			print A;
			pause(0.3);

			// Subtract multiples of the pivot row from all the other rows.
			for (k = 1; k <= i-1; k++) {
				A(k,j:n) = A(k,j:n) - A(k,j)*A(i,j:n);
			}

			for (k = i+1; k <= m; k++) {
				A(k,j:n) = A(k,j:n) - A(k,j)*A(i,j:n);
			}

			gotoxy(1,1);
			printf("eliminate in column %d          \n\n", j);
			pause(0.3);
			print A;
			pause(0.3);

			i = i + 1;
			j = j + 1;
		}
	}

	// Return "rational" numbers if appropriate.
	if (rats) {
		{num,den} = rat(A);
		A = num./den;
	}

	gotoxy(1,1);
	print " " * 30, "\n\n";
	print A;
	pause(0.3);
	print "\n";
	return A;
}


/*  -*- MaTX -*-
 *
 *  NAME
 *      ratmovie() -  Movie of the computation of the reduced row echelon form
 *
 *  SYNOPSIS
 *      R = ratmovie(A)
 *         Matrix R;
 *         Matrix A;
 *
 *      R = ratmovie(A, tol)
 *         Matrix R;
 *         Matrix A;
 *         Real tol;
 *
 *  DESCRIPTION
 *      Movie of the computation of the reduced row echelon form
 *	    with rational format output.
 *
 *      ratmovie(A) produces the reduced row echelon form of A.
 *      ratmovie(A,tol) uses the given tolerance in the rank tests.
 *
 */

Func Matrix ratmovie(A_,tol, ...)
	Matrix A_;
	Real tol;
{
	Matrix A;
	Integer i,j,k,kk,m,n,r;
	List R, rr, rr2, rr3;
	Real p;
	String zz;

	List rat(...);

	A = A_;

	{R} = rat(A,"s");

	clear;
	gotoxy(1,1);
	print "Original matrix\n\n";
	print "R = \n";
	ratprnt(R);
	pause(0.3);

	{m,n} = size(A);

	// Compute the default tolerance if none was provided.
	if (nargs < 2) {
		tol = length(A)*EPS*infnorm(A);
	}

	// Loop over the entire matrix.
	i = 1;
	j = 1;
	k = 0;

	while (i <= m && j <= n) {
		// Find value and index of largest element
		// in the remainder of column j.
		{p,k} = maximum(abs(Array(A(i:m,j))));
		k = k + i - 1;
		if (p <= tol) {
			// The column is negligible, zero it out.
			gotoxy(1,1);
			printf("column %d is negligible\n\n", j);
			print "R = \n";
			pause(0.3);

			A(i:m,j) = Z(m-i+1,1);
			{rr} = rat(Z(m-i+1,1),"s");
			rr3 = rr(1,List);
			zz = rr3(1,String);
			for (kk = i; kk <= m; kk++) {
				rr2 = R(kk,List);
				rr2(j) = zz;
				R(kk) = rr2;
			}

			ratprnt(R);
			pause(0.3);

			j = j + 1;
		} else {
			if (i != k) {
				// Swap i-th and k-th rows.
				gotoxy(1,1);
				printf("swap rows %d and %d          \n\n", i, k);
				print "R = \n";
				pause(0.3);

				A(Index([i k]),:) = A(Index([k i]),:);
				{rr} = rat(A(Index([i k]),:),"s");
				R(i) = rr(1,List);
				R(k) = rr(2,List);

				for (r = 1; r <= k; r++) {
					if (r == i || r == k) {
						ratprnt({R(r,List)});
					} else {
						print "\n";
					}
				}
				pause(0.3);
			}
			// Divide the pivot row by the pivot element.
			gotoxy(1,1);
			printf("pivot = A(%d,%d)          \n\n", i, j);
			print "R = \n";
			pause(0.3);

			A(i,j:n) = A(i,j:n)/A(i,j);
			{rr} = rat(A(i,:),"s");
			R(i) = rr(1,List);
			for (k = 1; k <= i-1; k++) {
				print "\n";
			}
			ratprnt({R(i,List)});
			pause(0.3);

			// Subtract multiples of the pivot row from all the other rows.
			gotoxy(1,1);
			printf("eliminate in column %d          \n\n", j);
			print "R = \n";
			pause(0.3);

			for (k = 1; k <= m; k++) {
				if (k != i) {
					A(k,j:n) = A(k,j:n) - A(k,j)*A(i,j:n);
					{rr} = rat(A(k,:),"s");
					R(k) = rr(1,List);
					ratprnt({R(k,List)});
				} else {
					print "\n";
				}
			}
			i = i + 1;
			j = j + 1;

			pause(0.3);
		}
		gotoxy(1,1);
		print " " * 30;
	}

	gotoxy(1,m+6);
	pause;
	print "\n";
	return A;
}


/*  -*- MaTX -*-
 *
 *  NAME
 *      eigmovie() - Symmetric eigenvalue movie
 *
 *  SYNOPSIS
 *      A = eigmovie(A)
 *         Matrix A;
 *
 *  DESCRIPTION
 *      eigmovie(A) shows a movie that depicts the computation of
 *      the eigenvalues of a symmetric matrix.
 */

Func Matrix eigmovie(A_)
	Matrix A_;
{
	Integer it,n,k;
	Real beta,gamma;
	Matrix II,Q,R,S,d,e,shift,u,v,z,A;
	Index j,kidx;
	Integer mflag;
//	String cmp;

	void eigmovie_print();

	A = A_;

	n = max(Cols(A), Rows(A));
	mflag = 0;
	
	if (n > 8) {
		print "Sorry, only 7 by 7 or smaller on this screen\n";
	} else {
		clear;
		print "\n";
		eigmovie_print(A, "Input matrix", mflag);

		A = (A + A#)/2;
		eigmovie_print(A, "Symmetrized input matrix", mflag);

		II = I(A);

		for (k = 2; k <= n-1; k++) {
			u = A(:,k-1);
			u(1:k-1) = Z(k-1,1);
			u = u/norm(u);
			if (u(k) < 0) {
				u = -u;
			}
			u(k) = u(k) + 1;
			beta = -u(k);  // -(norm(u)^2)/2
			v = A*u/beta;
			gamma = [v#*u/(2*beta)](1);
			v = v + gamma*u;
			A = A + u*v# + v*u#;
			j = [(k+1):n];
			z = Z(n-k,1);
			A(j,k-1) = z;
			A(k-1,j) = z#;

			eigmovie_print(A, "Householder similarity transformation " +
						   String(k-1), mflag);
		}

		it = 0;
		while (n > 1) {
			d = diag_vec(A);
			e = diag_vec(A,-1);
			A = diag_vec(d) + diag_vec(e,-1) + diag_vec(e,1);

			eigmovie_print(A, "Symmetric tridiagonal QR iteration " +
						   String(it), mflag);

			kidx = [n-1:n];
			S = A(kidx,kidx);

			if (abs(S(2,1)) < EPS*(abs(S(1,1)) + abs(S(2,2)))) {
				A(n,n-1) = 0;
				A(n-1,n) = 0;
				n = n-1;
			} else {
				shift = eigval(S);
				if (abs(shift(1) - A(n,n)) < abs(shift(2) - A(n,n))) {
					shift = [shift(1)];
				} else {
					shift = [shift(2)];
				}
				{Q,R} = qr(A - shift(1)*II);
				A = R*Q + shift(1)*II;
			}
			it = it + 1;
		}
	}

	eigmovie_print(A, "Output matrix ", mflag);

	return A;
}

Func void eigmovie_print(AA, mess, mflag)
	Matrix AA;
	String mess;
	Integer mflag;
{
	Integer i, j, reflag;
	String re, im;
	Matrix A;
	void mesh();
	
	if (isreal(AA)) {
		reflag = 1;
		A = AA;
	} else if ( ! any(Array(Im(AA)))) {
		reflag = 1;
		A = Re(AA);
	} else {
		reflag = 0;
		A = AA;
	}

	if (mflag) {
//		mesh(A);
	} else {
		printf("%s\n", mess);
		
		for (i = 1; i <= Rows(A); i++) {
			print "\n";
			for (j = 1; j <= Cols(A); j++) {
				if (reflag) {
					re = sprintf("% 6.2e ", A(i,j));
					if (re == " 0.00e+00 ") {
						re = "        0 ";
					}
					printf("%s", re);
				} else {
					re = sprintf("% 6.2e", Re(A(i,j)));
					if (re == " 0.00e+00") {
						re = "        0";
					}
					im = sprintf("%+6.2ej ", Im(A(i,j)));
					if (im == "+0.00e+00j ") {
						im = "        0j ";
					}
					printf("%s%s", re, im);
				}
			}
		}

		print "\n\n";
		pause;
	}
}


/*  -*- MaTX -*-
 *
 *  NAME
 *      ratprnt() -  Print a matrix in ratio form
 *
 *  SYNOPSIS
 *      ratprnt(R)
 *         List R;
 */

Func void ratprnt(R)
	List R;
{
	Integer i,j,m,n;
	List row;

	m = length(R);
	n = length(R(1,List));
	
	for (i = 1; i <= m; i++) {
		print "\n";
		row = R(i,List);
		for (j = 1; j <= n; j++) {
			printf("%s", row(j,String));
		}
	}
}

