
/*  -*- MaTX -*-
 *
 *  NAME
 *      besseln() - Integer order Bessel functions
 *
 *  SYNOPSIS
 *      J = besseln(n,x)
 *         Array J;
 *         Integer n;
 *         Array x;
 *
 *  DESCRIPTION
 *      besseln(n,X) is Bessel function, J-sub-n (X).
 *      Bessel functions are solutions to Bessel's differential
 *      equation of order n:
 *            2                    2   2
 *           x * y'' +  x * y' + (x - n ) * y = 0
 *
 *      The function is evaluated for every point in the array X.
 *      The order, n, must be a nonnegative integer scalar.
 *
 *      Modified Bessel functions of integer order may be calculated
 *      using besseln() with purely imaginary values of X.  The
 *      relationship is:
 *      	             n
 *      	I  (x) = (-1)  J  (ix)
 *      	 n              n
 *
 *  SEE ALSO
 *      bessel(), besselh() and bessela().
 *
 *  REFERENCES  
 *      [1] Abramowitz and Stegun, Handbook of Mathematical
 *          Functions, National Bureau of Standards, Applied Math.
 *          Series #55, sections 9.1.1 and 9.12.
 *	    [2] W.H. Press et al, "Numerical Recipes", Cambridge Univ.
 *	        Press, 1986, chapter 6.
 *
 */

Func Array besseln(n,x)
	Integer n;
	Array x;
{
	Integer k,mm;
	Matrix c;
	Real tiny;
	Array J,bk,bn,bkp1,bkp2,t,m,z;

	// Backwards three term recurrence for J-sub-n(x).
	// Temporarily replace x=0 with x=1
	z = (x == 0);
	x = x + z;

	// Starting index for backwards recurrence.
	c = [17.1032 0.2639 0.6487, -0.0018 0.6457];
	m = round(Re((c(1) + c(2)*n) .+ c(3)*abs(x) +
				 c(4)*n*abs(x) .+ c(5)*max([[n],[abs(x)]])));
	// Make sure m is even.
	m = 2*ceil(m/2);
	mm = Integer(max(makecolv(m)));

	tiny = 16.0^(-30);

	k = mm;
	bkp1 = 0*x;
	bk = tiny*(m==k);
	t = 2*bk;

	for (k = mm-1; k >= 0; k--) {
		bkp2 = bkp1;
		bkp1 = bk;
		bk = 2*(k+1)*bkp1 / x - bkp2 + tiny*(m==k);

		if (k == Integer(n)) {
			bn = bk;
		}
		if (k > 0 && rem(k,2)==0) {
			t = t + 2*bk;
		}
		if (k == 0) {
			t = t + bk;
		}
	}
	
	// Normalizing condition, J0(x) + 2*J2(x) + 2*J4(x) + ... = 1.
	J = bn / t;
	
	// Restore results for x = 0; J0(0) = 1, Jn(0) = 0 for n > 0.
	J = (1 .- z) * J + z*(n == 0);
	return J;
}
