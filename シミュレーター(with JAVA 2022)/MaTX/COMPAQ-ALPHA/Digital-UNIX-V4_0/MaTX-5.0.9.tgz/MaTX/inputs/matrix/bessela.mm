
/*  -*- MaTX -*-
 *
 *  NAME
 *      bessela() - Fractional order Bessel functions and accuracy estimate
 *
 *  SYNOPSIS
 *      {J,digits} = bessela(nu,x)
 *          Array J, digits;
 *          Real nu;
 *          Array x;
 *
 *  DESCRIPTION
 *       bessela(nu,X) is Bessel function, J-sub-nu (x).  Bessel 
 *       functions are solutions to Bessel's differential equation 
 *       of order nu:
 *               2                    2    2
 *              x * y'' +  x * y' + (x - nu ) * y = 0
 *
 *       The function is evaluated for every point in the array x.
 *       The order, nu, must be a nonnegative scalar.
 *
 *       Any negative value of digits is replaced by zero, the 
 *       corresponding J set to NaN and a division by zero warning 
 *       message is generated.
 *
 *  SEE ALSO
 *      bessel(), besseln() and besselh().
 *
 *  REFERENCE
 *      [1] Abramowitz and Stegun, Handbook of Mathematical
 *          Functions, National Bureau of Standards, Applied Math.
 *          Series #55, formulas 9.1.10 and 9.2.5.
 *
 */

Func List bessela(nu,x)
	Real nu;
	Array x;
{
	Integer kmin,k,l;
	Array oka,okp,xz,z,t;
	Array digits,J,Ja,Jp,da,dp,p,q,r,s,y;
	Real mu;

	kmin = 12;

	// Temporarily replace x=0 with x=1 
	xz = (x == 0);
	x = x + xz;

	// Asymptotic series 
	kmin = 12;		// Try the series for at least kmin/2 terms.
	z = (-1*ONE(x)) / (8*x)^2;
	t = 0*x;
	q = t;
	t = t .+ 1;
	p = t;
	r = abs(t);
	mu = 2*nu;
	k = 0;
	l = -1;
	oka = Re(x) > 0.9*nu;

	while (any(abs(t) > EPS*max(abs(p),abs(q)) && oka)) {
		s = t;
		k = k + 1;
		l = l + 2;
		t = (mu-l)*(mu+l)/k*t;
		q = q + t;
		k = k + 1;
		l = l + 2;
		t = (mu-l)*(mu+l)/k*t*z;
		p = p + t;
		r = max(r,abs(t));
		if (k >= 2*kmin) {
			oka = oka * (abs(t) <= 5*abs(s));
		}
	}

	q = q/(8*x);
	y = x .- (2*nu+1)*PI/4;
	Ja = sqrt((2)/(PI*x)) * (p*cos(y) - q*sin(y));
	da = max(oka*log10(max(abs(p),abs(q))/(EPS*abs(r))), Z(r));
	oka = oka*(da > 0);
	
	// If necessary, use power series expansion.
	// Requires the gamma function from another mm-file
	okp = da < 12;

	if (any(okp)) {
		t = okp * (x/2)^nu / [gammafnc([nu+1])](1);
		s = t;
		r = abs(t);
		z = -(x/2)^2;
		k = 0;

		while (any(abs(t) > EPS*abs(s) && okp)) {
			k = k + 1;
			t = z*t/(k*(nu+k));
			s = s + t;
			r = max(r,abs(t));
			okp = okp * (EPS*abs(r) <= abs(s));
		}

		Jp = s;
		dp = max(okp*log10((1 .- okp + abs(s))/(1 .- okp + EPS*abs(r))),Z(r));
		okp = okp*(dp > 0)*(dp > da);
		oka = oka*(da >= dp);
		digits = oka*da + okp*dp;
		J = oka*Ja + okp*Jp + (0)/digits;
	} else {
		J = Ja;
		digits = da;
	}
	
	// Restore results for x = 0; J0(0) = 1, Jnu(0) = 0 for nu > 0.
	J = (1 .- xz)*J + xz*(nu == 0.0);
	return {J,digits};
}

