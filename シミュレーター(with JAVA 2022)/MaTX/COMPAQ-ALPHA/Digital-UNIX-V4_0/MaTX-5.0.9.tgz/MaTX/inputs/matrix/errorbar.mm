
/*  -*- MaTX -*-
 *
 *  NAME
 *      errorbar() - Add error bars to a plot
 *
 *  SYNOPSIS
 *      erorrbar(x, y)
 *         Array x, y;
 *
 *      erorrbar(x, y, std)
 *         Array x, y;
 *         Array std;
 *
 *  DESCRIPTION
 *      errorbar(X,Y,E) adds error bars to an already existing plot of
 *      vector X versus vector Y.  E is a vector the same length as X
 *      and Y that specifies the lengths of the error bars.  The error
 *      bars are each drawn a distance of E(i) above and below the
 *      points in (X,Y) so that each bar is 2*E(i) long.
 *      For example,
 *
 *   	   x = [1:10];
 *   	   y = sin(x);
 *   	   e = std(y)*ONE(x);
 *   	   mgplot(1,x,y);
 *         errorbar(x,y,e)
 *
 *      draws error bars of unit standard deviation.
 *
 */

Func void errorbar(x, y_, stda, ...)
	Array x, y_, stda;
{
	Integer i,win,npt;
	Real ybot,ytop,tee;
	Matrix xl,xr;
	Array y;

	error(nargchk(2, 3, nargs, "errorbar"));

	npt = max(Cols(x), Rows(x));
	if (nargs == 2) {
		stda = y_;
		y = x;
		x = [1:npt];
	} else {
		y = y_;
	}

	tee = (max(x)-min(x))/100;	// make tee .02 x-distance for error bars
	xl = x .- tee;
	xr = x .+ tee;

	win = mgplot_cur_win();
	mgplot(win, x, y, {""});
	for (i = 1; i <= npt; i++) {
		if (abs(stda(i))) {
			ytop = y(i) + stda(i);
			ybot = y(i) - stda(i);
			mgreplot(win, [x(i)   x(i)], [ytop ybot], {""}, {"2"});
			mgreplot(win, [xl(i) xr(i)], [ytop ytop], {""}, {"2"});
			mgreplot(win, [xl(i) xr(i)], [ybot ybot], {""}, {"2"});
		}
	}
}
