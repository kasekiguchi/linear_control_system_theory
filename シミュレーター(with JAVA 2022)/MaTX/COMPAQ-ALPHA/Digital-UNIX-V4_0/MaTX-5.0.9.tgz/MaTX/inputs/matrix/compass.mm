
/*  -*- MaTX -*-
 *
 *  NAME
 *      compass() - Compass plot
 *
 *  SYNOPSIS
 *      compass(x)
 *         Array x;
 *
 *      compass(x,y)
 *         Array x;
 *         Array y;
 *
 *      compass(x,y,s)
 *         Array x;
 *         Array y;
 *         Integer s = 1;
 *
 *  DESCRIPTION
 *      compass(z) draws a graph that displays the angle and magnitude
 *      of the complex elements of z as arrows emanating from the origin.
 *
 *      compass(x,y) is equivalent to compass(x+i*y).  It displays the
 *      compass plot for the angles and magnitudes of the elements of
 *      matrices x and y.
 *
 *      compass(...,s) use line style s.
 *
 *	SEE ALSO
 *      rose(), feather() and quiver().
 *
 */

Func void compass(x_, y, s, ...)
	Array x_, y;
	Integer s;
{
	Integer i,win,n;
	Complex j;
	Matrix arrow,z;
	Array a,xx,yy,sq,x,xy;
	List name, col;

	error(nargchk(1, 3, nargs, "compass"));
	
	x = x_;

	j = (0,1);
	a = ([0:4] .+ 10/2)/4;
	sq = sqrt(2.0) * exp(-j*2*PI*a);

	xx = [0.0, 1.0,  0.8, 1.0,   0.8];
	yy = [0.0, 0.0, 0.08, 0.0, -0.08];
	arrow = xx + yy*j;

	if (nargs == 2) {
		s = 1;
	} else if (nargs == 1) {
		s = 1;
		y = Im(x);
		x = Re(x);
	}
	
	x = makecolv(x);
	y = makecolv(y);

	if (length(x) != length(y)) {
		error("compass(): X and Y must be same length.\n");
	}

	z = (x + y*j);
	a = z * arrow;
	xy = z * ONE(arrow);
	n = Rows(a)*Cols(a);

	a = makecolv(a);
	xy = makecolv(xy);
	a = [a, xy];

	name = makelist(n);
	col = makelist(n);
	for (i = 1; i <= n; i++) {
		name(i) = "";
		col(i) = sprintf("%d", s);
	}

	win = mgplot_cur_win();
	mgplot_grid(win, 1);
	mgplot(win, Re(a), Im(a), name, col);
}

