
/*  -*- MaTX -*-
 *
 *  NAME
 *      cdf2rdf() - Matrix in complex diagonal form to real diagonal form
 *
 *  SYNOPSIS
 *      {vv,dd} = cdf2rdf(v,d)
 *         Matrix vv, dd;
 *         CoMatrix v, d;
 *
 *  DESCRIPTION
 *      cdf2rdf() transforms the outputs of eig() from complex
 *      diagonal form to a real diagonal form.
 *
 *      In complex diagonal form, d has complex eigenvalues down the 
 *      diagonal.  In real diagonal form, the complex eigenvalues are 
 *      in 2-by-2 blocks on the diagonal.  Complex eigenvalue pairs 
 *      are assumed to be next to one another.
 *
 *   SEE ALSO
 *      eig
 */
 
Func List cdf2rdf(v, d)
	CoMatrix v, d;
{
	Integer i,k;
	Matrix dd,vv,t;
	CoMatrix twobytwo;
	Complex j;
	Index idx,index;

	j = (0,1);
	t = (I(Rows(d)),:);
	twobytwo = [[1 1][j, -j]];
	idx = find(trans(Im(diag2vec(d))));
	index = idx(1:2:length(idx));

	for (k = 1; k <= length(index); k++) {
		i = index(k);
		t(i:i+1,i:i+1) = twobytwo;
	}	

	vv = Re(v/t);
	dd = Re(t*d/t);
	return {vv,dd};
}
