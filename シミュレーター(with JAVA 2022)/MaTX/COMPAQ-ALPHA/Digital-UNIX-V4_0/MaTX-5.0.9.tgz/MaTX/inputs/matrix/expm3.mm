
/*  -*- MaTX -*-
 *
 *  NAME
 *      expm3() - Matrix exponential via eigenvectors and eigenvalues
 *
 *  SYNOPSIS
 *      EX = expm3(A)
 *        Matrix EX;
 *        Matrix A;
 *
 *  SEE ALSO
 *      exp(), exp1() and exp2()
 */

Func Matrix expm3(a)
	Matrix a;
{
	Matrix e,d,v;

	{d, v} = eig(a);
	e = v * vec2diag(Matrix(exp(Array(diag2vec(d))))) / v;
	return e;
}
