
/*  -*- MaTX -*-
 *
 *  NAME
 *      hex2num() - IEEE hexidecimal to double precision number conversion
 *
 *  SYNOPSIS
 *      x = hex2num(s)
 *         Real x;
 *         String s;
 *
 *  DESCRIPTION
 *      hex2num(S), where S is a 16 character string containing
 *      a hexidecimal number, returns the IEEE double precision
 *      floating point number it represents.  Fewer than 16
 *      characters are padded on the right with zeros.
 *
 *     For example, 
 *
 *       hex2num("400921fb54442d18") 
 *
 *     returns Pi.
 *
 *       hex2num("bff")
 *
 *     returns -1.
 *
 *     NaNs, infinities and denorms are handled correctly.
 *
 *  SEE ALSO
 *      hex().
 */

Func Real hex2num(s)
	String s;
{
	Real x,e,f;
	Integer i,z,a,neg,n;
	Array d,one;

	// More than 16 characters are truncated
	d = Z(1,16);
	n = length(s);
	one = ONE(1,n);
	z = Integer([abs("0")](1));
	a = Integer([abs("a")](1));

	d(1:n) = Array(abs(s)) - z*one;
	
	d = d + (z + 10 - a) * (d > 10);
	neg = d(1) > 7.0;

	if (neg)  {
		d(1)= d(1) - 8;
	}

	e = 16*(16*(d(1)-4) + d(2)) + d(3) + 1;
	f = 0.0;
	for (i = 16; i >= 4; i--) {
		f = (f + d(i))/16;
	}

	if (e > 1023.0) {
		if (f == 0.0) {
			x = Inf;
		} else {
			x = NaN;
		}
	} else if (e < -1022.0) {
		x = f * 2^(-1022);
	} else {
		x = (1 + f) * 2^e;
	}
	if (neg) {
		x = -x;
	}
	return x;
}
	
