
/*  -*- MaTX -*-
 *
 *  NAME
 *      poly2tex()  - Save a polynomial to a file in tex-form
 *      poly2texf() - Generate the tex-form of a polynomial
 *
 *  SYNOPSIS
 *        poly2tex(p, file)
 *           Polynomial p;
 *           String file;
 *  
 *        poly2tex(p, file, var_name)
 *           Polynomial p;
 *           String file;
 *           String var_name;
 *  
 *        tf = poly2texf(p)
 *          String tf;
 *          Polynomial p;
 *
 *        tf = poly2texf(p, var_name)
 *          String tf;
 *          Polynomial p;
 *          String var_name;
 *
 *  SEE ALSO
 *        mat2tex(), mat2texf(), rat2tex() and rat2texf()
 */

Func void poly2tex(p, file, var_name, ...)
	Polynomial p;
	String file, var_name;
{
	String poly2texf(...);

	error(nargchk(2, 3, nargs, "poly2tex"));

	if (nargs == 2) {
		fprintf(file, "%s", poly2texf(p));
	} else if (nargs == 3) {
		fprintf(file, "%s", poly2texf(p, var_name));
	}
}

Func String poly2texf(p, var_name, ...)
	Polynomial p;
	String var_name;
{
	Integer i;
	String tex;

	error(nargchk(1, 2, nargs, "poly2texf"));

	if (nargs < 2) {
		var_name = "s";
	}

	tex = String(p);
	if (var_name != "s") {
		while ((i = strchr(tex, "s"))) {
			if (length(tex) == 1) {
				tex = var_name;
			} else if (i == length(tex)) {
				tex = tex(1:i-1) + var_name;
			} else if (i == 1) {
				tex = var_name + tex(i+1:);
			} else {
				tex = tex(1:i-1) + var_name + tex(i+1:);
			} 
		}
	}
	return tex;
}
