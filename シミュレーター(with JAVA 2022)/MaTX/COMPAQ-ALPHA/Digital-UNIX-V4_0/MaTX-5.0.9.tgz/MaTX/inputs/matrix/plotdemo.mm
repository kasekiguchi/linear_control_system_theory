
/*  -*- MaTX -*-
 *
 *  NAME
 *      plotdemo() - Demonstration of plot
 *
 *  SYNOPSIS
 *      plotdemo()
 *
 *  DESCRIPTION
 *     This demo goes through some of MaTX's graphics abilities.
 */

Func void plotdemo()
{
	Integer win;
	Array t,y,x,z;
	Real tt;
	List names, lines;

	List meshdom();

	win = mgplot_cur_win();

	clear;
	print "\n";
	print "This demo goes through some of the MaTX graphics\n";
	print "capabilities. You don't need to hit any keys during\n";
	print "the demo; it runs on its own timer.\n\n";

	t = [0:0.3:10];
	y = sin(t);

	mgplot_reset(win);
	mgplot_grid(win,0);
	mgplot_title(win,"A simple X-Y plot");
	mgplot(win,t,y,{""});
	pause(1.0);

	mgplot_title(win,"Now with a dot, and with grid lines");
	mgplot_grid(win,1);
	mgplot_xlabel(win,"I do labels too.");
	mgplot_ylabel(win,"Hello, World.");
	mgreplot(win,t,y,{""},{"w dots"});
	pause(1.0);

	mgplot_reset(win);
	mgplot_title(win,"Four different line-types");
	mgplot(win,t,[[y][2*y][3*y][4*y]],{"","","",""});
	pause(1.0);

	t = [0.0:0.5:10];
	lines = {"w boxes", "w points", "w lines", "w dots", "w linespoints"};
	names = {"", "", "" , "", ""};
	mgplot_reset(win);
	mgplot_title(win,"Five different marker-types");
	mgplot(win,t,[[t][2*t .+ 3][3*t .+ 6][4*t .+ 9][5*t .+ 12]], names, lines);
	pause(1.0);

	t = [0.1:0.1:3];
	mgplot_reset(win);
	mgplot_title(win,"I do loglog and semilog plots");
	mgplot_loglog(win,exp(t),exp(t.*t),{""});

//	t = [0:0.05:PI+0.1];
//	y = sin(5*t);
//	polar(t,y);
//	mgplot_title(win,"And polar plots too");
//	mgplot_grid(win,1);
//	pause(1.0);

	t = [0:.3:30];
	mgplot_reset(win);
	mgplot_hold(win,1);
	mgplot_subplot(win,2,2,1);
	mgplot(win,t,sin(t));
	mgplot_subplot(win,2,2,2);
	mgplot(win,t,t.*sin(t));
	mgplot_subplot(win,2,2,3);
	mgplot(win,t,t.*sin(t).^2);
	mgplot_subplot(win,2,2,4);
	mgplot(win,t,t.^2 .*sin(t).^2);
	mgplot_hold(win,0);
	pause(1.0);

//	{x,y} = meshdom([-2:.2:2], [-2:.2:2]);
//	z = x .* Matrix(exp(Array(-x.^2 - y.^2)));

//	if (tt < 5) {
//		pause(Integer(5-t));
//	}
//
//	mesh(z);
//	mgplot_title(win,"This is a 3-D plot of  z = x * exp(-x^2 - y^2)");
//	pause;(2);
	clear;
}
