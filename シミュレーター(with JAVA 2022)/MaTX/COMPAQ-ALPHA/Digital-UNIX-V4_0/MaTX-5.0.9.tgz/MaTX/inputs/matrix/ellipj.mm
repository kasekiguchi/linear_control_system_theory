
/*  -*- MaTX -*-
 *
 *  NAME
 *      ellipj() - Jacobi elliptic functions SN, CN and DN.
 *
 *  SYNOPSIS
 *      {sn, cn, dn} = ellipj(u, m)
 *         Matrix sn,cn,dn;
 *         Matrix u, m;
 *
 *  DESCRIPTION
 *      ellipj(U,M) returns the values of the Jacobi elliptic functions 
 *      SN, CN and DN, evaluated at argument U and parameter M.
 *
 *      As currently implemented, M is limited to 0 < M < 1.
 *      ellipj(U,M) are accurate to EPS. U and M must either be matrices 
 *      of the same size or either one may be a scalar.
 *
 *      Be sure you don't confuse the modulus K with the parameter m -
 *      they are related in the following way:  m = k^2
 *
 *      ellipj() uses the method of the arithmetic-geometric mean
 *      described in [1].
 *
 *  REFERENCES
 *      [1] M. Abramowitz and I.A. Stegun, "Handbook of Mathematical
 *          Functions" Dover Publications, 1965, Ch. 16-17.6.
 *
 */

Func List ellipj(u_, m_)
	Matrix u_, m_;
{
	Matrix a,b,c,n,phin,cn,dn,sn,u,m;
	Integer i,mi,mm,mmax,mn,mu,ni,nm,nu;
	Array tmp1, tmp2;
	Real tol;
	Index in;

	u = u_;
	m = m_;
	tol = EPS;
	{mm,mn} = size(m);
	cn = Z(mm,mn);
	sn = cn;
	dn = sn;
	m = makerowv(m);	// make a row vector
	u = makerowv(u);
	{mu,nu} = size(u);
	{mm,nm} = size(m);

	if (mu != mm || nu != nm) {
		if (mu == 1 && nu == 1) {
			u = u * ONE(mm,nm);
		} else if (mm == 1 && nm == 1) {
			m = m * ONE(mu,nu);
		} else {
			error("ellipj(): Matrix dimensions must agree.\n");
		}
	}

	{mm,mn} = size(m);
	mmax = mm*mn;
	a = ONE(1,mmax);
	c = sqrt(Array(m));
	b = sqrt(Array(1 .- m));
	n = Z(1,mmax);
	i = 1;

	while (any(abs(Array(c(i,:))) > tol)) {
		i = i + 1;
		a = [[a][0.5 * (a(i-1,:) + b(i-1,:))]];
		b = [[b][sqrt(Array(a(i-1,:) .* b(i-1,:)))]];
		c = [[c][0.5 * (a(i-1,:) - b(i-1,:))]];

		in = find((abs(Array(c(i,:))) <= tol) && (abs(Array(c(i-1,:))) > tol));
		if (length(in) != 0) {
			mi = 1;
			ni = length(in);
			n(in) = ONE(mi,ni)*(i-1);
		}
	}
	phin = Z(i,mmax);
	phin(i,:) = (2.0 .^ n) .* a(i,:) .* u;

	while (i > 1) {
		i = i - 1;
		in = find(Array(n) >= i);
		phin(i,:) = phin(i+1,:);
		if (length(in) != 0) {
			tmp1 = rem(Array(phin(i+1,in)), 2*PI);
			tmp2 = Array(c(i+1,in))*sin(tmp1)/Array(a(i+1,in));
			phin(i,in) = 0.5*(asin(tmp2) + Array(phin(i+1,in)));
		}
	}
	sn = reshape(sin(rem(Array(phin(1,:)),2*PI))#, Rows(sn), Cols(sn));
	cn = reshape(cos(rem(Array(phin(1,:)),2*PI))#, Rows(cn), Cols(cn));

	sn = makerowv(sn);
	dn = reshape(sqrt(Array(1 .- m .* (sn.^2.0))), Rows(dn), Cols(dn));
	return{sn, cn, dn};
}

