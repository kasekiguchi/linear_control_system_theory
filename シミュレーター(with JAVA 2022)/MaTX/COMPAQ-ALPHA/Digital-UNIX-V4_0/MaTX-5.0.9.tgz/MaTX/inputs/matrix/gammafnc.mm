
/*  -*- MaTX -*-
 *
 *  NAME
 *      gammafnc() -  Complete and incomplete Gamma functions
 *
 *  SYNOPSIS
 *      b = gammafnc(a)
 *         Array b;
 *         Array a;
 *
 *      b = gammafnc(a, x)
 *         Array b;
 *         Array a;
 *         Array x;
 *
 *  DESCRIPTION
 *      gammafnc(A) returns the value of the complete Gamma function
 *      for every element of A.
 *
 *      gammafnc(A,X) returns the value of the incomplete Gamma function
 *      of A, integrated to limit X.  A and X must be matrices of the
 *      same size or either one may be a scalar.
 *
 *  REFERENCES
 *      [1] W.H. Press et al, "Numerical Recipes", Cambridge Univ.
 *          Press, 1986.
 */

Func Array gammafnc(a_, x_, ...)
	Array a_, x_;
{
	Array a, x, b;
	Integer i, m, mm, n, nn;

	error(nargchk(1, 2, nargs, "gammafnc"));

	a = a_;
	if (nargs == 2) {
		x = x_;
	}

	if (nargs > 1) {
		{m, n} = size(a);
		{mm, nn} = size(x);
		if (m != mm || n != nn) {
			if (m == 1 && n == 1) {
				a = [a](1)*ONE(mm,nn);
			} else if (mm == 1 && nn == 1) {
				x = [x](1)*ONE(m,n);
			} else {
				error("gammafnc(): Matrix dimensions must agree.\n");
			}
		}
	}

	b = a;
	for (i = 1; i <= Cols(a)*Rows(a); i++) {
		if (nargs == 1) {
			b(i) = gammac(a(i));		// Complete
		} else {
			b(i) = gammai(a(i),x(i));	// Incomplete
		}
	}
	return b;
}
