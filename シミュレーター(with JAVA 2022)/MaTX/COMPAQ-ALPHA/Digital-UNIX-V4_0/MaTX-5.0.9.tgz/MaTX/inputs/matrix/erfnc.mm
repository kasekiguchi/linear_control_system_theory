
/* -*- MaTX -*-
 *
 *  NAME
 *      erfnc() - Error function
 *
 *  SYNOPSIS
 *      b = erfnc(x1)
 *         Array b;
 *         Array x1;
 *
 *      b = erfnc(x1, x2)
 *         Array b;
 *         Array x1;
 *         Array x2;
 *
 *  DESCRIPTION
 *      erfnc(X) returns the value of the error function for every
 *      element of X, accurate to about 1E-5.  The error function
 *      is the integral of the normal probability distribution
 *      function from 0 to X:
 *
 *       erfnc(X) = 2/sqrt(PI) integral(0,X) exp(-t^2)
 *
 *      erfnc(X1,X2) returns the value of the error function integrated
 *      between X1 and X2:
 *
 *       erfnc(X1,X2) = 2/sqrt(PI) integral(X1,X2) exp(-t^2)
 *
 *      Either X1, X2, or both may matrices, in which case the function
 *      is evaluated at all the elements.
 *
 *  SEE ALSO
 *      inverf().
 *
 */

Func Array erfnc(x1, x2, ...)
	Array x1, x2;
{
	Integer m,m1,mm,n,n1,nn;
	Real scaling;
	Array b,arg1,arg2,x,rx2;

	error(nargchk(1, 2, nargs, "erfnc"));

	{m,n} = size(x1);

	if (nargs == 1) {
		arg1 = Z(m,n);
		arg2 = x1;
	} else if (nargs == 2) {
		arg1 = x1;
		arg2 = x2;
	}

	{m1,n1} = size(arg1);
	{mm,nn} = size(arg2);
	if (m1 != mm || n1 != nn) {
		if (m1 == 1 && n1 == 1) {
			arg1 = [arg1](1) * ONE(mm,nn);
		} else if (mm == 1 && nn == 1) {
			arg2 = [arg2](1) * ONE(m1,n1);
		} else {
			error("erfnc(): Matrix dimensions must agree.\n");
		}
	}
	scaling = sqrt(2);   // To eliminate Gaussian scaling
	x = [arg1 arg2]*scaling;
	{m,n} = size(arg1);
	
	rx2 = (Re(x)^2)/2;
	b = gammafnc(Array(0.5), rx2);
	b = b * sgn(x);
	b = b(:,(n+1):2*n) - b(:,1:n);
	return b;
}
