
/*  -*- MaTX -*-
 *
 *  NAME
 *      cov()     - Covariance
 *      cov_col() - Covariance matrix for each column
 *      cov_row() - Covariance matrix for each row
 *
 *  SYNOPSIS
 *      xy = cov(x)
 *          Real xy;
 *          Matrix x;
 *
 *      xy = cov(x, y)
 *          Real xy;
 *          Matrix x;
 *          Matrix y;
 *
 *      xy = cov_col(x)
 *          Matrix xy;
 *          Matrix x;
 *
 *      xy = cov_col(x, y)
 *          Matrix xy;
 *          Matrix x;
 *          Matrix y;
 *
 *      xy = cov_row(x)
 *          Matrix xy;
 *          Matrix x;
 *
 *      xy = cov_row(x, y)
 *          Matrix xy;
 *          Matrix x;
 *          Matrix y;
 *
 *  DESCRIPTION
 *      cov(x) returns the variance for all the elements.
 *      cov(x,y) is equal to cov([x y]).  
 *
 *      For matrices, where each row is an observation, and each 
 *      column a variable, cov_col(x) is the covariance matrix. 
 *
 *      diag_vec(cov_col(x)) is a vector of variances for each column,
 *      and sqrt(diag_vec(cov_col(x))) is a vector of standard deviations.
 *      cov_col(x,y) is cov_col([makecolv(x) makecolv(y)]).  
 *
 *      For matrices, where each column is an observation, and each 
 *      row a variable, cov_row(x) is the covariance matrix. 
 *
 *      diag_vec(cov_row(x)) is a vector of variances for each row,
 *      and sqrt(diag_vec(cov_row(x))) is a vector of standard deviations.
 *      cov_row(x,y) is cov_row([[makerowv(x)][makerowv(y)]]).
 *
 *  SEE ALSO
 *      corrcoef() and std().
 */

Func Real cov(x, y, ...)
	Matrix x, y;
{
	Matrix z;

	error(nargchk(1, 2, nargs, "cov"));
	
	if (nargs == 1) {
		return [cov_col(reshape(x, 1, Rows(x)*Cols(x)))](1,1);
	} else {
		z = [makecolv(x), makecolv(y)];
		return [cov_col(reshape(z, 1, Rows(z)*Cols(z)))](1,1);
	}
}

Func Matrix cov_col(x_, y_, ...)
	Matrix x_, y_;
{
	Matrix x, y;
	Matrix xy;
	Integer m, my, n, ny;

	error(nargchk(1, 2, nargs, "cov_col"));

	{m, n} = size(x_);

	if (nargs > 1) {
		{my, ny} = size(y_);
		if (m != my || n != ny) {
			error("cov_col(): X and Y must be the same size.\n");
		}
		if (m != 1 && n != 1) {
			error("cov_col(): X and Y must be vectors.\n");
		}
		x = [makecolv(x_), makecolv(y_)];
	} else if (min(Cols(x_), Rows(x_)) == 1) {
		x = makecolv(x_);
	} else {
		x = x_;
	}
	{m, n} = size(x);
	x = x - ONE(m,1) * (sum_col(x)/m);

	if (m == 1) {
		xy = Z(1);
	} else {
		xy = x#*x / (m-1);
	}
	return xy;
}

Func Matrix cov_row(x, y, ...)
	Matrix x, y;
{
	error(nargchk(1, 2, nargs, "cov_row"));
	
	if (nargs == 1) {
		return trans(cov_col(trans(x)));
	} else {
		return trans(cov_col(x, y));
	}
}
