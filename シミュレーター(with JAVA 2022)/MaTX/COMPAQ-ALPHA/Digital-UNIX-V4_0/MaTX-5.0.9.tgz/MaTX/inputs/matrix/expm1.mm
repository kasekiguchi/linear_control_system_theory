
/*  -*- MaTX -*-
 *
 *  NAME
 *      expm1() - Matrix exponential via Pade approximation
 *
 *  SYNOPSIS
 *      EX = expm1(A)
 *         Matrix EX;
 *         Matrix A;
 *
 *  DESCRIPTION
 *      Scale A by power of 2 so that its norm is < 1/2 .
 *
 *  REFERENCSE
 *      [1] Golub and Van Loan, Matrix Computations, Algorithm 11.3-1.
 *
 *  SEE ALSO
 *      exp(), exp2(), exp3() and log()
 */

Func Matrix expm1(aa)
	Matrix aa;
{
	Matrix a,e,X,d,cX;
	Integer n,p,q,qp1,q2p1,k;
	Real c,s;

	a = aa;

	s = infnorm(a);
	if (s > 0) {
		s = max(0.0, fix(log(s)/log(2.0)) + 2.0);
	}
	a = a/(2^Integer(s));

	// Pade approximation for exp(A)
	X = a; 
	{n,n} = size(a);
	c = 1.0/2.0;
	e = I(n) + c*a;
	d = I(n) - c*a;
	q = 6;
	p = 1;
	qp1 = q + 1;
	q2p1 = 2*q + 1;

	for (k = 2; k <= q; k++) {
		// c = c * (q-k+1) / (k*(2*q-k+1));
		// The following line is a little faster:

		c = c * Real(qp1 - k) / Real(k*(q2p1-k));
		X = a*X;
		cX = c*X;
		e = e + cX;
		if (p) {
			d = d + cX;
		} else {
			d = d - cX;
		}
		p = ! p;
	}
	e = d\e;

	// Undo scaling by repeated squaring
	for (k = 1; k <= Integer(s); k++) {
		e = e*e;
	}

	return e;
}
