
/*  -*- MaTX -*-
 *
 *  NAME
 *      givens() - Givens rotation matrix
 *
 *  SYNOPSIS
 *      G = givens(x, y)
 *         CoMatrix G;
 *         Complex x, y;
 *
 *  DESCRIPTION
 *      givens(x,y) returns the complex Givens rotation matrix
 *
 *           | c       s |                  | x |     | r | 
 *       G = |           |   such that  G * |   |  =  |   |
 *           |-conj(s) c |                  | y |     | 0 |
 *   	                                
 *      where c is real, s is complex, and c^2 + s^2 = 1. 
 *
 */

Func CoMatrix givens(x, y)
	Complex x, y;
{
	Matrix G;
	Real absx, nrm, scl;
	Complex c, s;

	scl = abs(x) + abs(y);

	absx = abs(x);
	if (absx == 0.0) {
		c = (0.0, 0.0);
		s = (1.0, 0.0);
	} else {
		nrm = scl*sqrt(Re((x/scl)*(x#/scl) + (y/scl)*(y#/scl)));
		c = (absx/nrm, 0.0);
		s = (x/absx)*(conj(y)/nrm);
	}
	G = [[    c   , s  ]
		 [-conj(s), c  ]];
	return G;
}
