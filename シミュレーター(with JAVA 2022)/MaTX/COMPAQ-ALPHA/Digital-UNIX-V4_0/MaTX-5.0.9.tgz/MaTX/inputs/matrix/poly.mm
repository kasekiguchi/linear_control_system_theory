
/*  -*- MaTX -*-
 *
 *  NAME
 *      poly() - Characteristic polynomial
 *
 *  SYNOPSIS
 *      P = poly(A)
 *        Matrix P;
 *        Matrix A;
 *
 *  DESCRIPTION
 *      If A is an n-by-n matrix, poly(A) is an n+1 element row vector whose
 *      element are the coefficients of the characteristic polynomial,
 *      det(sI - A).  The coefficients are ordered in decending powers:
 *
 *      If A is a vector containing the roots of a polynomial, poly(A) returns
 *      a row vector whose elements are the coefficients of the polynomial.
 *
 *  SEE ALSO
 *      makepoly() and Polynomial()
 */

Func Matrix poly(A)
	Matrix A;
{
	Matrix eg,p;
	Polynomial s, po;
	Integer m, n, N;

	{m, n} = size(A);
	
	if (m == 0 && n == 0) {
		return [1];
	} else if (m == n) {
		N = m;
		eg = eigval(A);
	} else if (m == 1 || n == 1) {
		N = m*n;
		eg = makecolv(A);
	} else {
		error("poly(): Argument must be a square matrix or a vector.\n");
	}

	s = Polynomial("s");
	
	if (isreal(A)) {
		po = Re(prod(s*ONE(N,1) - eg));
	} else {
		po = prod(s*ONE(N,1) - eg);
	}
	
	if (version() == 4) {
		p = fliplr(Matrix(po));
	} else {
		p = Matrix(po);
	}

	return p;
}

