
/*  -*- MaTX -*-
 *
 *  NAME
 *      hex2dec() - Hexadecimal to decimal number conversion
 *
 *  SYNOPSIS
 *      d = hex2dec(h)
 *         Integer d;
 *         String h;
 *
 *  DESCRIPTION
 *     hex2dec(D) returns hexadecimal number D in decimal form.
 *     For example, hex2dec("12B") and hex2dec("12b") both return 299.
 *
 *	SEE ALSO
 *      dec2hex(), hex2num() and Matrix().
 */

Func Integer hex2dec(h)
	String h;
{
	Integer i,m,n,hi,d;
	Matrix p,hh;

	n = length(h);
	p = cumprod([ONE(1) 16*ONE(1,n-1)]);
	hh = Z(1,n);

	for (i = 1; i <= n; i++) {
		hi = Integer([abs(h(i))](1));
		if ((hi > 96.0)) {
			hh(i) = hi - 87;
		} else if ((hi > 64.0)) {
			hh(i) = hi - 55;
		} else {
			hh(i) = hi - 48;
		}
	}
	d = Integer([hh*p(n:-1:1)#](1));

	return d;
}
