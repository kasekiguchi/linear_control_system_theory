
/*  -*- MaTX -*-
 *
 *  NAME
 *      deconv() - Deconvolution
 *
 *  SYNOPSIS
 *      {q,r} = deconv(b,a)
 *         Matrix q,r;
 *         Matrix b,a;
 *
 *  DESCRIPTION
 *      deconv(b,a) deconvolves vector a out of vector b.  The
 *      result is returned in vector q and the remainder in vector
 *      r such that b = conv(q,a) + r.
 *
 *  SEE ALSO
 *      conv().
 */

Func List deconv(b, a)
	Matrix b, a;
{
	Matrix q, r;
	Integer mb, na, nb;

	{mb, nb} = size(b);
	nb = max(mb, nb);
	na = max(Rows(a), Cols(a));

	if (na > nb) {
		q = Z(1);
		r = b;
		return {q, r};
	}
	if (a(1) == 0.0) {
		error("deconv(): First coefficient of A must be non-zero.\n");
	}
	/*
	 *	Deconvolution and polynomial division are the same operations
	 *	as a digital filter's impulse response B(z)/A(z):
	 */
	{q} = filter(b, a, [[1], Z(1,nb-na)]);
	if (mb != 1) {
		q = makecolv(q);
	}

	r = b - Matrix(conv(q, a));
	return {q, r};
}
