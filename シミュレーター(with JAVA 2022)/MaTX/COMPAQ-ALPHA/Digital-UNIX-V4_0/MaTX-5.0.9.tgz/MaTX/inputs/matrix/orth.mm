
/*  -*- MaTX -*-
 *
 *  NAME
 *      orth() - Orthogonalization
 *
 *  SYNOPSIS
 *      Q = orth(A)
 *         Matrix Q;
 *         Matrix A;
 *
 *      Q = orth(A,tol)
 *         Matrix Q;
 *         Matrix A;
 *         Real tol;
 *
 *  DESCRIPTION
 *      Q = orth(A) is an orthonormal basis for the range of A.  Q#*Q = I(A),
 *      the columns of Q span the same space as the columns of A and the
 *      number of columns of Q is the rank of A.
 *
 *  SEE ALSO
 *      null().
 *
 */

Func Matrix orth(A, tol, ...)
	Matrix A;
	Real tol;
{
	Integer r;
	Matrix Q,P,R;

	error(nargchk(1, 2, nargs, "orth"));
	
	if (nargs == 1) {
		tol = EPS*frobnorm(A);
	}

	// QR decomposition
	{Q,R,P} = qr_p(A);

	// Determine r = effective rank
	r = Integer(sum(abs(Array(diag_vec(R))) > tol));

	// Use first r columns of Q
	if (r > 0) {
		Q = Q(:,1:r);
		// Cosmetic sign adjustment
		Q = -Q;
		Q(:,r) = -Q(:,r);
	} else {
		Q = [];
	}
	return Q;
}
