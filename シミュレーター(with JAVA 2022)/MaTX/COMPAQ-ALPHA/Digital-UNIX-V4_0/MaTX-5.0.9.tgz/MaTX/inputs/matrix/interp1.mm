
/*  -*- MaTX -*-
 *
 *  NAME
 *      interp1() - 1-D interpolation using the FFT method
 *
 *  SYNOPSIS
 *      y = interp1()
 *         Matrix y;
 *
 *      y = interp1(x)
 *         Matrix y;
 *         Matrix x;
 *
 *      y = interp1(x,ny)
 *         Matrix y;
 *         Matrix x;
 *         Integer ny;
 *
 *  DESCRIPTION
 *      interp1(X,N) returns a length N vector Y obtained
 *      by interpolation within vector X.  N must be larger than
 *      the length of X.
 *
 *      The result has circular periodicity.
 *
 *      interp1() called with no arguments interpolates and plots 
 *      some random values.
 */

Func Matrix interp1(x,ny, ...)
	Matrix x;
	Integer ny;
{
	Integer i,m,n,nx,oldm,win;
	Matrix ax,a,b,y;

	error(nargchk(0, 2, nargs, "interp1"));

	if (nargs < 1) { // Demonstration.
		nx = 10;
		x = rand(nx,1);
		ny = 100;
	}
	
	{m,n} = size(x);
	oldm = m;
	if (m == 1) {
		x = x#;
		{m,n} = size(x);
	}
	if (ny <= m) {
		error("interp1(): NY must exceed length of X.\n");
	}

	i = m/2 + 1;
	if (rem(m,2) != 0) {
		i = (m + 1)/2;
	}
	if ((2^nextpow2(length(x)) - length(x)) == 0) {
		a = fft(x#)#;
	} else {
		a = DFT(x#)#;
	}

	b = [[a(1:i,:)]
		 [Z(ny-m,n)]
		 [a(i+1:m,:)]];

	if (rem(m,2) == 0) {
		if (rem(ny,2) == 0) {
			b(i) = b(i)/2;
			b(i+ny-m) = b(i);
		} else {
			b(i) = 0;
		}
	}
	if ((2^nextpow2(length(x)) - length(x)) == 0) {
		y = ifft(b#)#;
	} else {
		y = IDFT(b#)#;
	}
	if (oldm == 1) {
		y = y#;
	}
	y = y * ny / m;
	if ( ! isreal(x)) {
		if ( ! any(Im(x))) {
			y = Re(y);
		}
	} else {
		y = Re(y);
	}

	win = mgplot_cur_win();

	if (nargs < 1) { // Demonstration
		ax = [0:(ny-1)]/ny;
		ax = nx*ax .+ 1;
		mgplot(win, ax, y);

		ax = [0:(nx-1)]/nx;
		ax = nx*ax .+ 1;
		mgreplot(win, ax,x);

		mgplot_title(win,"Demonstration of interp1");
		mgplot_xlabel(win,"x");
		mgplot_ylabel(win,"y");
	}
	return y;
}
