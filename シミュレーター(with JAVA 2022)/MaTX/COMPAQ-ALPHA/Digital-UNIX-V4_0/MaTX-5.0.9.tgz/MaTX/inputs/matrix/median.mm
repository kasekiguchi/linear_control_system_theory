
/*  -*- MaTX -*-
 *
 *  NAME
 *      median()     - Median value for all elements
 *      median_col() - Median value for each column
 *      median_row() - Median value for each row
 *
 *  SYNOPSIS
 *      y = median(x)
 *        Real y;
 *        Matrix x;
 *
 *      y = median_col(x)
 *        Matrix y;
 *        Matrix x;
 *
 *      y = median_row(x)
 *        Matrix y;
 *        Matrix x;
 *
 *  DESCRIPTION
 *      median(x) is the median value of all the elements in x.
 *
 *      For matrices, 
 *
 *      median_col(X) is a row vector containing the median value
 *      of each column.
 *
 *      median_row(X) is a row vector containing the median value
 *      of each row.
 *
 *  SEE ALSO
 *      mean()
 */

Func Real median(x)
	Matrix x;
{
	Matrix y;

	y = median_col(x);

	if (length(y) == 1) {
		return y(1,1);
	} else {
		return [median_col(y)](1,1);
	}
}

Func Matrix median_col(x_)
	Matrix x_;
{
	Integer i,m,n;
	Matrix x,y,xx;

	x = x_;

	{m,n} = size(x);

	if (m == 1) {
		// row vector
		{x} = sort(x);
		if (rem(n,2)) {		// n is odd	
			y = [x((n+1)/2)];
		} else {			// n is even
			y = [(x(n/2) + x(n/2+1))/2];
		}
	} else {
		for (i = 1; i <= n; i++) {
			{xx} = sort(x(:,i));
			x(:,i) = xx;
		}

		if (rem(m,2)) {		// m is odd
			y = x((m+2)/2,:);
		} else {			// m is even
			y = (x(m/2,:) + x(m/2+1,:))/2;
		}
	}
	return y;
}

Func Matrix median_row(x)
	Matrix x;
{
	return trans(median_col(trans(x)));
}
