
/*  -*- MaTX -*-
 *
 *  NAME
 *      rref() - Reduced row echelon form
 *
 *  SYNOPSIS
 *      A = rref(A0)
 *         Matrix A;
 *         Matrix A0;
 *
 *      A = rref(A0,tol)
 *         Matrix A;
 *         Matrix A0;
 *         Real tol;
 *
 *  DESCRIPTION
 *      rref(A) produces the reduced row echelon form of A.
 *
 *      rref(A,tol) uses the given tolerance in the rank tests.
 *
 */

Func Matrix rref(A_,tol, ...)
	Matrix A_;
	Real tol;
{
	Integer i,j,k,m,n,rats;
	Matrix A,den,num;
	Real p;

	error(nargchk(1, 2, nargs, "rref"));

	A = A_;
	{m,n} = size(A);

	// Does it appear that elements of A are ratios of small integers?
	{num, den} = rat(A);
	rats = all(Array(A) == Array(num ./ den));

	// Compute the default tolerance if none was provided.
	if (nargs < 2) {
		tol = max(m,n)*EPS*infnorm(A);
	}

	// Loop over the entire matrix.
	i = 1;
	j = 1;
	while (i <= m && j <= n) {
		// Find value and index of largest element
		// in the remainder of column j.
		{p,k} = maximum(abs(Array(A(i:m,j))));
		k = k+i-1;
		if (p <= tol) {
			// The column is negligible, zero it out.
			A(i:m,j) = Z(m-i+1,1);
			j = j + 1;
		} else {
			// Swap i-th and k-th rows.
			A(Index([i k]),j:n) = A(Index([k i]),j:n);
			// Divide the pivot row by the pivot element.
			A(i,j:n) = A(i,j:n)/A(i,j);
			// Subtract multiples of the pivot row from all the other rows.
			for (k = 1; k <= i-1; k++) {
				A(k,j:n) = A(k,j:n) - A(k,j)*A(i,j:n);
			}
			for (k = i+1; k <= m; k++) {
				A(k,j:n) = A(k,j:n) - A(k,j)*A(i,j:n);
			}
			i = i + 1;
			j = j + 1;
		}
	}

	// Return "rational" numbers if appropriate.
	if (rats) {
		{num,den} = rat(A);
		A = num ./ den;
	}
	
	return A;
}
