
/* -*- MaTX -*-
 *
 *  NAME
 *      bessel() - Bessel function J-sub-nu (x) for every point in a array
 *
 *  SYNOPSIS
 *      J = bessel(alpha, x)
 *         Array J;
 *         Real alpha;
 *         Array x;
 *
 *  DESCRIPTION
 *      There are four different mm-files for Bessel functions.
 *      bessel(nu,x) is the Bessel function J-sub-nu (x) for 
 *      every point in array x.  The order nu must be a
 *      scalar, but not necessarily an integer.  bessel() is a
 *      driver that selects besseln() if nu is an integer and
 *      bessela() otherwise.
 *
 *      besseln(n,x) for integer order n, returns J-sub-n (x),
 *      the Bessel function of the first kind.
 *
 *      bessela(nu,x) for noninteger order nu, returns J-sub-nu (x).
 *      Warning: bessela(nu,x) may be inaccurate if both nu and x
 *      are greater than 50.
 *
 *      besselh(n,x) for integer order n, returns H-sub-n (x),
 *      the complex Hankel function, J-sub-n (x) + i * Y-sub-n (x).
 *
 *      Modified Bessel functions of integer order are just the usual
 *      Bessel functions evaluated with purely imaginary arguments.
 *
 *  SEE ALSO
 *      bessela() for more details.
 *
 */

Func Array bessel(alpha, x)
	Real alpha;
	Array x;
{
	Array ans;

	if (alpha == round(alpha)) {
		ans = besseln(Integer(alpha), x);
	} else {
        if (max(alpha, infnorm(Matrix(x))) > 25.0) {
			warning("bessel(): Results may be inaccurate.\n");
        }
       {ans} = bessela(alpha, x);
	}
	return ans;
}

