
/*  -*- MaTX -*-
 *
 *  NAME
 *      logspace() - Logarithmically spaced vector
 *
 *  SYNOPSIS
 *      y = logspace(d1, d2)
 *         Array y;
 *         Real d1, d2;
 *
 *      y = logspace(d1, d2, n)
 *         Array y;
 *         Real d1, d2;
 *         Integer n;
 *
 *  DESCRIPTION
 *      logspace(d1,d2) generates a row vector of 50 logarithmically
 *      equally spaced points between decades 10^d1 and 10^d2.
 *
 *      If d2 is PI, then the points are between 10^d1 and PI.
 *
 *      logspace(d1,d2,N) generates N points.
 *
 *  SEE ALSO
 *      linspace()
 */

Func Array logspace(d1, d2, n, ...)
	Real d1, d2;
	Integer n;
{
	Array y;

	error(nargchk(2, 3, nargs, "logspace"));

	if (nargs == 2) {
		n = 50;
	}
	if (d2 == PI) {
		d2 = log10(PI);
	}
	if (abs(d1) <= 0.1 || 10.0 <= abs(d2)) {
		d1 = log10(d1);
		d2 = log10(d2);
	}

	y = 10.0 .^ [d1 .+ [0:n-2]*(d2-d1)/(n-1), Matrix(d2)];
	return y;
}
