
/*  -*- MaTX -*-
 *
 *  NAME
 *      hadamard() - Hadamard matrix
 *
 *  SYNOPSIS
 *      H = hadamard(k)
 *         Matrix H;
 *         Integer k;
 *
 *  DESCRIPTION
 *      hadamard(k) is the Hadamard matrix of order n = 2^k
 */

Func Matrix hadamard(k)
	Integer k;
{
	Matrix H, T;

	// Compute it recursively
	if (k < 1) {
		H = ONE(1);
	} else { 
		T = hadamard(k-1);
		H = [[T T][T, -T]];
	}
	return H;
}
