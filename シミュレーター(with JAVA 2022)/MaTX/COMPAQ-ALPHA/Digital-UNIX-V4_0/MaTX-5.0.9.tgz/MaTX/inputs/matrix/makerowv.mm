
/* -*- MaTX -*-
 *
 *  NAME
 *      makerowv() - Make a row vector
 *
 *  SYNOPSIS
 *      v = makerowv(A)
 *         Matrix v;
 *         Matrix A;
 *
 *  SEE ALSO
 *      makecolv()
 */

Func Matrix makerowv(A)
	Matrix A;
{
	Integer m, n;
	
	{m,n} = size(A);
	if (m == 1 || n == 1) {
		return reshape(A, 1, m*n);
	} else {
		return reshape(trans(A), 1, m*n);
	}
}
