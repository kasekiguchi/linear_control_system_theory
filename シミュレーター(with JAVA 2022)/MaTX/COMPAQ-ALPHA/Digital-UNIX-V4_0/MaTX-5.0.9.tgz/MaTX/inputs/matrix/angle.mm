
/* -*- MaTX -*-
 *
 *  NAME
 *      angle() - Phase angles in radians
 *
 *  SYNOPSIS
 *      p = angle(h)
 *        Array p;
 *        CoArray h;
 *
 *  DESCRIPTION
 *      angle() returns the phase angles, in radians, of a matrix with
 *      complex elements.  Use abs() for the magnitudes.
 *
 *  SEE ALSO
 *      abs()
 */

Func Array angle(h)
	CoArray h;
{
	Array p;

	p = atan2(Im(h), Re(h));
	return p;
}
