
/*  -*- MaTX -*-
 *
 *  NAME
 *      interp3() - 2-D biharmonic data interpolation (gridding)
 *
 *  SYNOPSIS
 *      {zi,weights} = interp3()
 *          Matrix zi,weights;
 *
 *      {zi,weights} = interp3(x,y,z,xi,yi)
 *          Matrix zi,weights;
 *          Matrix x;
 *          Matrix y;
 *          Matrix z;
 *          Matrix xi;
 *          Matrix yi;
 *
 *      {zi,weights} = interp3(x,y,z,xi,yi,weights)
 *          Matrix zi,weights;
 *          Matrix x;
 *          Matrix y;
 *          Matrix z;
 *          Matrix xi;
 *          Matrix yi;
 *          Matrix weights;
 *
 *  DESCRIPTION
 *      interp3(x,y,z,xi,yi) uses biharmonic interpolation to
 *      find a matrix zi corresponding to new abscissa vectors xi
 *      and yi, given matrix z whose rows and columns correspond to
 *      vectors x and y.
 *
 *      If x, y, and z are all vectors, interp3() interpolates within the
 *      data given by the (possibly irregularly spaced) ordered triplets
 *      (x,y,z) to return {zi,weights} matrix zi.
 *
 *      interp3() also returns the computed interpolation weights,
 *      which can be reused as follows:
 *      interp3(...,weights) uses the given weights vector,
 *      instead of recalculating them from x, y, and z.
 *
 *      interp3() called with no arguments interpolates and contours
 *      some random (x,y,z) values.
 *
 */

Func List interp3(x,y,z,xi,yi,weights, ...)
	Matrix x,xi,y,yi,z;
	Matrix weights;
{
	Integer i,cols,im,in,m,n,rows,win;
	Matrix Green,oldxi,oldyi,xiyi,xiyim,xy,xym,zi,g,d;
	Matrix xxi,yyi,mask;

	List meshdom();

	error(nargchk(0, 6, nargs, "interp3"));

	if (nargs == 0) { // Random data for demonstration plot.
		x = rand(10,1);
		y = rand(10,1);
		z = rand(10,1);
		xi = ([0:10]/10)';
		yi = xi;
	}

	if (Cols(x)*Rows(x) != Cols(z)*Rows(z)) {
		if (length(x)*length(y) == Cols(z)*Rows(z)) {
			{x, y} = meshdom(x, y);
		} else {
			error("interp3(): Inconsistent sizes for x, y, and z.\n");
		}
	}

	z = makecolv(z);
	x = makecolv(x);
	y = makecolv(y);
	m = length(x);

	xy = x + y*(0,1);

	if (nargs < 6) {
		xym = xy * ONE(1,m);
		d = abs(Array(xym - xym#));
		mask = (Array(d) == 0);
		d = d + mask;
		g = (d.^2) .* Matrix((log(Array(d)) .- 1));   // Green's function.
		g = g .* (1 .- mask);
		weights = g \ z;
	}

	oldxi = xi;
	oldyi = yi;
	xi = makecolv(xi);
	yi = makecolv(yi);
	{xxi,yyi} = meshdom(xi#,yi#);
	xi = makecolv(xxi);
	yi = makecolv(yyi);
	{im,in} = size(xi);
	xym = ONE(im,1) * xy#;
	xiyi = xi + yi*(0,1);
	xiyim = xiyi * ONE(1,m);
	d = abs(Array(xiyim - xym));
	mask = (Array(d) == 0);
	d = d + mask;
	g = (d.^2) .* Matrix(log(Array(d)) .- 1);   // Green#s function.
	g = g .* (1 .- mask);
	zi = reshape(g*weights, Rows(xxi), Cols(xxi));

	if (nargs < 1) { // Demonstration plot.
//		contour(zi,10,oldxi,oldyi);
		win = mgplot_cur_win();
		mgplot(win,x#,y#);
		mgplot_title(win,"Demonstration of interp3");
		mgplot_xlabel(win,"x");
		mgplot_ylabel(win,"y");
	}

	return {zi,weights};
}
