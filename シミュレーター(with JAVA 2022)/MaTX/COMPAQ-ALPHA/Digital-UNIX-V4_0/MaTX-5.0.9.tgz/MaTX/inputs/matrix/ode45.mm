
/*  -*- MaTX -*-
 *
 *  NAME
 *      ode45() - Integrate a system of ODE using 4th-5th order 
                  Runge-Kutta formulas
 *
 *  SYNOPSIS
 *      {tout,yout} = ode45(FunFcn, t0, tfinal, y0)
 *         Matrix tout, yout;
 *         Matrix FunFcn();
 *         Real t0, tfinal;
 *         Matrix y0;
 *
 *      {tout,yout} = ode45(FunFcn, t0, tfinal, y0, tol)
 *         Matrix tout, yout;
 *         Matrix FunFcn();
 *         Real t0, tfinal;
 *         Matrix y0;
 *         Real tol;
 *
 *      {tout,yout} = ode45(FunFcn, t0, tfinal, y0, tol, trc)
 *         Matrix tout, yout;
 *         Matrix FunFcn();
 *         Real t0, tfinal;
 *         Matrix y0;
 *         Real tol;
 *         Integer trc;
 *
 *  DESCRIPTION
 *      Integrate a system of ordinary differential equations using
 *      4th and 5th order Runge-Kutta formulas.
 *
 *      ode45(FunFcn, t0, tfinal, y0) integrates the system
 *      of ordinary differential equations described by the function
 *      FunFcn() over the interval t0 to tfinal and using initial
 *      conditions y0.
 *
 *      ode45(FunFcn, t0, tfinal, y0, tol, 1) uses tolerance tol
 *      and displays status while the integration proceeds.
 *
 *      tout : Itegration time points (row-vector).
 *      yout : Solution, one solution column-vector per tout-value.
 *
 *      FunFcn : User-supplied problem description.
 *               Call: yprime = FunFcn(t,y)
 *                t      : Time (scalar)
 *                y      : Solution column-vector
 *                yprime : Returned derivative column-vector;
 *                         yprime(i) = dy(i)/dt
 *      t0     : Initial value of t
 *      tfinal : Final value of t
 *      y0     : Initial value column-vector.
 *      tol    : The desired accuracy. (Default: tol = 1.0e-6).
 *      trc    : If nonzero, each step is printed. (Default: trc = 0)
 *
 *  SEE ALSO
 *     ode23() and odedemo().
 *
 */

Func List ode45(FunFcn, t0, tfinal, y0, tol, trc, ...)
	Matrix FunFcn();
	Real t0, tfinal;
	Matrix y0;
	Real tol;
	Integer trc;
{
	Integer j;
	Matrix tout,yout,alpha,beta,f,gamma,y;
	Real h,hmax,hmin,pw,t,tau,delta;

	error(nargchk(4, 6, nargs, "ode45"));

	// The Fehlberg coefficients:
	alpha = [1.0/4.0  3.0/8.0  12.0/13.0  1.0  1.0/2.0]';

	beta  = [[[    1,      0,      0,    0,     0,  0]/4]
			 [[    3,      9,      0,    0,     0,  0]/32]
			 [[ 1932,  -7200,   7296,    0,     0,  0]/2197]
			 [[ 8341, -32832,  29440, -845,     0,  0]/4104]
			 [[-6080,  41040, -28352, 9295, -5643,  0]/20520]]';

	gamma = [[[902880  0  3953664  3855735, -1371249  277020]/7618050]
			 [[ -2090  0    22528    21970, -15048,   -27360]/752400 ]]';

	pw = 1.0/5.0;
	if (nargs < 6) {
		trc = 0;
	}
	if (nargs < 5) {
		tol = 1.e-6;
	}

	// Initialization
	t = t0;
	hmax = (tfinal - t)/5;
	hmin = (tfinal - t)/20000;
	h = (tfinal - t)/100;
	y = makecolv(y0);
	f = y*Z(1,6);
	tout = [t];
	yout = y#;
	tau = tol*max(infnorm(y), 1.0);

	if (trc) {
		clear;
		print "\n", t, "\n", h, "\n", y;
	}

	// The main loop
	while (t < tfinal && h >= hmin) {
		if (t + h > tfinal) {
			h = tfinal - t;
		}

		// Compute the slopes
		f(:,1) = FunFcn(t,y);
		for (j = 1; j <= 5; j++) {
			f(:,j+1) = FunFcn(t+alpha(j)*h, y+h*f*beta(:,j));
		}

		// Estimate the error and the acceptable error
		delta = infnorm(h*f*gamma(:,2));
		tau = tol*max(infnorm(y),1.0);

		// Update the solution only if the error is acceptable
		if (delta <= tau) {
			t = t + h;
			y = y + h*f*gamma(:,1);
			tout = [[tout][t]];
			yout = [[yout][y#]];
		}
		if (trc) {
			gotoxy(1,1);
			print "\n", t, "\n", h, "\n", y;
		}

		// Update the step size
		if (delta != 0.0) {
			h = min(hmax, 0.8*h*(tau/delta)^pw);
		}
	}
	
	if (t < tfinal) {
		warning("ode45(): singularity likely.\n");
		print t;
	}
	return {tout, yout};
}
