
/*  -*- MaTX -*-
 *
 *  NAME
 *      linspace() - Linearly spaced vector
 *
 *  SYNOPSIS
 *      y = linspace(d1, d2)
 *         Array y;
 *         Real d1, d2;
 *
 *      y = linspace(d1, d2, n)
 *         Array y;
 *         Real d1, d2;
 *         Integer n;
 *
 *  DESCRIPTION
 *      linspace(d1,d2) generates a row vector of 100 linearly
 *      equally spaced points between d1 and d2.
 *
 *      linspace(d1,d2,N) generates N points between d1 and d2.
 *
 *  SEE ALSO
 *      logspace()
 */

Func Array linspace(d1, d2, n, ...)
	Real d1, d2;
	Integer n;
{
	Array y;

	error(nargchk(2, 3, nargs, "linspace"));
	
	if (nargs == 2) {
		n = 100;
	} 

	y = [d1 .+ [0:n-2]*(d2-d1)/(n-1), Matrix(d2)];
	return y;
}
