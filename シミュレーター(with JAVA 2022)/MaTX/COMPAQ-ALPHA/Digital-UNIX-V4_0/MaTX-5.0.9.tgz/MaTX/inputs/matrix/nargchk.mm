
/* -*- MaTX -*-
 *
 *  NAME
 *      nargchk() - Check number of input arguments
 *
 *  SYNOPSIS
 *      mess = nargchk(low, high, number)
 *         String mess;
 *         Integer low, high, number;
 *
 *      mess = nargchk(low, high, number, name)
 *         String mess;
 *         Integer low, high, number;
 *         String name;
 *
 *  DESCRIPTION
 *      nargchk() check number of input arguments. Return error message if
 *      not between low and high.  If it is, return msg empty string.
 *
 *  SEE ALSO
 *      error()
 */

Func String nargchk(low, high, number, name, ...)
	Integer low, high, number;
	String name;
{
	String msg;
	msg = "";
	
	if (nargs < 3) {
		error("nargchk(): Not enough input arguments.\n");
	} else if (4 < nargs) {
		error("nargchk(): Too many input arguments.\n");
	}

	if (number < low) {
		if (4 <= nargs && length(name) != 0) {
			msg = sprintf("%s(): Not enough input arguments.\n", name);
		} else {
			msg = "Not enough input arguments.\n";
		}
	} else if (number > high) {
		if (4 <= nargs && length(name) != 0) {
			msg = sprintf("%s(): Too many input arguments.\n", name);
		} else {
			msg = "Too many input arguments.\n";
		}
	}

	return msg;
}
