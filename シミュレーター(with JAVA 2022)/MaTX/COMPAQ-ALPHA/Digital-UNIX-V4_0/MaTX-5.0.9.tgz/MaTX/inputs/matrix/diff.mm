
/* -*- MaTX -*-
 *
 *  NAME
 *      diff()     - Difference function for all elements
 *      diff_col() - Difference function for each column
 *      diff_row() - Difference function for each row
 *
 *  SYNOPSIS
 *     dx = diff(x)
 *         Matrix dx;
 *         Matrix x;
 *
 *     dx = diff(x, k)
 *         Matrix dx;
 *         Matrix x;
 *         Integer k;
 *
 *     dx = diff_col(x)
 *         Matrix dx;
 *         Matrix x;
 *
 *     dx = diff_col(x, k)
 *         Matrix dx;
 *         Matrix x;
 *         Integer k;
 *
 *     dx = diff_row(x)
 *         Matrix dx;
 *         Matrix x;
 *
 *     dx = diff_row(x, k)
 *         Matrix dx;
 *         Matrix x;
 *         Integer k;
 *
 *  DESCRIPTION
 *      If X is a vector [x(1) x(2) ... x(n)], then diff(X) returns 
 *      a vector of differences between adjacent elements 
 *      [x(2)-x(1) x(3)-x(2) ... x(n)-x(n-1)].
 *
 *      If X is a matrix, 
 *
 *      diff_col(X) calculates the differences for each column:
 *      diff_col(X) = X(2:n,:) - X(1:n-1,:).
 *      diff_col(X,n) is the n'th difference function.
 *
 *      diff_row(X) calculates the differences for each row:
 *      diff_row(X) = X(:,2:n) - X(:,1:n-1).
 *      diff_row(X,n) is the n'th difference function.
 * 
 *      diff(X) works for all elements. The result matrix is the
 *      same size as the given matrix.
 */

Func Matrix diff(x, k, ...)
	Matrix x;
	Integer k;
{
	Matrix y;

	error(nargchk(1, 2, nargs, "diff"));
	
	if (nargs == 1) {
		if (Rows(x) == 1 || Cols(x) == 1) {
			return diff_col(x);
		} else {
			error("diff(): Vector is expected.\n");
		}
	} else {
		if (Rows(x) == 1 || Cols(x) == 1) {
			return diff_col(x, k);
		} else {
			error("diff(): Vector is expected.\n");
		}
	}
}

Func Matrix diff_col(x_, k, ...)
	Matrix x_;
	Integer k;
{
	Matrix x;
	Integer i,m,n;

	error(nargchk(1, 2, nargs, "diff_col"));

	x = x_;

	if (nargs == 1) {
		k = 1;
	}
	for (i = 1; i <= k; i++) {
		{m,n} = size(x);
		if (m == 1) {
			x = x(2:n) - x(1:n-1);
		} else {
			x = x(2:m,:) - x(1:m-1,:);
		}
	}
	return x;
}

Func Matrix diff_row(x, k, ...)
	Matrix x;
	Integer k;
{
	error(nargchk(1, 2, nargs, "diff_row"));
	
	if (nargs == 1) {
		return trans(diff_col(trans(x)));
	} else {
		return trans(diff_col(trans(x), k));
	}
}

