
/*  -*- MaTX -*-
 *
 *  NAME
 *      num2str() - Number to string conversion
 *
 *  SYNOPSIS
 *      t = num2str(x)
 *         String t;
 *         Real x;
 *
 *  DESCRIPTION
 *      num2str(X) converts the scalar number x into a string
 *      representation t with about 4 digits and an exponent if
 *      required.
 *
 *  SEE ALSO
 *      int2str(), sprintf() and fprintf().
 *
 */

Func String num2str(x)
	Real x;
{
	String t;

	t = sprintf("%.4g", x);
	return t;
}
