
/*  -*- MaTX -*-
 *
 *  NAME
 *      fsolve() - Solution to a system of nonlinear equations.
 *
 *  SYNOPSIS
 *      {xf, termcode, path} = fsolve(fvec,x0)
 *         Matrix xf;
 *         Integer termcode;
 *         Matrix path;
 *         Matrix fvec();
 *         Matrix x0;
 *
 *      {xf, termcode, path} = fsolve(fvec,x0,details)
 *         Matrix xf;
 *         Integer termcode;
 *         Matrix path;
 *         Matrix fvec();
 *         Matrix x0;
 *         Matrix details;
 *
 *      {xf, termcode, path} = fsolve(fvec,x0,details,fparam)
 *         Matrix xf;
 *         Integer termcode;
 *         Matrix path;
 *         Matrix fvec();
 *         Matrix x0;
 *         Matrix details;
 *         Matrix fparam;
 *
 *      {xf, termcode, path} = fsolve(fvec,x0,details,fparam,jac)
 *         Matrix xf;
 *         Integer termcode;
 *         Matrix path;
 *         Matrix fvec();
 *         Matrix x0;
 *         Matrix details;
 *         Matrix fparam;
 *         List jac();
 *
 *      {xf, termcode, path} = fsolve(fvec,x0,details,fparam,jac,scale)
 *         Matrix xf;
 *         Integer termcode;
 *         Matrix path;
 *         Matrix fvec();
 *         Matrix x0;
 *         Matrix details;
 *         Matrix fparam;
 *         List jac();
 *         Matrix scale;
 *
 *  DESCRIPTION
 *      fsolve(f,x0) starts at x0 and produces a new vector x which solves
 *      for f(x) = 0.  f() is the function to be solved, normally an mm-file.
 *      For example, to find the x, y, and z that solve the simultaneous 
 *      equations
 *
 *   	     sin(x) + y^2 + log(z) - 7 = 0
 *   	     3*x + 2^y - z^3 + 1 = 0
 *   	     x + y + z - 5 = 0
 *
 *      Use fsolve(xyz,[1 1 1]') where xyz is the function :
 *
 *        Func Matrix xyz(p)
 *             Matrix p;
 *        {
 *             Matrix q;
 *             Real x, y, z;
 *   
 *   	        x = p(1); y = p(2); z = p(3);
 *   	        q = Z(3,1);
 *   	        q(1) = sin(x) + y^2 + log(z) - 7;
 *   	        q(2) = 3*x + 2^y - z^3 + 1;
 *   	        q(3) = x + y + z - 5;
 *             return q;
 *         }
 *
 *      fsolve() can take many other optional parameters.
 *
 *  xf       : The final approximation of the solution.
 *  termcode : Indicates the stopping reason (1 for normal termination).
 *  path     : Sequence of iterates.
 *
 *  fvec     : Name of a function which maps n-vectors into n-vectors.
 *  x0       : An initial guess of a solution (starting point for iterations).
 *  details  : A vector whose elements select various algorithmic
 *             options and specify various tolerances.
 *  fparam   : A set of parameters (constants) which, if nonempty,
 *             is passed on as a second argument to fvec() and JAC().
 *  jac      : The name of a function which implements the jacobian
 *             matrix (if available) of the function named in fvec().
 *  scale    : Typical values of X (1st column) and F (2nd col.)
 *             for scaling purposes (no zeros in SCALE).
 */

Func List fsolve(fvec,x0,details,fparam,jac,scale, ...)
	Matrix fvec();
	Matrix x0;
	Matrix details;
	Matrix fparam;
	List jac();
	Matrix scale;
{
	Integer termcode,maxtaken;
	Integer i,consecmax,itncount,nofun,norest,restart,retcode,tmp;
	Matrix path,xf,xplus,xc;
	Matrix F,FVc,FVplus,Jc,btrack,gc,Sx,SF,Hc,M,sN;
	Real fc,fplus;

	Matrix nebroyuf(); 
	List nefdjac(),nefn(...),neinck(),nelnsrch(),nemodel(),nestop();

	error(nargchk(2, 6, nargs, "fsolve"));

	// Initialization.
	if (nargs < 3) {
		details = Z(16,1);
	}

	i = length(details);
	if (i < 16) {
		details((i+1):16) = Z(16-i,1);  // For unspecified details.
	}
	if (nargs < 4) {
		details(15) = 0.0;              // No parameters to pass.
	} else if (isempty(fparam)) {
		details(15) = 0.0;
	} else {
		details(15) = 1.0;
	}
	if (details(15) == 0.0) {
		fparam = [];
	}
	if (nargs < 5) {
		details(4) = 0.0;               // No analytic jacobian.
	} else if (isempty(jac)) {
		details(4) = 0.0;
	}
	if (nargs < 6) {
		scale = [];                    // No scaling given.
		if (details(16) == 2.0) {
			details(16) = 1.0;
		}
	}
	details(14) = 1.0;

	if (details(14)) {
		path = x0#;
	}
	if (details(1) == 2.0) {
		btrack = [];
	}
	nofun = 0;		// Number of function evaluations.

	// Algorithm step 2.
	if (details(16) > 0.0) {     // Might need F(x0) for scaling.
		if (details(15)) {
			{fc,FVplus,nofun} = nefn(x0,ONE(length(x0),1),fvec,nofun,fparam);
		} else {
			{fc,FVplus,nofun} = nefn(x0,ONE(length(x0),1),fvec,nofun);
		}
	} else {
		FVplus = Z(length(x0),1);
	}
	{details,Sx,SF,termcode} = neinck(x0,FVplus,details,scale);

	// Algorithm step 3.
	if (termcode < 0) {
		xf = x0;
		if (details(14)) {
			path = [[path][xf#]];
		}
		return {xf,termcode,path};
	}

	// Algorithm step 4.
	itncount = 0;

	// Algorithm step 5.
	if (details(15)) {
		{fc,FVplus,nofun} = nefn(x0,SF,fvec,nofun,fparam);
	} else {
		{fc,FVplus,nofun} = nefn(x0,SF,fvec,nofun);
	}

	// Algorithm step 6.
	// {termcode,consecmax} = nestop0(x0,FVplus,SF,details(8));
	consecmax = 0;
	if ((max(Array(SF) .* abs(Array(FVplus))) <= 1E-2 * details(8))) {
		termcode = 1;
	} else {
		termcode = 0;
	}

	// Algorithm step 7.
	if (termcode > 0) {
		xf = x0;
		if (details(14)) {
			path = [[path][xf#]];
		}
	} else {
		if (details(4)) {
			if (details(15)) {
				{Jc,tmp} = jac(x0,fparam);
			} else {
				{Jc,tmp} = jac(x0);
			}           
			nofun = tmp + nofun;
		} else {
			{Jc,nofun} = nefdjac(fvec,FVplus,x0,Sx,details,nofun,fparam);
		}
		gc = Jc# * (FVplus .* (SF.^2));
		FVc = FVplus;
	}

	// Algorithm step 8.
	xc = x0;

	// Algorithm step 9.
	restart = 1;
	norest = 0;

	// Algorithm step 10 (iteration).
	if (details(1) > 0.0) {
		clear;
	}

	while (termcode == 0) {
		itncount = itncount + 1;
		if (details(4) || details(3) || (1-Integer(details(5)))) {
			{M,Hc,sN} = nemodel(FVc,Jc,gc,SF,Sx,Integer(details(2)));
		} else {
			error("fsolve(): Factored model not implemented.\n");
			// nemodfac();
		}
		if (details(2) == 1.0) {
			{retcode,xplus,fplus,FVplus,maxtaken,nofun,btrack} =
				nelnsrch(xc,fc,fvec,gc,sN,Sx,SF,details,nofun,btrack,fparam);
		} else if (details(2) == 2.0) {
			error("fsolve(): Hookstep not implemented.\n");
			// nehookst();
		} else {
			error("fsolve(): Dogleg not implemented.\n");
			// nedogdrv();
		}

		if ((retcode != 1 || restart ||
			 Integer(details(4)) || Integer(details(3)))) {
			if (details(4)) {
				if (details(15)) {
					{Jc,tmp} = jac(xplus,fparam);
				} else {
					{Jc,tmp} = jac(xplus);
				}
				nofun = tmp + nofun;
			} else if (details(3)) {
				{Jc,nofun} = nefdjac(fvec,FVplus,xplus,Sx,
									 details,nofun,fparam);
			} else if (details(5)) {
				error("fsolve(): Factored secant method not implemented.\n");
				// nebroyf();
			} else {
				// Broyden update
				Jc = nebroyuf(Jc,xc,xplus,FVc,FVplus,Sx,details(13));
			}
			if (details(5)) {
				error("fsolve(): Gradient calculation for factored method not implemented.\n");
				// Calculate gc using QR factorization (see book).
			} else {
				gc = Jc# * (FVplus .* (SF.^2));
			}

			{consecmax,termcode} =
				nestop(xc,xplus,FVplus,fplus,gc,Sx,SF,retcode,details,
					   itncount,maxtaken,consecmax);
		}

		if (((retcode == 1 || termcode == 2) &&
			 (1-restart) && Integer(1-details(4)) &&
			 Integer(1-details(3)))) {

			{Jc,nofun} = nefdjac(fvec,FVc,xc,Sx,details,nofun,fparam);
			gc = Jc# * (FVc .* (SF.^2));

			if (details(2) == 2.0 || details(2) == 3.0) {
				details(7) = -1.0;
			}
			restart = 1;
			norest = norest + 1;
		} else {
			if (termcode > 0) {
				xf = xplus;
				if (details(14)) {
					path = [[path][xf#]];
				}
			} else {
				restart = 0;
				if (details(14)) {
					path = [[path][xplus#]];
				}
			}
			xc = xplus;
			fc = fplus;
			FVc = FVplus;
			if (details(1) > 0.0) {
				print "The current iteration is: n", xc;
			}
		}
	}
	
	if (details(1) == 2.0) {
		pause "Press CR to see statistics . . .\n";
		
		clear;
		print "\n";
		print "Starting point: \n";
		print x0#;
		print "\n";
		printf("Termination condition: %d\n", termcode);
		printf("Number of iterations: %d\n", itncount);
		printf("Total number of function evaluations: %d\n", nofun);
		printf("Final norm(F(x)): %g\n", norm(FVc));
		if ((1-details(3)) && (1-details(4))) {
			printf("Number of restarts for secant methods: %d\n", norest);
		}
		print "Backtrack information: \n";
		print btrack;
		pause;
	}

	return {xf,termcode,path};
}


/*  -*- MaTX -*-
 *
 *  NAME
 *      nestop() - Part of the Nonlinear Equations package
 *
 *  SYNOPSIS
 *      {consecmax,termcode} = nestop(xc,xp,F,Fnorm,g,sx,sf,retcode,
 *                                     details,itncount,maxtaken,consecmax)
 *         Integer consecmax, termmode;
 *         Matrix xc,xp,F;
 *         Real Fnorm;
 *         Matrix g,sx,sf;
 *         Integer retcode;
 *         Matrix details;
 *         Integer itncount,maxtaken, consecmax;
 *
 *  DESCRIPTION
 *      It decides whether or not to stop iterating when solving a set of
 *      nonlinear equations.
 *
 *      Algorithm A7.2.3:  Part of the modular software system from the
 *      appendix of the book "Numerical Methods for Unconstrained 
 *      Optimization and Nonlinear Equations" by Dennis & Schnabel, 1983.
 *
 */

Func List nestop(xc,xp,F,Fnorm,g,sx,sf,retcode,details,
				 itncount,maxtaken,consecmax)
	Matrix xc,xp,F;
	Real Fnorm;
	Matrix g,sx,sf;
	Integer retcode;
	Matrix details;
	Integer itncount,maxtaken,consecmax;
{
	Integer termcode;
	Integer n;

	// Algorithm step 1.
	n = length(xc);
	termcode = 0;
	
	// Algorithm step 2.
	if (retcode == 1) {
		termcode = 3;
	} else if (max(Array(sf) .* abs(Array(F))) <= details(8)) {
		termcode = 1;
	} else if (max(abs(Array(xp - xc)) ./
				   max(abs(Array(xp)),Array(ONE(n,1)./sx)))
				   <= details(9)) {
		termcode = 2;
	} else if (itncount >= Integer(details(6))) {
		termcode = 4;
	} else if (maxtaken) {
		consecmax = consecmax + 1;
		if (consecmax == 5) {
			termcode = 5;
		}
	} else {
		consecmax = 0;
		if (details(4) || details(3)) {
			if (max(abs(Array(g)) .* max(abs(Array(xp)), Array(ONE(n,1)./sx))/max(Fnorm,(n/2.0))) <= details(10)) {
				termcode = 6;
			}
		}
	}
   return {consecmax,termcode};
}


/*  -*- MaTX -*-
 *
 *  NAME
 *      nefdjac() - Part of the Nonlinear Equations package
 *
 *  SYNOPSIS
 *      {J,nofun} = nefdjac(fvec,fc,xc,sx,details,nofun,fparam)
 *        Matrix J;
 *        Integer nofun;
 *        Matrix fvec();
 *        Matrix fc,xc.sx,details
 *        Integer nofun;
 *        Matrix fparam;
 *
 *  DESCRIPTION
 *      This is a "Finite Difference Jacobian Approximation". It
 *      calculates a finite difference appproximation to J(xc)
 *      (the Jacobian of F(x) at x = xc).
 *
 *      Algorithm A5.4.1: Part of the modular software system from
 *      the appendix of the book "Numerical Methods for Unconstrained
 *      Optimization and Nonlinear Equations" by Dennis & Schnabel 1983.
 */

Func List nefdjac(fvec,fc,xc,sx,details,nofun,fparam)
	Matrix fvec();
	Matrix fc,xc,sx;
	Matrix details;
	Integer nofun;
	Matrix fparam;
{
	Integer j,n;
	Real stepsizej,tempj,sqrteta;
	Matrix J,fj;

	// Algorithm step 1.
	n = length(fc);
	sqrteta = sqrt(details(13));

	// Algorithm step 2.
	J = Z(n,n);
	for (j = 1; j <= n; j++) {
		stepsizej = sqrteta*max(abs(xc(j)),1/sx(j))*(sgn(xc(j))+(xc(j) == 0.0));

		// To incorporate a different stepsize rule, change the previous line.
		tempj = xc(j);
		xc(j) = xc(j) + stepsizej;
		stepsizej = xc(j)-tempj;

		// The previous line reduces finite precision error slightly,
		// see section 5.4 of the book.
		if (details(15)) {
			fj = fvec(xc,fparam);       // Evaluate function w/parameters.
		} else {
			fj = fvec(xc);              // Evaluate function w/o parameters.
		}
		nofun = nofun + 1;
		J(1:n,j) = (fj(1:n) - fc(1:n))/stepsizej;
		xc(j) = tempj;
	}
	return {J,nofun};
}


/*  -*- MaTX -*-
 *
 *  NAME
 *      neinck() - Part of the Nonlinear Equations package
 *
 *  SYNOPSIS
 *      {dout,Sx,SF,termcode} = neinck(x0,din,scale);
 *          Matrix dout;
 *          Matrix SF,Sx;
 *          Integer termcode;
 *          Matrix x0,F0;
 *          Matrix din;
 *          Matrix scale;
 *
 *  DESCRIPTION
 *      It checks the input arguments and sets various tolerances and limits.
 *
 *      Part of the modular software system from the appendix of the 
 *      book "Numerical Methods for Unconstrained Optimization and 
 *      Nonlinear Equations" by Dennis & Schnabel, 1983.
 */

Func List neinck(x0,F0,din,scale)
	Matrix x0;
	Matrix F0;
	Matrix din;
	Matrix scale;
{
	Integer l,m,n,termcode;
	Matrix SF,Sx,dout;

	termcode = 0;
	dout = din;

	// Step 1.
	n = length(x0);
	if (n < 1) {
		termcode = -1;
		return {dout,[],[],termcode};
	}

	// Steps 2 && 3.
	{l,m} = size(scale);
	if (dout(16) == 2.0) {
		if (l == n && m == 2) {
			Sx = 1 / abs(Array(scale(:,1)));
			SF = 1 / abs(Array(scale(:,2)));
		} else {
			dout(16) = 1;
		}
	}
	if (dout(16) == 0.0) {
		Sx = ONE(n,1);
		SF = ONE(n,1);
	}
	if (dout(16) == 1.0) {
		if (any(x0 .== 0.0)) {
			x0(find(x0 .== 0.0)) = ONE(Integer(sum(x0 .== 0)),1);
		}
		if ((any(F0 .== 0.0))) {
			F0(find(F0 .== 0.0)) = ONE(Integer(sum(F0 .== 0)),1);
		}
		Sx = 1 / abs(Array(x0));
		SF = 1 / abs(Array(F0));
	}

	// Step 4.
	if (dout(12) <= 0.0) {
		dout(13) = EPS;
	} else {
		dout(13) = max(EPS,10^(-dout(12)));
	}
	if (dout(13) > 0.01) {
		termcode = -2;
		return {dout,Sx,SF,termcode};
	}

	// Step 5.
	if (dout(2) <= 0.0) {
		dout(2) = 1;    // Default to linesearch.
	}
	if ((dout(2) == 2.0 || dout(2) == 3.0) && dout(7) <= 0.0) {
		dout(7) = -1;
	}

	// Step 6.
	if (dout(6) <= 1.0) {
		dout(6) = 100;  // Default to 100 iteration limit.
	}
	if (dout(8) <= 0.0) {
		dout(8) = EPS ^ (1/3.0);        // fvectol.
	}
	if (dout(9) <= 0.0) {
		dout(9) = EPS ^ (2/3.0);        // steptol.
	}
	if (dout(10) <= 0.0) {
		dout(10) = EPS ^ (2/3.0);       // mintol.
	}
	if (dout(11) <= 0.0) {
		dout(11) = 1000 * max(norm(Sx .* x0),norm(vec2diag(Sx)));   // maxstep.
	}
	return {dout,Sx,SF,termcode};
}

/* -*- MaTX -*-
 *
 *  NAME
 *      nebroyuf() - Part of the Nonlinear Equations package
 *
 *  SYNOPSIS
 *      A = nebroyuf(A,xc,xp,fc,fp,sx,eta)
 *         Matrix A;
 *         Matrix xc,cp,fc,fp,sx;
 *         Real eta;
 *
 *  DESCRIPTION
 *      This updates A, a secant approximation to the jacobian, using
 *      broyden's unfactored secant update.
 *
 *      Algorithm A8.3.1:  Part of the modular software system from
 *      the appendix of the book "Numerical Methods for Unconstrained
 *      Optimization and Nonlinear Equations" by Dennis & Schnabel 1983.
 */

Func Matrix nebroyuf(A_,xc,xp,fc,fp,sx,eta)
	Matrix A_,xc,xp;
	Matrix fc,fp,sx;
	Real eta;
{
	Integer n;
	Real denom;
	Matrix A,tempi,s;
	Index ii;

	A = A_;

	// Algorithm step 1.
	n = Rows(A);
	s = xp - xc;

	// Algorithm step 2.
	denom = norm(sx.*s)^2;

	// Algorithm step 3.
	tempi = (fp - fc - A*s);

	ii = find(abs(Array(tempi)) < eta*(abs(Array(fp)) + abs(Array(fc))));
	
	if (length(ii)) {
		tempi(ii) = Z(length(ii),1);
	}
	A = A + tempi*(s .* (sx .* sx))# / denom;

	return A;
}

/*  -*- MaTX -*-
 *
 *  NAME
 *      nelnsrch() - Part of the Nonlinear Equations package
 *
 *  SYNOPSIS
 *      {retcode,xp,fp,Fp,maxtaken,nofun,btrack} =
 *                  nelnsrch(xc,fc,fn,g,p,sx,details,nofun,btrack,fparam);
 *         Integer retcode;
 *         Matrix xp;
 *         Real fp;
 *         Matrix Fp;
 *         Integer maxtaken,nofun;
 *         Matrix btrack;
 *
 *         Matrix xc;
 *         Real fc;
 *         Matrix fn(),g,p,sx,sf,details;
 *         Integer nofun;
 *         Matrix btrack,fparam;
 *
 *  DESCRIPTION
 *      It is a line search for use with Newton's Method of solving nonlinear
 *      equations.
 *
 *      Algorithm A6.3.1:  Part of the modular software system from the
 *      appendix of the book "Numerical Methods for Unconstrained Optimization
 *      and Nonlinear Equations" by Dennis & Schnabel, 1983.
 *
 */

Func List nelnsrch(xc,fc,fn,g,p,sx,sf,details,nofun,btrack,fparam)
	Matrix xc;
	Real fc;
	Matrix fn();
	Matrix g,p,sx;
	Matrix sf,details;
	Integer nofun;
	Matrix btrack;
	Matrix fparam;
{
	Integer maxtaken,retcode;
	Matrix xp, Fp;
	Integer bt,n;
	Real disc,minlambda,newtlen,alpha,rellength,fp,initslope,lambda;
	Real lambdatemp,lambdaprev,fpprev;
	Matrix a;

	List nefn(...);

	// Initialize some output variables.
	n = length(xc);
	xp = Z(n,1);
	fp = 0;

	// Algorithm step 1.
	maxtaken = 0;

	// Algorithm step 2.
	retcode = 2;

	// Algorithm step 3.
	alpha = 1E-4;

	// Algorithm step 4.
	newtlen = norm(sx .* p);

	// Algorithm step 5.
	if (newtlen > details(11)) {
		p = p * (details(11) / newtlen);
		newtlen = details(11);
	}

	// Algorithm step 6.
	initslope = [g#*p](1);

	// Algorithm step 7.
	rellength = max(abs(Array(p))./max(abs(Array(xc)),
									   (Array(ONE(n,1))./Array(sx))));

	//Algorithm step 8.
	minlambda = details(9)/rellength;

	// Algorithm step 9.
	lambda = 1.0;
	lambdaprev = 0.0;
	fpprev = 0.0;

	// Algorithm step 10.
	bt = 0;
	while (retcode >= 2) {
		xp = xc + lambda*p;                      // step 10.1
		if (details(15)) {
			{fp,Fp,nofun} = nefn(xp,sf,fn,nofun,fparam);    // step 10.2
		} else {
			{fp,Fp,nofun} = nefn(xp,sf,fn,nofun);
		}
		if (fp <= fc + alpha*lambda*initslope) {   // step 10.3a
			retcode = 0;
			maxtaken = ((lambda == 1.0) && (newtlen > 0.99*details(11)));
		} else if (lambda < minlambda) {              // step 10.3b
			retcode = 1;
			xp = xc;
		} else {                                     // step 10.3c
			if (lambda == 1.0) {
				if (details(1) > 0.0) {
					print "Quadratic Backtrack.\n";
				}
				bt = bt + 1;
				lambdatemp = -initslope / (2*(fp-fc-initslope));
			} else {
				if (details(1) > 0.0) {
					print "Cubic Backtrack.\n";
				}
				bt = bt + 1;

				a = (1/(lambda - lambdaprev)) *
					[[             1/lambda^2,       (-1/lambdaprev^2)]
					 [(-lambdaprev/(lambda^2)),  lambda/(lambdaprev^2)]] *
					 [[    (fp-fc-lambda*initslope)    ]
					  [(fpprev-fc-lambdaprev*initslope)]];

				disc = a(2)^2 - 3*a(1)*initslope;

				if (a(1) == 0.0) {
					lambdatemp = -initslope/(2*a(2));
				} else {
					lambdatemp = (-a(2)+sqrt(disc))/(3*a(1));
				}
				if (lambdatemp > 0.5*lambda) {
					lambdatemp = 0.5*lambda;
				}
			}
			lambdaprev = lambda;
			fpprev = fp;
			if (lambdatemp <= 0.1*lambda) {
				lambda = 0.1*lambda;
			} else {
				lambda = lambdatemp;
			}
		}
	}
	if (bt < length(btrack)) {
		btrack(bt+1) = btrack(bt+1) + 1;
	} else {
		btrack = [btrack, Z(1,bt-length(btrack)+1)];
		btrack(bt+1) = 1;
	}
	return {retcode,xp,fp,Fp,maxtaken,nofun,btrack };
}


/*  -*- MaTX -*-
 *
 *  NAME
 *      nefn() - Part of the Nonlinear Equations package
 *
 *  SYNOPSIS
 *       {fplus,FVplus} = nefn(xplus,SF,fvec)
 *           Real fplus;
 *           Matrix FVplus;
 *           Matrix xplus;
 *           Matrix SF;
 *           Matrix fvec();
 *           Integer nofun;
 *           Matrix fparam;
 *
 *  DESCRIPTION
 *      It evaluates the vector function and calculates the sum of squares
 *      for nonlinear equations.
 *
 *      Part of the modular software system from the appendix of the book
 *      "Numerical Methods for Unconstrained Optimization and Nonlinear
 *      Equations" by Dennis & Schnabel, 1983.
 *
 */

Func List nefn(xplus,SF,fvec,nofun,fparam, ...)
	Matrix xplus;
	Matrix SF;
	Matrix fvec();
	Integer nofun;
	Matrix fparam;
{
	Real fplus;
	Matrix FVplus;

	error(nargchk(4, 5, nargs, "nefn"));

	if (nargs < 5) {
		FVplus = fvec(xplus);
	} else {
		FVplus = fvec(xplus,fparam);
	}
	fplus = 0.5 * sum((SF .* FVplus).^2);
	nofun = nofun + 1;

	return {fplus,FVplus,nofun};
}


/*  -*- MaTX -*-
 *
 *  NAME
 *      nemodel() - part of the Nonlinear Equations package
 *
 *  SYNOPSIS
 *      {m,h,sn} = nemodel(fc,J,g,sf,sx,globmeth);
 *          Matrix m,h,sn;
 *          Matrix fc,J,g,sf,sx;
 *          Integer globmeth;
 * 
 *  DESCRIPTION
 *      It forms the affine model for use in solving nonlinear equations.
 *
 *      Algorithm A6.5.1: Part of the modular software system from
 *      the appendix of the book "Numerical Methods for Unconstrained
 *      Optimization and Nonlinear Equations" by Dennis & Schnabel 1983.
 */

Func List nemodel(fc,J,g,sf,sx,globmeth)
	Matrix fc,J,g,sf,sx;
	Integer globmeth;
{
	Matrix h,m,m1,m2,sn;
	Integer i,j,n,sing_;
	Real est,tem1,tem2,maxadd,tem,hnorm,temp;

	Real neconest();
	List neqrdcmp(), nechdcmp();
	Matrix neqrsolv();

	// Algorithm step 1.
	n = Rows(J);
	m = vec2diag(sf)*J;

	// Algorithm step 2.
	{m,m1,m2,sing_} = neqrdcmp(m);

	// Algorithm step 3.
	if (sing_ == 0) {
		for (j = 2; j <= n; j++) {
			m(1:(j-1),j) = m(1:(j-1),j)/sx(j);
		}
		m2 = m2./sx;
		est = neconest(m,m2);
	} else {
		est = 0.;
	}

	// Algorithm step 4.
	if (sing_ == 1 || est > 1./EPS) {
		h = J# * vec2diag(sf);
		h = h*h#;
		// calculate hnorm = norm(invDxHinvDx)
		tem = [abs(Array(h(1,:))) * (Array(ONE(n,1)) ./ Array(sx))](1);
		hnorm = (1.0/sx(1))*tem;
		for (i = 2; i <= n; i++) {
			tem1 = sum(abs(Array(h(:,i))) ./ Array(sx));
			tem2 = sum(abs(Array(h(i,:))) ./ Array(sx#));
			temp = (1 / sx(i))/(tem1+tem2);
			hnorm = max(temp,hnorm);
		}
		h = h + sqrt(n*EPS) * hnorm * (vec2diag(sx)^2);
		// caculate sn = (H)~*g
		{m,maxadd} = nechdcmp(h, 0.0);
		// Changed to use inline MaTX code
		// sn = nechsolv(g,m);
		sn = -m# \ (m \ g);
	} else { 
		// Calculate normal Newton step
		for (j = 2; j <= n; j++) {
			m(1:(j-1),j) = m(1:(j-1),j)*sx(j);
		}
		m2 = m2 .* sx;
		sn = -sf .* fc;
		sn = neqrsolv(m,m1,m2,sn);
		if (globmeth == 2 || globmeth == 3) {
			// lower triangle of M = R#
			m = triu(m) + triu(m)#;
			m = m - vec2diag(diag2vec(m)) + vec2diag(m2);
		}

		if (globmeth == 2) {
			// H = LL#
			for (i = 1; i <= n; i++) {
				for (j = i; j <= n; j++) {
					h(i,j) = sum(m(i,1:i).*m(j,1:i));
				}
			}
		}
	}

	return {m,h,sn};
}


/*  -*- MaTX -*-
 *
 *  NAME
 *      nechdcmp() - Part of the Nonlinear Equations package
 *
 *  SYNOPSIS
 *      {L,maxadd} = nechdcmp(H,maxoffl)
 *          Matrix L;
 *          Real maxadd;
 *          Matrix H;
 *          Real maxoffl;
 *
 *  DESCRIPTION
 *      This is a "Perturbed Cholesky Decomposition".  It finds a lower
 *      triangular matrix L such that L L# is a factorization of H+D, where
 *      D is a diagonal (non-negative) matrix that is added to H if necessary
 *      to make it positive definite (so that the factorization is possible).
 *      If H is already positive definite, the ordinary Cholesky decomposition
 *      (D = 0) is carried out.
 *
 *      Algorithm A5.5.2: Part of the modular software system from
 *      the appendix of the book "Numerical Methods for Unconstrained
 *      Optimization and Nonlinear Equations" by Dennis && Schnabel 1983.
 */

Func List nechdcmp(H,maxoffl)
	Matrix H;
	Real maxoffl;
{
	Integer i,j,m,n;
	Real maxadd,minljj,minl,minl2;
	Matrix L;

	// Check input arguments.
	{m,n} = size(H);
	if (m != n) {
		error("nechdcmp(): Matrix H must be square.\n");
	}

	// Algorithm step 1.
	minl = (EPS^0.25) * maxoffl;

	// Algorithm step 2.
	if (maxoffl == 0.0) {
		// This is the case when H is known to be positive def.
		maxoffl = sqrt(max(diag2vec(H)));
		minl2 = (EPS ^ 0.5) * maxoffl;
	}

	// Algorithm step 3.
	maxadd = 0.0;      // the maximum diagonal element (so far) in D.

	// Algorithm step 4.
	L = [];
	for (j = 1; j <= n; j++) {
		if (j == 1) { 
			L(j,j) = H(j,j);
		} else {
			L(j,j) = H(j,j) - [L(j,1:j-1)*L(j,1:j-1)#](1);
		}
		minljj = 0.;
		for (i = j+1; i <= n; i++) {
			if (j == 1) {
				L(i,j) = H(j,i);
			} else {
				L(i,j) = H(j,i) - [L(i,1:j-1)*L(j,1:j-1)#](1);
			}
			minljj = max(abs(L(i,j)),minljj);
		}
		minljj = max(minljj/maxoffl,minl);
		if (L(j,j) > minljj^2) {
			// Normal Cholesky iteration
			L(j,j) = sqrt(L(j,j));
		} else {
			// Augment H(j,j)
			if (minljj < minl2) {
				minljj = minl2;
				// Only possible when input maxoffl = 0
			}
			maxadd = max(maxadd,(minljj^2-L(j,j)));
			L(j,j) = minljj;
		}
		for (i = j+1; i <= n; i++) {
			L(i,j) = L(i,j)/L(j,j);
		}
		// L(j+1:n,j) = L(j+1:n,j)/L(j,j);
	}

	return {L,maxadd};
}


/*  -*- MaTX -*-
 *
 *  NAME
 *      neqrdcmp() - Part of the Nonlinear Equations package
 *
 *  SYNOPSIS
 *      {M,M1,M2,sing_} = neqrdcmp(M);
 *          Matrix M,M1,M2;
 *          Integer sing_;
 *
 *  DESCRIPTION
 *      It is a QR decomposition function.  It differs from the one built
 *      into MaTX in that the result is encoded as rotation angles.  Also,
 *      it is designed for square matrices only.
 *
 *      Algorithm A3.2.1:  Part of the modular software system from the
 *      appendix of the book "Numerical Methods for Unconstrained Optimization
 *      and Nonlinear Equations" by Dennis && Schnabel, 1983.
 *
 */

Func List neqrdcmp(M_)
	Matrix M_;
{
	Integer sing_,k,n;
	Real eta, sigma_;
	Matrix M,M1,M2,tau;

	M = M_;

	// Check size of input argument and allocate variables.
	n = Rows(M);
	M1 = Z(n,1);
	M2 = Z(n,1);

	// Algorithm step 1.
	sing_ = 0;

	// Algorithm step 2.
	for (k = 1; k <= n-1; k++) {
		eta = max(M(k:n,k));
		if (eta == 0.0) {
			M1(k) = 0;
			M2(k) = 0;
			sing_ = 1;
		} else {
			M(k:n,k) = M(k:n,k) / eta;
			sigma_ = (sgn(M(k,k)) + (M(k,k) == 0.0)) * norm(M(k:n,k));
			M(k,k) = M(k,k) + sigma_;
			M1(k) = sigma_ * M(k,k);
			M2(k) = -eta * sigma_;
			tau = (M(k:n,k)# * M(k:n,(k+1):n)) / M1(k);
			M(k:n,(k+1):n) = M(k:n,(k+1):n) - M(k:n,k) * tau;
		}
	}

	// Algorithm step 3.
	M2(n) = M(n,n);
	return {M,M1,M2,sing_};
}


/*  -*- MaTX -*-
 *
 *  NAME
 *      neconest() - Part of the Nonlinear Equations package
 *
 *  SYNOPSIS
 *      est = neconest(M,M2)
 *         Real est;
 *         Matrix M,M2;
 *
 *  DESCRIPTION
 *      This is an estimate of the l-1 condition number of an upper triangular
 *      matrix.
 *
 *      Algorithm A3.3.1:  Part of the modular software system from the
 *      appendix of the book "Numerical Methods for Unconstrained Optimization
 *      and Nonlinear Equations" by Dennis & Schnabel, 1983.
 */

Func Real neconest(M,M2)
	Matrix M,M2;
{
	Integer i,j,n;
	Matrix p,pm,x;
	Real est;
	Real xp,xm,temp,tempm;

	Matrix nersolv();

	// Allocate variables
	n = Rows(M);

	p = Z(n,1);
	pm = Z(n,1);
	x = Z(n,1);

	// Algorithm steps 1 & 2
	est = norm(triu(M) - vec2diag(diag2vec(M)) + vec2diag(M2) ,1);

	// Algorithm step 3
	x(1) = 1/M2(1);

	// Algorithm step 4
	if (2 <= n) {
		p(2:n) = M(1,2:n) * x(1);
	}

	// Algorithm step 5
	for (j = 2; j <= n; j++) {
		xp = ( 1-p(j)) / M2(j);
		xm = (-1-p(j)) / M2(j);
		temp  = abs(xp);
		tempm = abs(xm);
		for (i = j+1; i <= n; i++) {
			pm(i) = p(i) + M(j,i)*xm;
			tempm = tempm + abs(p(i))/abs(M2(i));
			p(i) = p(i) + M(j,i) * xp;
			temp = temp + abs(p(i))/abs(M2(i));
		}
		if ((temp > tempm)) {
			x(j) = xp;
		} else {
			x(j) = xm;
			p((j+1):n) = pm((j+1):n);
		}
	}

	// Algorithm steps 6 & 7
	est = est / norm(x,1);

	// Algorithm step 8
	x = nersolv(M,M2,x);

	// Algorithm steps 9 & 10
	est = est * norm(x,1);
	return est;
}


/*  -*- MaTX -*-
 *
 *  NAME
 *      neqrsolv() - Part of the Nonlinear Equations package
 *
 *  SYNOPSIS
 *      b = neqrsolv(M,M1,M2,b)
 *         Matrix b;
 *         Matrix M,M1,M2;
 *
 *  DESCRIPTION
 *      It is a linear equation solve function using the QR decomposition.
 *
 *      Algorithm A3.2.2:  Part of the modular software system from the
 *      appendix of the book "Numerical Methods for Unconstrained Optimization
 *      and Nonlinear Equations" by Dennis & Schnabel, 1983.
 */

Func Matrix neqrsolv(M,M1,M2,b_)
	Matrix M,M1,M2,b_;
{
	Integer j,n;
	Real tau;
	Matrix b;

	Matrix nersolv();

	b = b_;

	// Algorithm step 1.
	n = Rows(M);

	for (j = 1; j <= (n-1); j++) {
		tau = [(M(j:n,j)# * b(j:n)) / M1(j)](1);
		b(j:n) = b(j:n) - tau * M(j:n,j);
	}
	
	// Algorithm step 2.
	b = nersolv(M,M2,b);
	return b;
}


/*  -*- MaTX -*-
 *
 *  NAME
 *      nersolv() - Part of the Nonlinear Equations package
 *
 *  SYNOPSIS
 *      b = nersolv(M,M2,b)
 *         Matrix b;
 *         Matrix M,M2;
 *
 *  DESCRIPTION
 *      It is a linear equation solve function for upper triangular systems.
 *
 *      Algorithm A3.2.2a:  Part of the modular software system from the
 *      appendix of the book "Numerical Methods for Unconstrained Optimization
 *      and Nonlinear Equations" by Dennis & Schnabel, 1983.
 *
 */

Func Matrix nersolv(M, M2, b_)
	Matrix M, M2, b_;
{
	Matrix b;
	Integer i,n;

	b = b_;

	// Algorithm step 1.
	n = Rows(M);
	b(n) = b(n) / M2(n);

	// Algorithm step 2.
	for (i = n-1; i >= 1; i--) {
		b(i) = (b(i) - [M(i,(i+1):n) * b((i+1):n)](1)) / M2(i);
	}
	return b;
}
