
/*  -*- MaTX -*-
 *
 *  NAME
 *      unwrap()     - Correct phase angles for all elements
 *      unwrap_col() - Correct phase angles for each columun
 *      unwrap_row() - Correct phase angles for each row
 *
 *  SYNOPSIS
 *      pfix = unwrap(praw)
 *         Array pfix;
 *         Array praw;
 *
 *      pfix = unwrap(praw, tol)
 *         Array pfix;
 *         Array praw;
 *         Real tol;
 *
 *      pfix = unwrap_col(praw)
 *         Array pfix;
 *         Array praw;
 *
 *      pfix = unwrap_col(praw, tol)
 *         Array pfix;
 *         Array praw;
 *         Real tol;
 *
 *      pfix = unwrap_row(praw)
 *         Array pfix;
 *         Array praw;
 *
 *      pfix = unwrap_row(praw, tol)
 *         Array pfix;
 *         Array praw;
 *         Real tol;
 *
 *  DESCRIPTION
 *      unwrap(X) attempts to unwrap phase angles by adding +-2*Pi to
 *      them so that instead of jumping from -Pi to Pi, they will have
 *      a smooth transition across the branch cuts.
 *      The phase must be in radians. The tolerance  tol  is used
 *      to check the gap between each phase.
 *
 *      When X is a matrix,
 *
 *      unwrap_col(X) corrects the phase angles down each column. 
 *
 *      unwrap_row(X) corrects the phase angles down each row. 
 *
 *      unwrap(X) works for all elements. The result matrix is 
 *      the same size as the given matrix.
 *
 *  SEE ALSO
 *      angle() and abs().
 */

Func Array unwrap(praw, tol, ...)
	Array praw;
	Real tol;
{
	Array x;
	Integer m, n;

	error(nargchk(1, 2, nargs, "unwrap"));

	m = Rows(praw);
	n = Cols(praw);
	
	if (nargs == 1) {
		if (m == 1 || n == 1) {
			return unwrap_col(praw);
		} else {
			x = unwrap_col(reshape(praw, m*n, 1));
			return reshape(x, m, n);
		}
	} else {
		if (m == 1 || n == 1) {
			return unwrap_col(praw, tol);
		} else {
			x = unwrap_col(reshape(praw, m*n, 1), tol);
			return reshape(x, m, n);
		}
	}
}

Func Array unwrap_row(praw, tol, ...)
	Array praw;
	Real tol;
{
	error(nargchk(1, 2, nargs, "unwrap_row"));

	if (nargs == 1) {
		return trans(unwrap_col(trans(praw)));
	} else {
		return trans(unwrap_col(trans(praw), tol));

	}
}

Func Array unwrap_col(praw_, tol, ...)
	Array praw_;
	Real tol;
{
	Array praw,pfix,p,pd;
	Integer i,j,k,m,mo,no,n;
	Real closetopi;
	Index ijump;

	error(nargchk(1, 2, nargs, "unwrap_col"));
	
	praw = praw_;

	{m,n} = size(praw);
	mo = m;
	no = n;
	if (mo < no) {
		praw = trans(praw);
		{m,n} = size(praw);
	}

	pfix = praw;
	if (nargs == 1) {
		closetopi = PI*170./180.;    // Here is a tolerance.
	} else {
		closetopi = tol;             // Here is a tolerance.
	}

	for (j = 1; j <= n; j++) {
		p = praw(:,j);
		pd = diff(p);
		ijump = find(abs(pd) > closetopi);
		for (i = 1; i <= length(ijump); i++) {
			k = ijump(i);
			p(k+1:m) = p(k+1:m) .- 2*PI*sgn(pd(k));
		}
		pfix(:,j) = p;
	}

	if (mo < no) {
		pfix = trans(pfix);
	}
	return pfix;
}
