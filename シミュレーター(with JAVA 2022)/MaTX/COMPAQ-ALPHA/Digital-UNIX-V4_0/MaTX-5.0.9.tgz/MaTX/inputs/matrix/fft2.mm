
/*  -*- MaTX -*-
 *
 *  NAME
 *      fft2() - 2-D FFT
 *
 *  SYNOPSIS
 *      y = fft2(x)
 *         Array y;
 *         Array x;
 *
 *  DESCRIPTION
 *      fft2(X) is the 2-D FFT of X. Rows or columns that are not 
 *      an even power of two are padded with trailing zeros.
 *
 *  SEE ALSO
 *      fft(), ifft2() and fftshift().
 */

Func Array fft2(x)
	Array x;
{
	Array y;

	y = trans(fft(trans(fft(x))));
	return y;
}
