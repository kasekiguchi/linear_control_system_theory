
/*  -*- MaTX -*-
 *
 *  NAME
 *      polyfit() - Polynomial fitting
 *
 *  SYNOPSIS
 *      p = polyfit(x,y,n)
 *         Matrix p;
 *         Array x,y;
 *         Integer n;
 *
 *  DESCRIPTION
 *      polyfit(x,y,n) finds the coefficients of a polynomial
 *      formed from the data in vector x of degree n that fits
 *      the data in vector y in a least-squares sense.  
 *
 *      the regression problem is formulated in matrix format as:
 *
 *       y = A*P  or
 *
 *             3  2  
 *       y = [x  x  x  1] [[p3]
 *                         [p2]
 *                         [p1]
 *                         [p0]];
 *
 *      where the vector P contains the coefficients to be found.  For a
 *      7th order polynomial, matrix A would be:
 *
 *       A = [x.^7 x.^6 x.^5 x.^4 x.^3 x.^2 x ONE(x)];
 *
 */

Func Matrix polyfit(x_, y_, n)
	Array x_, y_;
	Integer n;
{
	Integer j;
	Array x, y;
	Matrix A, p;

	x = x_;
	y = y_;

	if (Cols(x) != Cols(y) || Rows(x) != Rows(y)) {
		error("polyfit(): X and Y vectors must be the same size\n");
	}
	x = makecolv(x);
	y = makecolv(y);
	n = n + 1;
	A = Z(max(Cols(x), Rows(x)), n);

	// Construct Vandermonde matrix
	for (j = 1; j <= n; j++) {
		A(:,j) = x^(n-j);
	}
	p = fliplr((A \ Matrix(y))#);
	return p;
}
