
/* -*- MaTX -*-
 *
 *  NAME
 *      rot90() - Rotate matrix 90 degrees
 *
 *  SYNOPSIS
 *      X = rot90(A)
 *         Matrix X;
 *         Matrix A;
 *
 *      X = rot90(A, k)
 *         Matrix X;
 *         Matrix A;
 *         Integer k;
 *
 *  DESCRIPTION
 *      rot90(A) is the 90 degree rotation of m x n matrix A.
 *      rot90(A, k) is the k*90 degree rotation of A, k = +-1,+-2,...
 *      For example,
 *
 *      A = [[1 2 3]      B = rot90(A) = [[3 6]
 *           [4 5 6]]                     [2 5]
 *                                        [1 4]]
 *
 *      mesh(B) then shows a 90 degree counter-clockwise rotation of mesh(A).
 *
 *  SEE ALSO
 *      trans()
 */

Func Matrix rot90(A, K, ...)
	Matrix A;
	Integer K;
{
	Matrix B;
	Integer k,m, n;

	error(nargchk(1, 2, nargs, "rot90"));

	{m, n} = size(A);
	if (nargs == 1) {
		k = 1;
	} else if (nargs == 2) {
		k = rem(K, 4);
		if (k < 0) {
			k = k + 4;
		}
	}

	if (k == 1) {
		B = A#;
		B = flipud(B);         // B = A(n:-1:1,:);
	} else if (k == 2) {
		B = fliplr(flipud(A)); // B = A(m:-1:1,n:-1:1);
	} else if (k == 3) {
		B = flipud(A);         // B = A(m:-1:1,:);
		B = B#;
	} else {
		B = A;
	}

	return B;
}

