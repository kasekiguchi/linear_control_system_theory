
/*  -*- MaTX -*-
 *
 *  NAME
 *      plotwow() - Interesting plots
 *
 *  SYNOPSIS
 *      plotwow()
 *
 *  DESCRIPTION
 *      This demo shows some interesting plots.
 *
 */

Func void plotwow()
{
	Integer win;
	Array t,x,y;
	Matrix dzx,dzy,z,pzx,pzy;

	List meshdom();
	void quiver(...);

	win = mgplot_cur_win();

	clear;
	print "\n";
	print "Let's define a peculiar vector, ";
	print "and then plot a growing cosine wave with points:\n";
	print "\n";
	print "\tt = [0:(.99*PI/2):500];\n";
	print "\tx = t.*cos(t);\n";
	print "\tmgplot(win,x,t,{\"\"},{\"w points\"});\n\n";
	pause "Strike any key for plot.";

	t = [0:(.99*PI/2):500];
	x = t.*cos(t);
	mgplot_reset(win);
	mgplot(win,x,t,{""},{"w points"});

	print "Next, with lines\n\n";
	print "\tmgplot(win,x,t,{\"\"});\n\n";
	pause "Strike any key for plot.";

	mgplot_reset(win);
	mgplot(win,x,t,{""});

	clear;
	print "\n";
	print "Now plot the growing cosine versus a growing sine:\n";
	print "\n";
	print "\ty = t.*sin(t);\n";
	print "\tmgplot(win,x,y,{\"\"});\n\n";
	pause "Strike any key for plot.";

	y = t.*sin(t);
	mgplot_reset(win);
	mgplot(win,x,y,{""});

#if 0
	clear;
	print "\n";
	print "Consider the function\n";
	print "\n";
	print "\tz = cos(x)*sin(y)\n";
	print "\n";
	print "in the interval -2 < x < 2,  -2 < y < 2.  To draw a mesh or\n";
	print "contour graph of this function, first form matrices x and y\n";
	print "containing a grid of values in this range:\n\n";
	print "\t{x,y} = meshdom([-2:.2:2],[-2:.2:2]);\n\n";

	pause;
	{x,y} = meshdom([-2:.2:2],[-2:.2:2]);

	print "\n";
	print "We can evaluate this function at all the points in x and y ";
	print "with:\n\n";
	print "\tz = cos(x) .* sin(y);\n\n";
	pause;

	z = cos(x) .* sin(y);

	clear;
	print "\n";
	print "A mesh plot of this function is:\n\n";

	pause "Press any key for plot.";
//	mesh(z);
	clear;
	print "\n";
	print "The gradient of z = cos(x)*sin(y) is easy to ";
	print "compute analytically:\n";
	print "\n";
	print "\tdz/dx = -sin(x)*sin(y)\n";
	print "\tdz/dy =  cos(x)*cos(y)\n\n";

	pause;
	
	print "We can evaluate the partials for all points in x and y:\n";
	print "\n";
	print "\tdzx = -sin(x).*sin(y);\n";
	print "\tdzy =  cos(x).*cos(y);\n\n";
	pause;

	dzx = -sin(x).*sin(y);
	dzy =  cos(x).*cos(y);

	clear;
	print "\n";
	print "If the gradient of a function is too complicated to compute\n";
	print "analytically, or if we start with data, the gradient can be\n";
	print "computed numerically:\n\n";
	print "\t{pzx,pzy} = gradient(z, [.2], [.2]);\n\n";
	pause;

	{pzx,pzy} = gradient(z, [.2], [.2]);
	print "\n";
	print "Overlaying a contour plot of the function and a\n";
	print "'quiver' plot of the partials puts directional\n";
	print "information on the contour plot:\n\n";
	print "\tcontour(z);\n";
	print "\tquiver(pzx,pzy);\n\n";

	pause "Press any key for plot.";

//	contour(z);
//	quiver(pzx,pzy);
#endif
	clear;
}
