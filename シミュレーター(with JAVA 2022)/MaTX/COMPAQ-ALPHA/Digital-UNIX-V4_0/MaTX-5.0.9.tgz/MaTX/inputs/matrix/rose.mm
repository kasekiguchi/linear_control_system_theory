
/*  -*- MaTX -*-
 *
 *  NAME
 *      rose() - Angle histogram, also known as a Rose plot
 *
 *  SYNOPSIS
 *      rose(x)
 *         Matrix x;
 *
 *      rose(x,y)
 *         Matrix x;
 *         Matrix y;
 *
 *      rose(x,y,nbins)
 *         Matrix x;
 *         Matrix y;
 *         Integer nbins;
 *
 *      rose(x,y,nbins,s)
 *         Matrix x;
 *         Matrix y;
 *         Integer nbins;
 *         Integer s;
 *
 *  DESCRIPTION
 *      rose(z) plots a circular histogram showing the distribution
 *      of the angles of the complex data in matrix z.  The default
 *      number of bins is 36.
 * 
 *      rose(X,Y) is equivalent to rose(X+i*Y).  It plots the angle
 *      histogram of atan2(Y,X), the angles specified by the elements
 *      of matrices X and Y.
 *
 *      rose(X,Y,n), where n is an integer, uses n bins.
 *      rose(...,S) uses line style S
 *
 *	SEE ALSO
 *      compass(), feather() and quiver().
 *
 */

Func void rose(x_,y_,nbins,s, ...)
	Matrix x_,y_;
	Integer nbins;
	Integer s;
{
	Integer bindef,k,m,n,sdef,win,i;
	Real delta,mx;
	Matrix a,ang,arrow,bins,d,f,w,xx,yy,z,sq,x,y;
	Index j;
	List name, col;

	error(nargchk(1, 4, nargs, "rose"));
	
	a = ([0:4] .+ 1.0/2.0) / 4;
	sq = sqrt(2.0) * exp(-(0,1)*2*PI*Array(a));

	xx = [0.0, 1.0,  0.8, 1.0,   0.8]';
	yy = [0.0, 0.0, 0.08, 0.0, -0.08]';
	arrow = xx + yy*(0,1);

	bindef = 36;
	sdef = 1;

	if (nargs == 3) {
		s = sdef;
		x = x_;
		y = y_;
	} else if (nargs == 2) {
		s = sdef;
		nbins = bindef;
		x = x_;
		y = y_;
	} else if (nargs == 1) {
		s = sdef;
		nbins = bindef;
		y = Im(x_);
		x = Re(x_);
	}
	
	x = makecolv(x);
	y = makecolv(y);

	if (length(x) != length(y)) {
		error("rose(): X and Y must be same length.\n");
	}
	
	{m,n} = size(x);
	
	z = x + y*(0,1);
	a = angle(z);
	bins = [-nbins/2.0:nbins/2.0]*2*PI/nbins;
	f = Z(1,nbins+1);
	for (i = 2; i <= nbins+1; i++) {
		f(i) = sum(Array(a) <= bins(i));
	}
	j = [1:nbins];
	f = f(j .+ 1) - f(j);
	mx = max(f);
	
	delta = 2*PI/nbins;
	ang = delta*[0:5]/5;
	w = [[0], ang, [0]];
	k = length(w);
	
	d = ONE(k,1)*Matrix([0:nbins-1])*delta .- PI;
	z = (w# * ONE(1,nbins)) + d;
	z = exp((0,1)*Array(z));
	z(1:k-1:k,:) = Z(2,nbins);
	y = ONE(k,1) * f;
	z = z .* y;
	sq = sq * mx;

	z = z#;
	name = makelist(Rows(z));
	col = makelist(Rows(z));
	for (i = 1; i <= Rows(z); i++) {
		name(i) = "";
		col(i) = sprintf("%d", s);
	}

	win = mgplot_cur_win();
	mgplot(win, Re(sq), Im(sq), {""}, {"3"});
	mgreplot(win, Re(z), Im(z), name, col);
}
