
/* -*- MaTX -*-
 *
 *  NAME
 *      tril() - Lower triangle
 *
 *  SYNOPSIS
 *      Y = tril(X)
 *         Matrix Y;
 *         Matrix X;
 *
 *      Y = tril(X, k)
 *         Matrix Y;
 *         Matrix X;
 *         Integer k;
 *
 *  DESCRIPTION
 *      tril(X) is the lower triangular part of X.
 *
 *      tril(X,k) is the elements on and below the k-th diagonal of X. 
 *        k = 0 is the main diagonal.
 *        k > 0 is above the main diagonal.
 *        k < 0 is below the main diagonal.
 *
 *  SEE ALSO
 *      triu()
 */

Func Matrix tril(X, k, ...)
	Matrix X;
	Integer k;
{
	Integer i, j, m, n;
	Matrix Y;

	error(nargchk(1, 2, nargs, "tril"));

	if (nargs == 1) {
		k = 0;
	}

	{m, n} = size(X);
	Y = Z(X);

	for (i = max(1,1-k); i <= m; i++) {
		for (j = 1; j <= min(n,i+k); j++) {
			Y(i,j) = X(i,j);
		}
	}
	return Y;
}
