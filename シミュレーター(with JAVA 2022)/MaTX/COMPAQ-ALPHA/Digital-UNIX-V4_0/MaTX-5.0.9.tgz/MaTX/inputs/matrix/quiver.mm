
/*  -*- MaTX -*-
 *
 *  NAME
 *      quiver() - Quiver plot
 *
 *  SYNOPSIS
 *      quiver(x)
 *         Matrix x;
 *
 *      quiver(x,y)
 *         Matrix x,y;
 *
 *      quiver(x,y,s)
 *         Matrix x,y;
 *         Integer s;
 *
 *  DESCRIPTION
 *      quiver(z) draws a graph that displays the angle and magnitude
 *      of the complex elements of z as arrows emanating from equally
 *      spaced grid positions, one arrow per matrix element.
 *
 *      quiver(X,Y) is equivalent to quiver(X+i*Y).  It displays the
 *      quiver plot for the angles and magnitudes of the elements of
 *      matrices X and Y.
 *
 *      quiver(X,Y,S) use line style S.
 *
 *  EXAMPLE
 *   	   {x,y} = meshdom([-2:.2:2], [-2:.2:2]);
 *   	   z = x .* exp(-x.^2 - y.^2);
 *   	   {px,py} = gradient(z, [0.2], [0.2]);
 *   	   contour(z);
 *         quiver(px,py);
 *
 *	SEE ALSO
 *      gradient(), compass(), feather(), and rose().
 */

Func void quiver(x,y,s, ...)
	Matrix x,y;
	Integer s;
{
	Integer i,m,n,win;
	Real scale;
	Matrix arrow,xx,yy,z,grd,a;
	List name, col;

	List meshdom();

	error(nargchk(1, 3, nargs, "quiver"));

	xx = [0.0, 1.0,  0.8, 1.0,  0.8]';
	yy = [0.0, 0.0, 0.08, 0.0, -.08]';
	arrow = xx + yy*(0,1);

	if (nargs == 2) {
		s = 3;
	} else if (nargs == 1) {
		s = 3;
		y = Im(x);
		x = Re(x);
	}

	{m,n} = size(x);
	{xx,yy} = meshdom([1:n], [1:m]);
	grd = xx + yy*(0,1);
	grd = makecolv(grd);
	x = makecolv(x);
	y = makecolv(y);
	z = (x + y*(0,1))#;
	scale = 0.90 / max(abs(Array(z)));
	a = scale*arrow*z + ONE(5,1) * grd#;

	name = makelist(Cols(a));
	col = makelist(Cols(a));
	for (i = 1; i <= Cols(a); i++) {
		name(i) = "";
		col(i) = sprintf("%d", s);
	}
	win = mgplot_cur_win();
	mgplot(win, trans(Re(a)), trans(Im(a)), name, col);
}





