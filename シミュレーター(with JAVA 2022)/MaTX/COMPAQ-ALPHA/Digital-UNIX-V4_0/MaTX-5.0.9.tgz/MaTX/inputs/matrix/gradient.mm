
/*  -*- MaTX -*-
 *
 *  NAME
 *      gradient() - Numerical gradient of a matrix.
 *
 *  SYNOPSIS
 *      {xx,yy} = gradient(a)
 *          Matrix xx, yy;
 *          Matrix a;
 *
 *      {xx,yy} = gradient(a,xax)
 *          Matrix xx, yy;
 *          Matrix a;
 *          Matrix xax;
 *
 *      {xx,yy} = gradient(a,xax,yax)
 *          Matrix xx, yy;
 *          Matrix a;
 *          Matrix xax;
 *          Matrix yax;
 *
 *  DESCRIPTION
 *      gradient(Z,DX,DY) returns the numerical partial derivatives
 *      of matrix Z in matrices PX = dZ/dx and PY = dZ/dy.   DX and DY
 *      may be scalars containing the sample spacing in the X and Y
 *      directions, or they may be vectors containing all the explicit
 *      locations.
 *
 *      gradient(A) assumes DX = DY = 1. 
 *
 *      If Y is a vector, gradient(Y) and gradient(Y,DX) return 
 *      {xx,yy} the one dimensional numerical derivative dY/dX.
 *
 *      For example,
 *
 *   	   {x,y} = meshdom([-2:.2:2], [-2:.2:2]);
 *   	   z = x .* exp(-x.^2 - y.^2);
 *   	   {px,py} = gradient(z, [0.2], [0.2]);
 *   	   contour(z);
 *         quiver(px,py);
 *
 *	SEE ALSO
 *      quiver() and contour().
 */

Func List gradient(a_, xax_, yax_, ...)
	Matrix a_;
	Matrix xax_, yax_;
{
	Integer i,m,n;
	Matrix xx,yy,xax,yax,ax,a,x,y,z,d;
	Index j,k;

	error(nargchk(1, 3, nargs, "gradient"));
	
	a = a_;

	{m,n} = size(a);
	if (nargs == 1) {
		xax = [1];
		yax = [1];
	} else if (nargs == 2) {
		yax = xax_;
	} else if (nargs == 3) {
		xax = xax_;
		yax = yax_;
	}

	if (length(xax) == 1) {
		xax = xax * Matrix([0:n-1]);
	}
	if (length(yax) == 1) {
		yax = yax * Matrix([m-1:-1:0]);
	}

	y = [];
	ax = makerowv(xax);
	for (i = 1; i <= 2; i++) {
		x = y;
		{m,n} = size(a);
		y = Z(m, n);
		j = [1:m];
		if (n > 1) {
			d = [ax(2) - ax(1)];
			y(j,1) = (a(j,2) - a(j,1)) / d(1);     // Left edge
			d = [ax(n) - ax(n-1)];
			y(j,n) = (a(j,n) - a(j,n-1)) / d(1);   // Right edge
		}
		if (n > 2) {
			k = [1:n-2];
			d = ONE(m,1) * (ax(k .+ 2) - ax(k));
			y(j, k .+ 1) = (a(j, k .+ 2) - a(j,k)) ./ d;   // Middle
		}
		a = a#;
		ax = makerowv(yax);
	}

	z = x + (0,1) * y#;

	xx = Re(z);
	yy = Im(z);

	return {xx,yy};
}
