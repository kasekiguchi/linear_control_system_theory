
/*  -*- MaTX -*-
 *
 *  NAME
 *      hist()     - Data for histograms-plot for all elements
 *      hist_col() - Data for histograms-plot for each column
 *      hist_row() - Data for histograms-plot for each row
 *
 *  SYNOPSIS
 *      {NN,XX} = hist(Y)
 *          Array NN,XX;
 *          Array Y;
 *
 *      {NN,XX} = hist(Y,n)
 *          Array NN,XX;
 *          Array Y;
 *          Integer n;
 *
 *      {NN,XX} = hist_col(Y)
 *          Array NN,XX;
 *          Array Y;
 *
 *      {NN,XX} = hist_col(Y,n)
 *          Array NN,XX;
 *          Array Y;
 *          Integer n;
 *
 *      {NN,XX} = hist_row(Y)
 *          Array NN,XX;
 *          Array Y;
 *
 *      {NN,XX} = hist_row(Y,n)
 *          Array NN,XX;
 *          Array Y;
 *          Integer n;
 *
 *  DESCRIPTION
 *      If y is a vector, hist(y) returns vectors xx and nn to 
 *      plot a histogram with 10 equally spaced bins between the 
 *      minimum and maximum values in  y, showing the distribution of
 *      the elements in vector y.
 *
 *      hist(y,n), where n is an integer, uses n bins.
 *
 *      If Y is a matrix, 
 *
 *      hist_col(Y) calculates the data for each column
 *      hist_col(Y,n), where  n  is an integer, uses  n  bins.
 *
 *      hist_row(Y) calculates the histerences for each row:
 *      hist_row(Y,n), where  n  is an integer, uses  n  bins.
 *
 *      hist(X) works for the all elements.
 *
 *  SEE ALSO
 *      bar()
 */

Func List hist(Y, n, ...)
	Array Y;
	Integer n;
{
	error(nargchk(1, 2, nargs, "hist"));
	
	if (nargs == 1) {
		return hist_row(reshape(Y, 1, Rows(Y)*Cols(Y)));
	} else {
		return hist_row(reshape(Y, 1, Rows(Y)*Cols(Y)), n);
	}
}

Func List hist_col(Y_, n, ...)
	Array Y_;
	Integer n;
{
	Integer i,j;
	Array y,nn,xx,xxx,NN,XXX,Y;
	Real maxy, miny, binwidth;

	error(nargchk(1, 2, nargs, "hist_col"));
	
	if (nargs == 1) {
		n = 10;
	}
	
	if (Rows(Y_) == 1 && Cols(Y_) != 1) {
		Y = makecolv(Y_);
	} else {
		Y = Y_;
	}

	XXX = Z(n,Cols(Y));
	NN = Z(n,Cols(Y));
	for (i = 1; i <= Cols(Y); i++) {
		y = Y(:,i);

		miny = min(y);
		maxy = max(y);
		binwidth = (maxy - miny)/n;
		xx = trans(miny .+ binwidth*[0:n]);
		xx(length(xx)) = maxy;
		xxx = xx(1:length(xx)-1) .+ binwidth/2;
		
		nn = Z(n+1,1);
		for (j = 2; j <= n + 1; j++) {
			nn(j,1) = length(find(y <= xx(j)));
		}
		nn = nn(2:n+1,1) - nn(1:n,1);

		XXX(:,i) = xxx;
		NN(:,i) = nn;
	}

	if (Rows(Y_) == 1 && Cols(Y_) != 1) {
		NN = trans(NN);
		XXX = trans(XXX);
	}

	return {NN, XXX};
}

Func List hist_row(Y, n, ...)
	Array Y;
	Integer n;
{
	Array NN, XXX;

	error(nargchk(1, 2, nargs, "hist_row"));
	
	if (nargs == 1) {
		{NN, XXX} = hist_col(trans(Matrix(Y)));
	} else {
		{NN, XXX} = hist_col(trans(Matrix(Y)), n);
	}
	NN = trans(Matrix(NN));
	XXX = trans(Matrix(XXX));
	return {NN, XXX};
}
