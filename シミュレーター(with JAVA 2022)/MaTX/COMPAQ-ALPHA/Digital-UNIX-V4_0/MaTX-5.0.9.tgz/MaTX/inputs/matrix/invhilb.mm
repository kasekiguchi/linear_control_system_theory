
/*  -*- MaTX -*-
 *
 *  NAME
 *      invhilb() - Inverse Hilbert matrix
 *
 *  SYNOPSIS
 *      H = invhilb(n)
 *         Matrix H;
 *         Integer n;
 *
 *  DESCRIPTION
 *      invhilb(n) is the inverse of the n by n matrix with elements
 *      1/(i+j-1), which is a famous example of a badly conditioned matrix.
 *      The result is exact for n less than about 15.
 *
 *  SEE ALSO
 *      hilb().
 *
 */

Func Matrix invhilb(n)
	Integer n;
{
	Matrix H;
	Integer i, j;
	Real p, r;

	p = Real(n);
	H = Z(n);

	for (i = 1; i <= n; i++) {
		if (i > 1) {
			p = ((n-i+1.0)*p*(n+i-1.0))/(i-1.0)^2;
		}
		r = p*p;
		H(i,i) = r/(2*i-1.0);
		for (j = i+1; j <= n; j++) {
			r = -((n-j+1.0)*r*(n+j-1.0))/(j-1.0)^2;
			H(i,j) = r/(i+j-1.0);
			H(j,i) = r/(i+j-1.0);
		}
	}
	return H;
}
