
/*  -*- MaTX -*-
 *
 *  NAME
 *      null() - Null space
 *
 *  SYNOPSIS
 *      Q = null(A,tol)
 *         Matrix Q;
 *         Matrix A;
 *
 *      Q = null(A,tol)
 *         Matrix Q;
 *         Matrix A;
 *         Real tol;
 *
 *  DESCRIPTION
 *      Q = null(A) is an orthonormal basis for the null space of A.
 *      Q#*Q = I,  A*Q = 0, and the number of columns of Q is the
 *      nullity of A.
 *
 *  SEE ALSO
 *      orth() and kerne().
 *
 */

Func Matrix null(A, tol, ...)
	Matrix A;
	Real tol;
{
	Matrix P,R,Q,d;
	Index idx;

	error(nargchk(1, 2, nargs, "null"));
	
	if (nargs == 1) {
		// Determine effective nullity
		tol = EPS*frobnorm(A);
	}

	// QR decomposition of the transpose
	{Q,R,P} = qr_p(A#);

	if (min(Cols(A), Rows(A)) > 1) {
		d = sum_row(abs(Array(R)))#;
	} else {
		d = [abs(R(1))];
	}
	idx = find(d .<= tol);

	// Use columns n of Q#.
	if (length(idx) > 0) {
		Q = Q(:,idx);
	} else {
		Q = [];
	}
	return Q;
}
