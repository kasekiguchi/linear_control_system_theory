
/*  -*- MaTX -*-
 *
 *	Copyright (C) 1989-1995  Masanobu Koga
 *            All Rights Reserved.
 *
 *	No part of this software may be used, copied, modified, and distributed
 *	in any form or by any means, electronic, mechanical, manual, optical or
 *	otherwise, without prior permission of Masanobu Koga.
 */

/* ------------------------------ Demo ------------------------------ */

// bench.mm
void bench() require "bench.mm";

// demo.mm
void demo() require "demo.mm";

// ctr_demo.mm
void ctr_demo() require "control/ctr_demo.mm" ;

// mat_demo.mm
void mat_demo() require "matrix/mat_demo.mm";

// sig_demo.mm
void sig_demo() require "signal/sig_demo.mm";

// rob_demo.mm
void rob_demo() require "robust/rob_demo.mm";

// idx_demo.mm
void idx_demo() require "ident/idx_demo.mm";

/* ------------------------------ Matrix ------------------------------ */

// DFT.mm
Array DFT(...) require "matrix/DFT.mm";
void DFT_plot(...) require "matrix/DFT.mm";

// IDFT.mm
Array IDFT(...) require "matrix/IDFT.mm";
void IDFT_plot(...) require "matrix/IDFT.mm";

// Mseq.mm
Array Mseq(...) require "matrix/Mseq.mm";

// PickUp.mm
Array PickUp() require "matrix/PickUp.mm";

// VecCont.mm
List VecCont() require "matrix/VecCont.mm";

// VecChop.mm
List VecChop() require "matrix/VecChop.mm";

// angle.mm
Array angle() require "matrix/angle.mm";

// backsub.mm
Matrix backsub() require "matrix/backsub.mm";

// bar.mm
List bar(...) require "matrix/bar.mm";
void barp(...) require "matrix/bar.mm";

// bessel.mm
Array bessel() require "matrix/bessel.mm";

// bessela.mm
List bessela() require "matrix/bessela.mm";

// besselh.mm
Array besselh() require "matrix/besselh.mm";

// besseln.mm
Array besseln() require "matrix/besseln.mm";

// cdf2rdf.mm
List cdf2rdf() require "matrix/cdf2rdf.mm";

// chol.mm
Matrix chol() require "matrix/chol.mm";

// compan.mm
Matrix compan() require "matrix/compan.mm";

// compass.mm
void compass(...) require "matrix/compass.mm";

// cond.mm
Real cond() require "matrix/cond.mm";

// conv.mm
Array conv() require "matrix/conv.mm";

// corrcoef.mm
Matrix corrcoef_col(...) require "matrix/corrcoef.mm";
Matrix corrcoef_row(...) require "matrix/corrcoef.mm";

// cov.mm
Real cov(...) require "matrix/cov.mm";
Matrix cov_col(...) require "matrix/cov.mm";
Matrix cov_row(...) require "matrix/cov.mm";

// cplxpair.mm
CoMatrix cplxpair(...) require "matrix/cplxpair.mm";

// dec2hex.mm
String dec2hex() require "matrix/dec2hex.mm";

// deconv.mm
List deconv() require "matrix/deconv.mm";

// diag_vec.mm
Matrix diag_vec(...) require "matrix/diag_vec.mm";

// diff.mm
Matrix diff(...) require "matrix/diff.mm";
Matrix diff_col(...) require "matrix/diff.mm";
Matrix diff_row(...) require "matrix/diff.mm";

// ellipj.mm
List ellipj() require "matrix/ellipj.mm";

// ellipk.mm
Matrix ellipk() require "matrix/ellipk.mm";

// erfnc.mm
Array erfnc(...) require "matrix/erfnc.mm";

// errorbar.mm
void errorbar(...) require "matrix/errorbar.mm";

// feather.mm
void feather(...) require "matrix/feather.mm";

// fft2.mm
Array fft2() require "matrix/fft2.mm";

// fftshift.mm
Array fftshift() require "matrix/fftshift.mm";

// fmin.mm
Real fmin(...) require "matrix/fmin.mm";

// fmins.mm
List fmins(...) require "matrix/fmins.mm";

// fplot.mm
List fplot(...) require "matrix/fplot.mm";

// fsolve.mm
List fsolve(...) require "matrix/fsolve.mm";

// funm.mm
Matrix funm() require "matrix/funm.mm";

// fzero.mm
Real fzero(...) require "matrix/fzero.mm";

// gallery.mm
Matrix gallery() require "matrix/gallery.mm";

// gammac.mm
Real gammac() require "matrix/gammac.mm";

// gammafnc.mm
Array gammafnc(...) require "matrix/gammafnc.mm";

// gammai.mm
Real gammai() require "matrix/gammai.mm";

// givens.mm
CoMatrix givens() require "matrix/givens.mm";

// gradient.mm
List gradient(...) require "matrix/gradient.mm";

// hadamard.mm
Matrix hadamard() require "matrix/hadamard.mm";

// hankel.mm
Matrix hankel(...) require "matrix/hankel.mm";

// hex2dec.mm
Integer hex2dec() require "matrix/hex2dec.mm";

// hex2num.mm
Real hex2num() require "matrix/hex2num.mm";

// hilb.mm
Matrix hilb() require "matrix/hilb.mm";

// hist.mm
List hist(...) require "matrix/hist.mm";
List hist_col(...) require "matrix/hist.mm";
List hist_row(...) require "matrix/hist.mm";

// ifft2.mm
CoArray ifft2() require "matrix/ifft2.mm";

// interp1.mm
Matrix interp1(...) require "matrix/interp1.mm";

// interp2.mm
List interp2(...) require "matrix/interp2.mm";

// interp3.mm
List interp3(...) require "matrix/interp3.mm";

// Matrix interp4..
Matrix interp4(...) require "matrix/interp4.mm";

// inverf.mm
Array inverf() require "matrix/inverf.mm";

// invhilb.mm
Matrix invhilb() require "matrix/invhilb.mm";

// isempty.mm
Integer isempty() require "matrix/isempty.mm";

// jordannf.mm
List jordannf(...) require "matrix/jordannf.mm";

// kronprod.mm
Matrix kronprod() require "matrix/kronprod.mm";

// kronsum.mm
Matrix kronsum() require "matrix/kronsum.mm";

// laguer.mm
List laguer() require "matrix/laguer.mm";

// linspace.mm
Array linspace(...) require "matrix/linspace.mm";

// logspace.mm
Array logspace(...) require "matrix/logspace.mm";

// magic.mm
Matrix magic() require "matrix/magic.mm";

// makecolv.mm
Matrix makecolv() require "matrix/makecolv.mm";

// makerowv.mm
Matrix makerowv() require "matrix/makerowv.mm";

// makepoly.mm
Polynomial makepoly() require "matrix/makepoly.mm";

// matlabio.mm
List matlab_read() require "matrix/matlabio.mm";
void matlab_write(...) require "matrix/matlabio.mm";

// mat2tex.mm
void mat2tex(...) require "matrix/mat2tex.mm";
String mat2texf(...) require "matrix/mat2tex.mm";

// median.mm
Real median() require "matrix/median.mm";
Matrix median_col() require "matrix/median.mm";
Matrix median_row() require "matrix/median.mm";

// membrane.mm
Matrix membrane(...) require "matrix/membrane.mm";

// meshdom.mm
List meshdom() require "matrix/meshdom.mm";

// nargchk.mm
String nargchk(...) require "matrix/nargchk.mm";

// nnls.mm
List nnls(...) require "matrix/nnls.mm";

// null.mm
Matrix null(...) require "matrix/null.mm";

// num2str.mm
String num2str() require "matrix/num2str.mm";

// orth.mm
Matrix orth(...) require "matrix/orth.mm";

// pascal.mm
Matrix pascal(...) require "matrix/pascal.mm";

// poly.mm
Matrix poly() require "matrix/poly.mm";

// poly2tex.mm
void poly2tex(...) require "matrix/poly2tex.mm";
String poly2texf(...) require "matrix/poly2tex.mm";

// polyder.mm
List polyder(...) require "matrix/polyder.mm";

// polyfit.mm
Matrix polyfit() require "matrix/polyfit.mm";

// ppval.mm
Matrix ppval() require "matrix/ppval.mm";
List unmkpp() require "matrix/ppval.mm";

// quad8.mm
List quad8(...) require "matrix/quad8.mm";

// quadf.mm
List quadf(...) require "matrix/quadf.mm";

// quiver.mm
void quiver(...) require "matrix/quiver.mm";

// rat.mm
List rat(...) require "matrix/rat.mm";

// rat2tex.mm
void rat2tex(...) require "matrix/rat2tex.mm";
String rat2texf(...) require "matrix/rat2tex.mm";

// resi2.mm
Complex resi2(...) require "matrix/resi2.mm";

// residue.mm
List residue(...) require "matrix/residue.mm";

// roots1.mm
List roots1() require "matrix/roots1.mm";

// rose.mm
void rose(...) require "matrix/rose.mm";

// rot90.mm
Matrix rot90(...) require "matrix/rot90.mm";

// rref.mm
Matrix rref(...) require "matrix/rref.mm";

// rsf2csf.mm
List rsf2csf() require "matrix/rsf2csf.mm";

// schord.mm
List schord(...) require "matrix/schord.mm";

// simplify.mm
RaMatrix simplify(...) require "matrix/simplify.mm";

// spline.mm
Matrix spline(...) require "matrix/spline.mm";
Matrix mkpp(...)   require "matrix/spline.mm";

// stairs.mm
List stairs(...) require "matrix/stairs.mm";
void stairsp(...) require "matrix/stairsp.mm";

// subspace.mm
Real subspace() require "matrix/subspace.mm";

// toeplitz.mm
Matrix toeplitz(...) require "matrix/toeplitz.mm";

// triu.mm
Matrix triu(...) require "matrix/triu.mm";

// tril.mm
Matrix tril(...) require "matrix/tril.mm";

// unwrap.mm
Array unwrap(...) require "matrix/unwrap.mm";
Array unwrap_col(...) require "matrix/unwrap.mm";
Array unwrap_row(...) require "matrix/unwrap.mm";

// vander.mm
Matrix vander() require "matrix/vander.mm";

/* ------------------------------ Signal ------------------------------ */

// bartlett.mm
Array bartlett() require "signal/bartlett.mm";

// bilinear.mm
List bilinear(...) require "signal/bilinear.mm";

// blackman.mm
Array blackman() require "signal/blackman.mm";

// boxcar.mm
Array boxcar() require "signal/boxcar.mm";

// buttap.mm
List buttap() require "signal/buttap.mm";

// butter.mm
List butter(...) require "signal/butter.mm";

// buttord.mm
List buttord(...) require "signal/buttord.mm";

// cceps.mm
Array cceps() require "signal/cceps.mm";

// cheb1ap.mm
List cheb1ap() require "signal/cheb1ap.mm";

// cheb1ord.mm
List cheb1ord(...) require "signal/cheb1ord.mm";

// cheb2ap.mm
List cheb2ap() require "signal/cheb2ap.mm";

// cheb2ord.mm
List cheb2ord(...) require "signal/cheb2ord.mm";

// chebwin.mm
Array chebwin() require "signal/chebwin.mm";

// cheby1.mm
List cheby1(...) require "signal/cheby1.mm";

// cheby2.mm
List cheby2(...) require "signal/cheby2.mm";

// cheb2ap.mm
List cheb2ap() require "signal/cheb2ap.mm";

// comb.mm
void comb(...) require "signal/comb.mm";

// conv2.mm
Array conv2() require "signal/conv2.mm";

// convmtx.mm
Array convmtx() require "signal/convmtx.mm";

// decimate.mm
Array decimate(...) require "signal/decimate.mm";

// detrend.mm
Array detrend(...) require "signal/detrend.mm";
Array detrend_col(...) require "signal/detrend.mm";
Array detrend_row(...) require "signal/detrend.mm";

// dftmtx.mm
Array dftmtx() require "signal/dftmtx.mm";

// ellip.mm
List ellip(...) require "signal/ellip.mm";

// ellipap.mm
List ellipap() require "signal/ellipap.mm";

// ellipord.mm
List ellipord(...) require "signal/ellipord.mm";

// fftfilt.mm
Array fftfilt(...) require "signal/fftfilt.mm";

// filer.mm
List filter(...) require "signal/filter.mm";

// filtfilt.mm
Matrix filtfilt() require "signal/filtfilt.mm";

// filtic.mm
Matrix filtic(...) require "signal/filtic.mm";

// fir1.mm
Matrix fir1(...) require "signal/fir1.mm";

// fir2.mm
Matrix fir2(...) require "signal/fir2.mm";

// freqs.mm
CoArray freqs() require "signal/freqs.mm";
void freqsp(...) require "signal/freqs.mm";

// freqz.mm
List freqz(...) require "signal/freqz.mm";
void freqzp(...) require "signal/freqz.mm";

// freqzw.mm
List freqzw(...) require "signal/freqzw.mm";

// freqs.mm
CoArray freqs() require "signal/freqs.mm";

// grpdelay.mm
List grpdelay(...) require "signal/grpdelay.mm";

// hamming.mm
Array hamming() require "signal/hamming.mm";

// hanning.mm
Array hanning() require "signal/hanning.mm";

// hilbert.mm
CoArray hilbert() require "signal/hilbert.mm";

// interp.mm
List interp(...) require "signal/interp.mm";

// invfreqs.mm
List invfreqs(...) require "signal/invfreqs.mm";

// invfreqz.mm
List invfreqz(...) require "signal/invfreqz.mm";

// kaiser.mm
Array kaiser() require "signal/kaiser.mm";

// lp2bp.mm
List lp2bp() require "signal/lp2bp.mm";

// lp2bs.mm
List lp2bs() require "signal/lp2bs.mm";

// lp2hp.mm
List lp2hp() require "signal/lp2hp.mm";

// lp2lp.mm
List lp2lp() require "signal/lp2lp.mm";

// nextpow2.mm
Integer nextpow2() require "signal/nextpow2.mm";

// polystab.mm
Matrix polystab() require "signal/polystab.mm";

// prony.mm
List prony() require "signal/prony.mm";

// rceps.mm
List rceps() require "signal/rceps.mm";

// remez.mm
List remez(...) require "signal/remez.mm";

// sawtooth.mm
Array sawtooth() require "signal/sawtooth.mm";

// specplot.mm
void specplot(...) require "signal/specplot.mm";

// spectrum.mm
Array spectrum(...) require "signal/spectrum.mm";

// square.mm
Array square(...) require "signal/square.mm";

// triang.mm
Array triang() require "signal/triang.mm";

// xcorr.mm
Array xcorr(...) require "signal/xcorr.mm";

// xcorr2.mm
Array xcorr2(...) require "signal/xcorr2.mm";

// xcov.mm
Array xcov(...) require "signal/xcov.mm";

// yulewalk.mm
List yulewalk(...) require "signal/yulewalk.mm";

/* ------------------------------ Control ------------------------------ */

// CharPoly.mm
Polynomial CharPoly() require "control/CharPoly.mm";

// ConMat.mm
Matrix ConMat() require "control/ConMat.mm";

// CoCanMat.mm
Matrix CoCanMat() require "control/CoCanMat.mm";

// CCTrans.mm
List CoCanTrans() require "control/CCTrans.mm";

// DHinf.mm
Matrix DHinf(...) require "control/DHinf.mm";

// Discretize.mm
List Discretize() require "control/Discret.mm";

// DOptimal.mm
Matrix DOptimal(...) require "control/DOptimal.mm";

// DRic.mm
Matrix DRic(...) require "control/DRic.mm";

// FR_Mseq.mm
List FR_Mseq() require "control/FR_Mseq.mm";

// Gopinath.mm
List Gopinath(...) require "control/Gopinath.mm";

// Hinf.mm
Matrix Hinf() require "control/Hinf.mm";

// Lyapunov.mm
Matrix Lyapunov() require "control/Lyapunov.mm";

// NicholsPlot_tf.mm
void NicholsP(...) require "control/NicholsP.mm";

// ObsMat.mm
Matrix ObsMat() require "control/ObsMat.mm";

// Optimal.mm
Matrix Optimal(...) require "control/Optimal.mm";

// PoleAsgn.mm
Matrix PoleAssign(...)  require "control/PoleAsgn.mm";
Matrix PoleAssignSISO() require "control/PoleAsgn.mm";
Matrix PoleAssignMIMO(...) require "control/PoleAsgn.mm";

// Resolven.mm
Matrix Resolvent()     require "control/Resolven.mm";
Matrix NumeResolvent() require "control/Resolven.mm";

// Ric.mm
Matrix Ric(...)  require "control/Ric.mm";
Matrix Ric2(...) require "control/Ric.mm";
Matrix ric(...)  require "control/Ric.mm";

// Riccati.mm
Matrix Riccati() require "control/Riccati.mm";

// Sig_tfm.mm
Array Sig_tfm() require "control/Sig_tfm.mm";

// TFadd.mm
List TFadd() require "control/TFadd.mm";

// TFsub.mm
List TFsub() require "control/TFsub.mm";

// TFmul.mm
List TFmul() require "control/TFmul.mm";

// TFinv.mm
List TFinv() require "control/TFinv.mm";

// TFtrans.mm
List TFtrans() require "control/TFtrans.mm";

// TFnegate.mm
List TFnegate() require "control/TFnegate.mm";

// TransFunc.mm
Rational TransFunc() require "control/TransFunc.mm";
RaMatrix TransFuncMat() require "control/TransFunc.mm";

// abcdchk.mm
String abcdchk(...) require "control/abcdchk.mm";

// acker.mm
Matrix acker() require "control/acker.mm";

// are.mm
Matrix are() require "control/are.mm";

// balreal.mm
List balreal() require "control/balreal.mm";

// blkbuild.mm
List blkbuild(...) require "control/blkbuild.mm";

// bode.mm
List bode_ss(...)       require "control/bode.mm";
List bode_tf(...)       require "control/bode.mm";
List bode_tfn(...)      require "control/bode.mm";
List bode_tfm(...)      require "control/bode.mm";
void bode_plot_ss(...)  require "control/bode.mm";
void bode_plot_tf(...)  require "control/bode.mm";
void bode_plot_tfn(...) require "control/bode.mm";
void bode_plot_tfm(...) require "control/bode.mm";
List bode(...)          require "control/bode.mm";
List Bode_tf(...)       require "control/bode.mm";
List Bode_tfm(...)      require "control/bode.mm";
void bodeplot(...)      require "control/bode.mm";
void BodePlot_tf(...)   require "control/bode.mm";

// ctrb.mm
Matrix ctrb() require "control/ctrb.mm";

// ctrbf.mm
List ctrbf(...) require "control/ctrbf.mm";

// c2d.mm
List c2d() require "control/c2d.mm";

// c2dt.mm
List c2dt() require "control/c2dt.mm";

// canon.mm
List canon(...) require "control/canon.mm";

// damp.mm
List damp() require "control/damp.mm";

// dbode.mm
List dbode(...)     require "control/dbode.mm";
void dbodeplot(...) require "control/dbode.mm";

// dimpulse.mm
List dimpulse() require "control/dimpulse.mm";

// dlyap.mm
Matrix dlyap() require "control/dlyap.mm";

// dlqe.mm
List dlqe() require "control/dlqe.mm";

// dlqr.mm
List dlqr(...) require "control/dlqr.mm";

// dlsim.mm
List dlsim(...) require "control/dlsim.mm";

// dmodred.mm
List dmodred() require "control/dmodred.mm";

// dstep.mm
List dstep() require "control/dstep.mm";

// d2c.mm
List d2c() require "control/d2c.mm";

// d2ce.mm
List d2ce() require "control/d2ce.mm";

// dbalreal.mm
List dbalreal() require "control/dbalreal.mm";

// dgram.mm
Matrix dgram() require "control/dgram.mm";

// fbode.mm
List fbode() require "control/fbode.mm";

// feedback.mm
List feedback() require "control/feedback.mm";

// feedbk.mm
List feedbk(...) require "control/feedbk.mm";

// fixphase.mm
Array fixphase() require "control/fixphase.mm";

// gmargin.mm
List gmargin(...) require "control/gmargin.mm";

// gram.mm
Matrix gram() require "control/gram.mm";

// impulse.mm
List impulse() require "control/impulse.mm";

// lqe.mm
List lqe() require "control/lqe.mm";

// lqr.mm
List lqr(...) require "control/lqr.mm";

// lqr2.mm
List lqr2(...) require "control/lqr2.mm";

// lqry.mm
List lqry(...) require "control/lqry.mm";

// LS.mm
Matrix LS() require "control/LS.mm";

// lsim.mm
List lsim(...) require "control/lsim.mm";

// ltifr.mm
CoMatrix ltifr() require "control/ltifr.mm";

// ltitr.mm
Matrix ltitr(...) require "control/ltitr.mm";

// lti1_th.mm
Matrix lti1_th() require "control/lti1_th.mm";

// lti2_th.mm
Matrix lti2_th() require "control/lti2_th.mm";

// lyap.mm
Matrix lyap(...) require "control/lyap.mm";

// margin.mm
List margin() require "control/margin.mm";

// minreal.mm
List minreal(...) require "control/minreal.mm";

// modred.mm
List modred() require "control/modred.mm";

// ngrid.mm
void ngrid() require "control/ngrid.mm";

// nyquist.mm
List nyquist_ss(...)       require "control/nyquist.mm";
List nyquist_tf(...)       require "control/nyquist.mm";
List nyquist_tfn(...)      require "control/nyquist.mm";
List nyquist_tfm(...)      require "control/nyquist.mm";
void nyquist_plot_ss(...)  require "control/nyquist.mm";
void nyquist_plot_tf(...)  require "control/nyquist.mm";
void nyquist_plot_tfn(...) require "control/nyquist.mm";
void nyquist_plot_tfm(...) require "control/nyquist.mm";
List nyquist(...)          require "control/nyquist.mm";
List Nyquist_tf(...)       require "control/nyquist.mm";
List Nyquist_tfm(...)      require "control/nyquist.mm";
void NyquitPlot(...)       require "control/nyquist.mm";
void nyqplot(...)          require "control/nyquist.mm";

// obsg.mm
List obsg() require "control/obsg.mm";

// obsv.mm
Matrix obsv() require "control/obsv.mm";

// obsvf.mm
List obsvf(...) require "control/obsvf.mm";

// parallel.mm
List parallel() require "control/parallel.mm";

// phi_lti1.mm
Matrix phi_lti1() require "control/phi_lti1.mm";

// phi_lti2.mm
Matrix phi_lti2() require "control/phi_lti2.mm";

// place.mm
Matrix place(...) require "control/place.mm";

// pmargin.mm
List pmargin(...) require "control/pmargin.mm";

// rlocus.mm
CoArray rlocus_ss(...)    require "control/rlocus.mm";
CoArray rlocus_tf(...)    require "control/rlocus.mm";
CoArray rlocus_tfn(...)   require "control/rlocus.mm";
CoArray rlocus_tfm(...)   require "control/rlocus.mm";
void rlocus_plot_ss(...)  require "control/rlocus.mm";
void rlocus_plot_tf(...)  require "control/rlocus.mm";
void rlocus_plot_tfn(...) require "control/rlocus.mm";
void rlocus_plot_tfm(...) require "control/rlocus.mm";
CoArray rlocus(...) require "control/rlocus.mm";
void rlocusp(...) require "control/rlocus.mm";

// RLS.mm
List RLS(...) require "control/RLS.mm";

// series.mm
List series() require "control/series.mm";

// ssappend.mm
List ssappend() require "control/ssappend.mm";

// ssconect.mm
List ssconnect() require "control/ssconect.mm";

// ss2tf.mm
List ss2tf(...) require "control/ss2tf.mm";

// ss2tfn.mm
Rational ss2tfn(...) require "control/ss2tfn.mm";

// ss2tfm.mm
RaMatrix ss2tfm(...) require "control/ss2tfm.mm";

// ss2zp.mm
List ss2zp(...) require "control/ss2zp.mm";

// step.mm
List step_ss()  require "control/step.mm";
List step_tf()  require "control/step.mm";
List step_tfn() require "control/step.mm";
List step_tfm() require "control/step.mm";
List step()     require "control/step.mm";
List Step_tf()  require "control/step.mm";
List Step_tfm() require "control/step.mm";

// stepfun.mm
Array stepfunc() require "control/stepfunc.mm";

// tf2ss.mm
List tf2ss() require "control/tf2ss.mm";

// tf2tfn.mm
Rational tf2tfn() require "control/tf2tfn.mm";

// tf2tfm.mm
RaMatrix tf2tfm() require "control/tf2tfm.mm";

// tf2zp.mm
List tf2zp() require "control/tf2zp.mm";

// tfn2ss.mm
List tfn2ss() require "control/tfn2ss.mm";

// tfn2tf.mm
List tfn2tf() require "control/tfn2tf.mm";

// tfn2tfm.mm
RaMatrix tfn2tfm() require "control/tfn2tfm.mm";

// tfn2zp.mm
List tfn2zp() require "control/tfn2zp.mm";

// tfm2ss.mm
List tfm2ss(...) require "control/tfm2ss.mm";

// tfm2tf.mm
List tfm2tf(...) require "control/tfm2tf.mm";

// tfm2tfn.mm
Rational tfm2tfn(...) require "control/tfm2tfn.mm";

// tfm2zp.mm
List tfm2zp(...) require "control/tfm2zp.mm";

// th_lti1.mm
RaMatrix th_lti1(...) require "control/th_lti1.mm";

// th_lti2.mm
RaMatrix th_lti2(...) require "control/th_lti2.mm";

// tzero.mm
CoMatrix tzero() require "control/tzero.mm";

// zgrid.mm
void zgrid() require "control/zgrid.mm";

// zp2ss.mm
List zp2ss() require "control/zp2ss.mm";

// zp2tf.mm
List zp2tf() require "control/zp2tf.mm";

// zp2tfn.mm
Rational zp2tfn() require "control/zp2tfn.mm";

// zp2tfm.mm
RaMatrix zp2tfm() require "control/zp2tfm.mm";

/* ------------------------------ Graph ------------------------------ */

// gcls.mm
void gcls() require "graph/gcls.mm";

// gplot.mm
void gplot(...) require "graph/gplot.mm";
void greplot(...) require "graph/gplot.mm";
void gplot_clear() require "graph/gplot.mm";
void gplot_reset() require "graph/gplot.mm";
void gplot_replot() require "graph/gplot.mm";
void gplot_cmd() require "graph/gplot.mm";
void gplot_quit() require "graph/gplot.mm";
void gplot_grid(...) require "graph/gplot.mm";
void gplot_key(...) require "graph/gplot.mm";
void gplot_loglog(...) require "graph/gplot.mm";
void greplot_loglog(...) require "graph/gplot.mm";
void gplot_options() require "graph/gplot.mm";
void gplot_psout(...) require "graph/gplot.mm";
void gplot_figcode(...) require "graph/gplot.mm";
void gplot_range(...) require "graph/gplot.mm";
void gplot_semilogx(...) require "graph/gplot.mm";
void greplot_semilogx(...) require "graph/gplot.mm";
void gplot_semilogy(...) require "graph/gplot.mm";
void greplot_semilogy(...) require "graph/gplot.mm";
void gplot_text(...) require "graph/gplot.mm";
void gplot_title()  require "graph/gplot.mm";
void gplot_xlabel(...) require "graph/gplot.mm";
void gplot_ylabel(...) require "graph/gplot.mm";
void gplot_subplot(...) require "graph/gplot.mm";

// mgplot.mm
void mgplot(...) require "graph/mgplot.mm";
void mgreplot(...) require "graph/mgplot.mm";
void mgplot_clear() require "graph/mgplot.mm";
void mgplot_reset() require "graph/mgplot.mm";
void mgplot_replot() require "graph/mgplot.mm";
void mgplot_cmd() require "graph/mgplot.mm";
void mgplot_quit(...) require "graph/mgplot.mm";
void mgplot_grid(...) require "graph/mgplot.mm";
void mgplot_key(...) require "graph/mgplot.mm";
void mgplot_loglog(...) require "graph/mgplot.mm";
void mgreplot_loglog(...) require "graph/mgplot.mm";
void mgplot_options() require "graph/mgplot.mm";
void mgplot_psout(...) require "graph/mgplot.mm";
void mgplot_figcode(...) require "graph/mgplot.mm";
void mgplot_range(...) require "graph/mgplot.mm";
void mgplot_semilogx(...) require "graph/mgplot.mm";
void mgreplot_semilogx(...) require "graph/mgplot.mm";
void mgplot_semilogy(...) require "graph/mgplot.mm";
void mgreplot_semilogy(...) require "graph/mgplot.mm";
void mgplot_text(...) require "graph/mgplot.mm";
void mgplot_title() require "graph/mgplot.mm";
void mgplot_xlabel(...) require "graph/mgplot.mm";
void mgplot_ylabel(...) require "graph/mgplot.mm";
Integer mgplot_cur_win(...) require "graph/mgplot.mm";
Integer mgplot_newwindow() require "graph/mgplot.mm";
Integer mgplot_hold(...) require "graph/mgplot.mm";
void mgplot_subplot(...) require "graph/mgplot.mm";

// xplot.mm
void xplot(...) require "graph/xplot.mm";
void xplot_grid(...) require "graph/xplot.mm";
void xplot_semilogx(...) require "graph/xplot.mm";
void xplot_title() require "graph/xplot.mm";
void xplot_xlabel() require "graph/xplot.mm";
void xplot_xsplit() require "graph/xplot.mm";
void xplot_ylabel() require "graph/xplot.mm";
void xplot_ysplit() require "graph/xplot.mm";


