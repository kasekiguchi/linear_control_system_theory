
/* -*- MaTX -*-
 *
 *  NAME
 *      margin() - Gain margin, phase margin, and crossover frequencies
 *
 *  SYNOPSIS
 *      {Gm,Pm,Wcg,Wcp} = margin(Mag,Phase,W)
 *          Real Gm,Pm,Wcg,Wcp;
 *          Array Mag,Phase,W;
 *
 *  DESCRIPTION
 *       margin() returns gain margin Gm, phase margin Pm, and associated
 *       frequencies Wcg and Wcp, given the Bode magnitude, phase, and
 *       frequency vectors Mag, Phase, and W from a system.  Interpolation
 *       is performed between frequency points to find the correct values.
 *       Here is an example,
 *
 *  EXAMPLE
 *       w = logspace(-1.0,2.0);
 *       {Mag,Phase} = bode(A,B,C,D,1,w);
 *       {Gm,Pm,Wcg,Wcp} = margin(Mag,Phase,w);
 *
 *  SEE ALSO
 *      gmargin() and pmargin()
 */

Func List margin(Mag, Phase_, w)
	Array Mag, Phase_, w;
{
	Array Phase;
	Real Gm,Pm,Wcg,Wcp,w1,w2,m1,m2,p1,p2;
	Integer i1,i2;
	Index i;

	// Make phase continuous through -180:
//	Phase = 180/PI*unwrap(Phase_*PI/180);
	Phase = Phase_;

	// Find gain margin:
	if (Phase(1) > -180.0) {
		i = find(Phase < -180.0);
	} else {
		i = find(Phase > -180.0);
	}

	if (length(i) == 0) {
		warning("margin(): Gain margin undefined; ");
		print "phase does not cross -180.\n";
		Gm = 1.0E300;  // Big number
	} else {
		i2 = i(1);
		i1 = i2 - 1;
		w1 = w(i1);
		w2 = w(i2);
		m1 = Mag(i1);
		m2 = Mag(i2);
		p1 = Phase(i1);
		p2 = Phase(i2);
		Wcg = w1 - (180.0+p1)/(p2-p1)*(w2-w1);
		Gm = 1.0 / (Mag(i1) + (m2-m1)/(w2-w1)*(Wcg-w1));
	}

	// Find phase margin:
	i = find(Mag < 1.0);
	if (length(i) == 0) {
		warning("margin(): Phase margin undefined; gain does not cross 1.0\n");
		Wcp = 0.0;
		Pm = 0.0;
		return {Gm,Pm,Wcg,Wcp};
	}
	i2 = i(1);
	i1 = i2 - 1;
	if (i1 == 0) {
		warning("margin(): Phase margin undefined; gain does not cross 1.0\n");
		Wcp = 0.0;
		Pm = 0.0;
		return {Gm,Pm,Wcg,Wcp};
	}
	w1 = w(i1);
	w2 = w(i2);
	m1 = Mag(i1);
	m2 = Mag(i2);
	p1 = Phase(i1);
	p2 = Phase(i2);
	Wcp = w1 + (1-m1)/(m2-m1)*(w2-w1);
	Pm = Phase(i1) + (p2-p1)/(w2-w1)*(Wcp-w1) + 180;

	return {Gm,Pm,Wcg,Wcp};
}
