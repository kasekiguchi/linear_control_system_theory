
/* -*- MaTX -*-
 *
 *  NAME
 *      Lyapunov() - Solution of Lyapunov Equation
 *
 *  SYNOPSIS
 *      P = Lyapunov(A, Q)
 *         Matrix P;
 *         Matrix A, Q;
 *
 *  DESCRIPTION
 *      Lyapunov() is obsolete.
 *
 *      Use P = lyap(A,Q)  for  P = Lyapunov(A, Q).
 *
 */

Func Matrix Lyapunov(A, Q)
	Matrix A, Q;
{
	return lyap(A, Q);
}
