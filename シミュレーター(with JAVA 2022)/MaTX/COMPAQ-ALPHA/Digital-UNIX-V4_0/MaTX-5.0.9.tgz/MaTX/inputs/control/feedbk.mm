
/* -*- MaTX -*-
 *
 *  NAME
 *      feedbk() - State-space Closed-loop transfer function
 *
 *  SYNOPSIS
 *      {A,B,C,D} = feedbk(A1,B1,C1,D1,type)
 *          Matrix A,B,C,D;
 *          Matrix A1,B1,C1,D1;
 *          Integer type;
 *
 *      {A,B,C,D} = feedbk(A1,B1,C1,D1,type,A2,B2,C2,D2)
 *          Matrix A,B,C,D;
 *          Matrix A1,B1,C1,D1;
 *          Integer type;
 *          Matrix A2,B2,C2,D2;
 *
 *      {A,B,C,D} = feedbk(A1,B1,C1,D1,type,FH)
 *          Matrix A,B,C,D;
 *          Matrix A1,B1,C1,D1;
 *          Integer type;
 *          Matrix FH;
 *
 *  DESCRIPTION
 *       feedbk() produces a state-space closed-loop transfer function for 
 *       5 common types of negative feedback:
 *    
 *      type = 1 -- forward loop, I; feedback loop, (A1,B1,C1,D1).
 *      type = 2 -- forward loop, (A1,B1,C1,D1); feedback loop, I.
 *      type = 3 -- forward loop, (A1,B1,C1,D1); feedback loop, (A2,B2,C2,D2).
 *      type = 4 -- state feedback: A2 <-- F.
 *      type = 5 -- output injection: A2 <-- H.
 * 
 *  SEE ALSO
 *      feedback()
 */

Func List feedbk(A1,B1,C1,D1,type,A2,B2,C2,D2, ...)
	Matrix A1,B1,C1,D1,A2,B2,C2,D2;
	Integer type;
{
	Matrix A,B,C,D;
	Integer sz,szi,szj;
	Matrix Dij,Dji,Idiv,Iii,Jjj,F,H;
	String msg;

	error(nargchk(5, 9, nargs, "feedbk"));

	msg = abcdchk(A1, B1, C1, D1);
	if (length(msg) > 0) {
		error("feedbk(): " + msg);
	}
	
	switch (type) {
	  case 1:
		sz = Rows(D1);
		Idiv = (I(sz) + D1)~;
		A = A1 - B1*Idiv*C1;
		B = B1*Idiv;
		C = -Idiv*C1;
		D = Idiv;
		break;
	  case 2:
		sz = Rows(D1);
		Idiv = (I(sz) + D1)~;
		A = A1 - B1*Idiv*C1;
		B = B1*Idiv;
		C = Idiv*C1;
		D = Idiv*D1;
		break;
	  case 3:
		msg = abcdchk(A2, B2, C2, D2);
		if (length(msg) > 0) {
			error("feedback(): " + msg);
		}

		Dji = D2*D1;
		Dij = D1*D2;
		szj = Rows(Dji);
		szi = Rows(Dij);
		Iii = (I(szj) + Dji)~;
		Jjj = (I(szi) + Dij)~;
		A = [[A1 - B1*Iii*D2*C1,     -B1*Iii*C2  ]
			 [    B2*Jjj*C1     A2 - B2*Jjj*D1*C2]];
		B = [[ B1*Iii  ]
			 [B2*Jjj*D1]];
		C = [Jjj*C1, -Jjj*D1*C2];
		D = Jjj*D1;
		break;
	  case 4:
		F = A2;
		A = A1 - B1*F;
		B = B1;
		C = C1 - D1*F;
		D = D1;
		break;
	  case 5:
		H = A2;
		A = A1 - H*C1;
		B = B1 - H*D1;
		C = C1;
		D = D1;
		break;
	}

	return {A,B,C,D};
}
