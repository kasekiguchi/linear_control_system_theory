
/* -*- MaTX -*-
 *
 *  NAME
 *      lqr() - Linear quadratic regulator design for continuous-time systems
 *              (Eigenvector decomposition algorithm)
 *
 *  SYNOPSIS
 *     {F,P} = lqr(A,B,Q,R)
 *        Matrix F,P;
 *        Matrix A,B,Q,R;
 *
 *     {F,P} = lqr(A,B,Q,R,S)
 *        Matrix F,P;
 *        Matrix A,B,Q,R;
 *        Matrix S;
 *
 *  DESCRIPTION
 *       lqr() calculates the optimal feedback gain matrix F such
 *       that the feedback law  u = -Fx  minimizes the cost function:
 *
 *          J = Integral (x#Qx + u#Ru) dt
 *
 *       subject to the constraint equation: 
 *          .
 *          x = Ax + Bu 
 *                
 *       Also returned is P, the steady-state solution to the associated 
 *       algebraic Riccati equation:
 *
 *          P A + A# P - P B R~ B# P + Q = 0
 *
 *       lqr() includes the cross-term S that relates u to x in the cost
 *       functional as
 *
 *          J = Integral (x#Qx + u#Ru + 2 x#Su) dt
 *
 *  SEE ALSO
 *      dlqr() and lqe()
 */

Func List lqr(A_, B, Q_, R, S, ...)
	Matrix A_, B, Q_, R, S;
{
	Integer m,mb,mn,mq,mr,n,nb,nnn,nq,nr;
	Matrix A,Q,F,P,chi,lambda,dre; 
	CoMatrix d,v;
	Index idx;
	String msg;

	error(nargchk(4, 5, nargs, "lqr"));

	msg = abcdchk(A_, B);
	if (length(msg) > 0) {
		error("lqr(): " + msg);
	}

	{m,n} = size(A_);
	{mb,nb} = size(B);
	{mq,nq} = size(Q_);
	if (m != mq || n != nq) { 
		error("lqr(): A and Q must be the same size.\n");
	}
	{mr,nr} = size(R);
	if (mr != nr || nb != mr) {
		error("lqr(): B and R must be consistent.\n");
	}

	if (nargs == 5) {
		{mn,nnn} = size(S);
		if (mn != m || nnn != nr) {
			error("lqr(): S must be consistent with Q and R.\n");
		}
		// Add cross term
		Q = Q_ - S/R*S#;
		A = A_ - B/R*S#;
	} else {
		S = Z(m,nb);
		A = A_;
		Q = Q_;
	}

	// Check if Q is positive semi-definite and symmetric
	if (any(Re(eigval(Q)) .< -EPS) || (norm(Q#-Q,1)/norm(Q,1) > EPS)) {
		error("lqr(): Q must be symmetric and positive semi-definite.\n");
	}

	// Check if R is positive definite and symmetric
	if (any(Re(eigval(R)) .<= -EPS) || (norm(R#-R,1)/norm(R,1) > EPS)) {
		error("lqr(): R must be symmetric and positive definite.\n");
	}

	// Start eigenvector decomposition by finding eigenvectors of Hamiltonian:
	{d, v} = eig([[A B/R*B#][Q, -A#]]);
	d = diag2vec(d);

	// Sort on real part of eigenvalues
	{dre,idx} = sort(Re(d));
	if (! (dre(n) < 0.0 && 0.0 < dre(n+1))) {
		error("lqr(): Can't order eigenvalues, (A,B) may be uncontrollable.\n");
	}

	// Select vectors with negative eigenvalues
	chi = v(1:n,idx(1:n));
	lambda = v((n+1):(2*n),idx(1:n));
	P = -Re(lambda/chi);
	F = R \ (S# + B#*P);

	return {F, P};
}
