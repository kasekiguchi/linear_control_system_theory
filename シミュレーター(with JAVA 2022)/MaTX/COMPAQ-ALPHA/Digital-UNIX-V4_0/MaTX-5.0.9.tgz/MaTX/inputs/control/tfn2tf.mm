
/* -*- MaTX -*-
 *
 *  NAME
 *      tfn2tf() -  Transfer function to transfer function conversion
 *
 *  SYNOPSIS
 *      {num,den} = tfn2tf(g)
 *         Matrix num,den;
 *         Rational g;
 *
 *  DESCRIPTION
 *       tfn2tf() calculates the transfer function representation:
 *
 *                 num(s)
 *          g(s) = ------
 *                 den(s)
 *
 *      of the system, whose transfer function is the rational polynomial g,
 *      from a single input. 
 *
 *  SEE ALSO
 *      ss2tf() and tf2zp()
 */

Func List tfn2tf(g)
	Rational g;
{
	Matrix num, den;
	
	if (version() == 4) {
		num = fliplr(Matrix(Nu(g)));
		den = fliplr(Matrix(De(g)));
	} else {
		num = Matrix(Nu(g));
		den = Matrix(De(g));
	}
	
	return {num, den};
}
