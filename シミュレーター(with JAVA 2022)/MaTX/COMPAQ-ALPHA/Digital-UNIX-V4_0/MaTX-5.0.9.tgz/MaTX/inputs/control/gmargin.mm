
/* -*- MaTX -*-
 *
 *  NAME
 *      gmargin() - Gain margin and crossover frequencies
 *
 *  SYNOPSIS
 *      {gm, wcp} = gmargin(G)
 *         Real gm, wcp;
 *         Rational G;
 *
 *      {gm, wcp} = gmargin(G, wmin)
 *         Real gm, wcp;
 *         Rational G;
 *         Real wmin;
 *
 *      {gm, wcp} = gmargin(G, wmin, wmax)
 *         Real gm, wcp;
 *         Rational G;
 *         Real wmin;
 *         Real wmax;
 *
 *      {gm, wcp} = gmargin(G, wmin, wmax, wtol)
 *         Real gm, wcp;
 *         Rational G;
 *         Real wmin;
 *         Real wmax;
 *         Real tol;
 *
 *  DESCRIPTION
 *       gmargin() returns gain margin Gm and associated frequencies Wcp,
 *       given the transfer function, range of frequency, and tolerance of
 *       frequency.
 *
 *  SEE ALSO
 *       pmargin()
 */

Func List gmargin(G, wmin, wmax, wtol, ...)
	Rational G;
	Real wmin, wmax, wtol;
{
	Real wcp, gm;
	Array w, gain, phase;
	Index wcp_idx;

	error(nargchk(1, 4, nargs, "gmargin"));

	if (nargs == 1) {
		wmin = 0.001;
		wmax = 1000.0;
		wtol = 1.0E-3;
	} else if (nargs == 2) {
		wmax = 1000.0;
		wtol = 1.0E-3;
	} else if (nargs == 3) {
		wtol = 1.0E-3;
	}

	for (;;) {
		w = logspace(log10(wmin), log10(wmax), 100);
		{gain, phase} = Bode_tf(G, w);
		gain = 20*log10(gain);
		phase = unwrap(phase);

		wcp_idx = find(phase < -180.0);
		if (length(wcp_idx) == 0) {
			warning("gmargin(): Gain margin undefined; phase does not cross -180\n");
			return {0.0, 0.0};
		} else if (length(wcp_idx) == Cols(w)) {
			warning("gmargin(): Gain margin undefined; phase has already crossed -180\n");
			return {0.0, 0.0};
		}

		wmin = w(wcp_idx(1)-1);
		wmax = w(wcp_idx(1));

		if (wmax - wmin < wtol) {
			wcp = wmax;
			gm = - gain(wcp_idx(1));
			break;
		}
	}

	return {gm, wcp};
}
