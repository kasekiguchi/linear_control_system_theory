
/* -*- MaTX -*-
 *
 *  NAME
 *      modred() - Model state reduction
 *
 *  SYNOPSIS
 *     {Ab,Bb,Cb,Db} = modred(A,B,C,D,elim)
 *        Matrix Ab,Bb,Cb,Db;
 *        Matrix A,B,C,D;
 *        Index elim;
 *
 *  DESCRIPTION
 *       modred() reduces the order of a model by eliminating the states
 *       specified in vector elim.  The state vector is partioned into X1,
 *       to be kept, and X2, to be eliminated,
 *
 *      	A = |A11  A12|		B = |B1|	C = |C1 C2|
 *      	    |A21  A22|		    |B2|
 *    	    .
 *      	x = Ax + Bu,   y = Cx + Du
 *   
 *       The derivative of X2 is set to zero, and the resulting equations
 *       solved for X1.  The resulting system has length(elim) fewer states
 *       and can be envisioned as having set the elim states to be infinitely
 *       fast.
 * 
 *  SEE ALSO
 *      balreal(), dmodred() and minreal()
 *
 */

Func List modred(A,B,C,D,elim)
	Matrix A,B,C,D;
	Index elim;
{
	Matrix Ab,Bb,Cb,Db;
	Integer ns,nu;
	Matrix a11,a12,a21,a22,b1,b2,c1,c2;
	Index keep;
	String msg;

	msg = abcdchk(A, B, C, D);
	if (length(msg) > 0) {
		error("modred(): " + msg);
	}

	// Form keep vector:
	{ns,nu} = size(B);
	keep = [1:ns];
	keep(elim) = Index([]);

	// Partition into x1, to be kept, and x2, to be eliminated:
	a11 = A(keep,keep);
	a12 = A(keep,elim);
	a21 = A(elim,keep);
	a22 = A(elim,elim);
	b1  = B(keep,:);
	b2  = B(elim,:);
	c1  = C(:,keep);
	c2  = C(:,elim);

	// Form final reduced matrices
	Ab  = a11 - a12/a22*a21;
	Bb  = b1 - a12/a22*b2;
	Cb  = c1 - c2/a22*a21;
	Db  = D - c2/a22*b2;
	return {Ab,Bb,Cb,Db};
}
