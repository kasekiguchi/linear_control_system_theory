
/*  -*- MaTX -*-
 *
 *  NAME
 *      phi_lti1() - Regressor vector for Least Squres method
 *
 *  SYNOPSIS
 *       phi = phi_lti1(Y, U, n, k)
 *           Matrix phi;   regressor vector 
 *           Array Y;      output of the system
 *           Array U;      input of the system
 *           Integer n;    number of states
 *           Integer k;    index of time
 *
 *  DESCRIPTION
 *       phi_lti1() generates a regressor vector for parameter estimation
 *       by least squares method from input output data of a linear time 
 *       invariant system.
 *
 *       It is assumed that all the elements of the transfer function
 *       in the same row have the common denominator such as
 *
 *       y(k) = G(q)u(k) + w(k)  or  y(k) = G(z)u(k) + w(k)
 *

G(q)=[[ b1_11 q^-1 + ... + b1_1n q^-n         bm_11 q^-1 + ... + bm_1n q^-n ]
      [-------------------------------, ..., -------------------------------]
      [1 + a_11 q^-1 + ... + a_1n q^-n,      1 + a_11 q^-1 + ... + a_1n q^-n]
      [                                                                     ]
      [                                                                     ]
      [ b1_p1 q^-1 + ... + b1_pn q^-n         bm_p1 q^-1 + ... + bm_pn q^-n ]
      [-------------------------------, ..., -------------------------------]
      [1 + a_p1 q^-1 + ... + a_pn q^-n,      1 + a_p1 q^-1 + ... + a_pn q^-n]]

G(z)=[[   b1_11 z^n-1 + ... + b1_1n             bm_11 z^n-1 + ... + bm_1n   ]
      [-------------------------------, ..., -------------------------------]
      [ z^n + a_11 z^n-1 + ... + a_1n         z^n + a_11 z^n-1 + ... + a_1n ]
      [                                                                     ]
      [                                                                     ]
      [   b1_p1 z^n-1 + ... + b1_pn             bm_p1 z^n-1 + ... + bm_pn   ]
      [-------------------------------, ..., -------------------------------]
      [ z^n + a_p1 q^z-n1 + ... + a_pn        z^n + a_p1 z^n-1 + ... + a_pn ]]

 *
 *      or in polynomial form:
 * 
 *        [[y1(k)]       [[u1(k)]
 *   A(q)  [y2(k)] = B(q) [u2(k)]  + w(k)
 *         [.....]        [.....]
 *         [yp(k)]]       [um(k)]] 
 *
 * A(q) = diag(1 + a_11 q^-1 + ... a_1n q^-n,
 *                        1 + a_21 q^-1 + ... a_2n q^-n,
 *                                   .............................,
 *                                            1 + a_p1 q^-1 + ... a_pn q^-n)
 * 
 * B(q) = [[1 + b1_11 q^-1 + ... b1_1n q^-n, 1 + b1_21 q^-1 + ... b1_2n q^-n
 *          ..............................., 1 + b1_m1 q^-1 + ... b1_mn q^-n]
 *         [1 + b2_11 q^-1 + ... b2_1n q^-n, 1 + b2_21 q^-1 + ... b2_2n q^-n
 *          ..............................., 1 + b2_m1 q^-1 + ... b2_mn q^-n]
 *         [................................................................]
 *         [1 + bp_11 q^-1 + ... bp_1n q^-n, 1 + bp_21 q^-1 + ... bp_2n q^-n
 *          ..............................., 1 + bp_m1 q^-1 + ... bp_mn q^-n]]
 *
 *      or in theta-parameter form:
 *
 *        [[y1(k)]
 *         [y2(k)] = phi(k)#*th + w(k)
 *         [.....]
 *         [yp(k)]]
 *   
 *     th  : p*n*(m+1) x 1
 *     phi : p x p*n*(m+1) 
 *
 *  th = [[th1]  th1 = [[ a_11] th2 = [[ a_21]   ... thp = [[ a_p1]
 *        [th2]         [ a_12]        [ a_22]   ...        [ a_p2]
 *        [...]         [ ....]        [ ....]   ...        [ ... ]
 *        [thp]]        [ a_1n]        [ a_2n]   ...        [ a_pn]
 *                      [b1_11]        [b1_21]   ...        [b1_p2]
 *                      [b1_12]        [b1_22]   ...        [b1_p2]
 *                      [ ....]        [ ....]   ...        [ ... ]
 *                      [b1_1n]        [b1_2n]   ...        [b1_pn]
 *                      [ ....]        [ ....]   ...        [ ... ]
 *                      [bm_11]        [bm_21]   ...        [bm_p2]
 *                      [bm_12]        [bm_22]   ...        [bm_p2]
 *                      [ ....]        [ ....]   ...        [ ... ]
 *                      [bm_1n]]       [bm_2n]]  ...        [bm_pn]]
 *    
 *   phi(k) = diag([[-y_1(k-1)]  [[-y_2(k-1)]   ..., [[-y_p(k-1)]
 *                  [  ....   ]   [  ....   ]   ...,  [  ....   ]
 *                  [-y_1(k-n)]   [-y_2(k-n)]   ...,  [-y_p(k-n)]
 *                  [ u_1(k-1)]   [ u_1(k-1)]   ...,  [ u_1(k-1)]
 *                  [  ....   ]   [  ....   ]   ...,  [  ....   ]
 *                  [ u_1(k-n)]   [ u_1(k-n)]   ...,  [ u_1(k-n)]
 *                  [  ....   ]   [   ....  ]   ...,  [  ....   ]
 *                  [  ....   ]   [   ....  ]   ...,  [  ....   ]
 *                  [ u_m(k-1)]   [ u_m(k-1)]   ...,  [ u_m(k-1)]
 *                  [  ....   ]   [  ....   ]   ...,  [  ....   ]
 *                  [ u_m(k-n)]], [ u_m(k-n)]], ...,  [ u_m(k-n)]])
 *
 */

Func Matrix phi_lti1(Y, U, n, k)
	Array Y;	// output of the system
	Array U;	// input of the system
	Integer n;	// number of states
	Integer k;	// index of time
{
	Matrix phi, u;
	Integer i, j, ii, m, p;

	m = Rows(U);
	p = Rows(Y);

	phi = Z(p*n*(m+1),p);
	u = Z(m*n,1);
	
	for (i = 1; i <= m; i++) {
		ii = n*(i-1);
		u(ii+1:ii+n,1) = U(i,k-1:k-n)#;
	}

	for (i = 1; i <= p; i++) {
		ii = (i-1)*n*(m+1);
		phi(ii+1:ii+n,i) = - Y(i,k-1:k-n)#;
		phi(ii+n+1:ii+n+m*n,i) = u;
	}

	return phi;
}
