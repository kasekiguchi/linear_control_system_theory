
/* -*- MaTX -*-
 *
 *  NAME
 *      dlqr() - Linear quadratic regulator design for discrete-time systems
 *
 *  SYNOPSIS
 *      {F,P} = dlqr(A,B,Q,R)
 *         Matrix F,P;
 *         Matrix A,B,Q,R;
 *
 *      {F,P} = dlqr(A,B,Q,R,S)
 *         Matrix F,P;
 *         Matrix A,B,Q,R,S;
 *
 *  DESCRIPTION
 *       dlqr() calculates the optimal feedback gain matrix F
 *       such that the feedback law:
 *
 *      	u = -Fx
 *
 *       minimizes the cost function:
 *
 *      	J = Sum (x#Qx + u#Ru)
 *
 *       subject to the constraint equation: 
 *		
 *      	x[n+1] = Ax[n] + Bu[n] 
 *                
 *       Also returned is P, the steady-state solution to the associated 
 *       discrete matrix Riccati equation:
 *
 *      	P - A#PA + A#PB(R + B#PB)~BP#A - Q = 0
 *
 *       dlqr() includes the cross-term S that relates u to x in the cost
 *       functional as
 *
 *          J = Sum (x#Qx + u#Ru + 2 x#Su) dt
 *
 *  SEE ALSO
 *      lqr()
 */

Func List dlqr(A,B,Q,R,S, ...)
	Matrix A,B,Q,R,S;
{
	Integer n;
	Matrix P,F,chi,d,lambda,v;
	Index idx;
	String msg;

	error(nargchk(4, 5, nargs, "dlqr"));

	msg = abcdchk(A, B);
	if (length(msg) > 0) {
		error("dlqr(): " + msg);
	}

	if (nargs == 4) {
		S = Z(B);
	}

	n = Cols(A);

	if (Rows(A) != Rows(Q) || Cols(A) != Cols(Q)) { 
		error("dlqr(): A and Q must be the same size.\n");
	}
	if (Rows(R) != Cols(R) || Cols(B) != Rows(R)) {
		error("dlqr(): B and R must be consistent.\n");
	}

	// Check if Q is positive semi-definite and symmetric
	if (any(Re(eigval(Q)) .< -EPS) || norm(Q# -Q,1)/norm(Q,1) > EPS) {
		error("dlqr(): Q must be symmetric and positive semi-definite.\n");
	}

	// Check if R is positive definite and symmetric
	if (any(Re(eigval(R)) .<= -EPS) || norm(R# -R,1)/norm(R,1) > EPS) {
		error("dlqr(): R must be symmetric and positive definite.\n");
	}

	// Eigenvectors of Hamiltonian
	{d, v} = eig([[A+B/R*B#/A#*Q, -B/R*B#/A#]
				  [    -A#\Q,       (A)~#   ]]);
	d = diag2vec(d);

	// Sort on magnitude of eigenvalues
	{d,idx} = sort(abs(Array(d)));
	if ( ! (d(n) < 1.0 && d(n+1) > 1.0) ) {
		error("dlqr(): Can't order eigenvalues, (A,B) may be uncontrollable.\n");
	}

	// Select vectors with eigenvalues inside unit circle
	chi = v(1:n,idx(1:n));
	lambda = v((n+1):(2*n),idx(1:n));
	P = Re(lambda/chi);
	F = (R + B#*P*B) \ (B#*P*A + S#);
	return {F, P};
}
