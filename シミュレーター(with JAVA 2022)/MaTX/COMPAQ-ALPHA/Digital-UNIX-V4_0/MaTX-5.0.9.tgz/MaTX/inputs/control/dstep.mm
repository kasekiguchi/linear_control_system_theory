
/* -*- MaTX -*-
 *
 *  NAME
 *      dstep() - Step response of discrete-time linear systems
 *
 *  SYNOPSIS
 *      {Y,X} = dstep(A,B,C,D,iu,N)
 *         Matrix Y,X;
 *         Matrix A,B,C,D;
 *         Integer iu,N;
 *
 *  DESCRIPTION
 *       dstep() calculates the response of the system:
 *
 *      	x[n+1] = Ax[n] + Bu[n]
 *      	y[n]   = Cx[n] + Du[n]
 *
 *       to a step applied to the iu'th input.  Integer N specifies how
 *       many points of the step response are to be found.  dstep() returns
 *       a matrix Y with as many rows as there are outputs y, and with N
 *       columns.  dstep() also returns the state time history.
 *
 *       If iu = 0, dstep() returns matrices
 *
 *       [[Y for 1st input]          [[X for 1st input]
 *        [Y for 2nd input]           [X for 2nd input]
 *        [...............]           [...............]
 *        [Y for m'th input]]  and    [Y for m'th input]].
 *
 *  SEE ALSO
 *      step()
 */

Func List dstep(A, B, C, D, iu, N)
	Matrix A, B, C, D;
	Integer iu, N;
{
	Integer i, n, m, p;
	Matrix X, Y, XX, YY;
	String msg;

	msg = abcdchk(A, B, C, D);
	if (length(msg) > 0) {
		error("dstep(): " + msg);
	}

	if (iu == 0) {
		n = Rows(A);
		m = Cols(B);
		p = Rows(C);
		YY = Z(m*p,N);
		XX = Z(m*n,N);
		for (i = 1; i <= m; i++) {
			{Y,X} = dlsim(A, B(:,i), C, D(:,i), ONE(1,N));
			YY(i-1,0,Y) = Y;
			XX(i-1,0,X) = X;
		}
	} else {
		{YY,XX} = dlsim(A, B(:,iu), C, D(:,iu), ONE(1,N));
	}
	return {YY,XX};
}
