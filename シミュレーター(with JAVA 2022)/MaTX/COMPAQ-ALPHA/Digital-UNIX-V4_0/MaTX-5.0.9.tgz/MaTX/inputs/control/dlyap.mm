
/* -*- MaTX -*-
 *
 *  NAME
 *      dlyap() - Discrete-time Lyapunov equation solution
 *
 *  SYNOPSIS
 *      P = dlyap(A,Q)
 *         Matrix P;
 *         Matrix Q,Q;
 *
 *  DESCRIPTION
 *       dlyap() solves the discrete Lyapunov equation:
 *
 *        A*P*A# + Q = P
 *
 *  SEE ALSO
 *      lyap()
 *
 */

Func Matrix dlyap(A, Q)
	Matrix A, Q;
{
	Integer m, n;
	Matrix A2, Q2, P;
	String msg;

	msg = abcdchk(A);
	if (length(msg) > 0) {
		error("dlyap(): " + msg);
	}

	{m, n} = size(A);
	A2 = (A + I(m))~ * (A - I(m));
	Q2 = (I(m) - A2) * Q * (I(m) - A2#)/2;
	P = lyap(A2, Q2);
	return P;
}
