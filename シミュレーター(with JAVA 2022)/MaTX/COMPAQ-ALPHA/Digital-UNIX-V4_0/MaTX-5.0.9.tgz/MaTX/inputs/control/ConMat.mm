
/* -*- MaTX -*-
 *
 *  NAME
 *      ConMat() - Controllability matrix of a continuous-time system
 *
 *  SYNOPSIS
 *      V = ConMat(A,B)
 *         Matrix V;
 *         Matrix A, B;
 *
 *  DESCRIPTION
 *      ConMat() is obsolete.
 *
 *      Use V = ctrb(A,B)  for  V = ConMat(A,B)
 *
 */

Func Matrix ConMat(A, B)
	Matrix A, B;
{
	return ctrb(A,B);
/*
	Integer i, n, m;
	Matrix V;

	n = Rows(A);
	m = Cols(B)*n;
	V = (Z(n,m),:);
	
	if (version() == 4) {
		V(0,0,B) = B;
		for (i = 2; i <= n; i++) {
			V(0,i-1,B) = A*V(0,i-2,B);
		}
	} else {
		V(1,1,B) = B;
		for (i = 2; i <= n; i++) {
			V(1,i,B) = A*V(1,i-1,B);
		}
	}

	if (isreal(A) && isreal(B)) {
		return Re(V);
	} else {
		return V;
	}
*/
}


