
/* -*- MaTX -*-
 *
 *  NAME
 *      ltifr() - Frequency response of linear time-invarient system
 *
 *  SYNOPSIS
 *      G = ltifr(A,B,s)
 *         CoArray G;
 *         Matrix A, B;
 *         CoArray s;
 *
 *  DESCRIPTION
 *      ltifr() calculates the complex response of the system:
 *      (s*I - A)^(1) * B
 *
 *  SEE ALSO
 *      ltitr()
 */

Func CoMatrix ltifr(A, B, s_)
	Matrix A;
	Matrix B;
	CoMatrix s_;
{
	CoMatrix G, s;
	Integer i, ns, n, m;
	String msg;

	msg = abcdchk(A, B);
	if (length(msg) > 0) {
		error("ltifr(): " + msg);
	}
	
	if (Rows(s_) > Cols(s_)) {
		s = trans(s_);
	} else {
		s = s_;
	}

	ns = Cols(s);
	n = Rows(A);
	m = Cols(B);
	G = Z(n, m, s);

	for (i = 1; i <= ns; i++) {
		G(:,(i-1)*m+1:i*m) = (s(i)*I(A) - A)~ * B;
	}

	return G;
}
