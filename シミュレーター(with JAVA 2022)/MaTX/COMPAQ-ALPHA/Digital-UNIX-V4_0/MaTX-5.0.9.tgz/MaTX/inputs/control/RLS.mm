
/*  -*- MaTX -*-
 *
 *  NAME
 *      RLS() - Parameter estimation by recursive least squres method
 *
 *	SYNOPSIS
 *      {th, P, TH} = RLS(Y, U, n, phi)
 *        Matrix th,P;
 *        Array TH;
 *        Array Y,U;
 *        Integer n;
 *        Matrix phi();
 *
 *      {th, P, TH} = RLS(Y, U, n, phi, th0)
 *        Matrix th,P;
 *        Array TH;
 *        Array Y,U;
 *        Integer n;
 *        Matrix phi();
 *        Matrix th0;
 *
 *      {th, P, TH} = RLS(Y, U, n, phi, th0, P0)
 *        Matrix th,P;
 *        Array TH;
 *        Array Y,U;
 *        Integer n;
 *        Matrix phi();
 *        Matrix th0,P0;
 *
 *      {th, P, TH} = RLS(Y, U, n, phi, th0, P0, lambda)
 *        Matrix th,P;
 *        Array TH;
 *        Array Y,U;
 *        Integer n;
 *        Matrix phi();
 *        Matrix th0,P0;
 *        Real lambda;
 *
 *  DESCRIPTION
 *      RLS() estimates the parameters of the linear time-invariant system,
 *      in transfer function matrix form:
 *
 *        y(k) = G(q)u(k) + w(k)  or   y(k) = G(z)u(k) + w(k)
 *
 *      in polynomial form:
 * 
 *        A(q)y(k) = B(q)u(k) + w(k)
 *
 *      in theta-parameter form:
 *
 *        y(k) = phi(k)#*th + w(k)
 *
 *      th    : estimated parameter
 *      P     : last covariance matrix
 *      TH    : series of estimated parameters
 *      Y     : output of the system
 *      U     : input of the system
 *      n     : number of states
 *      phi() : generates phi matrix
 *      th0   : initial value of parameters
 *      P0    : initial value of covariance matrix
 *      lambda: forgetting factor
 *
 *  SEE ALSO
 *      See phi_lti1() and phi_lti2() for phi().
 *      See also th_lti1(), th_lti2(), lti1_th() and lti2_th().
 */

Func List RLS(Y, U, n, make_phi, th0, P0, lambda, ...)
	Array Y;
	Array U;
	Integer n;
	Matrix make_phi();
	Matrix th0;
	Matrix P0;
	Real lambda;
{
	Integer m, p, k, N, M;
	Matrix th, P, K, phi, err, phi_tmp;
	Array TH;

	error(nargchk(4, 7, nargs, "RLS"));

	N = Cols(Y);
	p = Rows(Y);
	m = Rows(U);

	phi_tmp = make_phi(Y, U, n, n+1);
	M = Rows(phi_tmp);

	if (nargs < 7) {
		lambda = 1.0;
	}
	if (nargs < 6) {
		P0 = 1.0E3 * I(M);
	}
	if (nargs < 5) {
		th0 = Z(M, 1);
	}

	// Array for parameters
	TH = Z(Rows(th0), N-n+1);

	P = P0;
	th = th0;
	TH(:,1) = th;

	for (k = n+1; k <= N; k++) {
		phi = make_phi(Y, U, n, k);
		err = Matrix(Y(:,k)) - phi#*th;
		K = P*phi*(lambda*I(p) + phi#*P*phi)~;
		th = th + K*err;
		P = (P - K*phi#*P)/lambda;
		TH(:,k-n+1) = th;
	}

/*  The following statements are equivalent to the statements above.

	for (k = n+1; k <= N; k++) {
		phi = make_phi(Y, U, n, k);
		err = (Matrix(Y(:,k)) - phi#*th);
		P = (P - P*phi*(lambda*I(p) + phi#*P*phi)~*phi#*P)/lambda;
		th = th + P*phi*err;
		TH(:,k-n+1) = th;
	}
*/
	return {th, P, TH};
}
