
/*  -*- MaTX -*-
 *
 *  NAME
 *      ctrb() - Form controllability matrix
 *
 *  SYNOPSIS
 *      V = ctrb(A,B)
 *         Matrix V;
 *         Matrix A,B;
 *
 *  DESCRIPTION
 *      ctrb() returns the controllability matrix V = [B AB A^2B ...]
 *
 *  SEE ALSO
 *      obsv() and ctrbf()
 */

Func Matrix ctrb(A, B)
	Matrix A, B;
{
	Matrix V;
	Integer i, n;
	String msg;

	msg = abcdchk(A, B);
	if (length(msg) > 0) {
		error("ctrb(): " + msg);
	}

	n = Cols(A);
	if (isreal(A) && isreal(B)) {
		V = Z(1,n,B);
	} else {
		V = (Z(1,n,B),:);
	}

	if (version() == 4) {
		V(0,0,B) = B;
		for (i = 1; i <= n-1; i++) {
			V(0,i,B) = A*V(0,i-1,B);
		}
	} else {
		V(1,1,B) = B;
		for (i = 1; i <= n-1; i++) {
			V(1,i+1,B) = A*V(1,i,B);
		}
	}

	return V;
}
