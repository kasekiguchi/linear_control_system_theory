
/* -*- MaTX -*-
 *
 *  NAME
 *      PoleAssign() - Pole assignment of system
 *
 *  SYNOPSIS
 *      F = PoleAssign(A, B, Pole)
 *         Matrix F;
 *         Matrix A, B;
 *         CoMatrix Pole;
 *
 *      F = PoleAssign(A, B, Pole, batch)
 *         Matrix F;
 *         Matrix A, B;
 *         CoMatrix Pole;
 *         Integer batch;
 *
 *  DESCRIPTION
 *        A:    System matrix
 *        B:    Input matrix
 *        Pole: Complex column vector whose each
 *              element is a desired pole location
 *
 *        Ac = A + B*F
 *
 */

Matrix CoCanMat();
Polynomial CharPoly();

Func Matrix PoleAssign(A, B, P, batch, ...)
	Matrix A, B;
	CoMatrix  P;
	Integer batch;
{
	Matrix PoleAssignSISO(), PoleAssignMIMO(...);
	
	error(nargchk(3, 4, nargs, "PoleAssign"));

	if (nargs == 3) {
		batch = 1;
	}

	if (Cols(B) == 1) {
		return PoleAssignSISO(A, B, P);
	} else {
		return PoleAssignMIMO(A, B, P, batch);
	}
}

Func Matrix PoleAssignSISO(A, b, pole)
	Matrix A, b;
	CoMatrix pole;
{
	Matrix T, f, tmp;
	Polynomial s, p1, p2;
	Integer i, n;

	s = Polynomial("s");
	n = Rows(A);

	T = CoCanMat(A, b);
	p1 = CharPoly(A);

	tmp = s*ONE(n,1) - pole;
	p2 = Re(prod(tmp));
	if (version() == 4) {
		f = Matrix(p1 - p2) * T~;
	} else {
		f = fliplr(Matrix(p1 - p2)) * T~;
	}

	if (isreal(A) && isreal(b)) {
		return Re(f);
	} else {
		return f;
	}
}

Func Matrix PoleAssignMIMO(A, B, pole, batch, ...)
	Matrix A, B;
	CoMatrix pole;
	Integer batch;
{
	Integer i, m, n;
	Real a, b, eps;
	Matrix gzi, V, V1, V2, F;

	error(nargchk(3, 4, nargs, "PoleAssignMIMO"));

	if (nargs == 3) {
		batch = 1;
	}

	eps = EPS;

	n = Rows(A);
	m = Cols(B);

	V = Z(n,n);
	if (batch == 0) {
		gzi = Z(m,n);
		read gzi;
	} else {
		gzi = rand(m,n);
	}

	while (1) {
		for (i = 1; i <= n; i++) {
			a = Re(pole(i,1));
			b = Im(pole(i,1));

			if (abs(b) < eps) {	// pole(i) is real a real pole
				V(1:n,i) = (A - a*I(n))~ * B * gzi(1:m,i:i);
			} else { // pole(i) and pole(i+1) are complex conjugate poles
				V1 = ((A - a*I(n))^2 + b^2*I(n))~ * (A - a*I(n))*B;
				V2 = ((A - a*I(n))^2 + b^2*I(n))~ * (b*B);

				V(1:n,i)   = V1*gzi(*,i) - V2*gzi(*,i+1);
				V(1:n,i+1) = V1*gzi(*,i+1) + V2*gzi(*,i);
				i++;
			}
		}

		// V is a singular matrix
		if (minsing(V) < eps) {
			print "\n'gzi' is not a proper matrix.\n";
			print "Enter a matrix 'gzi' again.\n";
			pause;
		} else {
			break;
		}

		read gzi;
	}

	F = - gzi * V~;

	if (isreal(A) && isreal(B)) {
		return Re(F);
	} else {
		return F;
	}
}
