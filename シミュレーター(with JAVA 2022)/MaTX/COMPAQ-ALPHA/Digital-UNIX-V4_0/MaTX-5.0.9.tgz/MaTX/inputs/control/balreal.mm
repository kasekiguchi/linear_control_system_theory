
/* -*- MaTX -*-
 *
 *  NAME
 *      balreal() - Balanced state-space realization and model reduction
 *
 *  SYNOPSIS
 *      {Ab,Bb,Cb,G,T} = balreal(A,B,C)
 *         Matrix Ab,Bb,Cb,G,T;
 *         Matrix A,B,C;
 *
 *  DESCRIPTION
 *       balreal() returns a balanced state-space realization of the system.
 *       balreal() also returns a vector G containing the diagonal of the
 *       gramian of the balanced realization, and matrix T, the similarity
 *       transformation used to convert (A,B,C) to (Ab,Bb,Cb).  If the system
 *       (A,B,C) is normalized properly, small elements in gramian G
 *       indicate states that can be removed to reduce the model to lower
 *       order.
 *
 *  REFERENCES
 *      [1] Moore, B., Principal Component Analysis in Linear Systems:
 *          Controllability, Observability, and Model Reduction, IEEE 
 *          Transactions on Automatic Control, 26-1, Feb. 1981.
 *      [2] Laub, A., "Computation of Balancing Transformations", Proc. JACC
 *          Vol.1, paper FA8-E, 1980.
 *
 *  SEE ALSO
 *      minreal()
 */

Func List balreal(A, B, C)
	Matrix A, B, C;
{
	Matrix Ab, Bb, Cb, G, T;
	Matrix GG, Gc, Go, R, RGR, V, D;
	Index idx;
	String msg;

	msg = abcdchk(A, B, C);
	if (length(msg) > 0) {
		error("balreal(): " + msg);
	}

	Gc = gram(A, B);
	Go = gram(A#, C#);
	R = chol(Gc);
	RGR = R * Go * R#;
	RGR = tril(RGR) + tril(RGR, -1)#; // Make RGR exactly symmetric.
	{D, V} = eig(RGR);
	T = R# * V * vec2diag(diag2vec(D) .^ (-.25));
	Ab = T \ A * T;
	Bb = T \ B;
	Cb = C * T;
	G = diag2vec(gram(Ab, Bb))#;

	// Sort so G is in descending order
	{GG, idx} = sort(G);
	idx = idx(length(G):-1:1);
	Ab = Ab(idx,idx);
	Bb = Bb(idx,:);
	Cb = Cb(:,idx);

	T = T(idx,idx);
	G = G(idx);

	if (isreal(A) && isreal(B) && isreal(C)) {
		Ab = Re(Ab);
		Bb = Re(Bb);
		Cb = Re(Cb);
		T  = Re(T);
		G  = Re(G);
	}

	return {Ab, Bb, Cb, G, T};
}
