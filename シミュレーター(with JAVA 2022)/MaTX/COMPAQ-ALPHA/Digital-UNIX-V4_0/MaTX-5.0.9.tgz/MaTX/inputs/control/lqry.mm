
/* -*- MaTX -*-
 *
 *  NAME
 *      lqry() - Linear quadratic regulator design with output weighting
 *	             for continuous-time systems.
 *
 *  SYNOPSIS
 *      {K,P} = lqry(A,B,C,D,Q,R)
 *         Matrix K,P;
 *         Matrix A,B,C,D,Q,R;
 *
 *      {K,P} = lqry(A,B,C,D,Q,R,N)
 *         Matrix K,P;
 *         Matrix A,B,C,D,Q,R;
 *         Matrix N;
 *
 *  DESCRIPTION
 *      lqry() calculates the optimal feedback gain matrix K such
 *      that the feedback law  u = -Ky  minimizes the cost function:
 *
 *          J = Integral (y#Qy + u#Ru) dt
 *
 *      subject to the constraint equation: 
 *          .
 *          x = Ax + Bu,  y = Cx + Du
 *                
 *      Also returned is P, the steady-state solution to the associated 
 *      algebraic Riccati equation:
 *
 *         P A + A# P - P B R~ B# P + Q = 0
 *
 *  SEE AlSO
 *      lqr()
 */

Func List lqry(A, B, C, D, Q, R, N, ...)
	Matrix A, B, C, D, Q, R, N;
{
	Matrix K,P,NN,QQ,RR;
	String msg;

	error(nargchk(6, 7, nargs, "lqry"));

	msg = abcdchk(A, B, C, D);
	if (length(msg) > 0) {
		error("lqry(): " + msg);
	}

	if (nargs == 6) {
		N = Z(Rows(C),Cols(B));
	}
	QQ = C#*Q*C;
	RR = R + D#*N + N#*D + D#*Q*D;
	NN = C#*Q*D + C#*N;
	{K,P} = lqr(A,B,QQ,RR,NN);
	return {K,P};
}
