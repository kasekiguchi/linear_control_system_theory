
/* -* MaTX -*-
 *
 *  NAME
 *      c2d() - State space models from continuous to discrete time
 *
 *  SYNOPSIS
 *      {Phi, Gamma} = c2d(A,B,T)
 *         Matrix Phi, Gamma;
 *         Matrix A, B;
 *         Real T;
 *
 *  DESCRIPTION
 *       c2d() converts the continuous-time system:
 *      	.
 *      	x = Ax + Bu
 *
 *       to the discrete-time state-space system:
 *
 *      	x[n+1] = Phi * x[n] + Gamma * u[n]
 *
 *       assuming a zero-order hold on the inputs and sample time T.
 *
 *  SEE ALSO
 *      d2c()
 */

Func List c2d(A, B, T)
	Matrix A, B;
	Real T;
{
	Matrix Gamma, Phi, S;
	Integer m, n;
	String msg;

	msg = abcdchk(A, B);
	if (length(msg) > 0) {
		error("c2d(): " + msg);
	}

	n = Rows(A);
	m = Cols(B);
	S = exp([[  A,  B ]
			 [Z(m,m+n)]]*T);

	Phi = S(1:n,1:n);
	Gamma = S(1:n,n+1:n+m);

	return {Phi, Gamma};
}
