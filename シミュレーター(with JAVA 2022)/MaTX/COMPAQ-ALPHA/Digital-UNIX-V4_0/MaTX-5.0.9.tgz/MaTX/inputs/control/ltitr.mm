
/* -*- MaTX -*-
 *
 *  NAME
 *      ltitr() - Linear time-invariant time response
 *
 *  SYNOPSIS
 *      X = ltitr(A, B, U)
 *         Array X;
 *         Matrix A,B;
 *         Array U;
 *
 *      X = ltitr(A, B, U, x0)
 *         Array X;
 *         Matrix A,B;
 *         Array U;
 *         Matrix x0;
 *
 *  DESCRIPTION
 *      ltitr() calculates the time response of the system:
 *
 *         x[n+1] = Ax[n] + Bu[n]
 *
 *      to input sequence U. Matrix U must have as many rows as
 *      there are inputs, u. Each column of U corresponds to a new
 *      time point. ltitr() returns a matrix X with as many rows
 *      as there are outputs y, and with length(U) columns.
 *
 *      ltitr(..., x0) can be used if initial conditions exist.
 *      Here is what it implements, in high speed:
 *
 *  SEE ALSO
 *      ltifr()
 */ 

Func Matrix ltitr(A, B, U_, x0, ...)
	Matrix A;
	Matrix B;
	Matrix U_;
	Matrix x0;
{
	Integer i, n, k, flag;
	Matrix X, U, u, x;
	String msg;

	error(nargchk(3, 4, nargs, "ltitr"));

	msg = abcdchk(A, B);
	if (length(msg) > 0) {
		error("ltitr(): " + msg);
	}
	
	if (Rows(U_) > Cols(U_)) {
		flag = 1;
	} else {
		flag = 0;
	}

	if (flag) {
		U = trans(U_);
	} else {
		U = U_;
	}

	n = Cols(A);
	k = Cols(U);
	
	if (nargs == 3) {
		x0 = Z(n,1);
	}
	
	if (iscomplex(A) || iscomplex(B) || iscomplex(x0)) {
		X = (Z(n,k),:);
	} else {
		X = Z(n,k);
	}

	x = x0;
	for (i = 1; i <= k; i++) {
		X(:,i) = x;
		u = U(:,i);
		x = A*x + B*u;
	}

	if (flag) {
		return trans(X);
	} else {
		return X;
	}
}

