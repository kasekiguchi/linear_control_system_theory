
/* -*- MaTX -*-
 *
 *  NAME
 *      dlsim() - Simulation of discrete-time linear systems
 *
 *  SYNOPSIS
 *      {Y,X} = dlsim(A,B,C,D,U)
 *         Matrix Y, X;
 *         Matrix A,B,C,D;
 *         Matrix U;
 *
 *      {Y,X} = dlsim(A,B,C,D,U,x0)
 *         Matrix Y, X;
 *         Matrix A,B,C,D;
 *         Matrix U;
 *         Matrix x0;
 *
 *  DESCRIPTION
 *       dlsim() calculates the time response of the system:
 *		
 *         x[n+1] = Ax[n] + Bu[n],  y[n]   = Cx[n] + Du[n]
 *
 *       to input sequence U.  Array U must have as many columns as there
 *       are inputs, u.  Each column of U corresponds to a new time point.
 *       dlsim() returns a matrix Y with as many rows as there are outputs
 *       y, and with length(U) columns. dlsim() also returns the state time
 *       history.
 *
 *  SEE ALSO
 *      lsim()
 */

Func List dlsim(A, B, C, D, U, x0_, ...)
	Matrix A, B, C, D, x0_;
	Matrix U;
{
	Matrix X, Y, x0;
	String msg;

	error(nargchk(5, 6, nargs, "dlsim"));

	msg = abcdchk(A, B, C, D);
	if (length(msg) > 0) {
		error("dlsim(): " + msg);
	}

	if (nargs == 5) {
		x0 = Z(Rows(A),1);
	} else {
		x0 = x0_;
	}

	X = ltitr(A, B, U, x0);
	Y = C*X + D*U;
	return {Y, X};
}
