
/*  -*- MaTX -*-
 *
 *  NAME
 *      canon() - State-space to canonical form transformation
 *
 *  SYNOPSYS
 *      {ab,bb,cb,db,T} = canon(a,b,c,d)
 *        Matrix ab,bb,cb,db,T;
 *        Matrix a,b,c,d;
 *
 *      {ab,bb,cb,db,T} = canon(a,b,c,d,Type)
 *        Matrix ab,bb,cb,db,T;
 *        Matrix a,b,c,d;
 *        String Type;
 *
 *  DESCRIPTION
 *      canon(A,B,C,D,"type") transforms the continuous state-space 
 *      system (A,B,C,D) into the canonical form specified by
 *      type: "modal" transforms the state-space system into modal form 
 *             where the system eigenvalues appear on the diagonal. 
 *             The system must be diagonalizable.
 *
 *            "companion" transforms the state-space system into 
 *             companion canonical form where the characteristic
 *             polynomial appears in the right column.
 *
 *            "controllable" transforms the state-space system into 
 *             controllable canonical form where the characteristic
 *             polynomial appears in the last row.
 *
 *      Transformation matrix T is returned where z = Tx:
 *
 *      The modal form is useful for determining the relative
 *      controllability of the system modes.  Note: the companion 
 *      form is ill-conditioned and should be avoided if possible.
 *
 *  SEE ALSO
 *      ctrb() and ctrbf().
 */

Func List canon(a,b,c,d,Type, ...)
	Matrix a,b,c,d;
	String Type;
{
	Matrix T,ab,bb,cb,db,Vinv,Tinv_trans;
	CoMatrix D, V;
	Integer k;
	String msg;

	error(nargchk(4, 5, nargs, "canon"));

	msg = abcdchk(a, b, c, d);
	if (length(msg) > 0) {
		error("canon(): " + msg);
	}

	if (nargs == 4) {
		Type = "modal";
	}
  
	if (Type == "modal"(1:min(5,length(Type)))) {  // Modal form
		{D, V} = eig(a);
		k = 1;
		// Transformation to modal form based on eigenvectors
		T = [];
		while (k <= Rows(D)) {
			if (Im(D(k,k)) != 0.0) {
				T(:,k)   = Re(V(:,k));
				T(:,k+1) = Im(V(:,k));
				k = k + 2;
			} else {
				T(:,k) = V(:,k);
				k = k + 1;
			}
		}
		ab = T \ a * T;
		bb = T \ b;
		cb = c * T;
		db = d;
	} else if (Type == "companion"(1:min(9,length(Type)))) { // Companion form
		// Transformation to companion form based on controllability matrix
		if (length(b)) {
			T = ctrb(a,b(:,1));
			if (1/cond(T) < EPS) {
				error("canon(): System must be controllable from first input.\n");
			}
		} else {
			T = [];
		}
		ab = T \ a * T;
		bb = T \ b;
		cb = c * T;
		db = d;
	} else if (Type == "controllable"(1:min(12,length(Type)))) {
		// Controllable form

		// Transformation to companion form based on controllability matrix
		if (length(b)) {
			V = ctrb(a,b(:,1));
			if (1/cond(V) < EPS) {
				error("canon(): System must be controllable from first input.\n");
			}
			Vinv = inv(V);
			Tinv_trans = ctrb(a#, Vinv(Rows(V),:)#);
			T = (Tinv_trans#)~;
		} else {
			T = [];
		}

		ab = T \ a * T;
		bb = T \ b;
		cb = c * T;
		db = d;
	} else {
		error("canon(): TYPE must be either \"modal\", \"companion\" or \"controllable\".\n");
	}
	
	// Return inverse of T to be compatible with ss2ss()
	T = T~;
	
	return {ab,bb,cb,db,T};
}
