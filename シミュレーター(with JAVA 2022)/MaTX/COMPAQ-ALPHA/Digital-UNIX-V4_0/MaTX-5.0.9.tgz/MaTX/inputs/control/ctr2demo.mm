
/*  -*- MaTX -*-
 *
 *  NAME
 *      ctr2demo() - Demonstration of control toolbox
 *
 *  SYNOPSIS
 *      ctr2demo()
 */

Func void ctr2demo()
{
	List mm;
	Integer i;
	void pgm2_1(), pgm2_2();
	
	mm = {"Pole Assignment",
		  "Using a transformation matrix",
		  "Ackermann's method",
		  "Quit"};

	i = 1;
	for (;;) {
		i = menu(mm, i);
		switch (i) {
		  case 1:
			pgm2_1();
			break;
		  case 2:
			pgm2_2();
			break;
		  default:
			return;
			break;
		}
		i++;
	}
}

/*
 * Determination of state feedback gain matrix K by
 * use of transformation matrix T
 */
Func void pgm2_1()
{
	Real a1, a2, a3, aa1, aa2, aa3;
	Real k1, k2, k3;
	Complex i;
	Matrix A, B, C, D;
	Matrix M, W, T, JA, J, JJ, K;

	print "\nSolve pole assignment problem using a trasformation matrix\n";

	print "\nInput A, B, C, and D matrices\n\n";

	print "  A = [[ 0    1   0]\n";
	print "       [ 0    0   1]\n";
	print "       [-6, -11, -6]]\n";
	print "  B = [[0]\n";
	print "       [0]\n";
	print "       [10]]\n";
	print "  C = [1 0 0]\n";
	print "  D = [0]\n";
	pause;

	print A = [[ 0    1   0]
			   [ 0    0   1]
			   [-6, -11, -6]];
	print B = [[0]
			   [0]
			   [10]];
	print C = [1 0 0];
	print D = [0];

	print "\nCalclate controllability matrix M\n";
	print "  M = ctrb(A, B)\n";
	pause;

	print M = ctrb(A, B);

	print "\nCheck the controllability\n";
	print "  rank(M)\n";
	pause;

	print rank(M);

	print "\nCalculate the characteristic polynomial of A ";
	print "and its coefficients\n";
	print "  JA = poly(A)\n";
	print "  a1 = JA(2); a2 = JA(3); a3 = JA(4);\n";
	pause;

	print JA = poly(A);
	a1 = JA(2); a2 = JA(3); a3 = JA(4);

	print "\nCalculate the transformation matrix T to";
	print "controllable canonical form.\n";
	print "  W = [[a2 a1 1]\n";
	print "       [a1  1 0]\n";
	print "       [ 1  0 0]];\n";
	print "  T = M*W\n";
	pause;

	W = [[a2 a1 1]
		 [a1  1 0]
		 [ 1  0 0]];

	print T = M * W;

	print "\nCalculate the characteristic polynomial\n";
	print "whose roots are desired closed-loop poles.\n";

	print "  i = (0,1);\n";
	print "  J = diag(-2+2*sqrt(3.0)*i, -2-2*sqrt(3.0)*i, -10.0)\n";
	print "  JJ = poly(J)\n";
	print "  aa1 = JJ(2); aa2 = JJ(3); aa3 = JJ(4);\n";
	pause;

	i = (0,1);
	J = diag(-2+2*sqrt(3.0)*i, -2-2*sqrt(3.0)*i, (-10.0,0));
	print JJ = Re(poly(J));
	aa1 = JJ(2); aa2 = JJ(3); aa3 = JJ(4);

	print "\nCalculate state feedback gain matrix K\n";
	print "  K = [aa3 - a3, aa2 - a2 aa1 -a1]\n";
	print "  k1 = K(1); k2 = K(2); k3 = K(3);\n";
	pause;

	print K = [aa3 - a3, aa2 - a2 aa1 -a1];
	k1 = K(1); k2 = K(2); k3 = K(3);	

	pause;
}

/*
 * Determination of state feedback gain matrix K by use
 * of Ackermann's formula
 */
Func void pgm2_2()
{
	Complex i;
	Real k1, k2, k3;
	Matrix A, B, P, M, K;

	print "\nSolve a pole assignment problem by Ackermann's method\n";

	print "\nInput A and B matrices\n";
	print "  A = [[ 0    1   0]\n";
	print "       [ 0    0   1]\n";
	print "       [-6, -11, -6]]\n";
	print "  B = [[0]\n";
	print "       [0]\n";
	print "       [10]]\n";
	pause;

	print A = [[ 0    1   0]
			   [ 0    0   1]
			   [-6, -11, -6]];
	print B = [[0]
			   [0]
			   [10]];

	print "\nCalculate controllability matrix M.\n";
	print "  M = ctrb(A,B)\n";
	pause;

	print M = ctrb(A,B);

	print "\nCheck controllability\n";
	print "  rank(M)\n";
	pause;

	print rank(M);

	print "\nMake a vector P whose elements are desired closed-loop poles.\n";
	print "  i = (0,1);\n";
	print "  P = [[-2+2*sqrt(3.0)*i]\n";
	print "       [-2-2*sqrt(3.0)*i]\n";
	print "       [      -10       ]]\n";
	pause;

	i = (0,1);
	print P = [[-2+2*sqrt(3.0)*i]
			   [-2-2*sqrt(3.0)*i]
			   [       -10      ]];

	print "\nCalculate state feedback gain K by Ackermann's method\n";
	print "  K = - PoleAssign(A, B, P)\n";
	print "  k1 = K(1); k2 = K(2); k3 = K(3);\n";
	pause;

	print K = - PoleAssign(A, B, P);
	k1 = K(1); k2 = K(2); k3 = K(3);	

	pause;
}
