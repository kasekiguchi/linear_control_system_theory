
/* -*- MaTX -*-
 *
 *  NAME
 *      CharPoly() - Characteristic polynomial by Faddeev's algorithm
 *
 *  SYNOPSIS
 *      p = CharPoly(A)
 *        Polynomial p;
 *        Matrix A;
 *
 *  DESCRIPTION
 *      CharPoly() is obsolete.
 *
 *      Use p = makepoly(A)  for  p = CharPoly(A)
 */

Func Polynomial CharPoly(A)
	Matrix	A;
{
	return makepoly(A);
/*
	Integer	i, n;
	Matrix Gamma, AA;
	Polynomial ch;

	n = Rows(A);
	AA = (A,:);
	Gamma = Z(n, 1, AA);
	ch = Polynomial((Z(1,n+1),:));

	ch(n) = 1.0;
	
	if (version() == 4) {
		Gamma(n-1, 0, AA) = I(n);
	} else {
		Gamma(n, 1, AA) = I(n);
	}
	ch(n-1) = - trace(AA);
	
	for (i = n-2; i >= 0; i--) {
		if (version() == 4) {
			Gamma(i, 0, AA) = AA*Gamma(i+1, 0, AA) + ch(i+1)*I(n);
			ch(i) = - trace(AA*Gamma(i, 0, AA)) / (n - i);
		} else {
			Gamma(i+1, 1, AA) = AA*Gamma(i+2, 1, AA) + ch(i+1)*I(n);
			ch(i) = - trace(AA*Gamma(i+1, 1, AA)) / (n - i);
		}
	}

	if (isreal(A)) {
		return Re(ch);
	} else {
		return ch;
	}
*/
}
