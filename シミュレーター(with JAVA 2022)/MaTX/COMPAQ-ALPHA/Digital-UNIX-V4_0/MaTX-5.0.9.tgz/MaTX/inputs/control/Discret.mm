
/* -*- MaTX -*-
 *
 *  NAME
 *      Discretize() - State space models from continuous to discrete time
 *
 *  SYNOPSIS
 *      {Phi, Gamma} = Discretize(A,B,T)
 *         Matrix Phi, Gamma;
 *         Matrix A,B;
 *         Real T;
 *
 *  DESCRIPTION
 *      Discretize() is obsolite.
 *
 *      Use  {Phi,Gamma} = c2d(A,B,T)  for  {Phi,Gamma} = Discretize(A,B,T).
 *
 *  SEE ALSO
 *      c2d() and d2c()
 */

Func List Discretize(A, B, T)
	Matrix A, B;
	Real T;
{
	return c2d(A, B, T);
}
