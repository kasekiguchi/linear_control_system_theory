
/*  -*- MaTX -*-
 *
 *  NAME
 *      tzero() - Transmission zeros
 *
 *  SYNOPSIS
 *      z = tzero(a,b,c,d)
 *         CoMatrix z;
 *         Matrix a,b,c,d;
 *
 *  DESCRIPTION
 *      tzero() returns the transmission zeros of the state-space system:
 *   		.
 *   		x = Ax + Bu
 *   		y = Cx + Du
 *
 *      Care must be exercised to disregard any large zeros that may
 *      actually be at infinity. 
 *
 *  REFERENCES
 *      [1] A.J Laub and B.C. Moore, Calculation of Transmission Zeros
 *          Using QZ Techniques, Automatica, 14, 1978, p557
 *      [2] A. Emami-Naeini and P. Van Dooren, Computation of Zeros of
 *          Linear Multivariable Systems, Automatica, Vol. 14, No. 4,
 *          pp. 415-430, 1982.
 *
 *  SEE ALSO
 *      poles()
 */

Func CoMatrix tzero(a,b,c,d)
	Matrix a,b,c,d;
{
	Integer i,m,n,nz,r;
	Real nrm;
	Matrix aa,aa1,aa2,bb;
	CoMatrix z, z1, z2;
	String msg;

	msg = abcdchk(a, b, c, d);
	if (length(msg) > 0) {
		error("tzero(): " + msg);
	}

	{n,m} = size(b);
	{r,n} = size(c);
	aa = [[a b][c d]];

	if (m == r) {
		bb = Z(aa);
		bb(1:n,1:n) = I(n);
		z = eigval(aa,bb);
		z = z( ! isnan(z) && isfinite(z)); // Punch out NaN's and Inf's
	} else {
		nrm = norm(aa,1);
		if (m > r) {
			aa1 = [[aa][nrm*(rand(m-r,n+m) .- .5)]];
			aa2 = [[aa][nrm*(rand(m-r,n+m) .- .5)]];
		} else {
			aa1 = [aa nrm*(rand(n+r,r-m) .- .5)];
			aa2 = [aa nrm*(rand(n+r,r-m) .- .5)];
		}
		bb = Z(aa1);
		bb(1:n,1:n) = I(n);
		z1 = eigval(aa1,bb);
		z2 = eigval(aa2,bb);
		z1 = z1( ! isnan(z1) && isfinite(z1));   // Punch out NaN's and Inf's
		z2 = z2( ! isnan(z2) && isfinite(z2));
		nz = length(z1);
		for (i = 1; i <= nz; i++) {
			if (any(abs(Array(z1(i) .- z2)) .< nrm*sqrt(EPS))) {
				z = [[z][z1(i)]];
			}
		}
	}
	return z;
}
