
/*  -*- MaTX -*-
 *
 *  NAME
 *      lyap() - Lyapunov equation
 *
 *  SYNOPSIS
 *      P = lyap(A,Q)
 *         Matrix P;
 *         Matrix A,Q;
 *
 *      P = lyap(A,B,Q)
 *         Matrix P;
 *         Matrix A,B;
 *         Matrix Q;
 *
 *  DESCRIPTION
 *    	 lyap(A,Q) solves the special form of the Lyapunov matrix equation:
 *
 *    		A*P + P*A# = -Q
 *
 *    	 lyap(A,B,Q) solves the general form of the Lyapunov matrix equation:
 *
 *    		A*P + P*B = -Q
 *
 *	SEE ALSO
 *      dlyap().
 *
 */

Func Matrix lyap(A, B_, Q_, ...)
	Matrix A, B_, Q_;
{
	Matrix B,Q,P,ema,uqu,y;
	CoMatrix ua,ta,ub,tb;
	Integer ma,mb,mq,na,nb,nq,real_flg,k;
	Index km1;
	Array p1,p2,sum_;
	String msg;

	error(nargchk(2, 3, nargs, "lyap"));

	if (nargs == 2) {
		Q = B_;
		B = A#;

		msg = abcdchk(A);
		if (length(msg) > 0) {
			error("lyap(): " + msg);
		}
	} else {
		B = B_;
		Q = Q_;

		msg = abcdchk(A,B);
		if (length(msg) > 0) {
			error("lyap(): " + msg);
		}
	}

	{ma,na} = size(A);
	{mb,nb} = size(B);
	{mq,nq} = size(Q);

	if (ma != na || mb != nb || mq != ma || nq != mb) {
		 error("lyap(): Dimensions do not agree.\n");
	}

	// Check if problem has any complex inputs
	real_flg = 1;
	if (iscomplex(A) || iscomplex(B) || iscomplex(Q)) {
		real_flg = 0;
	}

	/*
	 * Perform schur decomposition on A and B (note: complex schur form
	 * forced by adding small complex part so ua and ub are complex upper
	 * triangular)
	 */
	{ua,ta} = schur(A);
	{ua,ta} = rsf2csf(ua,ta);
	{ub,tb} = schur(B);
	{ub,tb} = rsf2csf(ub,tb);

	// Check all combinations of ua(i,i)+ub(j,j) for zero
	p1 = ONE(mb,1)*diag_vec(ta)#;
	p2 = diag_vec(tb)*ONE(1,ma);
	sum_ = abs(p1) + abs(p2);
	
	if (any(sum_ .== 0) || any(abs(p1 + p2) < 1000*EPS*sum_)) {
		error("lyap(): Solution is not unique.\n");
	}

	uqu = -ua#*Q*ub;  // Transform Q

	// Solve for first column of transformed solution
	y = (Z(ma,mb),:);
	ema = I(ma);
	y(:,1) = (ta + ema*tb(1,1)) \ uqu(:,1);

	// Solve for remaining columns of transformed solution
	for (k = 2; k <= mb; k++) {
		km1 = [1:(k-1)];
		y(:,k) = (ta + ema*tb(k,k)) \ (uqu(:,k) - y(:,km1)*tb(km1,k));
	}

	P = ua*y*ub#;  // Find untransformed solution 

	// Ignore complex part if real inputs
	if (real_flg) {
		P = Re(P);
	}
	return P;
}
