
/*  -*- MaTX -*-
 *
 *  NAME
 *      ctrldemo() -
 *
 *  SYNOPSIS
 *      ctrldemo()
 */

Func void ctrldemo()
{
	Integer win;
	Matrix a,b,c,d,den1,den2,k,num,q,r,p,t;
	Matrix Wn,den,w,y,z;
	Array mag, phase_;
	CoMatrix ro;
	Polynomial s;
	Rational G;

	win = mgplot_cur_win();

	clear;
	print "\n";
	print "This demo shows the use of some of the control system designn\n";
	print "and analysis tools available in MaTX.\n\n";
	pause;

	print "\n";
	print "Suppose we start with a plant description in transfer function ";
	print "form:\n";
	print "                   2                    \n";
	print "              0.2 s  +  0.3 s  +  1     \n";
	print "H(s)  =  -------------------------------\n";
	print "           2                            \n";
	print "         (s  +  0.4 s  +  1) (s  +  0.5)\n";
	print "\n";
	print "We define the polynomail variable 's', then enter the transfer ";
	print "function:\n";
	print "\n";
	print "\ts = Polynomial(\"s\");\n";
	print "\tG = (0.2*s^2 + 0.3*s + 1)/((s^2 + 0.4*s + 1)*(s + 0.5));\n\n";
	pause;

	s = Polynomial("s");
	G = (0.2*s^2 + 0.3*s + 1)/((s^2 + 0.4*s + 1)*(s + 0.5));

	print "\n";
	print "We can get the coefficients of the numerator and the demonimator.";
	print "\n";
	print "\n";
	print "\t{num,den} = tfm2tf([G],1);\n";
	print "\tprint num, den;\n";
	print "\n";
	pause;

	{num,den} = tfm2tf([G],1);
	print num, "\n", den, "\n";

	print "\n";
	print "We can look at the natural frequencies and damping factors of ";
	print "the plant poles:\n\n";
	print "\t{Wn,z} = damp(den);\n";
	print "\tprint Wn,z;\n\n";
	pause;
	
	{Wn,z} = damp(den);
	print Wn, "\n", z, "\n";

	print "\n";
	print "A root-locus can be obtained by defining a vector of desired\n";
	print "gains, and then using rlocus():\n";
	print "\n";
	print "\tk = [0:.5:10];\n";
	print "\tro = rlocus(num,den,k);\n";
	print "\n";
	pause;

	k = [0:.5:10];
	ro = rlocus(num,den,k);

	print "\r                    \r";
	print "\tmgplot(win,Re(ro),Im(ro));\n";
	print "\tmgplot_title(win,\"Root-locus\");\n";
	print "\tmgplot_xlabel(win,\"Real part\");\n";
	print "\tmgplot_ylabel(win,\"Imag part\");\n";
	print "\n";
	pause "Strike any key for plot";

	mgplot_reset(win);
	mgplot_title(win,"Root-locus");
	mgplot_xlabel(win,"Real part");
	mgplot_ylabel(win,"Imag part");
	mgplot(win,Re(ro),Im(ro),{"","",""},{"1","1","1"});

	print "\n";
	print "The plant may be converted to a state space representation\n";
	print "\t .           \n";
	print "\t x = Ax + Bu \n";
	print "\t y = Cx + Du \n";
	print "\n";
	print "using the tf2ss command:\n";
	print "\n";
	print "\t{a,b,c,d} = tf2ss(num,den);\n";
	print "\n";
	pause "Strike any key to see a, b, c, and d";

	{a,b,c,d} = tf2ss(num,den);
	print "\n";
	print a,"\n", b,"\n",c,"\n",d,"\n";

	print "\n";
	print "For systems described in state-space or by transfer functions,\n";
	print "the step response is found by first defining a time axis and\n";
	print "then using the step() function:\n";
	print "\n";
	print "\tt = [0:0.3:15];\n";
	print "\t{y} = step(a,b,c,d,1,t);\n";
	print "\n";
	pause;

	t = [0:0.3:15];
	{y} = step(a,b,c,d,1,t);

	print "\r                    \r";
	print "\tmgplot(win,t,y,{\"y\"});\n";
	print "\tmgplot_title(win,\"Step response\");\n";
	print "\tmgplot_xlabel(win,\"time(sec)\");\n";
	print "\n";
	pause "Strike any key for plot";

	mgplot_reset(win);
	mgplot(win,t,y,{"y"});
	mgplot_title(win,"Step response");
	mgplot_xlabel(win,"time(sec)");

	print "\n";
	print "The frequency response is found by defining a logarithmically\n";
	print "spaced frequency axis, and then using the bode() function:\n";
	print "                            -1      1\n";
	print "this is 50 points between 10  and 10 \n\n";
	print "\tw = logspace(-1.0, 1.0);\n";
	print "\t{mag,phase} = bode(a,b,c,d,1,w);\n";
	print "\tmag = 20*log10(mag)\n";
	print "\n";
	pause;

	w = logspace(-1.0, 1.0);
	{mag,phase_} = bode(a,b,c,d,1,w);
	mag = 20*log10(mag);

	print "\r                    \r";
	print "\tmgplot_semilogx(win1,w,mag,{\"magnitude\"});\n";
	print "\tmgplot_title(win1,\"Magnitude response\");\n";
	print "\tmgplot_xlabel(win1,\"Radians/s\");\n";
	print "\n";

	print "\tmgplot_semilogx(win2,w,phase,{\"phase\"});\n";
	print "\tmgplot_title(win2,\"Phase response\");\n";
	print "\tmgplot_xlabel(win2,\"Radians/s\");\n";
	print "\n";

	pause "Strike any key for plot";

	mgplot_reset(win);
	mgplot_hold(win, 1);
	mgplot_subplot(win,2,1,1);
	mgplot_title(win,"Magnitude response");
	mgplot_xlabel(win,"Radians/s");
	mgplot_semilogx(win,w,mag,{"magnitude"});

	mgplot_subplot(win,2,1,2);
	mgplot_title(win,"Phase response");
	mgplot_xlabel(win,"Radians/s");
	mgplot_semilogx(win,w,phase_,{"phase"});
	mgplot_hold(win, 0);
}
