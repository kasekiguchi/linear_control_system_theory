
/* -*- MaTX -*-
 *
 *  NAME
 *      tfm2tf() - Transfer function matrix to transfer function conversion.
 *
 *  SYNOPSIS
 *     {NUM,den} = tfm2tf(G)
 *        Matrix NUM, den;
 *        RaMatrix G;
 *
 *     {NUM,den} = tfm2tf(G,iu)
 *        Matrix NUM, den;
 *        RaMatrix G;
 *        Integer iu;
 *
 *  DESCRIPTION
 *      tfm2tf() calculates the transfer function representation:
 *          .                              -1
 *          x = Ax + Bu    G(s) = C (sI - A) B + D
 *          y = Cx + Du
 *
 *      of the system:
 *                  NUM(s) 
 *         G(s) = --------
 *                  den(s)
 *
 *      from the iu'th input.  G contains transfer function matrix.
 *      Vector den contains the coefficients of the denominator in descending
 *      powers of s.  The numerator coefficients are returned in matrix NUM
 *      with as many rows as there are outputs y.
 *
 *  SEE ALSO
 *      ss2tf(), tf2zp() and tfm2ss()
 */

Func List tfm2tf(G, iu, ...)
	RaMatrix G;
	Integer iu;
{
	Matrix A, B, C, D, NUM, den;

	error(nargchk(1, 2, nargs, "tfm2tf"));
	
	if (nargs == 1) {
		iu = 1;
	}

	{A,B,C,D} = tfm2ss(G,iu);
	{NUM,den} = ss2tf(A,B,C,D,iu);
	return {NUM, den};
}
