
/*  -*- MaTX -*-
 *
 *  NAME
 *      c2dt() - Continuous state space models to discrete models
 *	             with pure time delay in the inputs.
 *
 *  SYNOPSIS
 *      {Ad,Bd,Cd,Dd} = c2dt(A,B,C,T,lambda)
 *         Matrix Ad,Bd,Cd,Dd;
 *         Matrix A,B,C;
 *         Real T,lambda;
 *
 *  DESCRIPTION
 *       c2dt() converts the continuous time system
 *          .
 *          x(t) = Ax(t) + Bu(t-lambda)
 *          y(t) = Cx(t) + Du(t)
 *
 *       to the discrete system with sample time T,
 *
 *          x(k+1) = Ad x(k) + Bd u(k)
 *          y(k)   = Cd x(k) + Dd u(k) 
 *
 *  REFERENCES
 *       [1]  Franklin and Powell, Digital Control; Addison and Wesley;
 *            1980 chapter 6, pages 171-177, with extension for
 *            multivariable controls and outputs.
 *
 */

Func List c2dt(A,B,C,T,lambda)
	Matrix A,B,C;
	Real T,lambda;
{
	Matrix Gamma,H,J,Phi,GAMMA1,GAMMA2,PHI1,s1,s2,s3,s4,s5,s6;
	Integer nc,no,ns,l;
	Real m;
	String msg;

	msg = abcdchk(A, B, C);
	if (length(msg) > 0) {
		error("c2dt(): " + msg);
	}

	{ns,nc} = size(B);
	{no,ns} = size(C);
	l = Integer(ceil(lambda/T));
	m = l*T - lambda;

	s1 = exp([[A*m, B*m][Z(nc,ns+nc)]]);
	s2 = exp([[A*(T-m), B*(T-m)][Z(nc,ns+nc)]]);

	PHI1 = s1(1:ns,1:ns)*s2(1:ns,1:ns);
	GAMMA1 = s1(1:ns,1:ns)*s2(1:ns,ns+1:ns+nc);
	GAMMA2 = s1(1:ns,ns+1:ns+nc);
	if (l == 0) {
		// This is the modified z-transform case
		Phi   = PHI1;
		Gamma = PHI1 * GAMMA2 + GAMMA1;
		H     =  C;
		J     =  C * GAMMA2;
		//	delay less than one period
	} else if (l == 1) {
		s6 = Z(nc,ns+l*nc);

		Phi   = [[PHI1, GAMMA1][s6]];
		Gamma = [[GAMMA2][I(nc)]];
		H     =  [C,Z(no,nc)];
		J     =  Z(no,nc);
	} else {
		s3 = I((l-1)*nc);
		s4 = Z(ns,(l-2)*nc);
		s5 = Z((l-1)*nc,ns+nc);
		s6 = Z(nc,ns+l*nc);

		Phi   =  [[PHI1,GAMMA1,GAMMA2,s4][s5,s3][s6]];
		Gamma =  [[Z(ns+(l-1)*nc,nc)][I(nc)]];
		H     =  [C,Z(no,l*nc)];
		J     =  Z(no,nc);
	}
	
	return {Phi, Gamma, H, J};
}
