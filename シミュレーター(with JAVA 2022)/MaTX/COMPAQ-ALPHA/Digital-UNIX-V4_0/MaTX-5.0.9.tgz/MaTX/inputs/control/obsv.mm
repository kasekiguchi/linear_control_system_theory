
/* -*- MaTX -*-
 *
 *  NAME
 *      obsv() - Form observability matrix 
 *
 *  SYNOPSIS
 *      Ob = obsv(A,C)
 *         Matrix Ob;
 *         Matrix A,C;
 *
 *  DESCRIPTION
 *      obsv() returns the observability matrix Ob = [[C][CA][CA^2 ...]]
 *
 *  SEE ALSO
 *      ctrb() and obsvf()
 */

Func Matrix obsv(A, C)
	Matrix A, C;
{
	return ctrb(A#, C#)#;
/*
	Matrix Ob;
	Integer i, m, n;

	{m,n} = size(A);
	Ob = C;
	for (i = 1; i <= n-1; i++) {
		Ob = [[C][Ob*A]];
	}
	return Ob;
*/
}
