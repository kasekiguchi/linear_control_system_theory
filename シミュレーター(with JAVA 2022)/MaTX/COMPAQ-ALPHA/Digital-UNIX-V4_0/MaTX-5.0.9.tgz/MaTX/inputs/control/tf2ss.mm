
/* -*- MaTX -*-
 *
 *  NAME
 *      tf2ss() -  Transfer function to state-space conversion
 *
 *  SYNOPSIS
 *      {A,B,C,D} = tf2ss(NUM, den)
 *          Matrix NUM, den;
 *          Matrix A,B,C,D;
 *
 *  DESCRIPTION
 *       tf2ss() calculates the state-space representation:
 *           .
 *           x = Ax + Bu,  y = Cx + Du
 *
 *       of the system:
 *
 *                  NUM(s) 
 *          H(s) = --------
 *                  den(s)
 *
 *       from a single input.  Vector 'den' must contain the coefficients of
 *       the denominator in descending powers of s.  Matrix 'NUM' must contain
 *       the numerator coefficients with as many rows as there are outputs y.
 *       The A,B,C,D matrices are returned in controller canonical form.  This 
 *       calculation also works for discrete systems but the numerator must be
 *       padded with trailing zeros to make it the same length as the
 *       denominator.
 *
 *  SEE ALSO
 *      ss2tf(), tf2zp() and tfm2ss()
 */

Func List tf2ss(NUM_, den_)
	Matrix NUM_, den_;
{
	Matrix A,B,C,D,NUM,den;
	Integer n,mden,mnum,nnum;
	Index inz;

	NUM = NUM_;
	den = den_;

	{mnum,nnum} = size(NUM);
	{mden,n} = size(den);

	// Strip leading zeros from denominator
	inz = find(den .!= 0);
	if (length(inz) > 0) {
		den = den(inz(1):n);
	} else {
		den = [1];
	}
	{mden,n} = size(den);

	// Check for proper numerator
	if (nnum > n) {
		// Try to strip leading zeros to make proper
		if (all(NUM(:,1:nnum-n) .== 0)) {
			NUM = NUM(:,nnum-n+1:nnum);
			{mnum,nnum} = size(NUM);
		} else {
			error("tf2ss(): Denominator must be higher order than numerator.\n");
		}
	}

	/*
	 *	Pad numerator with leading zeros, to make it have the same number
	 *	of columns as the denominator, and normalize it to den(1)
	 */
	NUM = [Z(mnum,n-nnum), NUM]/den(1);

	// Do the D-matrix first
	D = NUM(:,1);

	// Handle special constant case:
	if (n == 1) {
		A = [];
		B = [];
		C = [];
		return {A,B,C,D};
	}

	// Now do the rest, starting by normalizing den to den(1),
	den = den(2:n)/den(1);
	A = [[-den][I(n-2,n-1)]];
	B = I(n-1,1);
	C = NUM(:,2:n) - NUM(:,1)*den;

	return {A,B,C,D};
}
