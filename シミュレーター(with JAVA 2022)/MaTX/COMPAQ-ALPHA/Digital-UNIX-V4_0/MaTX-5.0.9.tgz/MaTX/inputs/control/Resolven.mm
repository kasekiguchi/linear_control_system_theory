
/* -*- MaTX -*-
 *
 *  NAME
 *      Resolvent()     - Calculate resolvent matrix (s*I - A)^(-1) of matrix A
 *      NumeResolvent() - Calculate the numerator of a resolvent matrix
 *
 *  SYNOPSIS
 *      R = Resolvent(A)
 *         Matrix R;
 *         Matrix A;
 */

Func Matrix Resolvent(A)
	Matrix	A;
{
	Matrix	Gamma, N, R, AA;
	Polynomial s, ch;
	Integer	n, i;

	s = Polynomial("s");
	n = Rows(A);
	AA = (A,:);
	Gamma = Z(n, 1, AA);
	ch = Polynomial((Z(1,n+1),:));

	ch(n) = 1.0;
	
	if (version() == 4) {
		Gamma(n-1, 0, AA) = I(n);
	} else {
		Gamma(n, 1, AA) = I(n);
	}
	ch(n-1) = - trace(AA);
	
	if (version() == 4) {
		for (i = n-2; i >= 0; i--) {
			Gamma(i, 0, AA) = AA*Gamma(i+1, 0, AA) + ch(i+1)*I(n);
			ch(i) = - trace(AA*Gamma(i, 0, AA)) / (n - i);
		}
	} else {
		for (i = n-2; i >= 0; i--) {
			Gamma(i+1, 1, AA) = AA*Gamma(i+2, 1, AA) + ch(i+1)*I(n);
			ch(i) = - trace(AA*Gamma(i+1, 1, AA)) / (n - i);
		}
	}

	N = Z(n, n);
	if (version() == 4) {
		for (i = 0; i < n; i++) {
			N = N + Gamma(i, 0, AA) * s^i;
		}
	} else {
		for (i = 0; i < n; i++) {
			N = N + Gamma(i+1, 1, AA) * s^i;
		}
	}

	R = N / ch;

	if (isreal(A)) {
		return Re(R);
	} else {
		return R;
	}
}

Func Matrix NumeResolvent(A)
	Matrix	A;
{
	Matrix	Gamma, N, AA;
	Polynomial s, ch;
	Integer	n, i;

	s = Polynomial("s");
	n = Rows(A);
	AA = (A,:);
	Gamma = Z(n, 1, AA);
	ch = Polynomial((Z(1, n+1),:));

	ch(n) = 1.0;
	
	if (version() == 4) {
		Gamma(n-1, 0, AA) = I(n);
	} else {
		Gamma(n, 1, AA) = I(n);
	}
	ch(n-1) = - trace(AA);
	
	if (version() == 4) {
		for (i = n-2; i >= 0; i--) {
			Gamma(i, 0, AA) = AA*Gamma(i+1, 0, AA) + ch(i+1)*I(n);
			ch(i) = - trace(AA*Gamma(i, 0, AA)) / (n - i);
		}
	} else {
		for (i = n-2; i >= 0; i--) {
			Gamma(i+1, 1, AA) = AA*Gamma(i+2, 1, AA) + ch(i+1)*I(n);
			ch(i) = - trace(AA*Gamma(i+1, 1, AA)) / (n - i);
		}
	}

	N = (Z(n,n),:);
	if (version() == 4) {
		for (i = 0; i < n; i++) {
			N = N + Gamma(i, 0, AA) * s^i;
		}
	} else {
		for (i = 0; i < n; i++) {
			N = N + Gamma(i+1, 1, AA) * s^i;
		}
	}

	if (isreal(A)) {
		return Re(N);
	} else {
		return N;
	}
}
