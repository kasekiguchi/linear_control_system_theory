
/*  -*- MaTX -*-
 *
 *  NAME
 *      dbalreal() - Discrete balanced state-space realization and
 *                   model reduction
 *
 *  SYNOPSIS
 *      {Ab,Bb,Cb,M,T} = dbalreal(A,B,C)
 *         Matrix Ab,Bb,Cb,M,T;
 *         Matrix A,B,C;
 *
 *  DESCRIPTION
 *       dbalreal() returns a balanced state-space realization of the system.
 *       dbalreal() also returns a vector M containing the diagonal
 *       of the gramian of the balanced realization, and matrix T, the
 *       similarity transformation used to convert (A,B,C) to (Ab,Bb,Cb).
 *
 *       If the system (A,B,C) is normalized properly, small elements in 
 *       gramian M indicate states that can be removed to reduce the model
 *       to lower order.
 *
 *  SEE ALSO
 *      dmodred(), balreal() and modred().
 *
 */

Func List dbalreal(A, B, C)
	Matrix A, B, C;
{
	Matrix T, Ab, Bb, Cb, M;
	Matrix D, Gc, Go, R, V, U;
	String msg;

	msg = abcdchk(A, B, C);
	if (length(msg) > 0) {
		error("dbalreal(): " + msg);
	}

	Gc = dgram(A, B);
	Go = dgram(A#, C#);
	R = chol(Gc);
	/*
	 *	{V, D} = eig(R * Go * R#);
	 *	Fix because symmetrix matrix does not have orthogonal eigenvalues
	 */
	{U, D, V} = svd(R * Go * R#);
	D = D .* sgn(U# * V);
	T = R# * V * vec2diag(diag2vec(D) .^ (-0.25));
	Ab = T \ A * T;
	Bb = T \ B;
	Cb = C * T;
	M = diag2vec(dgram(Ab,Bb))#;

	return {Ab, Bb, Cb, M, T};
}
