
/*  -*- MaTX -*-
 *
 *  NAME
 *      LS() - Parameter estimation by Batch Least Squres method
 *
 *  SYNOPSIS
 *      th = LS(Y, U, n, phi)
 *        Matrix th;
 *        Array Y,U;
 *        Integer n;
 *        Matrix phi();
 *
 *  DESCRIPTION
 *      LS() estimates the parameters of the linear time-invariant system,
 *      in transfer function matrix form:
 *    
 *         y(k) = G(q)u(k) + w(k)  or   y(k) = G(z)u(k) + w(k)
 *
 *      in polynomial form:
 * 
 *         A(q)y(k) = B(q)u(k) + w(k)
 *
 *      in theta-parameter form:
 *
 *         y(k) = phi(k)'*th + w(k)
 *
 *      th  : estimated parameter
 *      Y   : output of the system
 *      U   : input of the system
 *      n   : number of states
 *      phi : phi() generates phi matrix
 *
 *  SEE ALSO
 *      phi_lti1(), phi_lti2() for phi(), th_lti1(), th_lti2(), 
 *      lti1_th() and lti2_th().
 */

Func Matrix LS(Y, U, n, phi)
	Array Y;
	Array U;
	Integer n;
	Matrix phi();
{
	Integer N;
	Matrix th, Phi, yy, X;
	Matrix R, f;

	List Phi_yy();

	{Phi, yy} = Phi_yy(Y, U, n, phi);
	N = Cols(Y) - n;

	R = Phi*Phi'/N;
	f = Phi*yy/N;
	X = chol(R);		// R = X'*X
	th = X \ (X' \ f);	// solution of 'f = R * th'

	return th;
}

Func List Phi_yy(Y, U, n, phi)
	Array Y;		// output of the system
	Array U;		// input of the system
	Integer n;		// number of states
	Matrix phi();	// phi() generates phi matrix
{
	Integer k, kk;
	Integer p, N;
	Matrix Phi, yy, phi_tmp;

	N = Cols(Y) - n;
	p = Rows(Y);

	phi_tmp = phi(Y, U, n, n+1);
	Phi = Z(1,N,phi_tmp);
	yy = Z(N*p,1);
	for (k = n+1; k <= Cols(Y); k++) {
		kk = (k-n-1)*p;
		Phi(:,kk+1:kk+p) = phi(Y, U, n, k);
		yy(kk+1:kk+p,1) = Y(:,k);
	}

	return {Phi, yy};
}
