
/*  -*- MaTX -*-
 *
 *  NAME
 *      phi_lti2() - Regressor vector for Least Squres method
 *
 *  SYNOPSIS
 *       phi = phi_lti2(Y, U, n, k)
 *         Matrix phi;   regressor vector 
 *         Array Y;      output of the system
 *         Array U;      input of the system
 *         Integer n;    number of states
 *         Integer k;    index of time
 *
 *  DESCRIPTION
 *       phi_lti2() generates a regressor vector for parameter estimation
 *       by least squares method from input output data of a linear time 
 *       invariant system.
 *
 *       It is assumed that all the elements of the transfer function
 *       have the common denominator such as
 *
 *       y(k) = G(q)u(k) + w(k)  or   y(k) = G(z)u(k) + w(k)
 *

G(q)=[[ b1_11 q^-1 + ... + b1_1n q^-n         bm_11 q^-1 + ... + bm_1n q^-n ]
      [-------------------------------, ..., -------------------------------]
      [ 1 + a_1 q^-1 + ... + a_n q^-n         1 + a_1 q^-1 + ... + a_n q^-n ]
      [                                                                     ]
      [                                                                     ]
      [ b1_p1 q^-1 + ... + b1_pn q^-n         bm_p1 q^-1 + ... + bm_pn q^-n ]
      [-------------------------------, ..., -------------------------------]
      [ 1 + a_1 q^-1 + ... + a_n q^-n         1 + a_1 q^-1 + ... + a_n q^-n ]]

G(z)=[[   b1_11 z^n-1 + ... + b1_1n             bm_11 z^n-1 + ... + bm_1n   ]
      [-------------------------------, ..., -------------------------------]
      [  z^n + a_1 z^n-1 + ... + a_n           z^n + a_1 z^n-1 + ... + a_n  ]
      [                                                                     ]
      [                                                                     ]
      [   b1_p1 z^n-1 + ... + b1_pn             bm_p1 z^n-1 + ... + bm_pn   ]
      [-------------------------------, ..., -------------------------------]
      [  z^n + a_1 q^z-n1 + ... + a_n          z^n + a_1 z^n-1 + ... + a_n  ]]

 *
 *      or in polynomial form:
 *
 *      [[y1(k)]       [[u1(k)]
 * A(q)  [y2(k)] = B(q) [u2(k)]  + w(k)
 *       [.....]        [.....]
 *       [yp(k)]]       [um(k)]] 
 * 
 * A(q) = diag(1 + a_1 q^-1 + ... a_n q^-n,
 *                       1 + a_1 q^-1 + ... a_n q^-n,
 *                                 ...........................,
 *                                           1 + a_1 q^-1 + ... a_n q^-n)
 * 
 * B(q) = [[1 + b1_11 q^-1 + ... b1_1n q^-n, 1 + b1_21 q^-1 + ... b1_2n q^-n
 *          ..............................., 1 + b1_m1 q^-1 + ... b1_mn q^-n]
 *         [1 + b2_11 q^-1 + ... b2_1n q^-n, 1 + b2_21 q^-1 + ... b2_2n q^-n
 *          ..............................., 1 + b2_m1 q^-1 + ... b2_mn q^-n]
 *         [................................................................]
 *         [1 + bp_11 q^-1 + ... bp_1n q^-n, 1 + bp_21 q^-1 + ... bp_2n q^-n
 *          ..............................., 1 + bp_m1 q^-1 + ... bp_mn q^-n]]
 *
 *      or in theta-parameter form:
 * 
 *     [[y1(k)]
 *      [y2(k)] = phi(k)#*th + w(k)
 *      [.....]
 *      [yp(k)]]
 *
 *	  th  : (n + p*n*m) x 1
 *	  phi : p x (n + p*n*m)
 *
 *  th = [[a_1]  th1 = [[b1_11] th2 = [[b1_21]   ... thp = [[b1_p2]
 *        [a_2]         [b1_12]        [b1_22]   ...        [b1_p2]
 *        [...]         [ ....]        [ ....]   ...        [ ... ]
 *        [a_n]         [b1_1n]        [b1_2n]   ...        [b1_pn]
 *        [th1]         [ ....]        [ ....]   ...        [ ... ]
 *        [th2]         [bm_11]        [bm_21]   ...        [bm_p2]
 *        [...]         [bm_12]        [bm_22]   ...        [bm_p2]
 *        [thp]]        [ ....]        [ ....]   ...        [ ... ]
 *                      [bm_1n]]       [bm_2n]]  ...        [bm_pn]]
 *
 *  phi(k) = [[YY(k)]
 *            [UU(k)]]
 *
 *  UU(k) = diag([[ u_1(k-1)]   [ u_1(k-1)]   ...,  [ u_1(k-1)]
 *                [  ....   ]   [  ....   ]   ...,  [  ....   ]
 *                [ u_1(k-n)]   [ u_1(k-n)]   ...,  [ u_1(k-n)]
 *                [  ....   ]   [   ....  ]   ...,  [  ....   ]
 *                [  ....   ]   [   ....  ]   ...,  [  ....   ]
 *                [ u_m(k-1)]   [ u_m(k-1)]   ...,  [ u_m(k-1)]
 *                [  ....   ]   [  ....   ]   ...,  [  ....   ]
 *                [ u_m(k-n)]], [ u_m(k-n)]], ...,  [ u_m(k-n)]])
 *
 *  YY(k) = [[-y_1(k-1), -y_2(k-1), ..., -y_p(k-1)]
 *           [  ....   ,   ....   , ...,   ....   ]
 *           [-y_1(k-n), -y_2(k-n), ..., -y_p(k-n)]]
 *
 */

Func Matrix phi_lti2(Y, U, n, k)
	Array Y;	// output of the system
	Array U;	// input of the system
	Integer n;	// number of states
	Integer k;	// index of time
{
	Matrix phi, u;
	Integer i, j, ii, m, p;

	m = Rows(U);
	p = Rows(Y);

	phi = Z(p*m*n+n,p);
	u = Z(m*n,1);
	
	for (i = 1; i <= m; i++) {
		ii = n*(i-1);
		u(ii+1:ii+n,1) = U(i,k-1:k-n)#;
	}

	phi(1:n,*) = - Y(*,k-1:k-n)#;
	for (i = 1; i <= p; i++) {
		ii = n + (i-1)*n*m;
		phi(ii+1:ii+m*n,i) = u;
	}
	return phi;
}


