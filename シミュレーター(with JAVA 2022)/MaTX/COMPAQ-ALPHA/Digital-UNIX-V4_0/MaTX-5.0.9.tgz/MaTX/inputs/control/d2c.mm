
/* -*- MaTX -*-
 *
 *  NAME
 *      d2c() - Conversion of state space models from discrete to
 *              continuous time
 *
 *  SYNOPSIS
 *      {A, B} = d2c(Phi, Gamma, T)
 *          Matrix A,B;
 *          Matrix Phi, Gamma;
 *          Real T;
 *
 *  DESCRIPTION
 *       d2c() converts the discrete-time system:
 *
 *      	x[n+1] = Phi * x[n] + Gamma * u[n]
 *
 *       to the continuous-time state-space system:
 *      	.
 *      	x = Ax + Bu
 *
 *       assuming a zero-order hold on the inputs and sample time T.
 *
 *  SEE ALSO
 *      c2d()
 */

Func List d2c(Phi, Gamma, T)
	Matrix Phi, Gamma;
	Real T;
{
	Matrix A, B, S;
	Integer m, n;
	String msg;

	msg = abcdchk(Phi, Gamma);
	if (length(msg) > 0) {
		error("d2c(): " + msg);
	}

	n = Rows(Phi);
	m = Cols(Gamma);

	/*
	 * Phi = [1] case cannot be computed through matrix logarithm.
	 * Handle as a special case.
	 */
	if (n == 1) {
		if (Phi == [1]) {
			A = [0];
			B = Gamma/T;
			return {A, B};
		}
	}

	// Do rest of cases using matrix logarithm.
	S = Re(log([[  Phi ,  Gamma]
				[Z(m,n),   I(m)]]))/T;
	A = S(1:n,1:n);
	B = S(1:n,n+1:n+m);
	return {A, B};
}
