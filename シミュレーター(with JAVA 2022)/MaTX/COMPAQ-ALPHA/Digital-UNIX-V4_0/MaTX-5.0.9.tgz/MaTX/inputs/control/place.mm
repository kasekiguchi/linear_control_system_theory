
/* -*- MaTX -*-
 *
 *  NAME
 *      place() - Computes the state feedback matrix
 *
 *  SYNOPSIS
 *      K = place(A, B, P)
 *         Matrix K;
 *         Matrix A, B;
 *         CoMatrix P;
 *
 *      K = place(A, B, P, prt)
 *         Matrix K;
 *         Matrix A, B;
 *         CoMatrix P;
 *         Integer prt;
 *
 *  DESCRIPTION
 *      place() computes the state feedback matrix K such that
 *      the eigenvalues of  A-B*K  are those specified in vector P.
 *      The complex eigenvalues in the vector P must appear in consecu-
 *      tive complex conjugate pairs. No eigenvalue may be placed with
 *      multiplicity greater than the number of inputs.  
 *
 *      If prt = 1, how well the eigenvalues were placed is shown.
 *      The value seems to give an estimate of how many decimal digits 
 *      in the eigenvalues of A-B*K match the specified numbers given 
 *      in the array P.
 *
 *      A warning_flag message is printed if the nonzero closed loop poles
 *      are greater than 10% from the desired locations specified in P.
 *
 *  SEE ALSO
 *      acker()
 *
 *  REFERENCE
 *      [1] Kautsky, Nichols, Van Dooren, "Robust Pole Assignment in Linear 
 *          State Feedback," Intl. J. Control, 41(1985)5, pp 1129-1155
 *
 */

Func Matrix place(A, B, P_, prt, ...)
	Matrix A, B;
	CoMatrix P_;
	Integer prt;
{
	Integer ntry,i,imax,j,k,m,mp1,n,nmmp1,nx;
	Matrix K,pr,pi,cmplx,Bx,Pr,Q,Qb,R,Rb,S,Ss,Us,Vs,X,Xf,q0,q1;
	CoMatrix ps, P, Pc;
	Real cnd;
	Index idx;
	String msg;

	error(nargchk(3, 4, nargs, "place"));

	msg = abcdchk(A, B);
	if (length(msg) > 0) {
		error("place(): " + msg);
	}
	
	if (nargs < 4) {
		prt = 0;
	}

	// number of iterations for optimization
	ntry = 5;
	
	if (Rows(P_) < Cols(P_)) {
		P = reshape(P_, length(P_), 1);
	} else {
		P = P_;
	}
	{n,m} = size(B);

	nx = 0;
	i = 1;
	pr = pi = cmplx = [];
	while (i <= n) {
		if (Im(P(i)) != 0.0) {
			pr = [pr, [Re(P(i))]];
			pi = [pi, [Im(P(i))]];
			cmplx = [cmplx, [1]];
			i = i + 2;
		} else {
			pr = [pr, [Re(P(i))]];
			pi = [pi, [0]];
			cmplx = [cmplx, [0]];
			i = i + 1;
		}
		nx = nx + 1;
	}

	m = rank(B);

	// Make sure there are more inputs than repeated poles:
	{ps} = sort(P);
	for (i = 1; i <= n-m; i++) {
		imax = min(n,i+m);
		if (all(ps(i:imax) .== ps(i))) {
			error("place(): Can't place poles with multiplicity greater than the number of inputs.\n");
		}
	}
	nmmp1 = n - m + 1;
	mp1 = m + 1;

	{Qb,Rb} = qr(B);
	q0 = Qb(:,1:m);
	q1 = Qb(:,mp1:n);
	Rb = Rb(1:m,:);

	// Special case: (#inputs) == (#states) - efficient, but not clean
	if (m == n) {
		A = A - vec2diag(Re(P));
		i = 0;
		for (j = 1; j <= nx; j++) {
			i = i + 1;
			if (cmplx(j)) {
				A(i,i+1) = A(i,i+1) + pi(j);
				A(i+1,i) = A(i+1,i) - pi(j);
				i = i+1;
			}
		}
		if (prt) {
			printf("place: ndigits = %g\n", fix(log10(1.0/EPS)));
		}
		K = Rb \ q0# * A;
		return K;
	}

	// Compute bases for eigenvectors
	Bx = [];
	for (i = 1; i <= nx; i++) {
		{Q,R} = qr(((pr(i) + (0,1)*pi(i))*I(n) - A)#*q1);
		Bx = [Bx, Q(:,nmmp1:n)];
	}

	/*
	 *  Choose basis set
	 *  At each iteration of i pick the eigenvector Xj, j != i, 
	 *  which is "most orthogonal" to the current eigenvector Xi
	 */
	X = Z(Bx);
	for (i = 1; i <= nx; i++) {
		X(:,i) = Bx(:,(i-1)*m+1);
	}

	if (m > 1) {
		for (k = 1; k <= ntry; k++) {
			for (i = 1; i <= nx; i++) {
				if (i == 1) {
					S = X(:,i+1:nx);
				} else {
					S = [X(:,1:i-1), X(:,i+1:nx)];
				}
				S = [S conj(S)];
				{Us, Ss, Vs} = svd(S);
				Pr = Bx(:,(i-1)*m+1:i*m);
				Pr = Pr*Pr#;
				X(:,i) = Pr*Us(:,n);
				X(:,i) = X(:,i)/norm(X(:,i));
			}
		}
	}

	Xf = [];
	for (i = 1; i <= nx; i++) {
		if (cmplx(i)) {
			Xf = [Xf, X(:,i), conj(X(:,i))];
		} else {
			Xf = [Xf, X(:,i)];
		}
	}

	cnd = cond(Xf);
	if (cnd*EPS >= 1.0) {
		warning("place(): Can't place eigenvalues there\n");
		return K;
	}
	if (prt) {
		printf("place: ndigits = %g\n", fix(log10(cnd/EPS)));
	}

	// Compute feedback
	K = Rb\q0#*(A - Re(Xf*vec2diag(P)/Xf));

	// Check results. Start by removing 0.0 pole locations
	{P} = sort(P);
	idx = find(P .!= 0.0);
	P = P(idx);
	{Pc} = sort(eigval(A - B*K));
	Pc = Pc(idx);
	if (max(abs(Array(P-Pc))/abs(Array(P))) > 0.1) {
		warning("place(): Pole locations are more than 10% in error.\n");
	}

	return K;
}
