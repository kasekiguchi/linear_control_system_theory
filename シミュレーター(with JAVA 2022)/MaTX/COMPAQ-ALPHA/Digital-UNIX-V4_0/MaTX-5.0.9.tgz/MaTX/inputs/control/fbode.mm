
/* -*- MaTX -*-
 *
 *  NAME
 *      fbode() - Fast Bode response of continuous-time linear systems
 *
 *  SYNOPSIS
 *      {Mag, Phase} = fbode(A,B,C,D,iu,W)
 *          Array Mag, Phase;
 *          Matrix A,B,C,D;
 *          Integer iu;
 *          Array W;
 *
 *  DESCRIPTION
 *      fbode() calculates the frequency response of the system:
 *         .
 *         x = Ax + Bu                 -1
 *         y = Cx + Du    G(s) = C(sI-A) B + D
 *
 *         mag(w) = abs(G(jw)),    phase(w) = angle(G(jw))
 *
 *      from the iu'th input.  Vector W must contain the frequencies, in
 *      radians, at which the Bode response is to be evaluated.  fbode()
 *      returns matrices Mag and Phase (in degrees) with as many rows as
 *      there are outputs y, and with length(W) columns. 
 *      fbode() is a faster, but less accurate, version of bode().
 *
 *  SEE ALSO
 *      bode()
 */

Func List fbode(A,B,C,D,iu,w)
	Matrix A,B,C,D;
	Integer iu;
	Array w;
{
	Array Mag, Phase;
	Integer i,ma,na,no,ns,nw;
	Complex j;
	CoMatrix wj;
	CoMatrix At,Bt,Ct,Dt,P;
	CoArray G;
	String msg;

	msg = abcdchk(A, B, C, D);
	if (length(msg) > 0) {
		error("fbode(): " + msg);
	}

	j = (0,1);
	error(abcdchk(A,B,C,D));
	{no,ns} = size(C);
	nw = max(Cols(w), Rows(w));
		
	{At, P} = eig(A);   // Reduce A to diagonal form
	Bt = P \ B(:,iu);   // Apply similarity transformations to B and C
	Ct = C * P;
	Dt = D(:,iu);
	wj = ONE(ns,1)*Matrix(w)*j;
	At = diag2vec(At)*ONE(1,nw);
	Bt = Bt*ONE(1,nw);
	G = Ct * (wj-At).~ .* Bt + vec2diag(Dt)*ONE(no,nw);

	Mag = abs(G);
	Phase = 180/PI*unwrap(Im(log(G)));

	/*
	 * Uncomment the following line for decibels, but be warned that
	 * the MARGIN function will not work with decibel data.
	 *
	 * Mag = 20*log10(Mag);
	 */

	return {Mag, Phase};
}
