
/* -*- MaTX -*-
 *
 *  NAME
 *      rlocus_ss()       - Root locus
 *      rlocus_tf()       - Root locus
 *      rlocus_tfn()      - Root locus
 *      rlocus_tfm()      - Root locus
 *      rlocus_plot_ss()  - Root locus plot
 *      rlocus_plot_tf()  - Root locus plot
 *      rlocus_plot_tfn() - Root locus plot
 *      rlocus_plot_tfm() - Root locus plot
 *
 *  SYNOPSIS
 *      R = rlocus_ss(A,b,c,d)
 *         CoArray R;
 *         Matrix A,b,c,d;
 *
 *      R = rlocus_ss(A,b,c,d,K)
 *         CoArray R;
 *         Matrix A,b,c,d;
 *         Array K;
 *
 *      R = rlocus_tf(num,den)
 *         CoArray R;
 *         Matrix num, den;
 *
 *      R = rlocus_tf(num,den,K)
 *         CoArray R;
 *         Matrix num, den;
 *         Array K;
 *
 *      R = rlocus_tfn(g)
 *         CoArray R;
 *         Rational g;
 *
 *      R = rlocus_tfn(g,K)
 *         CoArray R;
 *         Rational g;
 *         Array K;
 *
 *      R = rlocus_tfm(g)
 *         CoArray R;
 *         RaMatrix g;
 *
 *      R = rlocus_tfm(g,K)
 *         CoArray R;
 *         RaMatrix g;
 *         Array K;
 *
 *      rlocus_plot_ss(A,b,c,d)
 *         Matrix A,b,c,d;
 *
 *      rlocus_plot_ss(A,b,c,d,K)
 *         Matrix A,b,c,d;
 *         Array K;
 *
 *      rlocus_plot_tf(num,den)
 *         Matrix num,den;
 *
 *      rlocus_plot_tf(num,den,K)
 *         Matrix num,den;
 *         Array K;
 *
 *      rlocus_plot_tfn(g)
 *         Rational g;
 *
 *      rlocus_plot_tfn(g,K)
 *         Rational g;
 *         Array K;
 *
 *      rlocus_plot_tfm(g)
 *         RaMatrix g;
 *
 *      rlocus_plot_tfm(g,K)
 *         RaMatrix g;
 *         Array K;
 *
 *  DESCRIPTION
 *       rlocus_tf(num, den) calculates the locus of the zeros of:
 *
 *                        num(s)
 *         H(s) = 1 + k ----------  =  0
 *                        den(s)
 *
 *      for the gains specified in vector K.  Vectors num and den must contain 
 *      the numerator and denominator coefficents in descending powers of s.
 *
 *      rlocus_nd(num,den,K) returns a matrix R with length(K) rows and 
 *      (length(den)-1) columns containing the complex root locations.
 *      Each row of the matrix corresponds to a gain from vector K.  
 *      The root-locus may be plotted with  gplot(1, Re(R), Im(R)).
 *
 *      rlocus_plot_tf(num,den) plots root-locus from the transfer function
 *
 *                         num(s)
 *          H(s) = 1 + k ----------  =  0
 *                         den(s)
 *
 *      for the gains specified in vector K.
 *
 */

Func CoArray rlocus_ss(A, b, c, d, K, ...)
	Matrix A, b, c, d;
	Array K;
{
	Integer i;
	Matrix bc,k;
	Array tmp;
	CoArray R;

	error(nargchk(4, 5, nargs, "rlocus_ss"));

	if (nargs == 4) {
		K = logspace(1e-3, 1e3, 1000);
	}

	R = (Z(Rows(b),length(K)),:);

	// Find eigenvalues of:  A - b*(I + k*d)~*k*c:
	k = K/(1 .+ K*d(1));
	bc = b*c;
	for (i = 1; i <= length(k); i++) {
		R(:,i) = eigval(A - bc*k(i));
	}
	return R;
}

Func CoArray rlocus_tfn(g, K, ...)
	Rational g;
	Array K;
{
	Matrix A,b,c,d;
	CoArray R;

	error(nargchk(1, 2, nargs, "rlocus_tfn"));

	{A,b,c,d} = tfn2ss(g);

	if (nargs == 2) {
		R = rlocus_ss(A,b,c,d);
	} else {
		R = rlocus_ss(A,b,c,d,K);
	}
	return R;
}

Func CoArray rlocus_tfm(G, K, ...)
	RaMatrix G;
	Array K;
{
	Matrix A,b,c,d;
	CoArray R;
	
	error(nargchk(1, 2, nargs, "rlocus_tfm"));

	{A,b,c,d} = tfm2ss(G);
	
	if (nargs == 1) {
		R = rlocus_ss(A,b,c,d);
	} else {
		R = rlocus_ss(A,b,c,d,K);
	}
	return R;
}

Func CoArray rlocus_tf(num, den, K, ...)
	Matrix num, den;
	Array K;
{
	Matrix A,b,c,d;
	CoArray R;

	error(nargchk(2, 3, nargs, "rlocus_tf"));

	{A,b,c,d} = tf2ss(num,den);

	if (nargs == 2) {
		R = rlocus_ss(A,b,c,d);
	} else {
		R = rlocus_ss(A,b,c,d,K);
	}
	return R;
}

Func void rlocus_plot_ss(A, b, c, d, K,...)
	Matrix A, b, c, d;
	Array K;
{
	Integer win;
	CoArray R;

	error(nargchk(4, 5, nargs, "rlocus_plot_ss"));
	
	if (nargs == 4) {
		R = rlocus_ss(A,b,c,d);
	} else {
		R = rlocus_ss(A,b,c,d,K);
	}

	win = mgplot_cur_win();
	mgplot_grid(win, 1);
	mgplot_key(win, 0);
	mgplot_cmd(win, "set data style points");
	mgplot(win, Re(R), Im(R));
}

Func void rlocus_plot_tfn(g, K,...)
	Rational g;
	Array K;
{
	Matrix A,b,c,d;
	
	error(nargchk(1, 2, nargs, "rlocus_plot_tfn"));

	{A,b,c,d} = tfn2ss(g);
	
	if (nargs == 2) {
		rlocus_plot_ss(A,b,c,d);
	} else {
		rlocus_plot_ss(A,b,c,d,K);
	}	
}

Func void rlocus_plot_tfm(G, K,...)
	RaMatrix G;
	Array K;
{
	Matrix A,b,c,d;

	error(nargchk(1, 2, nargs, "rlocus_plot_tfm"));

	{A,b,c,d} = tfm2ss(G);
	
	if (nargs == 1) {
		rlocus_plot_ss(A,b,c,d);
	} else {
		rlocus_plot_ss(A,b,c,d,K);
	}
}

Func void rlocus_plot_tf(num, den, K,...)
	Matrix num, den;
	Array K;
{
	Matrix A,b,c,d;
	
	error(nargchk(2, 3, nargs, "rlocus_plot_tf"));

	{A,b,c,d} = tf2ss(num,den);
	
	if (nargs == 2) {
		rlocus_plot_ss(A,b,c,d);
	} else {
		rlocus_plot_ss(A,b,c,d,K);
	}	
}

Func CoArray rlocus(num, den, K, ...)
	Matrix num, den;
	Array K;
{
	CoArray R;

	error(nargchk(2, 3, nargs, "rlocus"));

	if (nargs == 2) {
		R = rlocus_tf(num, den);
	} else {
		R = rlocus_tf(num, den, K);
	}

	return trans(R);
}

Func void rlocusp(num, den, K, ...)
	Matrix num, den;
	Array K;
{
	error(nargchk(2, 3, nargs, "rlocusp"));

	pause "rlocusp() is obsolete. Use rlocus_plot_tf()", 1;
	print "\n";

	if (nargs == 2) {
		rlocus_plot_tf(num, den);
	} else {
		rlocus_plot_tf(num, den, K);
	}
}

