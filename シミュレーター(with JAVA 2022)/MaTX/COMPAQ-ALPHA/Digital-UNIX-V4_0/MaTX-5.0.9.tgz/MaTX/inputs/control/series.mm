
/* -*- MaTX -*-
 *
 *  NAME
 *      series() - Series connection of two state-space systems
 *
 *  SYNOPSIS
 *      {A,B,C,D} = series(A1,B1,C1,D1,A2,B2,C2,D2)
 *         Matrix A,B,C,D;
 *         Matrix A1,B1,C1,D1,A2,B2,C2,D2;
 *
 *  DESCRIPTION
 *       series() produces an aggregate state-space system with the outputs
 *       of system 1 connected to the inputs of system 2.  An error results
 *       if there are different numbers of rows in (C1,D1) than columns in
 *       (B2,D2).
 *
 *  SEE ALSO
 *      parallel()
 */

Func List series(A1,B1,C1,D1,A2,B2,C2,D2)
	Matrix A1,B1,C1,D1,A2,B2,C2,D2;
{
	Matrix A,B,C,D;
	Integer ma1,ma2,na1,na2;
	String msg;

	msg = abcdchk(A1, B1, C1, D1);
	if (length(msg) > 0) {
		error("series(): " + msg);
	}
	msg = abcdchk(A2, B2, C2, D2);
	if (length(msg) > 0) {
		error("series(): " + msg);
	}

	{ma1,na1} = size(A1);
	{ma2,na2} = size(A2);
	
	if (ma1 == 0) {
		A = A2;
		B = B2;
		C = C2;
		D = D1*D2;
	} else if (ma2 == 0) {
		A = A1;
		B = B1;
		C = C1;
		D = D1*D2;
	} else {
		A = [[  A1 ,Z(ma1,na2)]
			 [B2*C1,    A2    ]];
		B = [[  B1 ]
			 [B2*D1]];
		C = [D2*C1 C2];
		D = D2*D1;
	}
	return {A,B,C,D};
}
