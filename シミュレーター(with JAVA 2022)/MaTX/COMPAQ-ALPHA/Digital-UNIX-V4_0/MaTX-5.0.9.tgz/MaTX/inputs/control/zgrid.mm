
/* -*- MaTX -*-
 *
 *  NAME
 *      zgrid() - Axis limits and aspect ratio for a unit circle
 *
 *  SYNOPSIS
 *      zgrid()
 *
 *  DESCRIPTION
 *      zgrid() sets the axis limits and aspect ratio for a unit circle
 *   	and generates grid lines of constant damping factor (zeta)
 *   	and natural frequency (Wn) within the unit Z-plane circle.
 *
 *	REFERENCE
 *   	 [1] Digital Control, Franklin and Powell, pg. 104
 */

Func void zgrid()
{
	Integer i, win;
	Matrix e_itheta,e_r,m,zz,zw;
	List name, cols;

	win = mgplot_cur_win();
	m = tan(asin([0:.1:1]));
	zz = exp(Array(Matrix([0:PI/20:PI])# * (-m + (0,1)*ONE(m))));
	e_itheta = exp((0,1)*[PI/2:PI/20:PI]#);
	e_r = exp([0:PI/10:PI]);
	zw = (ONE(e_itheta)*e_r).^(e_itheta*ONE(e_r));

	name = makelist(Rows(zz));
	cols = makelist(Rows(zz));
	for (i = 1; i <= Rows(zz); i++) {
		name(i) = "";
		cols(i) = "1";
	}

	mgplot(win,Re(zz), Im(zz),name,cols);
	mgreplot(win,Re(zz),-Im(zz),name,cols);
	mgreplot(win,Re(zw), Im(zw),name,cols);
	mgreplot(win,Re(zw),-Im(zw),name,cols);
}
