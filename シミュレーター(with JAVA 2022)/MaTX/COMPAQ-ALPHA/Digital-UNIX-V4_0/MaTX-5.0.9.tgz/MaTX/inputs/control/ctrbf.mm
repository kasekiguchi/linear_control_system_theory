
/* -*- MaTX -*-
 *
 *  NAME
 *      ctrbf() - Controllability staircase form
 *
 *  SYNOPSIS
 *      {Ab,Bb,Cb,T,K} = ctrbf(A,B,C)
 *          Matrix Ab,Bb,Cb,T,K;
 *          Matrix A,B,C;
 *
 *      {Ab,Bb,Cb,T,K} = ctrbf(A,B,C,tol)
 *          Matrix Ab,Bb,Cb,T,K;
 *          Matrix A,B,C;
 *          Real tol;
 *
 *  DESCRIPTION
 *       ctrbf() returns a decomposition into the controllable/
 *       uncontrollable subspaces.  ctrbf(..., tol) uses tolerance tol.
 *
 *       If [A B] has rank r < n, then there is a similarity
 *       transformation T such that
 *
 *         Ab = T*A*T# ,  Bb = T*B ,  Cb = C*T#
 *
 *       and the transformed system has the form
 *
 *              | Anc    0 |         | 0 |
 *         Ab = |----- ----| ,  Bb = |---| ,  Cb = [Cnc | Cc].
 *              | A21   Ac |         |Bc |
 *                                                    -1            -1
 *       where (Ac, Bc) is controllable, and Cc (sI-Ac) Bc = C (sI-A) B.
 *
 *  SEE ALSO
 *      ctrb() and obsvf()
 */

Func List ctrbf(A, B, C, tol, ...)
	Matrix A, B, C;
	Real tol;
{
	Integer ra, ca, rb, cb;
	Integer jj, deltajn1, deltaj, sigmajn1, sigmaj;
	Integer rsj, csj, roj, rbb, cbb, ruj, cuj, rojn1;
	Matrix Ab, Bb, Cb, t, k;
	Matrix ptjn1, ajn1, bjn1;
	Matrix uj, sj, vj, p, ptj;
	Matrix bb, abxy, aj, bj_;
	String msg;

	error(nargchk(3, 4, nargs, "ctrbf"));

	msg = abcdchk(A, B, C);
	if (length(msg) > 0) {
		error("ctrbf(): " + msg);
	}

	// This function implements the Staircase Algorithm of Rosenbrock, 1968.
	{ra, ca} = size(A);
	{rb, cb} = size(B);

	// Assign Initial Conditions :
	ptjn1 = I(ra);
	ajn1 = A;
	bjn1 = B;
	rojn1 = cb;
	deltajn1 = 0;
	sigmajn1 = ra;
	k = Z(1, ra);

	if (nargs == 3) {
		tol = ra * norm(A,1) * EPS;
	}

	// Begin Major Loop :
	for (jj = 1; jj <= ra; jj++) {
		{uj, sj, vj} = svd(bjn1);
		{rsj, csj} = size(sj);
		p = rot90(I(rsj),1);
		uj = uj * p;
		bb = uj# * bjn1;

		roj = rank(bb, tol);
		{rbb, cbb} = size(bb);
		sigmaj = rbb - roj;
		sigmajn1 = sigmaj;
		k(jj) = roj;

		if (roj == 0) {
			break;
		}
		if (sigmaj == 0) {
			break;
		}

		abxy = uj# * ajn1 * uj;
		aj   = abxy(1:sigmaj,1:sigmaj);
		bj_   = abxy(1:sigmaj,sigmaj+1:sigmaj+roj);
		ajn1 = aj;
		bjn1 = bj_;
		{ruj, cuj} = size(uj);
		ptj = ptjn1 * [[      uj       , Z(ruj,deltajn1)]
					   [Z(deltajn1,cuj),   I(deltajn1)  ]];
		ptjn1 = ptj;
		deltaj = deltajn1 + roj;
		deltajn1 = deltaj;
	}

	// Final Transformation :
	t = ptjn1#;
	Ab = t * A * t#;
	Bb = t * B;
	Cb = C * t#;

	return {Ab, Bb, Cb, t, k};
}
