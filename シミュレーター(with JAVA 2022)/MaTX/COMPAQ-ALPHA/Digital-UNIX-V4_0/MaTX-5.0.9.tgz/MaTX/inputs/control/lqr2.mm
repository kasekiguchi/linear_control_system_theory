
/* -*- MaTX -*-
 *
 *  NAME
 *      lqr2() - Linear-quadratic regulator design for continuous-time systems
 *               (Schur algorithm)
 *
 *  SYNOPSIS
 *      {K,P} = lqr2(A,B,Q,R)
 *          Matrix K,P;
 *          Matrix A,B,Q,R
 *
 *      {K,P} = lqr2(A,B,Q,R,N)
 *          Matrix K,P;
 *          Matrix A,B,Q,R
 *          Matrix N;
 *
 *  DESCRIPTION
 *       lqr2() calculates the optimal feedback gain matrix K such
 *       that the feedback law  u = -Kx  minimizes the cost function:
 *
 *         J = Integral (x# Q x + u# R u) dt
 *                                          
 *       subject to the constraint equation:
 *          .
 *          x = Ax + Bu 
 *
 *       Also returned is P, the steady-state solution to the associated 
 *       algebraic Riccati equation:
 *
 *         P A + A# P - P B R~ B# P + Q = 0
 *
 *       lqr2() includes the cross-term N that relates u to x in
 *       the cost functional as
 *
 *          J = Integral (x# Q x + u# R u + 2 x# N u) dt
 *
 *       lqr2() uses the Schur algorithm of [1] and is more numerically
 *       reliable than lqr(), which uses eigenvector decomposition.
 *
 *  REFERENCES
 *        [1] A.J. Laub, "A Schur Method for Solving Algebraic Riccati
 *            Equations", IEEE Transactions on Automatic Control, vol. AC-24,
 *            1979, pp. 913-921.
 *
 *  SEE ALSO
 *      lqr()
 */

Func List lqr2(A, B, Q, R, N, ...)
	Matrix A, B, Q, R, N;
{
	Integer m,n;
	Matrix K,P,F,G,H,Rb,Ri,Rs;
	String msg;

	error(nargchk(4, 5, nargs, "lqr2"));

	msg = abcdchk(A, B);
	if (length(msg) > 0) {
		error("lqr2(): " + msg);
	}
	
	{n,m} = size(B);
	Ri = R~;
	Rb = Ri*B#;
	G = B*Rb;

	/*
	 * Convert data for linear-quadratic regulator problem
	 * to data for the algebraic Riccati equation. 
	 *
	 * F = A - B*R~*N#
	 * G = B*R~*B#
	 * H = Q - N*R~*N#
	 *
	 * R must be symmetric positive definite.
	 */

	if (nargs > 4) {
		Rs = Ri*N#;
		F = A - B*Rs;
		H = Q - N*Rs;
	} else {
		Rs = Z(m, n);
		F = A;
		H = Q;
	}

	P = are(F, G, H);  // Solve ARE
	K = Rs + Rb*P;     // Find gains

	return {K, P};
}
