
/* -*- MaTX -*-
 *
 *  NAME
 *      ssappend() - Append together the dynamics of two state-space systems
 *
 *  SYNOPSIS
 *     {A,B,C,D} = ssappend(A1,B1,C1,D1,A2,B2,C2,D2)
 *        Matrix A,B,C,D;
 *        Matrix A1,B1,C1,D1,A2,B2,C2,D2;
 *
 *  DESCRIPTION
 *       ssappend() produces an aggregate state-space system consisting of
 *       the appended dynamics of systems 1 and 2.  The resulting system is:
 *      	 .
 *      	|x1| = |A1 0| |x1| + |B1 0| |u1|
 *      	|x2|   |0 A2| |x2| + |0 B2| |u2|
 *
 *      	|y1| = |C1 0| |x1| + |D1 0| |u1|
 *      	|y2|   |0 C2| |x2| + |0 D2| |u2|
 *
 *  SEE ALSO
 *      series() and parallel().
 *
 */


Func List ssappend(A1,B1,C1,D1,A2,B2,C2,D2)
	Matrix A1,B1,C1,D1,A2,B2,C2,D2;
{
	Matrix A,B,C,D;
	Integer ma1,ma2,md1,md2,na1,na2,nd1,nd2;
	String msg;

	msg = abcdchk(A1, B1, C1, D1);
	if (length(msg) > 0) {
		error("ssappend(): " + msg);
	}
	msg = abcdchk(A2, B2, C2, D2);
	if (length(msg) > 0) {
		error("ssappend(): " + msg);
	}

	{ma1,na1} = size(A1);
	{md1,nd1} = size(D1);
	{ma2,na2} = size(A2);
	{md2,nd2} = size(D2);
	A = [[     A1    Z(ma1,na2)]
		 [Z(ma2,na1)     A2    ]];
	B = [[     B1    Z(ma1,nd2)]
		 [Z(ma2,nd1)     B2    ]];
	C = [[     C1    Z(md1,na2)]
		 [Z(md2,na1)     C2    ]];
	D = [[     D1    Z(md1,nd2)]
		 [Z(md2,nd1)     D2    ]];

	return {A,B,C,D};
}
