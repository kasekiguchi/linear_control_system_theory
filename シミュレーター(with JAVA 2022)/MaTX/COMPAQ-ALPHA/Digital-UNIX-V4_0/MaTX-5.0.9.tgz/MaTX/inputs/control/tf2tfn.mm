
/* -*- MaTX -*-
 *
 *  NAME
 *      tf2tfn() -  Transfer function to transfer function conversion
 *
 *  SYNOPSIS
 *      g = tf2tfn(num,den)
 *         Rational g;
 *         Matrix num, den;
 *
 *  DESCRIPTION
 *       tf2tfn() calculates the transfer function representation:
 *
 *                  num(s) 
 *          g(s) = --------
 *                  den(s)
 *
 *      from a single input.
 *      This calculation also works for discrete systems but the 
 *      numerator must be padded with
 *      trailing zeros to make it the same length as the denominator.
 *
 *  SEE ALSO
 *      ss2tf() and tf2zp()
 */

Func Rational tf2tfn(num, den)
	Matrix num, den;
{
	Rational g;
	Polynomial nn, dd;

	if (version() == 4) {
		nn = Polynomial(fliplr(num));
		dd = Polynomial(fliplr(den));
	} else {
		nn = Polynomial(num);
		dd = Polynomial(den);
	}

	g = nn/dd;

	return g;
}
