
/* -*- MaTX -*-
 *
 *  NAME
 *      DOptimal() - Solves a discrete time optimal control problem
 *
 *  SYNOPSIS
 *      F = DOptimal(A, B, Q, R)
 *         Matrix F;
 *         Matrix A,B,Q,R;
 *
 *      F = DOptimal(A, B, Q, R, S)
 *         Matrix F;
 *         Matrix A,B,Q,R,S;
 *
 *  DESCRIPTION
 *      DOptimal() is obsolete.
 *
 *      Use  {F} = dlqr(A,B,Q,R); F = -F;  for  F = DOptimal(A,B,Q,R)
 *
 *  SEE ALSO
 *      dlqr()
 */

Func Matrix DOptimal(A, B, Q, R, S, ...)
	Matrix A, B, Q, R, S;
{
	Matrix F;

	error(nargchk(4, 5, nargs, "DOptimal"));

	if (nargs == 4) {
		{F} = dlqr(A, B, Q, R);
		F = - F;
	} else if (nargs == 5) {
		{F} = dlqr(A, B, Q, R, S);
		F = - F;
	}

	return F;
}












