
/* -*- MaTX -*-
 *
 *  NAME
 *      ss2tf()	- State-space to transfer function conversion
 *
 *  SYNOPSIS
 *      {NUM, den} = ss2tf(A,B,C,D)
 *         Matrix NUM, den;
 *         Matrix A,B,C,D;
 *
 *      {NUM, den} = ss2tf(A,B,C,D,iu)
 *         Matrix NUM, den;
 *         Matrix A,B,C,D;
 *         Integer iu;
 *
 *  DESCRIPTION
 *      ss2tf() calculates the transfer function:
 *
 *                  NUM(s)          -1
 *          H(s) = -------- = C(sI-A) B + D
 *                  den(s)
 *      of the system:
 *          .
 *          x = Ax + Bu,  y = Cx + Du
 *
 *      from the iu'th input.  Vector den contains the coefficients of the
 *      denominator in descending powers of s.  The numerator coefficients
 *      are returned in matrix NUM with as many rows as there are outputs y.
 *
 *  SEE ALSO
 *      ss2tfm() and ss2zp()
 */

Func List ss2tf(A, B, C, D, iu, ...)
	Matrix A, B, C, D;
	Integer iu;
{
	Matrix den, NUM, b, d;
	Integer i,mc,nc;
	String msg;
	
	error(nargchk(4, 5, nargs, "ss2tf"));

	msg = abcdchk(A, B, C, D);
	if (length(msg) > 0) {
		error("ss2tf(): " + msg);
	}

	if (nargs == 4) {
		iu = 1;
	}

	den = poly(A);

	if (Rows(B) == 0 || Cols(B) == 0) {
		b = Z(0,1);
	} else {
		b = B(:,iu);
	} 
	d = D(:,iu);

	nc = Cols(C);
	mc = Rows(D);
	
	if (isreal(A) && isreal(B) && isreal(C) && isreal(D)) {
		NUM = ONE(Rows(D), nc+1);
	} else {
		NUM = (ONE(Rows(D), nc+1),:);
	}

	for (i = 1; i <= mc; i++) {
		if (Rows(C) == 0 || Cols(C) == 0) {
			NUM(i,1) = d(i);
		} else {
			NUM(i,:) = poly(A - b*C(i,:)) + (d(i) - 1) * den;
		}
	}
	return {NUM, den};
}
