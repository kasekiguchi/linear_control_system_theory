
/* -*- MaTX -*-
 *
 *  NAME
 *      Riccati() - Solution of Riccati Equation
 *
 *  SYNOPSIS
 *      P = Riccati(A,B,Q,R)
 *         Matrix P;
 *         Matrix A,B,Q,R;
 *
 *  DESCRIPTION
 *      Solution of the Riccati equation:
 *
 *        A#*P + P*A + Q - P*B*R~*B#*P = 0
 *
 */

Func Matrix Riccati(A, B, Q, R)
	Matrix A, B, Q, R;
{
	return Ric(A, -Q, -B*R~*B#);
}
