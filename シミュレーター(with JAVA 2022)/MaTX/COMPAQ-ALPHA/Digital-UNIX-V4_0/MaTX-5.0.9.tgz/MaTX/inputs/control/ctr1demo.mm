
/*  -*- MaTX -*-
 *
 *  NAME
 *      ctr1demo() - Demonstration of control toolbox
 *
 *  SYNOPSIS
 *      ctr1demo()
 */

Func void ctr1demo()
{
	Integer win;
	Matrix A, B, C, D, P;
	RaMatrix G;
	Rational g;
	Array w, ga, ph, re, im;
	CoMatrix g_poles, g_zeros;

	print "\n";
	print "A linear system:\n";
	pause;

	print "A=[[ 2  2   3]\n";
	print "   [ 0  0   1]\n";
	print "   [ 5  9, -1]]\n";
	print "B=[1 0 0]'; C=[1, -1 0]; D=[0];\n";
	pause;
	A=[[ 2  2   3]
	   [ 0  0   1]
	   [ 5  9, -1]];
	B=[1 0 0]'; C=[1, -1 0]; D=[0];

	print "\n";
	print "print A, B, C, D;                      // Show A,B,C,D\n";
	pause;
	print A, B, C, D;

	print "\n";
	print "G = ss2tfm(A, B, C, D)        // Transfer function matrix\n";
	pause;
	print G = ss2tfm(A, B, C, D);

	print "\n";
	print "g = G(1,1);                            // Transfer function\n";
	pause;
	print g = G(1,1);

	print "\n";
	print "g_poles = poles(g)                     // Poles\n";
	pause;
	print g_poles = poles(g);

	print "\n";
	print "g_zeros = zeros(g)                     // Zeros\n";
	pause;
	print g_zeros = zeros(g);

	print "\n";
	print "w = logspace(0.01, 100.0);             // Log scale data\n";
	pause;
	w = logspace(0.01, 100.0);

	print "\n";
	print "{ga, ph} = bode_tfn(g, w);             // Bode diagram\n";
	print "ga = 20*log10(ga);                     // [dB]\n";
	pause;
	{ga, ph} = bode_tfn(g, w);
	ga = 20*log10(ga);

	print "\n";
	print "mgplot_subplot(win, 2, 1, 1);\n";
	print "mgplot_semilogx(win, w, ga, {\"gain\"});   // Gain diagram\n";
	print "mgplot_subplot(win, 2, 1, 2);\n";
	print "mgplot_semilogx(win, w, ph, {\"phase\"});  // Phase diagram\n";
	pause;
	win = mgplot_cur_win();
	mgplot_reset(win);

	mgplot_hold(win, 1);
	mgplot_subplot(win, 2, 1, 1);
	mgplot_semilogx(win, w, ga, {"gain"});
	mgplot_subplot(win, 2, 1, 2);
	mgplot_semilogx(win, w, ph, {"phase"});
	mgplot_hold(win, 0);

	print "\n";
	print "{re, im} = nyquist_tfn(g, w);             // Nyquist diagram\n";
	pause;
	{re, im} = nyquist_tfn(g, w);

	print "\n";
	print "mgplot_subplot(win, 1, 1);\n";
	print "mgplot_cmd(win, \"set xrange [-3:1]\");\n";
	print "mgplot_cmd(win, \"set yrange [-2:1]\");\n";
	print "mgplot_grid(win, 1);                     // show grid\n";
	print "mgplot(win, re, im, {\"nyquist\"});      // Nyquist diagram\n";
	pause;
	mgplot_reset(win);

	mgplot_hold(win, 1);
	mgplot_subplot(win,1,1);
	mgplot_cmd(win, "set xrange [-3:1]");
	mgplot_cmd(win, "set yrange [-2:1]");
	mgplot_grid(win, 1);
	mgplot(win, re, im, {"nyquist"});
	mgplot_hold(win, 0);

	print "\n";
	pause;
}
