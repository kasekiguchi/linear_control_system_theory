
/*  -*- MaTX -*-
 *
 *  NAME
 *      acker() - Pole placement gain selection using Ackermann's formula
 *
 *  SYNOPSIS
 *      k = acker(A,b,P)
 *         Matrix k;
 *         Matrix A,b;
 *         CoMatrix P; 
 *
 *  DESCRIPTION
 *       acker() calculates the feedback gain matrix k such that
 *       the single input system
 *      	.
 *      	x = Ax + bu 
 *
 *       with a feedback law of  u = -kx  has closed loop poles at the 
 *       values specified in vector P, i.e.,  P = eigval(A-b*k).
 *
 *       This algorithm uses Ackermann's formula.  This method
 *       is NOT numerically reliable and starts to break down 
 *       rapidly for problems of order greater than 10, or for
 *       weakly controllable systems.
 *
 *       A warning_flag message is printed if the nonzero closed loop poles
 *       are greater than 10% from the desired locations specified in P.
 *
 *  SEE ALSO
 *      place().
 *
 *  REFERENCSE 
 *       [1] Kailath, T.  "Linear Systems", p. 201, Prentice-Hall, 1980.
 *
 */

Func Matrix acker(A, b, P_)
	Matrix A, b;
	CoMatrix P_;
{
	Matrix k;
	CoMatrix P, PC;
	Index idx;
	String msg;

	error(abcdchk(A,b));

	msg = abcdchk(A, b);
	if (length(msg) > 0) {
		error("acker(): " + msg);
	}

	if (Cols(b) != 1) {
		error("acker(): System must be single input.\n");
	}

	// Make sure roots are in a column vector
	P = makecolv(P_);
	if (Rows(A) != Rows(P)) {
		error("acker(): Vector P must have size(A) elements.\n");
	}

	// Form gains using Ackerman's formula
	if (version() == 4) {
		k = ctrb(A,b) \ eval(Polynomial(fliplr(poly(P))), A);
	} else {
		k = ctrb(A,b) \ eval(Polynomial(poly(P)), A);
	}
	k = k(Rows(A),:);

	// Check results. Start by removing 0.0 pole locations
	{P} = sort(P);
	idx = find(P .!= 0.0);
	P = P(idx);
	{PC} = sort(eigval(A - b*k));
	PC = PC(idx);

	if (max(abs(P-PC)/abs(P)) > 0.1) {
		warning("acker(): Pole locations are more than 10% in error.\n");
	}
	return k;
}
