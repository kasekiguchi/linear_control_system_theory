
/* -*- MaTX -*-
 *
 *  NAME
 *      paralell() -  Parallel connection of two state-space systems
 *
 *  SYNOPSIS
 *     {A,B,C,D} = parallel(A1,B1,C1,D1,A2,B2,C2,D2)
 *        Matrix A,B,C,D;
 *        Matrix A1,B1,C1,D1,A2,B2,C2,D2
 *
 *  DESCRIPTION
 *       parallel() produces a state-space system consisting of the parallel
 *       connection of systems 1 and 2 such that Y = Y1 + Y2.  The resulting
 *       system is:
 *      	 .
 *      	|x1| = |A1 0| |x1| + |B1 0|
 *      	|x2|   |0 A2| |x2| + |0 B2|
 *
 *      	|y| = y1+y2 = |C1 C2| |x1| + |D1 D2| |u1|
 *      	                      |x2|           |u2|     
 *  SEE ALSO
 *      series()
 */

Func List parallel(A1,B1,C1,D1,A2,B2,C2,D2)
	Matrix A1,B1,C1,D1,A2,B2,C2,D2;
{
	Matrix AA,BB,CC,DD;
	Integer ma1,ma2,md1,md2,na1,na2,nd1,nd2;
	String msg;

	msg = abcdchk(A1, B1, C1, D1);
	if (length(msg) > 0) {
		error("parallel(): " + msg);
	}
	msg = abcdchk(A2, B2, C2, D2);
	if (length(msg) > 0) {
		error("parallel(): " + msg);
	}


	{ma1,na1} = size(A1);
	{md1,nd1} = size(D1);
	{ma2,na2} = size(A2);
	{md2,nd2} = size(D2);
	AA = [[    A1,    Z(ma1,na2)]
		  [Z(ma2,na1),    A2    ]];
	BB = [[    B1,    Z(ma1,nd2)]
		  [Z(ma2,nd1),    B2    ]];
	CC = [C1 C2];
	DD = [D1 D2];

	return {AA,BB,CC,DD};
}
