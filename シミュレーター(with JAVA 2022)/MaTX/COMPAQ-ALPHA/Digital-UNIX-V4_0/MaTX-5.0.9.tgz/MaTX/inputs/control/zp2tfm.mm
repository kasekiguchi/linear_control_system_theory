
/* -*- MaTX -*-
 *
 *  NAME
 *      zp2tfm() - Zero-pole to transfer function matrix conversion
 *
 *  SYNOPSIS  
 *      G = zp2tfm(z,p,k)
 *        RaMatrix G;
 *        CoMatrix z,p;
 *        Matrix k;
 *
 *  DESCRIPTION
 *      zp2tfm() forms the transfer function matrix:
 *
 *               NUM(s)
 *       G(s) = -------- 
 *               den(s)
 *
 *      for SIMO systems given a set of pole locations in column vector 'p',
 *      a matrix 'z' with the zero locations in as many columns as there are
 *      outputs, and the gains for each numerator transfer function in
 *      vector 'k'.
 *
 *      The function will not work if 'p' or 'z' have elements not in complex
 *      pairs.
 *
 *  SEE ALSO
 *      tfm2zp(), zp2tf() and zp2ss()
 */

Func RaMatrix zp2tfm(z, p, k)
	CoMatrix z, p;
	Matrix k;
{
	Matrix den, NUM;
	RaMatrix G;

	{NUM, den} = zp2tf(z, p, k);
	G = tf2tfm(NUM, den);
	return G;
}
