
/* -*- MaTX -*-
 *
 *  NAME
 *      impulse() - Impulse response of continuous-time linear systems
 *
 *  SYNOPSIS
 *      {Y,X} = impulse(A,B,C,D,iu,T)
 *          Matrix X,Y;
 *          Matrix A,B,C,D;
 *          Integer iu;
 *          Matrix T;
 *
 *  DESCRIPTION
 *       impulse() calculates the response of the system:
 *      	.
 *      	x = Ax + Bu
 *      	y = Cx + Du
 *
 *       to an impulse applied to the iu'th input.  Vector T must be a
 *       regularly spaced time vector that specifies the time axis for the
 *       impulse response.  impulse() returns a matrix Y with as many rows
 *       as there are outputs y, and with length(T) columns. 
 *
 *       impulse(A,B,C,D,iu,T) also returns the state time history.
 *
 *       If iu == 0, impulse() returns matrices
 *
 *       [[Y for 1st input]          [[X for 1st input]
 *        [Y for 2nd input]           [X for 2nd input]
 *        [...............]           [...............]
 *        [Y for m'th input]]  and    [Y for m'th input]].
 *
 *  SEE ALSO
 *      step() and dimpulse()
 */

Func List impulse(A,B,C,D,iu,T)
	Matrix A,B,C,D;
	Integer iu;
	Matrix T;
{
	Integer i,n,m,p,N;
	Matrix Ad,Bd,b,x0,X,Y,XX,YY,U;
	Real dt;
	String msg;

	msg = abcdchk(A, B, C, D);
	if (length(msg) > 0) {
		error("impulse(): " + msg);
	}

	N = length(T);
	U = Z(1,N);
	dt = T(2) - T(1);

	if (iu == 0) {
		n = Rows(A);
		m = Cols(B);
		p = Rows(C);
		YY = Z(m*p,N);
		XX = Z(m*n,N);

		for (i = 1; i <= m; i++) {
			x0 = b = B(:,i);
			{Ad, Bd} = c2d(A, b, dt);
			X = ltitr(Ad, Bd, U, x0);
			Y = C*X;
			
			if (version() == 4) {
				YY(i-1,0,Y) = Y;
				XX(i-1,0,X) = X;
			} else {
				YY(i,1,Y) = Y;
				XX(i,1,X) = X;
			}
		}
	} else {
		x0 = b = B(:,iu);
		{Ad, Bd} = c2d(A, b, dt);
		XX = ltitr(Ad, Bd, U, x0);
		YY = C*XX;
	}

	return {YY, XX};
}
