
/*  -*- MaTX -*-
 *
 *  NAME
 *      lti2_th() - Convert transfer function to theta-parameter
 *
 *  SYNOPSIS
 *       th = lti2_th(G)
 *        Matrix th;
 *        RaMatrix G;
 *
 *  DESCRIPTION
 *       lti2_th() converts transfer function matrix G of a linear time
 *       invarient system to the theta parameter th.
 *
 *       It is assumed that all the elements of the transfer function
 *       have the common denominator such as
 *
 *       y(k) = G(q)u(k) + w(k)
 *                               or
 *       y(k) = G(z)u(k) + w(k)
 *

G(q)=[[ b1_11 q^-1 + ... + b1_1n q^-n         bm_11 q^-1 + ... + bm_1n q^-n ]
      [-------------------------------, ..., -------------------------------]
      [ 1 + a_1 q^-1 + ... + a_n q^-n         1 + a_1 q^-1 + ... + a_n q^-n ]
      [                                                                     ]
      [                                                                     ]
      [ b1_p1 q^-1 + ... + b1_pn q^-n         bm_p1 q^-1 + ... + bm_pn q^-n ]
      [-------------------------------, ..., -------------------------------]
      [ 1 + a_1 q^-1 + ... + a_n q^-n         1 + a_1 q^-1 + ... + a_n q^-n ]]

G(z)=[[   b1_11 z^n-1 + ... + b1_1n             bm_11 z^n-1 + ... + bm_1n   ]
      [-------------------------------, ..., -------------------------------]
      [  z^n + a_1 z^n-1 + ... + a_n           z^n + a_1 z^n-1 + ... + a_n  ]
      [                                                                     ]
      [                                                                     ]
      [   b1_p1 z^n-1 + ... + b1_pn             bm_p1 z^n-1 + ... + bm_pn   ]
      [-------------------------------, ..., -------------------------------]
      [  z^n + a_1 q^z-n1 + ... + a_n          z^n + a_1 z^n-1 + ... + a_n  ]]

 *
 *      or in polynomial form:
 *
 *      [[y1(k)]       [[u1(k)]
 * A(q)  [y2(k)] = B(q) [u2(k)]  + w(k)
 *       [.....]        [.....]
 *       [yp(k)]]       [um(k)]] 
 * 
 * A(q) = diag(1 + a_1 q^-1 + ... a_n q^-n,
 *                       1 + a_1 q^-1 + ... a_n q^-n,
 *                                 ...........................,
 *                                           1 + a_1 q^-1 + ... a_n q^-n)
 * 
 * B(q) = [[1 + b1_11 q^-1 + ... b1_1n q^-n, 1 + b1_21 q^-1 + ... b1_2n q^-n
 *          ..............................., 1 + b1_m1 q^-1 + ... b1_mn q^-n]
 *         [1 + b2_11 q^-1 + ... b2_1n q^-n, 1 + b2_21 q^-1 + ... b2_2n q^-n
 *          ..............................., 1 + b2_m1 q^-1 + ... b2_mn q^-n]
 *         [................................................................]
 *         [1 + bp_11 q^-1 + ... bp_1n q^-n, 1 + bp_21 q^-1 + ... bp_2n q^-n
 *          ..............................., 1 + bp_m1 q^-1 + ... bp_mn q^-n]]
 *
 *      or in theta-parameter form:
 * 
 *     [[y1(k)]
 *      [y2(k)] = phi(k)#*th + w(k)
 *      [.....]
 *      [yp(k)]]
 *
 *	  th  : (n + p*n*m) x 1
 *	  phi : p x (n + p*n*m)
 *
 *  th = [[a_1]  th1 = [[b1_11] th2 = [[b1_21]   ... thp = [[b1_p2]
 *        [a_2]         [b1_12]        [b1_22]   ...        [b1_p2]
 *        [...]         [ ....]        [ ....]   ...        [ ... ]
 *        [a_n]         [b1_1n]        [b1_2n]   ...        [b1_pn]
 *        [th1]         [ ....]        [ ....]   ...        [ ... ]
 *        [th2]         [bm_11]        [bm_21]   ...        [bm_p2]
 *        [...]         [bm_12]        [bm_22]   ...        [bm_p2]
 *        [thp]]        [ ....]        [ ....]   ...        [ ... ]
 *                      [bm_1n]]       [bm_2n]]  ...        [bm_pn]]
 *
 *  phi(k) = [[YY(k)]
 *            [UU(k)]]
 *
 *  UU(k) = diag([[ u_1(k-1)]   [ u_1(k-1)]   ...,  [ u_1(k-1)]
 *                [  ....   ]   [  ....   ]   ...,  [  ....   ]
 *                [ u_1(k-n)]   [ u_1(k-n)]   ...,  [ u_1(k-n)]
 *                [  ....   ]   [   ....  ]   ...,  [  ....   ]
 *                [  ....   ]   [   ....  ]   ...,  [  ....   ]
 *                [ u_m(k-1)]   [ u_m(k-1)]   ...,  [ u_m(k-1)]
 *                [  ....   ]   [  ....   ]   ...,  [  ....   ]
 *                [ u_m(k-n)]], [ u_m(k-n)]], ...,  [ u_m(k-n)]])
 *
 *  YY(k) = [[-y_1(k-1), -y_2(k-1), ..., -y_p(k-1)]
 *           [  ....   ,   ....   , ...,   ....   ]
 *           [-y_1(k-n), -y_2(k-n), ..., -y_p(k-n)]]
 *
 */

Func Matrix lti2_th(G)
	RaMatrix G;
{
	Integer m;	// number of inputs
	Integer n;	// number of states
	Integer p;	// number of outputs
	Matrix th;	// theta parameter
	Integer i, j, ii;
	Polynomial N, D;

	m = Cols(G);
	p = Rows(G);
	D = De(G(1,1));
	n = degree(D);

	th = Z(n+m*n*p,1);
	if (version() == 4) {
		th(1:n,1) = [fliplr(Matrix(D))](2:n+1)#;
	} else {
		th(1:n,1) = [Matrix(D)](2:n+1)#;
	}
	
	for (i = 1; i <= p; i++) {
		for (j = 1; j <= m; j++) {
			N = Nu(G(i,j));
			ii = m*n*(i-1) + n*(j-1) + n;
			if (version() == 4) {
				th(ii+1:ii+n,1) = [fliplr(Matrix(N))](1:n)#;
			} else {
				th(ii+1:ii+n,1) = [Matrix(N)](1:n)#;
			}
		}
	}
	return th;
}


