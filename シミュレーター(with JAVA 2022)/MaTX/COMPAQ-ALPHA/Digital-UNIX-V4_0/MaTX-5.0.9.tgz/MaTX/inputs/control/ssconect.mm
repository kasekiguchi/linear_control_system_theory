
/* -*- MaTX -*-
 *
 *  NAME
 *      ssconnect() - Form an (A,B,C,D) state-space model of the system
 *
 *  SYNOPSIS
 *      {Ac,Bc,Cc,Dc} = ssconnect(A,B,C,D,Q,iu,iy)
 *         Matrix Ac,Bc,Cc,Dc;
 *         Matrix A,B,C,D,Q;
 *         Index iu,iy;   
 *
 *  DESCRIPTION
 *       ssconnect() returns the state-space model matrices (Ac,Bc,Cc,Dc) 
 *       of a system given the block diagonal, unconnected (A,B,C,D) 
 *       matrices and a matrix Q that specifies the interconnections.
 *
 *       The matrix Q has a row for each block, where the first element 
 *       of each row is the number of the block.  The subsequent
 *       elements of each row specify where the block gets its sum_ming inputs,
 *       with negative elements used to indicate minus inputs to the sum_ming
 *       junction.  
 *
 *       For example, if a block 7 gets its inputs from the outputs
 *       of blocks 2, 15, and 6, and the block 15 input is negative, the 7'th
 *       row of Q would be [7 2, -15 6].   Vectors iu and iy can be used to 
 *       select the final inputs and outputs for (Ac,Bc,Cc,Dc). 
 *
 *  SEE ALSO
 *      ssappend() and blkbuild()
 *
 */

Func List ssconnect(a,b,c,d,q,iu,iy)
	Matrix a,b,c,d,q;
	Index iu,iy;
{
	Matrix aa,bb,cc,dd;
	Integer i,m,md,mq,n,nd,nq;
	Matrix k,t;
	Array qi;
	String msg;

	msg = abcdchk(a, b, c, d);
	if (length(msg) > 0) {
		error("ssconnect(): " + msg);
	}

	{mq,nq} = size(q);
	{md,nd} = size(d); 

	/*
	 *	Form k from q, the feedback matrix such that u = k*y
	 *	forms the desired connected system.  k is a matrix of
	 *	zeros and plus or minus ones.
	 */
	k = Z(nd,md);

	// Go through rows of Q
	for (i = 1; i <= mq; i++) {
		// Remove zero elements from each row of Q
		qi = q(i,find(q(i,:)));
		{m,n} = size(qi);
		// Put the zeros and +-ones in K
		if (n != 1) {
			k(Integer(qi(1)),Index(abs(qi(2:n)))) = sgn(qi(2:n));
		}
	}

	/*
	 * Use output feedback to form closed loop system
	 *	.
	 *	x = Ax + Bu
	 *	y = Cx + Du      where  u = k*y + Ur 
	 *
	 */
	bb = b / (I(nd) - k*d);
	aa = a + bb*k*c;
	t = I(md) - d*k;
	cc = t \ c;
	dd = t \ d;

	// Select just the outputs and inputs wanted:
	bb = bb(:,iu);
	cc = cc(iy,:);
	dd = dd(iy,iu);

	return {aa,bb,cc,dd};
}
