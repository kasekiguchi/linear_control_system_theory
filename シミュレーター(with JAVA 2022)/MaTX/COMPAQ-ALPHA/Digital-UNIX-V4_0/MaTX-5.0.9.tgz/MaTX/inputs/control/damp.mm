
/* -*- MaTX -*-
 *
 *  NAME
 *      damp() - Natural frequency and damping factor
 *
 *  SYNOPSIS
 *      {wn, z} = damp(A)
 *         Matrix wn, z;
 *         Matrix A;
 *
 *  DESCRIPTION
 *       damp(A) returns vectors Wn and Z containing the natural frequencies
 *       and damping factors of A.   The variable A can be in one of several
 *       formats:
 *
 *        1) If A is square, it is assumed to be the state-space "A" matrix.
 *        2) If A is a row vector, it is assumed to be a vector of
 *           the polynomial coefficients from a transfer function.
 *        3) If A is a column vector, it is assumed to contain root locations.
 *
 *       In all cases, damp() returns the natural frequencies and damping
 *       factors of the system.
 *
 */

Func List damp(A)
	Matrix A;
{
	Matrix wn,z;
	Integer m,n;
	CoArray r;
	
	{m,n} = size(A);
	
	if (m == n) {
		r = eigval(A);
	} else if (m == 1) {
		if (version() == 4) {
			r = roots(Polynomial(fliplr(A)));
		} else {
			r = roots(Polynomial(A));
		}
	} else if (n == 1) {
		r = A;
	} else {
		error("damp(): Argument must be a vector or a square matrix.\n");
	}
	wn = abs(r);
	z = -cos(atan2(Im(r),Re(r)));
	return {wn, z};
}
