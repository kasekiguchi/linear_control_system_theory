
/* -*- MaTX -*-
 *
 *  NAME
 *      tfn2tfm() -  Transfer function to transfer function matrix conversion
 *
 *  SYNOPSIS
 *      G = tfn2tfm(g)
 *         RaMatrix G;
 *         Rational g;
 *
 *  DESCRIPTION
 *       tf2tfm() calculates the transfer function matrix representation:
 *
 *          .                              -1
 *          x = Ax + Bu    G(s) = C (sI - A) B + D
 *          y = Cx + Du
 *
 *      of the system, whose transfer function is the rational polynomial g,
 *      from a single input. 
 *
 *      The elements of G(s) have the same denominator. This calculation
 *      also works for discrete systems but the numerator must be padded with
 *      trailing zeros to make it the same length as the denominator.
 *
 *  SEE ALSO
 *      ss2tf() and tf2zp()
 */

Func RaMatrix tfn2tfm(g)
	Rational g;
{
	return [g];
}
