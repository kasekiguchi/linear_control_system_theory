
/*  -*- MaTX -*-
 *
 *  NAME
 *      ctr4demo() - Demonstration of control toolbox
 *
 *  SYNOPSIS
 *      ctr4demo()
 */

Func void ctr4demo()
{
	List mm;
	Integer i;
	void pgm4_1(), pgm4_2();
	
	mm = {"Observer",
		  "Using trasformation to observable canonical form",
		  "Using dual system",
		  "Quit"};

	i = 1;
	for (;;) {
		i = menu(mm, i);
		switch (i) {
		  case 1:
			pgm4_1();
			break;
		  case 2:
			pgm4_2();
			break;
		  default:
			return;
			break;
		}
		i++;
	}
}

/*
 * Design of full-order state observer
 */
Func void pgm4_1()
{
	Real a1, a2, a3, aa1, aa2, aa3;
	Complex i;
	Matrix A, C, N, W, T, Ke, J, JJ, p;

	print "\nObserver(using trasformation to observable canonical form)\n";
	print "\nInput A and C matrices\n";

	print "  A = [[ 0    1   0]\n";
	print "       [ 0    0   1]\n";
	print "       [-6, -11, -6]]\n";
	print "  C = [1 0 0]\n";
	pause;

	print A = [[0 1 0][0 0 1][-6,-11,-6]];
	print C = [1 0 0];

	print "\nCalculate observability matrix N\n";
	print "  N = obsv(A,C)\n";
	pause;

	print N = obsv(A,C);

	print "\nCheck the observability\n";
	print "  rank(N)\n";
	pause;

	print rank(N);

	print "\nCalculate the characteristic polynomial of A\n";
	print "  p = poly(A)";
	print "  a1 = p(2); a2 = p(3); a3 = p(4);\n";
	pause;

	print p = poly(A);
	a1 = p(2); a2 = p(3); a3 = p(4);	

	print "\nCalculate trasformation matrix T to observable canonical form\n";
	print "  W = [[a2 a1 1]\n";
	print "       [a1  1 0]\n";
	print "       [ 1  0 0]];\n";
	print "  T = W*N'\n";
	pause;

	W = [[a2 a1 1]
		 [a1  1 0]
		 [ 1  0 0]];

	print T = W * N';

	print "\nCalculate the characteristic polynomial of the observer\n";
	print "which has the desired poles.\n\n";

	print "  i = (0,1);\n";
	print "  J = diag(-2+2*sqrt(3.0)*i, -2-2*sqrt(3.0)*i, (-5.0,0.0))\n";
	print "  JJ = Re(poly(J))\n";
	print "  aa1 = JJ(2); aa2 = JJ(3); aa3 = JJ(4);\n";
	pause;

	i = (0,1);
	J = diag(-2+2*sqrt(3.0)*i, -2-2*sqrt(3.0)*i, (-5.0,0.0));
	print JJ = Re(poly(J));
	aa1 = JJ(2); aa2 = JJ(3); aa3 = JJ(4);

	print "\nCalculate the gain matrix Ke of observer\n";
	print "  Ke = T \\ [aa3 - a3, aa2 - a2 aa1 -a1]\n";
	pause;

	print Ke = T \ [[aa3 - a3][aa2 - a2][aa1 - a1]];

	pause;
}

/*
 * Design of full-order state observer
 */
Func void pgm4_2()
{
	Complex i;
	Polynomial phi;
	Matrix A, C, N, J, JJ, Phi, Ke;

	print "\nObserver(Using dual system)\n";
	print "\nInput A and C matrices\n";

	print "  A = [[ 0    1   0]\n";
	print "       [ 0    0   1]\n";
	print "       [-6, -11, -6]]\n";
	print "  C = [1 0 0]\n";
	pause;

	print A = [[0 1 0][0 0 1][-6,-11,-6]];
	print C = [1 0 0];

	print "\nCalculate observability matrix N\n";
	print "  N = obsv(A,C)\n";
	pause;

	print N = obsv(A,C);

	print "\nCheck observability\n";
	print "  rank(N)\n";
	pause;

	print rank(N);

	print "\nCalculate the characteristic polynomail of observer\n";
	print "which has the desired poles.\n";

	print "  i = (0,1);\n";
	print "  J = diag(-2+2*sqrt(3.0)*i, -2-2*sqrt(3.0)*i, (-5.0,0.0))\n";
	print "  JJ = Re(poly(J))\n";
	pause;

	i = (0,1);
	J = diag(-2+2*sqrt(3.0)*i, -2-2*sqrt(3.0)*i, (-5.0,0));
	print JJ = Re(poly(J));

	print "\nCalcuate polynomial matrix phi(A) using phi(s)\n";
	if (version() == 4) {
		print "  phi = Polynomial(fliplr(JJ))\n";
	} else {
		print "  phi = Polynomial(JJ)\n";
	}
	print "  Phi = eval(phi, A)\n\n";
	pause;
	
	if (version() == 4) {
		print phi = Polynomial(fliplr(JJ));
	} else {
		print phi = Polynomial(JJ);
	}
	print Phi = eval(phi, A);

	print "\nCalculate the gain matrix Ke of observer\n";
	print "  Ke = Phi * N' \\ [[0][0][1]]\n";
	pause;

	print Ke = Phi * N' \ [[0][0][1]];

	pause;
}
