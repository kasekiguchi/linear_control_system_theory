
/* -*- MaTX -*-
 *
 *  NAME
 *      tfm2tfn() - Transfer function matrix to transfer function conversion.
 *
 *  SYNOPSIS
 *     g = tfm2tfn(G)
 *        Rational g;
 *        RaMatrix G;
 *
 *     g = tfm2tf(G,iu)
 *        Rational g;
 *        RaMatrix G;
 *        Integer iu;
 *
 *     g = tfm2tf(G,iu,jo)
 *        Rational g;
 *        RaMatrix G;
 *        Integer iu;
 *        Integer jo;
 *
 *  DESCRIPTION
 *      tfm2tfn() calculates the transfer function representation
 *      from the iu'th input to jo'th output.
 *
 *  SEE ALSO
 *      ss2tf(), tf2zp() and tfm2ss()
 */

Func Rational tfm2tfn(G, iu, jo, ...)
	RaMatrix G;
	Integer iu;
	Integer jo;
{
	Rational g;

	error(nargchk(1, 2, nargs, "tfm2tfn"));
	
	if (nargs == 1) {
		iu = 1;
		jo = 1;
	} else if (nargs == 2) {
		iu = 1;
	}

	g = G(iu,jo);
	return g;
}
