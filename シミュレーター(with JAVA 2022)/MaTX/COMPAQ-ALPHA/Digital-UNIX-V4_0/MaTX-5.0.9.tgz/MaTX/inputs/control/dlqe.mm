
/* -*- MaTX -*-
 *
 *  NAME
 *      dlqe() - Discrete linear quadratic estimator design
 *
 *  SYNOPSIS
 *      {L,M,P} = dlqe(A,G,C,Q,R)
 *         Matrix L,M,P;
 *         Matrix A,G,C,Q,R;
 *
 *  DESCRIPTION
 *       For the discrete-time system:
 *
 *         x[n+1] = Ax[n] + Bu[n] + Gw[n]	    (State equation)
 *         z[n]   = Cx[n] + Du[n] +  v[n]	    (Measurements)
 *
 *       with process noise and measurement noise covariances:
 *
 *         E[w] = E[v] = 0,  E[ww'] = Q,  E[vv'] = R
 *
 *       the function dlqe() returns the gain matrix L
 *     	 such that the discrete, stationary Kalman filter:
 *  	      		
 *         x[n+1] = Ax[n] + Bu[n]                    (State update)
 *           x[n] = x[n] + L(z[n], - Hx[n], - Du[n]) (Observation update)
 *
 *       produces an LQG optimal estimate of x.
 *
 *       dlqe() returns the gain matrix L, the Riccati equation solution M,
 *       and the estimate error covariance after the measurment update:
 *
 *        P = E{[[x-x][x-x]]'}
 *
 *  SEE ALSO
 *      lqe()
 */

Func List dlqe(A,G,C,Q,R)
	Matrix A,G,C,Q,R;
{
	Matrix L,M,P,K,S;

	// Use dlqr() to calculate estimator gains using duality
	{K,S} = dlqr(A#, C#, G*Q*G#, R);
	M = S#;
	L = S*C#/(C*S*C# + R);
	P = A\(M - G*Q*G#)/A#;

	return {L,M,P};
}
