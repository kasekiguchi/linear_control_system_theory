
/*  -*- MaTX -*-
 *
 *  NAME
 *      blkbuild() - Builds a block diagonal state space structure
 *                   from a block diagram of transfer functions
 *
 *  SYNOPSIS
 *      {A,B,C,D} = blkbuild(n1,d1,n2,d2,....,n9,d9)
 *         Matrix A,B,C,D;
 *         Matrix n1,d1,n2,d2,...,n9,d9;
 *
 *  DESCRIPTION
 *       nblocks	is the number of blocks in the diagram.
 *
 *       n1...ni	are the numerator and denominator polynomials for the
 *         and		transfer function blocks 1 to i.
 *       d1...di
 *
 *       a,b,c,d	is the resulting state space structure.  The matrices
 *    	 are built up by progressive appended additions of the
 *    	 matrix representations of each of the transfer functions.
 *
 *  SEE ALSO
 *      ssconnect().
 *
 */

Func List blkbuild(n1,d1,n2,d2,n3,d3,n4,d4,n5,d5,n6,d6,n7,d7,n8,d8,n9,d9, ...)
	Matrix n1,d1,n2,d2,n3,d3,n4,d4,n5,d5,n6,d6,n7,d7,n8,d8,n9,d9;
{
	Integer i;
	Matrix A,B,C,D,a,b,c,d;

	{A,B,C,D} = tf2ss(n1, d1);
	if (nargs/2 >= 2) {
		{a,b,c,d} = tf2ss(n2, d2);
		{A,B,C,D} = ssappend(a,b,c,d,a,b,c,d);
	}
	if (nargs/2 >= 3) {
		{a,b,c,d} = tf2ss(n3, d3);
		{A,B,C,D} = ssappend(a,b,c,d,a,b,c,d);
	}
	if (nargs/2 >= 4) {
		{a,b,c,d} = tf2ss(n4, d4);
		{A,B,C,D} = ssappend(a,b,c,d,a,b,c,d);
	}
	if (nargs/2 >= 5) {
		{a,b,c,d} = tf2ss(n5, d5);
		{A,B,C,D} = ssappend(a,b,c,d,a,b,c,d);
	}
	if (nargs/2 >= 6) {
		{a,b,c,d} = tf2ss(n6, d6);
		{A,B,C,D} = ssappend(a,b,c,d,a,b,c,d);
	}
	if (nargs/2 >= 7) {
		{a,b,c,d} = tf2ss(n7, d7);
		{A,B,C,D} = ssappend(a,b,c,d,a,b,c,d);
	}
	if (nargs/2 >= 8) {
		{a,b,c,d} = tf2ss(n8, d8);
		{A,B,C,D} = ssappend(a,b,c,d,a,b,c,d);
	}
	if (nargs/2 >= 9) {
		{a,b,c,d} = tf2ss(n9, d9);
		{A,B,C,D} = ssappend(a,b,c,d,a,b,c,d);
	}
	if (nargs/2 >= 10) {
		error("blkbuild(): Too many blocks for blkbuild().\n");
	}
	
	return {A,B,C,D};
}

