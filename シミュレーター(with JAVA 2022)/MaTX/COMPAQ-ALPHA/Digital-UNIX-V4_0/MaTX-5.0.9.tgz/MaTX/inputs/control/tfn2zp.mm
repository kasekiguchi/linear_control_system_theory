
/* -*- MaTX -*-
 *
 *  NAME
 *      tfn2zp() - Transfer function to zero-pole conversion.
 *
 *  SYNOPSIS
 *      {z,p,k} = tfn2zp(g)
 *         CoMatrix z, p;
 *         Matrix k;
 *         Rational g;
 *
 *  DESCRIPTION
 *       tf2zp() finds the zeros, poles, and gains:
 *
 *                        (s-z1)(s-z2)...(s-zn)
 *              g(s) =  K ---------------------
 *                        (s-p1)(s-p2)...(s-pn)
 *
 *      from a SIMO transfer function g(s).
 *
 *      The zero locations are returned in the columns of matrix z.
 *      The pole locations are returned in column vector P, 
 *      and the gains for each numerator transfer function in vector K.
 *
 *  SEE ALSO
 *      tf2ss(), tf2tfm(), zp2ss(), zp2tf() and zp2tfm()
 */

Func List tfn2zp(g)
	Rational g;
{
	CoMatrix z, p;
	Matrix A, B, C, D, k;

	{A,B,C,D} = tfn2ss(g);
	{z,p,k} = ss2zp(A,B,C,D,1);
	return {z, p, k};
}
