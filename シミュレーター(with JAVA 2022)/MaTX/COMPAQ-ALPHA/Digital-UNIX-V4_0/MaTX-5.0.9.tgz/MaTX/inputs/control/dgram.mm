
/*  -*- MaTX -*-
 *
 *  NAME
 *      dgram() - Discrete-time controllability and observability gramians
 *
 *  SYNOPSIS
 *      G = dgram(A, B)
 *         Matrix G;
 *         Matrix A, B;
 *
 *  DESCRIPTION
 *       dgram(A,B) returns the discrete controllability gramian.
 *       dgram(A#,C#) returns the observability gramian.
 *
 *  SEE ALSO
 *      gram().
 *
 *  REFERENCES
 *      [1] Kailath, T. "Linear Systems", Prentice-Hall, 1980.
 *      [2] Laub, A., "Computation of Balancing Transformations",
 *          Proc. JACC Vol.1, paper FA8-E, 1980.
 *
 */

Func Matrix dgram(A, B)
	Matrix A, B;
{
	Matrix G, S, U, V, P;
	String msg;

	msg = abcdchk(A, B);
	if (length(msg) > 0) {
		error("dgram(): " + msg);
	}

	{U, S, V} = svd(B);
	P = dlyap(U#*A*U, S*S#);
	G = U*P*U#;

	G = (G + G#)/2;
	return G;
}
