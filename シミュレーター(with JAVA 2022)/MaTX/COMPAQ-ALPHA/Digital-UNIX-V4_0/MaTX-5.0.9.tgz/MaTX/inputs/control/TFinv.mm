
/* -*- MaTX -*-
 *
 *  NAME
 *      TFinv() -  Inverse a state-space system
 *
 *  SYNOPSIS
 *     {A,B,C,D} = TFinv(S)
 *        Matrix A,B,C,D;
 *        List S;
 *        S = {A1,B1,C1,D1}
 *
 *  DESCRIPTION
 *      TFinv() produces a state-space system of the inverse of system 1
 *      such that G = G1^(-1). 
 *
 */

Func List TFinv(G1)
	List G1;
{
	Matrix a1, b1, c1, d1;
	Matrix A, B, C, D;

	{a1, b1, c1, d1} = G1;

	A = a1 - b1*d1~*c1;
	B = b1*d1~;
	C = - d1~*c1;
	D = d1~;

	return {A, B, C, D};
}

