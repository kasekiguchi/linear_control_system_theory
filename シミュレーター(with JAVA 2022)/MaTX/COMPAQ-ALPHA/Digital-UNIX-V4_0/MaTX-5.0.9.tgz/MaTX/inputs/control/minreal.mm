
/* -*- MaTX -*-
 *
 *  NAME
 *      minreal() - Minimal realization and pole-zero cancellation
 *
 *  SYNOPSIS
 *      {Am,Bm,Cm,Dm,tol} = minreal(A,B,C,D)
 *         Real tol;
 *         Matrix Am,Bm,Cm,Dm;
 *         Matrix A,B,C,D;
 *
 *      {Am,Bm,Cm,Dm,tol} = minreal(A,B,C,D,tol)
 *         Real tol;
 *         Matrix Am,Bm,Cm,Dm;
 *         Matrix A,B,C,D;
 *         Real tol;
 *
 *      {Am,Bm,Cm,Dm,tol} = minreal(A,B,C,D,tol,order)
 *         Real tol;
 *         Matrix Am,Bm,Cm,Dm;
 *         Matrix A,B,C,D;
 *         Real tol;
 *         Integer order;
 *
 *  DESCRIPTION
 *      minreal() returns a minimal realization of the state-space system.
 *
 *      minreal(..., tol) uses the tolerance 'tol' in deciding which states
 *      to eliminate.
 *
 *      minreal(..., order) returns a realization of the state-space system
 *      of order 'order', while the tolerance is automaticaly decided.
 *
 *  SEE ALSO
 *      balreal()
 */

Func List minreal(A, B, C, D, tol, order, ...)
	Matrix A, B, C, D;
	Real tol;
	Integer order;
{
	Integer flag;
	Matrix Am, Bm, Cm, Dm;
	String msg;

	List minreal_local();

	error(nargchk(4, 6, nargs, "minreal"));

	msg = abcdchk(A, B, C, D);
	if (length(msg) > 0) {
		error("minreal(): " + msg);
	}

	if (nargs == 6) {
		if (order < 1 || Rows(A) < order) {
			error("minreal(): order must be between 1 and Rows(A)\n");
		}
	} else {
		order = Rows(A);
	}

	if (nargs != 5) {
		tol = 10*Rows(A)*norm(A,1)*EPS;
	}

	flag = 0;
	do {
		{Am, Bm, Cm, Dm} = minreal_local(A, B, C, D, tol);
		if (nargs != 6 || Rows(Am) == order) {
			break;
		}
		if (order < Rows(Am)) {
			if (flag == 2) {
				break;
			}
			tol = tol*2;
			flag = 1;
		} else if (order > Rows(Am)) {
			if (flag == 1) {
				break;
			}
			tol = tol/2;
			flag = 2;
		}
	} while (1);

	return {Am, Bm, Cm, Dm, tol};
}

Func List minreal_local(A, B, C, D, tol)
	Matrix A, B, C, D;
	Real tol;
{
	Matrix Am, Bm, Cm, Dm;
	Matrix T, K;
	Integer ns, nu, kk, nn;

	{ns, nu} = size(B);
	
	{Am, Bm, Cm, T, K} = ctrbf(A, B, C, tol);
	kk = Integer(sum(K));
	nu = ns - kk;
	nn = nu;
	if (kk > 0) {
		Am = Am(nu+1:ns,nu+1:ns);
		Bm = Bm(nu+1:ns,:);
		Cm = Cm(:,nu+1:ns);
	} else if (kk == 0) {
		Am = Z(0,0);
		Bm = Z(0,Cols(Bm));
		Cm = Z(Rows(Cm),0);
	}

	ns = ns - nu;
	if (ns) {
		{Am, Bm, Cm, T, K} = obsvf(Am, Bm, Cm, tol);
		kk = Integer(sum(K));
		nu = ns - kk;
		nn = nn + nu;
		if (kk > 0) {
			Am = Am(nu+1:ns,nu+1:ns);
			Bm = Bm(nu+1:ns,:);
			Cm = Cm(:,nu+1:ns);
		} else if (kk == 0) {
			Am = Z(0,0);
			Bm = Z(0,Cols(Bm));
			Cm = Z(Rows(Cm),0);
		}
	}

//	printf("%d states removed by minreal().\n", nn);
	Dm = D;

	return {Am, Bm, Cm, Dm};
}

/*
Func void main()
{
	Matrix a,b,c,d;
	Matrix am,bm,cm,dm;
	Rational G, Gm;
	Polynomial s;

	s = Polynomial("s")
	G = (s+1)/((s+1)*(s+2));
	print G;
	{a,b,c,d} = tfm2ss([G]);
	{am,bm,cm,dm} = minreal(a,b,c,d);
	print ss2tf(am,bm,cm,dm);
}
*/

