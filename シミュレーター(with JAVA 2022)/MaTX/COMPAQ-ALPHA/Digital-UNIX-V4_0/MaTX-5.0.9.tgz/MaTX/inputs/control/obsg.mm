
/* -*- MaTX -*-
 *
 *  NAME
 *      obsg() - Minimal order observer by Gopinath's method
 *
 *  SYNOPSIS
 *      {Ao,Bo,Co,Do} = obsg(A,B,C,D,P)
 *         Matrix Ao,Bo,Co,Do;
 *         Matrix A,B,C,D;
 *         CoMatrix P;
 *
 *  DESCRIPTION
 *      (A,B,C,D) : System 
 *             P  : Poles of the observer
 *
 *  SEE ALSO
 *      Gopinath()
 */

Func List obsg(A,B,C,D,P)
	Matrix A,B,C,D;
	CoMatrix P;
{
	Matrix Ao,Bo,Co,Do;
	Integer m,n,no,p;
	Matrix Ab,Ab11,Ab12,Ab21,Ab22,Bb,Bb1,Bb2,Cb,L,T,Ti;
	String msg;

	Matrix spl();

	msg = abcdchk(A, B, C, D);
	if (length(msg) > 0) {
		error("obsg(): " + msg);
	}

	{n,m} = size(B);
	{p,n} = size(C);
	no = n - p;

	Ti = spl(C,1);
	T = (Ti)~;
	Ab = Ti*A*T;
	Bb = Ti*B;
	Cb = C*T;
	
	Ab11 = Ab(1:no,1:no);
	Ab12 = Ab(1:no,no+1:n);
	Ab21 = Ab(no+1:n,1:no);
	Ab22 = Ab(no+1:n,no+1:n);
	Bb1 = Bb(1:no,:);
	Bb2 = Bb(no+1:n,:);

	L = place(Ab11#, Ab21#, P);
	L = L#;

	Ao = Ab11 - L*Ab21;
	Bo = [(Ao*L + Ab12 - L*Ab22), (Bb1 - L*Bb2)];
	Co = [[I(no)][Z(p,no)]];
	Do = [[L][I(p)]];
	Co = T*Co;
	Do = T*Do;

	return {Ao,Bo,Co,Do};
}


/* -*- MaTX -*-
 *
 *  NAME
 *      splt() - Supplement row vectors or column vectors to X
 *
 *  SYNOPSIS
 *      S = spl(X,sw)
 *         Matrix S;
 *         Matrix X;
 *         Integer sw;
 *
 *	DESCRIPTION
 *      Supplement row vectors or column vectors to X so that an
 *      augumented matrix S is non-singular.
 *
 *      sw specify a location of supplemented vectors
 *      sw = 0 : supplemented vectors are located after X
 *      sw = 1 : they are located before X
 *
 *      X must be full rank.
 */

Func Matrix spl(X,sw)
	Matrix X;
	Integer sw;
{
	Matrix S;
	Integer col,m,n,nd;
	Matrix d,s21,s22,u,v;

	{n,m} = size(X);

	if (n >= m) {
		col = 1;
		X = X#;
		nd = n;
		n = m;
		m = nd;
	} else {
		col = 0;
	}

	{u, d, v} = svd(X);
	s21 = Z(m-n,n);
	s22 = I(m-n);

	// scale = (d(1,1)+d(n,n))/2.0;
	// s22 = scale*s22;

	S = [[d][s21,s22]];

	// S = [[u,s21#][s21,v(n+1:m,n+1:m)]]*S*v#;
	S = [[u,s21#][s21,I(m-n)]]*S*v#;
	if (sw != 0) {
		S = [[S(n+1:m,:)][S(1:n,:)]];
	}
	if (col != 0) {
		S = S#;
	}
	
	return S;
}
