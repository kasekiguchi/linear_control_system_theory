
/* -*- MaTX -*-
 *
 *  NAME
 *      dbode()     - Bode response of discrete-time linear systems
 *      dbodeplot() - Plot Bode response of -time linear system
 *
 *  SYNOPSIS
 *      {Mag,Phase,w} = dbode(A,B,C,D,Ts)
 *          Array Mag, Phase;
 *          Matrix A,B,C,D;
 *          Real Ts;
 *
 *      {Mag,Phase,w} = dbode(A,B,C,D,Ts,iu)
 *          Array Mag, Phase;
 *          Matrix A,B,C,D;
 *          Real Ts;
 *          Integer iu;
 *
 *      {Mag,Phase,w} = dbode(A,B,C,D,Ts,iu,w)
 *          Array Mag, Phase;
 *          Matrix A,B,C,D;
 *          Real Ts;
 *          Integer iu;
 *          Array w;
 *
 *      dbodeplot(A,B,C,D,Ts)
 *          Matrix A,B,C,D;
 *          Real Ts;
 *
 *      dbodeplot(A,B,C,D,Ts,iu)
 *          Matrix A,B,C,D;
 *          Real Ts;
 *          Integer iu;
 *
 *      dbodeplot(A,B,C,D,Ts,iu,w)
 *          Matrix A,B,C,D;
 *          Real Ts;
 *          Integer iu;
 *          Array w;
 *
 *  DESCRIPTION
 *       dbode() calculates the frequency response of the system:
 *
 *         x[n+1] = Ax[n] + Bu[n]                     -1
 *         y[n]   = Cx[n] + Du[n]        G(z) = C(zI-A) B + D
 *
 *         mag(w) = abs(G(exp(jw))),   phase(w) = angle(G(exp(jw)))
 *
 *       from the iu'th input.  Ts is the sample period. Vector w must 
 *       contain the frequencies, in radians/sec, at which the Bode response
 *       is to be evaluated. Normally, the elements of w should not exceed 
 *       PI/Ts. Aliasing will occur at frequencies greater than the Nyquist 
 *       frequency (PI/Ts).  
 *
 *       dbode() returns matrices Mag (absolute value) and Phase (in degrees)
 *       with as many rows as there are outputs y, and with length(w) columns.
 *
 *       dbodeplot() plots matrices gain and phase (in degree) with as many 
 *       columns with length(w) rows.  
 *
 *  SEE ALSO
 *       See logspace() to generate frequency vectors that are equally 
 *       spaced logarithmically in frequency up to Pi. 
 */

Func List dbode(a, b, c, d, Ts, iu, w, ...)
	Matrix a, b, c, d;
	Real Ts;
	Integer iu;
	Array w;
{
	Matrix A, B, C, D;
	Array Mag, Phase, G;
	Integer no, ns, nw;
	Matrix P, T;
	Complex j;
	String msg;

	error(nargchk(4, 7, nargs, "dbode"));

	msg = abcdchk(a, b, c, d);
	if (length(msg) > 0) {
		error("dbode(): " + msg);
	}


	if (nargs < 5) {
		Ts = 1.0;
	}
	if (nargs < 6) {
		iu = 1;
	}
	if (nargs < 7) {
		w = logspace(-2.0, 3.0);
	}
	
	j = (0, 1);
	{no, ns} = size(c);
	nw = Cols(w);

	/// Balance A
	{T, A} = balance(a);
	B = T \ b;
	C = c * T;

	// Reduce A to Hessenberg form:
	{P, A} = hess(A);

	// Apply similarity transformations from 
	// Hessenberg reduction to B and C:
	B = P# * B(:,iu);
	C = C * P;
	D = d(:,iu);
	G = ltifr(A, B, exp(j*w*Ts));
	G = C*Matrix(G) + vec2diag(D)*ONE(no,nw);

	Mag = abs(G);
	Phase = 180/PI*unwrap(Im(log(G)));

//	Mag = 20*log10(abs(G));
	return {Mag, Phase, w};
}

Func void dbodeplot(A, B, C, D, Ts, iu, w, ...)
	Matrix A, B, C, D;
	Real Ts;
	Integer iu;
	Array w;
{
	Array gain, phase, dB0, deg180;
	Integer i, p, win;
	List name1, name2;
	
	if (nargs < 4 || 7 < nargs) {
		error("dbodeplot(): Incorrect number of arguments.\n");
	}
	if (nargs < 5) {
		iu = 1;
	}
	if (nargs < 6) {
		w = logspace(-2.0, 3.0);
	}
	if (nargs < 7) {
		Ts = 1.0;
	}

    dB0 = 0.00001*Z(w);
    deg180 = -180*ONE(w);
	{gain, phase} = dbode(A, B, C, D, Ts, iu, w);
	gain = 20*log10(gain);

	p = Rows(C);
	name1 = makelist(p+1);
	name2 = makelist(p+1);
	for (i = 1; i <= p; i++) {
		name1(i) = sprintf("gain-%d", i);
		name2(i) = sprintf("phase-%d", i);
	}
	name1(p+1) = "";
	name2(p+1) = "";

	win = mgplot_cur_win();
	mgplot_subplot(win,2,1,1);
    mgplot_xlabel(win, "w [rad/sec]");
    mgplot_ylabel(win, "gain [dB]");
	mgplot_title(win, "Bode Plot (gain)");
	mgplot_semilogx(win, w, [[gain][dB0]], name1);

	mgplot_subplot(win,2,1,2);
	mgplot_title(win, "Bode Plot (phase)");
    mgplot_xlabel(win, "w [rad/sec]");
    mgplot_ylabel(win, "phase [deg]");
	mgplot_semilogx(win, w, [[phase][deg180]], name2);

	mgplot_reset(win);

//  mgreplot_semilogx(win, w, dB0, {""});
//  mgreplot_semilogx(2, w, deg180, {""});
//	mgplot_reset(2);
}
