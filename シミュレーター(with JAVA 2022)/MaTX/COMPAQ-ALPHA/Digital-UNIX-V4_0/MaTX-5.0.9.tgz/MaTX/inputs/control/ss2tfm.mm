
/* -*- MaTX -*-
 *
 *  NAME
 *      ss2tfm() - State-space to transfer function matrix conversion
 *
 *  SYNOPSIS
 *      G = ss2tfm(A,B,C,D)
 *        RaMatrix G;
 *        Matrix A,B,C,D;
 *
 *      G = ss2tfm(A,B,C,D,iu)
 *        RaMatrix G;
 *        Matrix A,B,C,D;
 *        Integer iu;
 *
 *  DESCRIPTION
 *       ss2tfm() calculates the transfer function matrix:
 *                      -1
 *         G(s) = C(sI-A) B + D
 *
 *       of the system:
 *         .
 *         x = Ax + Bu,  y = Cx + Du
 *
 *       ss2tfm(...,iu) calculates the transfer function matrix:
 *
 *                     -1
 *         G(s) = C(sI-A) B(:,iu) + D(:,iu)
 *
 *      of the system:
 *         .
 *         x = Ax + Bu,  y = Cx + Du
 *
 *      from the iu'th input.
 *
 *  SEE ALSO
 *      ss2tf() and ss2zp()
 */

Func RaMatrix ss2tfm(A, B, C, D, iu, ...)
	Matrix A, B, C, D;
	Integer iu;
{
	Integer i, m, p;
	Matrix den, NUM;
	Polynomial s;
	RaMatrix G;
	String msg;

	error(nargchk(4, 5, nargs, "ss2tfm"));

	msg = abcdchk(A, B, C, D);
	if (length(msg) > 0) {
		error("ss2tfm(): " + msg);
	}
	
	if (nargs == 5) {
		{NUM, den} = ss2tf(A, B, C, D, iu);
		G = tf2tfm(NUM, den);
	} else {
		{p,m} = size(D);

		s = Polynomial("s");
		if (isreal(A) && isreal(B) && isreal(C) && isreal(D)) {
			G = Z(p,m,1/s);				// p x m rational matrix
		} else {
			G = (Z(p,m,1/s),:);			// p x m rational matrix
		}
		for (i = 1; i <= m; i++) {
			{NUM, den} = ss2tf(A, B, C, D, i);
			G(:,i) = tf2tfm(NUM, den);
		}
	}

	return G;
}
