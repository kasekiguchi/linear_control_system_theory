
/* -*- MaTX -*-
 *
 *  NAME
 *      tf2zp() - Transfer function to zero-pole conversion.
 *
 *  SYNOPSIS
 *      {z,p,k} = tf2zp(NUM,den)
 *         CoMatrix z, p;
 *         Matrix k;
 *         Matrix NUM, den;
 *
 *  DESCRIPTION
 *       tf2zp() finds the zeros, poles, and gains:
 *
 *                        (s-z1)(s-z2)...(s-zn)
 *              H(s) =  K ---------------------
 *                        (s-p1)(s-p2)...(s-pn)
 *
 *      from a SIMO transfer function in polynomial form:
 *
 *                      NUM(s)
 *              H(s) = -------- 
 *                      den(s)
 *
 *      Vector den specifies the coefficients of the denominator in 
 *      descending powers of s.  Matrix NUM indicates the numerator 
 *      coefficients with as many rows as there are outputs.  The zero
 *      locations are returned in the columns of matrix z, with as many 
 *      columns as there are rows in NUM.  The pole locations are returned 
 *      in column vector P, and the gains for each numerator transfer function
 *      in vector K.
 *
 *  SEE ALSO
 *      tf2ss(), tf2tfm(), zp2ss(), zp2tf() and zp2tfm()
 */

Func List tf2zp(NUM, den)
	Matrix NUM, den;
{
	CoMatrix z, p;
	Matrix A, B, C, D, k;

	{A,B,C,D} = tf2ss(NUM, den);
	{z,p,k} = ss2zp(A,B,C,D,1);
	return {z, p, k};
}
