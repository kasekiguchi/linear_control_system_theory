
/* -*- MaTX -*-
 *
 *  NAME
 *      ss2zp()	- State-space to zero-pole conversion
 *
 *  SYNOPSIS
 *      {z,p,k} = ss2zp(A,B,C,D)
 *         CoMatrix z,p;
 *         Matrix k;
 *         Matrix A,B,C,D;
 *
 *      {z,p,k} = ss2zp(A,B,C,D,iu)
 *         CoMatrix z,p;
 *         Matrix k;
 *         Matrix A,B,C,D;
 *         Integer iu;
 *
 *  DESCRIPTION
 *       ss2zp() calculates the transfer function in factored form:
 *
 *                         -1          (s-z1)(s-z2)...(s-zn)
 *      	H(s) = C(sI-A) B + D =  k ---------------------
 *                                     (s-p1)(s-p2)...(s-pn)
 *      of the system:
 *          .
 *          x = Ax + Bu,  y = Cx + Du
 *
 *      from the iu'th input.  Vector p contains the pole locations of the
 *      denominator of the transfer function.  The numerator zeros are
 *      returned in the columns of matrix z with as many columns as there are
 *      outputs y.  The gains for each numerator transfer function are 
 *      returned in column vector k.
 *
 *  SEE ALSO
 *      ss2tf() and ss2tfm()
 */

Func List ss2zp(A, B, C, D, iu, ...)
	Matrix A, B, C, D;
	Integer iu;
{
	Matrix k, b, d, CAn, markov, s1, s2;
	CoMatrix p, zv, z;
	Integer i, iter, no, ns;
	Index idx;
	String msg;

	error(nargchk(4, 5, nargs, "ss2zp"));

	msg = abcdchk(A, B, C, D);
	if (length(msg) > 0) {
		error("ss2zp(): " + msg);
	}
	
	if (nargs == 4) {
		iu = 1;
	}

	// Remove relevant input:
	b = B(:,iu);
	d = D(:,iu);

	// Do poles first, they're easy:
	p = eigval(A);

	// Now try zeros, they're harder:
	{no,ns} = size(C);
	z = (ONE(ns,no),:)*Inf;		// Set whole z matrix to infinities

	// Loop through outputs, finding zeros
	for (i = 1; i <= no; i++) {
		s1 = [[A b][C(i,:), Matrix(d(i))]];
		s2 = vec2diag([ONE(1,ns), Z(1)]);
		zv = eigval(s1,s2);
		// Now put NS valid zeros into Z. There will always
		// be at least one NaN or infinity.
		zv = zv( ! isnan(zv) && isfinite(zv));
		if ( ! isempty(zv)) {
			z(1:length(zv),i) = zv;
		}
	}

	// Now finish up by finding gains using Markov parameters
	k = d;
	CAn = C;
	iter = 0;
	while (any(k .== 0)) {	// do until all k's are finished
		idx = find(k .== 0);
		if (iter > ns) {
			// Note: iter count is needed because when B is all zeros
			// it does not otherwise converge.
			k(idx) = Z(length(idx),1);
			break;
		}
		iter = iter + 1;
		markov = CAn*b;
		k(idx) = markov(idx);
		CAn = CAn*A;
	}

	return {z, p, k};
}
