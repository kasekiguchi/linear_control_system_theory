
/* -*- MaTX -*-
 *
 *  NAME
 *      TFnegate() -  Negate a state-space system
 *
 *  SYNOPSIS
 *      {A,B,C,D} = TFnegate(S)
 *          Matrix A,B,C,D;
 *          List S;
 *          S = {A1,B1,C1,D1};
 *
 *  DESCRIPTION
 *      TFnegate() produces a state-space system of the negate of system 1
 *      such that Y = - Y1.  The resulting system is:
 *      	 .
 *      	|x1| = |A1| |x1| + |B1||u|
 *
 *      	|y| = - y1 = |- C1| |x1| + |- D1| |u|
 *
 *                   G = - G1
 *
 *               +----+    +----+
 *           --->| G1 |--->| -1 |--->
 *               +----+    +----+
 *   
 */

Func List TFnegate(G1)
	List G1;
{
	Matrix a1, b1, c1, d1;

	{a1, b1, c1, d1} = G1;
	return {a1, -b1, c1, -d1};
}

