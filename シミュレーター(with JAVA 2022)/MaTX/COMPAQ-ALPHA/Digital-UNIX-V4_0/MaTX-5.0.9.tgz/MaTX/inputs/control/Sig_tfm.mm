
/* -*- MaTX -*-
 *
 *  NAME
 *      Sig_tfm() - Singular Value Frequency Response
 *
 *  SYNOPSIS
 *      SV = Sig_tfm(G, W, type)
 *         Matrix SV;
 *         RaMatrix G;
 *         Matrix w;
 *         Integer type;
 *
 *  DESCRIPTION
 *      Sig_tfm(G, W, type) produces the matrix SV containing the singular 
 *      values of the square system G(s) with the frequency response G(jw).
 *      The singular values are sorted according to their value as
 *
 *      [maxsing, ..., minsing]'.
 *
 *      Sig_tfm() calculates the SVD of one of the following types:
 *
 *          Type = 1   ----   G(jw) 
 *          Type = 2   ----   inv(G(jw))
 *          Type = 3   ----   I + G(jw)
 *          Type = 4   ----   I + inv(G(jw)) 
 *
 *      Vector W contains the frequencies at which the frequency response
 *      is to be evaluated. The SV matrix has rows which correspond to the 
 *      singular values in decending order.
 *
 */

Func Array Sig_tfm(G, w, type)
	RaMatrix G;
	Array w;
	Integer type;
{
	Integer i, m, n;
	Complex j;
	CoMatrix Gw;
	Array SV;

	print "\n          ..... Working ...... please wait .....\n";
	
	j = (0,1);
	m = Cols(G);
	n = Cols(w);

	SV = Z(m, n);
	for (i = 1; i <= n; i++) {
		Gw = eval(G, j*w(i));
		if (type == 1) {
			SV(:,i) = singval(Gw);
		} else if (type == 2) {
			SV(:,i) = singval(Gw~);
		} else if (type == 3) {
			SV(:,i) = singval(I(Gw) + Gw);
		} else if (type == 4) {
			SV(:,i) = singval(I(Gw) + Gw~);
		} else {
			error("Sig_tfm(): type is incorrect.\n");
		}
	}

	return SV;
}

