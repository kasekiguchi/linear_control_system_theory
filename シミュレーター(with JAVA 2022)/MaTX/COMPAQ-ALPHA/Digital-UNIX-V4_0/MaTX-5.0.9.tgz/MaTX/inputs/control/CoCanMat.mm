
/* -*- MaTX -*-
 *
 *  NAME
 *      CoCanMat() - Transformation matrix to transform a SISO system matrix
 *                   to the controlable canonical form
 *
 *  SYNOPSIS
 *      T = CoCanMat(A,b)
 *         Matrix T;
 *         Matrix A,b;
 *
 */

Func Matrix CoCanMat(A, b)
	Matrix A, b;
{
	Integer n;
	Matrix T, Tinv_trans, V, Vinv;

	n = Rows(A);
	V = ctrb(A, b);
	Vinv = V~;

	// l# = Vinv(n,:)
	// (T~)# = [l A#*l A#^2*l ... A#^(n-1)*l]

	Tinv_trans = ctrb(A#, Vinv(n,:)#);
	T = (Tinv_trans#)~;

	return T;
}


/*
Func void main()
{
	Matrix A, b;
	Matrix T;
	Integer order_of_system;

	Matrix CoCanMat();
	List InputAB();

	while (1) {
		read order_of_system;
		if (order_of_system == 0) {
			break;
		}

		{A, b} = InputAB(order_of_system);

		T = CoCanMat(A, b);
		print T;
	}
}
*/

