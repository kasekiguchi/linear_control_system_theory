
/* -*- MaTX -*-
 *
 *  NAME
 *      ngrid() - Grid lines for a Nichols chart
 *
 *  SYNOPSIS
 *      ngrid()
 *
 *  DESCRIPTION
 *      ngrid() generates grid lines for a Nichols chart. The
 *      chart relates H/(1+H) to H, where H is any complex number.
 *      ngrid() generates a grid over the region 0.1 < abs(H) < 100
 *      and -200 < angle(H) < -50 degrees with lines of constant
 *      abs(H/(1+H)) and angle(H/(1+H)) drawn in.
 *
 *  EXAMPLE
 *      {mag,phase} = bode(num,den,w);
 *      mgplot_grid(win,1);
 *      mgplot_semilogy(win,phase,mag);
 *
 *	REFERENCE
 *      [1] J.K Roberge, Operational Amplifiers: Theory and Practice,
 *          John Wiley and Sons, 1975, pg. 152.
 */

Func void ngrid()
{
	Integer i,j,mm,np,win;
	Complex ii;
	Matrix gain,m,p,phase;
	CoMatrix g, z;
	List name, cols;

	win = mgplot_cur_win();
	ii = (0,1);

	// Define desired gain and phase curves
	m = [0.01 0.1 0.2 0.5 0.8 0.9 0.95 0.98 0.99 0.995 0.998 0.999
		 1.001 1.002 1.005 1.01 1.02 1.05 1.1 1.2 1.5 2 3];
	p = [-359.99999, -359.9, -359.8, -359.5, -359, -358, -355, -350,
		 -340, -330, -310, -290, -270, -250, -230, -210, -150, -130,
		 -110, -90, -70, -50, -30, -20, -10, -5, -2, -1, -0.5, -0.2,
		 -0.1, -0.00001];

	// Perform mapping and plot Nichols grid lines
	{p,m} = meshdom(p,m);
	z = m .* Matrix(exp(ii*Array(p)/180*PI));
	g = z ./ (1 .- z);
	gain = 20*log10(abs(Array(g)));
	phase = rem(angle(g)/PI*180 .+ 360, 360.0) .- 360;

	name = makelist(length(m));
	cols = makelist(length(m));
	for (i = 1; i <= length(m); i++) {
		name(i) = "";
		cols(i) = "5";
	}

	mgplot(win,phase(1,:),gain(1,:),{""},{"5"});
	mgplot_range(win, -360.0, 10.0, -50.0, 60.0);

	/*
	 * Now put text labels on the curve.  No clean way to do this,
	 * so we'll just have to brute-force it.
	 */
	{mm,np} = size(p);
	j = np - 1;
	for (i = 1; i <= 17; i++) {
		mgplot_text(win,sprintf("%.4g",m(i,1)),phase(i,j),gain(i,j));
	}

	j = np - 7;
	for (i = 19; i <= 21; i++) {
		mgplot_text(win,sprintf("%.4g",m(i,1)),phase(i,j),gain(i,j));
	}

	j = np - 11;
	for (i = 22; i <= mm; i++) {
		mgplot_text(win,sprintf("%.4g",m(i,1)),phase(i,j),gain(i,j));
	}

	i = mm;

	j = 12;
	mgplot_text(win,sprintf("%.4g",p(1,j)),phase(i,j)-5,gain(i,j)-.05);

	for (j = 13; j <= 21; j = j + 2) {
		mgplot_text(win,sprintf("%.4g",p(1,j)),phase(i,j)-5,gain(i,j)-.05);
	}

	for (j = 22; j <= 26; j++) {
		mgplot_text(win,sprintf("%.4g",p(1,j)),phase(i,j)-5,gain(i,j)-.05);
	}

	i = mm - 13;
	for (j = 27; j <= np; j++) {
		mgplot_text(win,sprintf("%.4g",p(1,j)),phase(i,j)-5,.73*gain(i,j));
	}

	mgplot(win,phase,gain,name,cols);
	mgreplot(win,phase#,gain#,name,cols);
}
