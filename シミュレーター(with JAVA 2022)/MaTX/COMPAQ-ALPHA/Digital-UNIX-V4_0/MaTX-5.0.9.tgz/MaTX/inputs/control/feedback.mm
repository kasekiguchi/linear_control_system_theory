
/* -*- MaTX -*-
 *
 *  NAME
 *      feedback() - Connect the dynamics of two state-space systems
 *                   using feedback
 *
 *  SYNOPSIS
 *      {A,B,C,D} = feedback(A1,B1,C1,D1,A2,B2,C2,D2)
 *          Matrix A,B,C,D;
 *          Matrix A1,B1,C1,D1,A2,B2,C2,D2;
 *
 *  DESCRIPTION
 *       feedback() produces an aggregate state-space system consisting
 *       of the negative feedback connection of the two systems 1 and 2.
 *       Typically, system 1 is a plant and system 2 a compensator.
 *       Given two systems:
 *          .
 *          x1 = A1*x1 + B1*u1
 *          y1 = C1*x1 + D1*u1         u->--S---s1---+--->y
 *          .                               |        |
 *          x2 = A2*x2 + B2*u2              +-<-s2---+
 *          y2 = C2*x2 + D2*u2
 *
 *       then the connection is described by  u1 = u - y2
 *       resulting in the new system:
 *
 *         x = A*x + B*u
 *         y = C*x + B*u
 *
 *       where the output y is the same as the old y1.
 *
 *  SEE ALSO
 *      series(), parallel(), ssappend(), and ssconnect().
 *
 */

Func List feedback(A1,B1,C1,D1,A2,B2,C2,D2)
	Matrix A1,B1,C1,D1,A2,B2,C2,D2;
{
	Matrix A,B,C,D;
	Integer md1,md2,nd1,nd2;
	Matrix T;
	String msg;

	msg = abcdchk(A1, B1, C1, D1);
	if (length(msg) > 0) {
		error("feedback(): " + msg);
	}
	msg = abcdchk(A2, B2, C2, D2);
	if (length(msg) > 0) {
		error("dmodred(): " + msg);
	}

	{md1,nd1} = size(D1);
	{md2,nd2} = size(D2);

	T = I(md1) + D1*D2;
	A = [[A1-B1*D2/T*C1  B1*(D2/T*D1-I(nd1))*C2]
		 [   B2/T*C1        A2-B2/T*D1*C2      ]];
	B = [[B1*(I(md2)-D2/T*D1)]
		 [     B2/T*D1       ]];
	C = [T\C1, -T\D1*C2];
	D = T\D1;
	return {A,B,C,D};
}
