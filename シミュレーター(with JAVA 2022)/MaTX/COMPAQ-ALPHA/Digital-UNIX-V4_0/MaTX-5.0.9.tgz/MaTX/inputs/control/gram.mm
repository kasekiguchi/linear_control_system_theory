
/* -*- MaTX -*-
 *
 *  NAME
 *      gram() - Controllability and observability gramians
 *
 *  SYNOPSIS
 *      G = gram(A, B)
 *         Matrix G;
 *         Matrix A, B;
 *
 *  DESCRIPTION
 *      gram(A, B) returns the controllability gramian:
 *
 *        Gc = integral {exp(At) B B# exp(A#t)} dt
 *
 *      gram(A#,C#) returns the observability gramian:
 *
 *        Go = integral {exp(A#t) C# C exp(At)} dt
 *
 *  SEE ALSO
 *      dgram(), ctrb() and obsv().
 *
 *  REFERENCES 
 *       [1] Laub, A., "Computation of Balancing Transformations",
 *           Proc. JACC Vol.1, paper FA8-E, 1980.
 *
 */

Func Matrix gram(A, B)
	Matrix A, B;
{
	Matrix U, S, V, G;
	String msg;

	msg = abcdchk(A, B);
	if (length(msg) > 0) {
		error("gram(): " + msg);
	}

	{U, S, V} = svd(B);
	G = U * lyap(U#*A*U, S*S#) * U#;
	G = (G + G#)/2;
	return G;
}
