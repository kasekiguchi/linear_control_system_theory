
/* -*- MaTX -*-
 *
 *  NAME
 *      stepfun() - Unit step function
 *
 *  SYNOPSIS
 *      y = stepfun(t, t0)
 *         Array y;
 *         Array t;
 *         Real t0;
 *
 *  DESCRIPTION
 *       stepfun(T,T0), where T is a monotonically increasing vector,
 *       returns a vector the same length as T with zeros where T < T0
 *       and ones where T >= T0.
 *
 *  SEE ALSO
 *      step()
 */

Func Array stepfun(t,to)
	Array t;
	Real to;
{
	Integer m,n,i;
	Array y;
	Index idx;

	{m,n} = size(t);
	y = Z(m,n);

	idx = find(t >= to);
	if (isempty(idx)) {
		return y;
	}
	i = idx(1);
	if (m == 1) {
		y(i:n) = ONE(1,n-i+1);
	} else {
		y(i:m) = ONE(m-i+1,1);
	}
	return y;
}
