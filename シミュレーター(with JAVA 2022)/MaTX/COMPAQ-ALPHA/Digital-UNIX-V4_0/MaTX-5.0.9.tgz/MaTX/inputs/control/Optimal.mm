
/* -*- MaTX -*-
 *
 *  NAME
 *      Optimal() - Linear quadratic regulator design for 
 *                  continuous-time system
 *
 *  SYNOPSIS
 *      F = Optimal(A,B,Q,R)
 *         Matrix F;
 *         Matrix A,B,Q,R;
 *
 *      F = Optimal(A,B,Q,R,S)
 *         Matrix F;
 *         Matrix A,B,Q,R,S;
 *
 *  DESCRIPTION
 *       Optimal() is obsolete.
 *
 *       Use  {F} = lqr(A,B,Q,R); F = -F;  for  F = Optimal(A,B,Q,R).
 */

Func Matrix Optimal(A, B, Q, R, S, ...)
	Matrix A, B, Q, R, S;
{
	Matrix F;

	error(nargchk(4, 5, nargs, "Optimal"));

	if (nargs == 4) {
		{F} =  lqr(A,B,Q,R);
		F = -F;
	} else {
		{F} =  lqr(A,B,Q,R,S);
		F = -F;
	}
	return F;
}
