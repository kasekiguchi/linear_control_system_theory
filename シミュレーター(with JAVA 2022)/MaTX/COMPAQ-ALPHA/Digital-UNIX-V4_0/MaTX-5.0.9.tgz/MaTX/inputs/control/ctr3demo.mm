
/*  -*- MaTX -*-
 *
 *  NAME
 *      ctr3demo() - Demonstration of control toolbox
 *
 *  SYNOPSIS
 *      ctr3demo()
 */


Func void ctr3demo()
{
	List mm;
	Integer i;
	void pgm3_1(), pgm3_2();
	
	mm = {"Servo Control System",
		  "Plant with an integrator",
		  "Plant without integrator",
		  "Quit"};

	i = 1;
	for (;;) {
		i = menu(mm, i);
		switch (i) {
		  case 1:
			pgm3_1();
			break;
		  case 2:
			pgm3_2();
			break;
		  default:
			return;
			break;
		}
		if (i == 3) { break; }
		i++;
	}
}

/*
 * Design of a type 1 servo system
 */
Func void pgm3_1()
{
	Integer win;
	Complex i;
	Matrix A, B, C, D, K;
	Real k1, k2, k3;
	Matrix AA, BB, CC, DD;
	Matrix M, P;
	Array t, x, y;

	print "\nDesign of 1-type servo control system\n";
	print "\nPlant with an integrator\n";

	print "\nInput A, B, C, and D matrices\n";
	print "  A = [[0   1   0]\n";
	print "       [0   0   1]\n";
	print "       [0, -2, -3]]\n";
	print "  B = [[0]\n";
	print "       [0]\n";
	print "       [1]]\n";
	print "  C = [1 0 0]\n";
	print "  D = [0]\n";
	pause;

	print A = [[0   1   0]
			   [0   0   1]
			   [0, -2, -3]];
	print B = [[0]
			   [0]
			   [1]];
	print C = [1 0 0];
	print D = [0];

	print "\nCalculate controllability matrix M\n";
	print "  M = ctrb(A,B)\n";
	pause;

	print M = ctrb(A,B);

	print "\nCheck controllability\n";
	print "  rank(M)\n";
	pause;

	print rank(M);

	print "\nMake a vector whose elements are desired closed-loop poles\n";
	print "  i = (0,1);\n";
	print "  P = [[-2+2*sqrt(3.0)*i]\n";
	print "       [-2-2*sqrt(3.0)*i]\n";
	print "       [       -10      ]]\n";
	pause;

	i = (0,1);
	print P = [[-2+2*sqrt(3.0)*i]
			   [-2-2*sqrt(3.0)*i]
			   [      -10       ]];

	print "\nSolve pole assignment problem\n";
	print "  K = - PoleAssign(A, B, P)\n";
	print "  k1 = K(1); k2 = K(2); k3 = K(3);\n";
	pause;

	print K = - PoleAssign(A, B, P);
	k1 = K(1); k2 = K(2); k3 = K(3);
	pause;

	print "\nStep response of servo system(Plant with an integrator)\n\n";
	print "Calculate the state equation and output equation of the closed-loop system.\n\n";

	print "  AA = A - B*K\n";
	print "  BB = B*k1\n";
	print "  CC = C\n";
	print "  DD = D\n";
	pause;

	AA = A - B*K;
	BB = B*k1;
	CC = C;
	DD = D;

	print "\nCalculate the step response\n";
	print "  t = linspace(0.0, 3.0);\n";
	print "  {y, x} = step_ss(AA, BB, CC, DD, 1, t);\n";
	pause;

	t = linspace(0.0, 3.0);
	{y, x} = step_ss(AA, BB, CC, DD, 1, t);

	print "\nPlot the step response (y vs t)\n";
	print "  mgplot_subplot(win, 2, 1, 1);\n";
	print "  mgplot_grid(win, 1);\n";
	print "  mgplot_title(win, \"Unit-Step Response of the Designed Servo System\");\n";
	print "  mgplot_xlabel(win, \"Sec\");\n";
	print "  mgplot_ylabel(win, \"Output y\");\n";
	print "  mggplot(win, t, y, {\"y\"});\n";
	pause;
	win = mgplot_cur_win();
	mgplot_reset(win);

	mgplot_subplot(win, 2, 1, 1);
	mgplot_grid(win, 1);
	mgplot_title(win, "Unit-Step Response of the Designed Servo System");
	mgplot_xlabel(win, "Sec");
	mgplot_ylabel(win, "Output y");
	mgplot(win, t, y, {"y"});

	print "\nPlot step response (x vs t)\n";
	print "  mgplot_subplot(win, 2, 1, 2);\n";
	print "  mgplot_grid(win, 1);\n";
	print "  mgplot_title(win, \"Step-Response Curves for x1, x2, x3\");\n";
	print "  mgplot_xlabel(win, \"Sec\");\n";
	print "  mgplot_ylabel(win, \"x1, x2, x3\");\n";
	print "  mgplot_text(win, \"x1\", 1.2,  1.55);\n";
	print "  mgplot_text(win, \"x2\", 0.45, 2.4);\n";
	print "  mgplot_text(win, \"x3\", 0.28, 6.0);\n";
	print "  mgplot(win, t, x, {\"x1\", \"x2\", \"x3\"});\n";
	pause;

	mgplot_subplot(win, 2, 1, 2);
	mgplot_grid(win, 1);
	mgplot_title(win, "Step-Response Curves for x1, x2, x3");
	mgplot_xlabel(win, "Sec");
	mgplot_ylabel(win, "x1, x2, x3");
	mgplot_text(win, "x1", 1.2,  1.55);
	mgplot_text(win, "x2", 0.45, 2.4);
	mgplot_text(win, "x3", 0.28, 6.0);
	mgplot(win, t, x, {"x1", "x2", "x3"});

	print "\n";
	pause;
}

/*
 * Design of an inverted pendulum control system
 */
Func void pgm3_2()
{
	Integer win;
	Complex i;
	Matrix A, B, C, D, K;
	Real k1, k2, k3, k4, KI;
	Matrix A1, B1, KK, M, P;
	Matrix AA, BB, CC, DD, K;
	Array t, x, y;

	print "\nPlant without integrator\n";
	print "\nInput A, B, C, and D matrices\n";

	print "  A = [[      0 1 0 0]\n";
	print "       [ 20.601 0 0 0]\n";
	print "       [      0 0 0 1]\n";
	print "       [-0.4905 0 0 0]];\n";
	print "  B = [[ 0 ]\n";
	print "       [ -1]\n";
	print "       [ 0 ]\n";
	print "       [0.5]];\n";
	print "  C = [0 0 1 0];\n";
	print "  D = [0];\n";
	pause;

	A = [[      0 1 0 0]
		 [ 20.601 0 0 0]
		 [      0 0 0 1]
		 [-0.4905 0 0 0]];
	B = [[0][-1][0][0.5]];
	C = [0 0 1 0];
	D = [0];

	print "\nAugment A, B, C, D of plant to get A1 and B1 as\n";
	print "  A1 = [[ A Z(4,1)]\n";
	print "        [-C,  Z(1)]]\n";
	print "  B1 = [[B]\n";
	print "        [0]]\n";
	pause;

	print A1 = [[A Z(4,1)][-C, Z(1)]];
	print B1 = [[B][0]];

	print "\nCalculate the controllability matrix M of augmented system\n";
	print "  M = ctrb(A1, B1)\n";
	pause;

	print M = ctrb(A1, B1);

	print "\nCheck the controllability of the augmented system\n";
	print "  rank(M)\n";
	pause;

	print rank(M);

	print "\nMake a vector whose elements are desired closed-loop poles\n";
	print "  i = (0,1);\n";
	print "  P = [[-1+sqrt(3.0)*i]\n";
	print "       [-1-sqrt(3.0)*i]\n";
	print "       [      -5      ]\n";
	print "       [      -5      ]\n";
	print "       [      -5      ]]\n";
	pause;

	i = (0,1);
	print P = [[-1+sqrt(3.)*i][-1-sqrt(3.)*i][-5][-5][-5]];

	print "\nSolve the pole assignment problem\n";
	print "  KK = - PoleAssign(A1, B1, P)\n";
	print "  k1 = KK(1); k2 = KK(2); k3 = KK(3); k4 = KK(4); KI = -KK(5);\n";
	pause;

	print KK = - PoleAssign(A1, B1, P);
	k1 = KK(1); k2 = KK(2); k3 = KK(3); k4 = KK(4); KI = -KK(5);
	pause;

	print "\nStep response of servo system(Plant without integrator)\n\n";

	print "Calcuate state feedback gain matrix K\n";
	print "  K = [k1 k2 k3 k4]\n";
	pause;

	print K = [k1 k2 k3 k4];

	print "\nCalculate the state equation and output equation of closed-loop system\n\n";

	print "  AA = [[ A - B*K, B*KI]\n";
	print "        [   -C   , Z(1)]];\n";
	print "  BB = [[0]\n";
	print "        [0]\n";
	print "        [0]\n";
	print "        [1]];\n";
	print "  CC = [C Z(1)];\n";
	print "  DD = [0];\n";
	pause;

	print AA = [[A - B*K, B*KI][-C, Z(1)]];
	print BB = [[0][0][0][0][1]];
	print CC = [C Z(1)];
	print DD = [0];

	print "\nCalculate the step response\n";
	print "  t = linspace(0.0, 5.0);\n";
	print "  {y, x} = step_ss(AA, BB, CC, DD, 1, t);\n";
	pause;

	t = linspace(0.0, 5.0);
	{y, x} = step_ss(AA, BB, CC, DD, 1, t);

	print "\nPlot the step response (y vs t)\n";
	print "  mgplot_subplot(win, 2, 1, 1);\n";
	print "  mgplot_grid(win, 1);\n";
	print "  mgplot_title(win, \"Output y versus Time t\");\n";
	print "  mgplot_xlabel(win, \"Sec\");\n";
	print "  mgplot_ylabel(win, \"Output y = x3\");\n";
	print "  mgplot(win, t, y, {\"y\"});\n";
	pause;
	win = mgplot_cur_win();
	mgplot_reset(win);

	mgplot_subplot(win, 2, 1, 1);
	mgplot_grid(win, 1);
	mgplot_title(win, "Output y versus Time t");
	mgplot_xlabel(win, "Sec");
	mgplot_ylabel(win, "Output y = x3");
	mgplot(win, t, y, {"y"});

	print "\nPlot the step response (x vs t)\n";
	print "  mgplot_subplot(win, 2, 1, 2);\n";
	print "  mgplot_grid(win, 1);\n";
	print "  mgplot_title(win, \"Response Curves for x1, x2, x3, x4, x5\");\n";
	print "  mgplot_xlabel(win, \"Sec\");\n";
	print "  mgplot_ylabel(win, \"x1, x2, x3, x4, x5\");\n";
	print "  mgplot_text(win, \"x1\", 1.2,  0.05);\n";
	print "  mgplot_text(win, \"x2\", 1.2, -0.32);\n";
	print "  mgplot_text(win, \"x3\", 1.2,  0.33);\n";
	print "  mgplot_text(win, \"x4\", 2.2,  0.25);\n";
	print "  mgplot_text(win, \"x5\", 1.5,  1.28);\n";
	print "  mgplot(win, t, x, {\"x1\", \"x2\", \"x3\", \"x4\", \"x5\"});\n";
	pause;

	mgplot_subplot(win, 2, 1, 2);
	mgplot_grid(win, 1);
	mgplot_title(win, "Response Curves for x1, x2, x3, x4, x5");
	mgplot_xlabel(win, "Sec");
	mgplot_ylabel(win, "x1, x2, x3, x4, x5");
	mgplot_text(win, "x1", 1.2,  0.05);
	mgplot_text(win, "x2", 1.2, -0.32);
	mgplot_text(win, "x3", 1.2,  0.33);
	mgplot_text(win, "x4", 2.2,  0.25);
	mgplot_text(win, "x5", 1.5,  1.28);
	mgplot(win, t, x, {"x1", "x2", "x3", "x4", "x5"});

	print "\n";
	pause;
}
