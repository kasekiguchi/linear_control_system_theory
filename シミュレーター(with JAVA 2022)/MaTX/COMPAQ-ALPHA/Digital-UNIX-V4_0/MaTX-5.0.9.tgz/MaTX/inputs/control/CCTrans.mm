
/* -*- MaTX -*-
 *
 *  NAME
 *      CoCanTrans() - Transformation to controllable canonical form
 *
 *  SYNOPSIS
 *      {Ac,bc,cc} = CoCanTrans(A,b,c)
 *          Matrix Ac,bc,cc;
 *          Matrix A,b,c;
 *
 *  DESCRIPTION
 *      CoCanTrans() is obsolete.
 *
 *      Use  {Ac,bc,cc} = canon(A,b,c,Z(1),"controllable")
 *
 *      for  {Ac,bc,cc} = CoCanTrans(A,b,c)
 */

Func List CoCanTrans(A, b, c)
	Matrix A, b, c;
{
	Matrix Ac, bc, cc;

	{Ac,bc,cc} = canon(A,b,c,Z(1),"controllable");

/*
	Matrix T, Tinv;
	Matrix Ac, bc, cc;

	T = CoCanMat(A, b);
	Tinv = T~;

	Ac = Tinv * A * T;
	bc = Tinv * b;
	cc = c * T;
*/
	return {Ac, bc, cc};
}

/*
Func void main()
{
	Matrix A, b, c;
	Matrix A2, b2, c2;
	Integer    order_of_system;

	List CoCanTrans();
	List InputABC();

	while (1) {
		read order_of_system;
		if (order_of_system == 0) {
			break;
		}

		{A, b, c} = InputABC(order_of_system);

		{A2, b2, c2} = CoCanTrans(A, b, c);
		print A2, b2, c2;
	}
}
*/

