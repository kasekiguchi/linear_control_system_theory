
/* -*- MaTX -*-
 *
 *  NAME
 *      are() - Stabilizaing solution to the continuous-time Riccati equation
 *
 *  SYNOPSIS
 *      P = are(A, R, Q)
 *         Matrix P;
 *         Matrix A, R, Q;
 *
 *  DESCRIPTION
 *       are() returns the stablizing solution (if it exists)
 *       to the continuous-time Riccati equation:
 *
 *         A#*P + P*A - P*R*P + Q = 0
 *
 *      assuming R is symmetric and nonnegative definite and Q is symmetric.
 *
 *  SEE ALSO
 *      Ric() and ric()
 */

Func Matrix are(A,R,Q)
	Matrix A,R,Q;
{
	Matrix P;
	Integer i,n,nc,nr,ns;
	Matrix index;
	CoMatrix q,t;
	Real tol;
	String msg;

	msg = abcdchk(A);
	if (length(msg) > 0) {
		error("are(): " + msg);
	}

	// check for correct input problem
	{nr,nc} = size(A);
	n = nr;
	if (nr != nc) {
		error("are(): Nonsquare A matrix.\n");
	}
	{nr,nc} = size(R);
	if (nr != n || nc != n) {
		error("are(): Incorrectly dimensioned R matrix.\n");
	}
	{nr,nc} = size(Q);
	if (nr != n || nc != n) {
		error("are(): Incorrectly dimensioned Q matrix.\n");
	}

	{q,t} = schur([[ A,  -R]
				   [-Q, -A#]]*(1.0+EPS*EPS*(0,1))); 
	tol = 10.0*EPS*max(abs(diag2vec(t)));	// ad hoc tolerance

	/*
	 *  Prepare an array called index to send message to ordering routine 
	 *  giving location of eigenvalues with respect to the imaginary axis.
	 *  -1  denotes open left-half-plane
	 *   1  denotes open right-half-plane
	 *   0  denotes within tol of imaginary axis
	 */
	ns = 0;
	index = [];
	for (i = 1; i <= 2*n; i++) {
		if (Re(t(i,i)) < -tol) {
			index = [index, -1];
			ns = ns + 1;
		} else if (Re(t(i,i)) > tol) {
			index = [index 1];
		} else {
			index = [index 0];
		}
	}
	if (ns != n) {
		error("are(): No solution, (A,B) may be uncontrollable or no solution exists.\n");
	}
	{q,t} = schord(q,t,index);
	P = Re(q(n+1:n+n,1:n)/q(1:n,1:n));

	return P;
}
