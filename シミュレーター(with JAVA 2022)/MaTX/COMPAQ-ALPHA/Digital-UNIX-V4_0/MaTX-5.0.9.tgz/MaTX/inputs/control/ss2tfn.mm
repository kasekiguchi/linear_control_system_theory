
/* -*- MaTX -*-
 *
 *  NAME
 *      ss2tfn()	- State-space to transfer function conversion
 *
 *  SYNOPSIS
 *      g = ss2tfn(A,B,C,D)
 *         Rational g;
 *         Matrix A,B,C,D;
 *
 *      g = ss2tfn(A,B,C,D,iu)
 *         Rational g;
 *         Matrix A,B,C,D;
 *         Integer iu;
 *
 *  DESCRIPTION
 *      ss2tfn() calculates the transfer function:
 *
 *                       -1
 *          g(s) = C(sI-A) B + D
 *
 *      of the system:
 *          .
 *          x = Ax + Bu,  y = Cx + Du
 *
 *      from the iu'th input.  
 *
 *  SEE ALSO
 *      ss2tfm() and ss2zp()
 */

Func Rational ss2tfn(A, B, C, D, iu, ...)
	Matrix A, B, C, D;
	Integer iu;
{
	Matrix num, den;
	Rational g;
	String msg;
	
	error(nargchk(4, 5, nargs, "ss2tfn"));

	msg = abcdchk(A, B, C, D);
	if (length(msg) > 0) {
		error("ss2tfn(): " + msg);
	}

	if (nargs == 4) { 
		{num, den} = ss2tf(A,B,C,D);
	} else {
		{num, den} = ss2tf(A,B,C,D,iu);
	}

	g = tf2tfn(num, den);
	return g;
}
