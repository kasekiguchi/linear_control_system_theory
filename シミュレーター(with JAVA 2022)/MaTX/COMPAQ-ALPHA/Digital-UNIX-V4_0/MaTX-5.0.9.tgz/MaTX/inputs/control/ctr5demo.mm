
/*  -*- MaTX -*-
 *
 *  NAME
 *      ctr5demo() - Demonstration of control toolbox
 *
 *  SYNOPSIS
 *      ctr5demo()
 */

Func void ctr5demo()
{
	List mm;
	Integer i;
	void pgm5_1(), pgm5_2();
	
	mm = {"LQ Optimal Control",
		  "LQ optimal regulator",
		  "LQ optimal 1-type serbo��controller",
		  "Quit"};

	i = 1;
	for (;;) {
		i = menu(mm, i);
		switch (i) {
		  case 1:
			pgm5_1();
			break;
		  case 2:
			pgm5_2();
			break;
		  default:
			return;
			break;
		}
		i++;
	}
}

/*
 * Design of quadratic optimal regulator system
 */
Func void pgm5_1()
{
	Matrix A, B, C, D, Ac, Cc;
	Matrix Q, R, P, F, EE;
	Array to, xo, yo, tc, xc, yc;
	Integer win;

	print "\nLQ optimal regulator\n";
	print "\nInput A and B matrices\n";

	print "  A = [[  0    1   0]\n";
	print "       [  0    0   1]\n";
	print "       [-35, -27, -9]]\n";
	print "  B = [[0]\n";
	print "       [0]\n";
	print "       [1]]\n";
	pause;

	print A = [[0 1 0][0 0 1][-35, -27, -9]];
	print B = [[0][0][1]];

	print "\nInput weighting matrices Q and R\n";
	print "  Q = 100 * I(3)\n";
	print "  R = [1]\n";
	pause;

	print Q = 100 * I(3);
	print R = [1];

	print "\nCalculate optimal feedback gain\n";
	print "  {F} = lqr(A, B, Q, R);\n";
	pause;
	
	{F} = lqr(A, B, Q, R);
	print F;

	print "\nCalculate closed-loop poles\n";
	print "  EE = eigval(A - B*F)\n";
	pause;

	print EE = eigval(A - B*F);

	print "\nStep response of the closed-loop system\n";
	print "  C = I(3);\n";
	print "  D = Z(3,1);\n";
	print "  to = linspace(0.0, 5.0);\n";
	print "  {yo, xo} = step_ss(A, B, C, D, 1, to);\n";

	C = I(3);
	D = Z(3,1);
	to = linspace(0.0, 5.0);
	{yo, xo} = step_ss(A, B, C, D, 1, to);

	print "\nPlot the step response (yo vs t)\n";
	print "  mgplot_subplot(win, 3, 1, 1);\n";
	print "  mgplot_title(win, \"\");\n";
	print "  mgplot(win, t, yo(1,:), {\"yo1\"});\n";
	pause;
	win = mgplot_cur_win();
	mgplot_reset(win);

	mgplot_subplot(win, 3, 1, 1);
	mgplot_grid(win, 1);
	mgplot(win, to, yo(1,:), {"yo1"});

	print "\nPlot the step response (yo2 vs t)\n";
	print "  mgplot_subplot(win, 3, 1, 2);\n";
	print "  mgplot_grid(win, 1);\n";
	print "  mgplot(win, t, yo(2,:), {\"yo2\"});\n";
	pause;

	mgplot_subplot(win, 3, 1, 2);
	mgplot_grid(win, 1);
	mgplot(win, to, yo(2,:), {"yo2"});

	print "\nPlot the step response (yo3 vs t)\n";
	print "  mgplot_subplot(win, 3, 1, 3);\n";
	print "  mgplot_grid(win, 1);\n";
	print "  mgplot(win, t, yo(3,:), {\"yo3\"});\n";
	pause;

	mgplot_subplot(win, 3, 1, 3);
	mgplot_grid(win, 1);
	mgplot(win, to, yo(3,:), {"yo3"});

	print "\nPlot the step response\n";
	print "  Ac = A - B*F;\n";
	print "  Cc = C - D*F;\n";
	print "  tc = linspace(0.0, 5.0);\n";
	print "  {yc, xc} = step_ss(Ac, B, Cc, D, 1, tc);\n";

	Ac = A - B*F;
	Cc = C - D*F;
	tc = linspace(0.0, 5.0);
	{yc, xc} = step_ss(Ac, B, Cc, D, 1, tc);

	print "\nPlot the step response (yo1, yc1 vs t)\n";
	print "  mgplot_subplot(win, 3, 1, 1);\n";
	print "  mgplot_grid(win, 1);\n";
	print "  mgplot(win, t, [[yo(1,:)][yc(1,:)]], {\"yo1\",\"yc1\"});\n";
	pause;

	mgplot_subplot(win, 3, 1, 1);
	mgplot_grid(win, 1);
	mgplot(win, tc, [[yo(1,:)][yc(1,:)]], {"yo1","yc1"});

	print "\nPlot the step response (yo2, yc2 vs t)\n";
	print "  mgplot_subplot(win, 3, 1, 2);\n";
	print "  mgplot_grid(win, 1);\n";
	print "  mgplot(win, t, [[yo(2,:)][yc(2,:)]], {\"yo2\",\"yc2\"});\n";
	pause;

	mgplot_subplot(win, 3, 1, 2);
	mgplot_grid(win, 1);
	mgplot(win, tc, [[yo(2,:)][yc(2,:)]], {"yo2","yc2"});

	print "\nPlot the step response (yo3, yc3 vs t)\n";
	print "  mgplot_subplot(win, 3, 1, 3);\n";
	print "  mgplot_grid(win, 1);\n";
	print "  mgplot(win, t, [[yo(3,:)][yc(3,:)]], {\"yo3\",\"yc3\"});\n";
	pause;

	mgplot_subplot(win, 3, 1, 3);
	mgplot_grid(win, 1);
	mgplot(win, tc, [[yo(3,:)][yc(3,:)]], {"yo3","yc3"});
	pause;
}

/*
 * Design of quadratic optimal regulator system
 */
Func void pgm5_2()
{
	Integer win;
	Real f1, f2, f3;
	Matrix A, B, F, Q, R, P;
	Matrix AA, BB, CC, DD, C, D;
	Array t, x, y;

	print "\nLQ optimal 1-type servo control system\n";
	print "\nInput A and B\n";

	print "  A = [[0   1   0]\n";
	print "       [0   0   1]\n";
	print "       [0, -2, -3]]\n";
	print "  B = [[0]\n";
	print "       [0]\n";
	print "       [1]]\n";
	pause;

	print A = [[0 1 0][0 0 1][0, -2, -3]];
	print B = [[0][0][1]];

	print "\nInput weighting matrices Q and R\n";
	print "  Q = diag(100.0, 1.0, 1.0)\n";
	print "  R = [0.01]\n";
	pause;

	print Q = diag(100.0, 1.0, 1.0);
	print R = [0.01];

	print "\nSolve a Riccati equation\n";
	print "  P = Riccati(A, B, Q, R)\n";
	pause;

	print P = Riccati(A, B, Q, R);

	print "\nCalculate optimal state feedback gain\n";
	print "  {F} = lqr(A, B, Q, R);\n";
	print "  f1 = F(1); f2 = F(2); f3 = F(3);\n";
	pause;

	{F} = lqr(A, B, Q, R);
	print F;
	f1 = F(1); f2 = F(2); f3 = F(3);
	pause;

	print "\nStep response of 1-type servo control system\n";

	print "\nState and output equation of the closed-loop system\n";
	print "  C = [1 0 0];\n";
	print "  D = [0];\n";
	print "  AA = A - B*F\n";
	print "  BB = B*f1\n";
	print "  CC = C\n";
	print "  DD = D\n";
	pause;

	C = [1 0 0];
	D = [0];
	print AA = A - B*F;
	print BB = B*f1;
	print CC = C;
	print DD = D;

	print "\nStep response of the closed-loop system\n";
	print "  t = linspace(0.0, 3.0);\n";
	print "  {y, x} = step_ss(AA, BB, CC, DD, 1, t);\n";
	pause;

	t = linspace(0.0, 3.0);
	{y, x} = step_ss(AA, BB, CC, DD, 1, t);

	print "\nPlot the step response (y vs t)\n";
	print "  mgplot_subplot(win, 2, 1, 1);\n";
	print "  mgplot_grid(win, 1);\n";
	print "  mgplot_title(win, \"Unit-Step Response of Quadratic Optimal Control System\");\n";
	print "  mgplot_xlabel(win, \"Sec\");\n";
	print "  mgplot_ylabel(win, \"Output y = x1\");\n";
	print "  mgplot(win, t, y, {\"y\"});\n";
	pause;
	win = mgplot_cur_win();
	mgplot_reset(win);

	mgplot_subplot(win, 2, 1, 1);
	mgplot_grid(win, 1);
	mgplot_title(win, "Unit-Step Response of Quadratic Optimal Control System");
	mgplot_xlabel(win, "Sec");
	mgplot_ylabel(win, "Output y = x1");
	mgplot(win, t, y, {"y"});

	print "\nPlot the step response (x vs t)\n";
	print "  mgplot_subplot(win, 2, 1, 2);\n";
	print "  mgplot_grid(win, 1);\n";
	print "  mgplot_title(win, \"Response Curves x1, x2, x3 versus t\");\n";
	print "  mgplot_xlabel(win, \"Sec\");\n";
	print "  mgplot_ylabel(win, \"x1, x2, x3\");\n";
	print "  mgplot_text(win, \"x1\", 1.6, 1.2);\n";
	print "  mgplot_text(win, \"x2\", 0.7, 1.3);\n";
	print "  mgplot_text(win, \"x3\", 0.3, 3.4);\n";
	print "  mgplot(win, t, x, {\"x1\", \"x2\", \"x3\"});\n";
	pause;

	mgplot_subplot(win, 2, 1, 2);
	mgplot_grid(win, 1);
	mgplot_title(win, "Response Curves x1, x2, x3 versus t");
	mgplot_xlabel(win, "Sec");
	mgplot_ylabel(win, "x1, x2, x3");
	mgplot_text(win, "x1", 1.6, 1.2);
	mgplot_text(win, "x2", 0.7, 1.3);
	mgplot_text(win, "x3", 0.3, 3.4);
	mgplot(win, t, x, {"x1", "x2", "x3"});

	print "\n";
	pause;
}


