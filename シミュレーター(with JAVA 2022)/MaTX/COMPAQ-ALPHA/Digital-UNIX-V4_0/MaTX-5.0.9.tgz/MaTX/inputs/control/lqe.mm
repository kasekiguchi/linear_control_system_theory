
/* -*- MaTX -*-
 *
 *  NAME
 *      lqe() - Linear quadratic estimator design
 *
 *  SYNOPSIS
 *     {L,P} = lqe(A,G,C,Q,R)
 *        Matrix L,P;
 *        Matrix A,G,C,Q,R;
 *
 *  DESCRIPTION
 *      For the continuous-time system:
 *      	.
 *      	x = Ax + Bu + Gw	    ( State equation )
 *      	z = Cx + Du + v		    ( Measurements   )
 *
 *      with process noise and measurement noise covariances:
 *
 *      	E[w] = E[v] = 0,  E[ww#] = Q,  E[vv#] = R
 *
 *      the function lqe() returns the gain matrix L such that
 *      the stationary Kalman filter:
 *      	.
 *      	x = Ax + Bu + L(z - Hx - Du)
 *
 *      produces an LQG optimal estimate of x.  lqe() returns the gain
 *      matrix L and the Riccati equation solution P which is the estimate
 *      error covariance.  Calculate estimator gains using lqr() and duality.
 *      Note, cross term, if needed, is G*T
 *
 *  SEE ALSO
 *      lqr()
 */

Func List lqe(A, G, C, Q, R)
	Matrix A, G, C, Q, R;
{
	Matrix L, P;

	{L,P} = lqr(A#, C#, G*Q*G#, R);
	L = L#;
	P = P#;

	return {L,P};
}
