
/* -*- MaTX -*-
 *
 *  NAME
 *      tf2tfm() -  Transfer function to transfer function matrix conversion
 *
 *  SYNOPSIS
 *      G = tf2tfm(NUM,den)
 *         RaMatrix G;
 *         Matrix NUM, den;
 *
 *  DESCRIPTION
 *       tf2tfm() calculates the transfer function matrix representation:
 *
 *          .                              -1
 *          x = Ax + Bu    G(s) = C (sI - A) B + D
 *          y = Cx + Du
 *
 *      of the system:
 *
 *                  NUM(s) 
 *          G(s) = --------
 *                  den(s)
 *
 *      from a single input.  Vector 'den' must contain the coefficients of 
 *      the denominator in descending powers of s.  Matrix 'NUM' must contain 
 *      the numerator coefficients with as many rows as there are outputs y.
 *      The elements of G(s) have the same denominator. This calculation
 *      also works for discrete systems but the numerator must be padded with
 *      trailing zeros to make it the same length as the denominator.
 *
 *  SEE ALSO
 *      ss2tf() and tf2zp()
 */

Func RaMatrix tf2tfm(NUM, den)
	Matrix NUM, den;
{
	Integer i, p;
	Polynomial dd;
	PoMatrix N;

	p = Rows(NUM);
	if (version() == 4) {
		dd = Polynomial(fliplr(den));
	} else {
		dd = Polynomial(den);
	}
	N  = PoMatrix(Z(p,1));
	
	for (i = 1; i <= p; i++) {
		if (version() == 4) {
			N(i) = Polynomial(fliplr(NUM(i,:)));
		} else {
			N(i) = Polynomial(NUM(i,:));
		}
	}

	return N/dd;
}
