
/* -*- MaTX -*-
 *
 *  NAME
 *      TFadd() - Parallel connection of two state-space systems
 *
 *  SYNOPSIS
 *      {A,B,C,D} = TFadd(S1, S2)
 *         Matrix A,B,C,D;
 *         List S1, S2;
 *         S1 = {A1,B1,C1,D1}
 *         S2 = {A2,B2,C2,D2}
 *
 *  DESCRIPTION
 *      TFadd() produces a state-space system consisting of the add connection
 *      of systems 1 and 2 such that Y = Y1 + Y2.  The resulting system is:
 *      	 .
 *      	|x1| = |A1 0| |x1| + |B1||u|
 *      	|x2|   |0 A2| |x2| + |B2|
 *
 *      	|y| = y1+y2 = |C1 C2| |x1| + |D1 + D2| |u|
 *                                |x2|
 *            G = G1 + G2
 *
 *                  +----+     
 *              +-->| G1 |--+  
 *              |   +----+  |	    
 *              |           + v 
 *          ----+     	    o---->
 *              |           + ^ 
 *              |   +----+  |	 
 *        	    +-->| G2 |--+ 
 *        	        +----+     
 */

Func List TFadd(G1, G2)
	List G1, G2;
{
	Matrix a1, b1, c1, d1;
	Matrix a2, b2, c2, d2;
	Integer n1, m1, p1;
	Integer n2, m2, p2;
	Matrix A, B, C, D;

	{a1, b1, c1, d1} = G1;
	{a2, b2, c2, d2} = G2;

	n1 = Cols(a1);
	m1 = Cols(b1);
	p1 = Rows(c1);

	n2 = Cols(a2);
	m2 = Cols(b2);
	p2 = Rows(c2);

	if (m1 != m2) {
		error("TFadd(): input number is incorrect.\n");
	} else if (p1 != p2) {
		error("TFadd(): output number is incorrect.\n");
	}

	A = [[    a1   Z(n1,n2)]
		 [Z(n2,n1)     a2   ]];
	B = [[b1]
		 [b2]];
	C = [c1 c2];
	D = [d1 + d2];

	return {A, B, C, D};
}

