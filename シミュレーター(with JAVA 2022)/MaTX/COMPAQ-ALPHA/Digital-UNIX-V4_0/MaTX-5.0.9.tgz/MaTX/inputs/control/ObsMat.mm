
/* -*- MaTX -*-
 *
 *  NAME
 *      ObsMat() - Observability Matrix of continumous-time system
 *
 *  SYNOPSIS
 *       N = ObsMat(A,C)
 *         Matrix N;
 *         Matrix A, C;
 *
 *  DESCRIPTION
 *      ObsMat() is obsolete.
 *
 *      Use N = obsv(A,C)  for  N = ObsMat(A,C)
 *
 */

Func Matrix ObsMat(A, C)
	Matrix A, C;
{
	return obsv(A,C);
/*
	return ConMat(A#, C#);
*/
}

