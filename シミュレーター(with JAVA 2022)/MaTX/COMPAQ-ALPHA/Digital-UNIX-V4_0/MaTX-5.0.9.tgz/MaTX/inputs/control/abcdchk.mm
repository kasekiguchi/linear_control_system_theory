
/* -*- MaTX -*-
 *
 *  NAME
 *      abcdchk() - Check that dimensions of A,B,C,D are consistent
 *
 *  SYNOPSIS
 *      msg = abcdchk(A)
 *         String msg;
 *         Matrix A;
 *
 *      msg = abcdchk(A,B)
 *         String msg;
 *         Matrix A,B;
 *
 *      msg = abcdchk(A,B,C)
 *         String msg;
 *         Matrix A,B,C;
 *
 *      msg = abcdchk(A,B,C,D)
 *         String msg;
 *         Matrix A,B,C,D;
 *
 *  DESCRIPTION
 *      abcdchk() checks that dimensions of A,B,C,D are consistent, and
 *      returns empty string if they are, or an error message string
 *      if they are not.
 *
 *  SEE ALSO
 *      error() and nargchk()
 */

Func String abcdchk(A,B,C,D, ...)
	Matrix A,B,C,D;
{
	String msg;
	Integer ma,mb,mc,md,na,nb,nc,nd;

	error(nargchk(1, 4, nargs, "abcdchk"));

	msg = "";
	{ma,na} = size(A);

	if (ma != na) {
		msg = "A matrix must be square.\n";
	}

	if (nargs > 1) {
		{mb,nb} = size(B);
		if (ma != mb) {
			msg = "A and B matrices must have the same number of rows.\n";
		}
	}
	if (nargs > 2) {
		{mc,nc} = size(C);
		if (nc != ma) {
			msg ="A and C matrices must have the same number of columns.\n";
		}
	}
	if (nargs > 3) {
		{md,nd} = size(D);
		if (ma+mb+mc == 0) {
			return msg;
		}
		if (md != mc) {
			msg = "C and D matrices must have the same number of rows.\n";
		}
		if (nd != nb) {
			msg = "B and D matrices must have the same number of columns.\n";
		}
	}

	return msg;
}
