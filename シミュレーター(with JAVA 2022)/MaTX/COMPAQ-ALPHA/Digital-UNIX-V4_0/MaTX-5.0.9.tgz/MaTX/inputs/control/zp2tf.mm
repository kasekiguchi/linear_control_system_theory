
/* -*- MaTX -*-
 *
 *  NAME
 *      zp2tf() - Zero-pole to transfer function conversion
 *
 *  SYNOPSIS
 *      {NUM,den} = zp2tf(z,p,k)
 *         Matrix NUM,den;
 *         CoMatrix z,p;
 *         Matrix k;
 *
 *  DESCRIPTION
 *      zp2tf() forms the transfer function:
 *
 *                     NUM(s)
 *             H(s) = -------- 
 *                     den(s)
 *   
 *      for SIMO systems given a set of pole locations in column vector p,
 *      a matrix z with the zero locations in as many columns as there are
 *      outputs, and the gains for each numerator transfer function in 
 *      vector k.
 *
 *      The function will not work if p or z have elements not in complex
 *      pairs.
 *
 *  SEE ALSO  
 *      tf2zp(), zp2tfm() and zp2ss()
 *
 */

Func List zp2tf(z, p, k_)
	CoMatrix z, p;
	Matrix k_;
{
	Matrix den, NUM, k, pj, zj;
	Integer j, m, mk, n, nk;

	den = Re(poly(p));  // denominator

	k = makecolv(k_);
	if (isempty(z)) {
		NUM = k;
		return {NUM, den};
	}

	{m, n} = size(z);
	{mk, nk} = size(k);
	if (mk != n) {
		if (m == 1) {
			error("zp2tf(): Z and P must be column vectors.\n");
		}
		error("zp2tf(): K must have as many elements as Z has columns.\n");
	}

	NUM = Z(Rows(k), length(p));
	for (j = 1; j <= n; j++) {
		zj = z(:,j);
		pj = Re(poly(zj)*k(j));
		NUM(j,:) = [Z(1,m-length(pj)+1), pj];
	}
	return {NUM, den};
}
