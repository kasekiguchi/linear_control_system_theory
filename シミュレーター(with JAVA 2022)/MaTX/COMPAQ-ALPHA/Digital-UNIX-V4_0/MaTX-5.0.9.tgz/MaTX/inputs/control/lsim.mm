
/* -*- MaTX -*-
 *
 *  NAME
 *      lsim() - Simulation of continuous-time linear systems to arbitrary
 *               inputs
 *
 *  SYNOPSIS
 *     	{Y, X} = lsim(A,B,C,D,U,T)
 *            Matrix Y,X;
 *            Matrix A,B,C,D;
 *            Matrix U,T;
 *
 *     	{Y, X} = lsim(A,B,C,D,U,T,x0)
 *            Matrix Y,X;
 *            Matrix A,B,C,D;
 *            Matrix U,T;
 *            Matrix x0;
 *
 *  DESCRIPTION
 *      lsim() calculates the time response of the system:
 *         .
 *         x = Ax + Bu,  y = Cx + Du
 *
 *      to input time history U.  Matrix U must have as many rows as 
 *      there are inputs, u.  Each column of U corresponds to a new time
 *      point, and U must have length(T) columns. 
 *
 *      lsim() returns a matrix Y with as many rows as there are outputs
 *      y, and with length(T) columns.  lsim() also returns the state
 *      time history.
 *
 *      lsim() now assumes a straight line approximation between the discrete
 *      values of u. This is achieved via a first order hold approximation.
 *
 *  SEE ALSO
 *      dlsim()
 */

Func List lsim(a, b, c, d, U_, T, x0_, ...)
	Matrix a, b, c, d, x0_;
	Matrix U_, T;
{
	Matrix A, B, C, D, Ad, Bd, X, Y, U, x0;
	Integer m, n, N;
	Real dt;
	String msg;
	
	error(nargchk(6, 7, nargs, "lsim"));

	msg = abcdchk(a, b, c, d);
	if (length(msg) > 0) {
		error("lsim(): " + msg);
	}

	{n, m} = size(b);
	N = Cols(U_);

	U = U_;

	if (nargs == 6) {
		x0 = Z(n,1);
	} else {
		x0 = x0_;
	}

	// First Order Hold Approximation 
	dt = T(2) - T(1);

	// For first order hold approximation first add m integrators in series
	{A,B,C,D} = series(Z(m),I(m),I(m),Z(m),a,b,c,d);

	// Get equivalent zero order hold discrete system
	{Ad,Bd} = c2d(A,B,dt);

	/*
	 * For first order hold add (z-1)/T in series
	 * This is equivalent to differentiating u.
	 * Transfer first sample to initial conditions.
	 */
	x0 = [[Z(m,1)]
		  [  x0  ]] + B*U(:,1);

	U(:,1:N-1) = (U(:,2:N) - U(:,1:N-1))/dt;
	U(:,N)     = U(:,N-1);

	X = ltitr(Ad,Bd,U,x0);
	Y = C*X + D*U;

	// Remove the integrator state
	X = X(m+1:m+n,:);

	return {Y, X};
}
