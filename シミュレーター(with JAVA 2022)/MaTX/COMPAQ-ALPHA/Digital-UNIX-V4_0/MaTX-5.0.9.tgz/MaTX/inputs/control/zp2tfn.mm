
/* -*- MaTX -*-
 *
 *  NAME
 *      zp2tfn() - Zero-pole to transfer function conversion
 *
 *  SYNOPSIS
 *      g = zp2tf(z,p,k)
 *         Rational g;
 *         CoMatrix z,p;
 *         Matrix k;
 *
 *  DESCRIPTION
 *      zp2tfn() forms the transfer function g(s)
 *      for SIMO systems given a set of pole locations in column vector p,
 *      a matrix z with the zero locations in as many columns as there are
 *      outputs, and the gains for each numerator transfer function in 
 *      vector k.
 *
 *      The function will not work if p or z have elements not in complex
 *      pairs.
 *
 *  SEE ALSO  
 *      tf2zp(), zp2tfm() and zp2ss()
 *
 */

Func Rational zp2tfn(z, p, k_)
	CoMatrix z, p;
	Matrix k_;
{
	Rational g;
	Matrix num, den;
	
	{num, den} = zp2tf(z, p, k_);
	g = tf2tfn(num, den);
	return g;
}
