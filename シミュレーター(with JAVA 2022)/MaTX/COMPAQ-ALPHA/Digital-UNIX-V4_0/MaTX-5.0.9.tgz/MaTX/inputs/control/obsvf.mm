
/* -*- MaTX -*-
 *
 *  NAME
 *      obsvf() - Observability staircase form
 *	
 *  SYNOPSIS
 *      {Ab,Bb,Cb,T,K} = obsvf(A,B,C)
 *         Matrix Ab,Bb,Cb,T,K;
 *         Matrix A,B,C;
 *
 *      {Ab,Bb,Cb,T,K} = obsvf(A,B,C,tol)
 *         Matrix Ab,Bb,Cb,T,K;
 *         Matrix A,B,C;
 *         Real tol;
 *
 *  DESCRIPTION
 *      obsvf() returns a decomposition into the observable/unobservable
 *      subspaces. obsvf(..., tol) uses tolerance tol.
 *
 *      If [[A][C]] has rank r <= n, then there is a similarity
 *      transformation T such that
 *
 *         Ab = T * A * T' ,  Bb = T * B  ,  Cb = C * T' .
 *
 *      and the transformed system has the form
 *
 *              | Ano   A12|        |Bno|
 *        Ab =  ----------  ,  Bb =  ---  ,  Cb = [ 0 | Co].
 *              |  0    Ao |        |Bo |
 *
 *	                                           -1          -1
 *      where {Ac,Bc} is controllable, and Cc(sI-Ac)Bc = C(sI-A)B.
 *
 *  SEE ALSO
 *      ctrbf() and obsv()
 */

Func List obsvf(A, B, C, tol, ...)
	Matrix A, B, C;
	Real tol;
{
	Matrix Ab, Bb, Cb, T, K;
	Matrix aa, bb, cc;
	String msg;

	error(nargchk(3, 4, nargs, "obsvf"));

	msg = abcdchk(A, B, C);
	if (length(msg) > 0) {
		error("obsvf(): " + msg);
	}

	if (nargs == 4) {
		{aa, bb, cc, T, K} = ctrbf(A#, C#, B#, tol);
	} else if (nargs == 3) {
		{aa, bb, cc, T, K} = ctrbf(A#, C#, B#);
	}

	Ab = aa#;
	Bb = cc#;
	Cb = bb#;

	return {Ab, Bb, Cb, T, K};
}
