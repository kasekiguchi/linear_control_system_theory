
/* -*- MaTX -*-
 *
 *  NAME
 *      TransFunc()	   - Transfer function of SISO system
 *      TransFuncMat() - Transfer function matrix of MIMO system
 *
 *  SYNOPSIS
 *      g = TransFunc(A,b,c,d)
 *         Rational g;
 *         Matrix A,b,c,d;
 *
 *      G = TransFuncMat(A,B,C,D)
 *         RaMatrix G;
 *         Matrix A,B,C,D;
 *
 *  DESCRIPTION
 *      TransFunc() and TransFuncMat are obsolete.
 *
 *      Use  g = [ss2tfm(A,b,c,d)](1,1)  for  g = TransFunc(A,b,c,d)
 *
 *      Use  G = ss2tfm(A,b,c,d)  for  G = TransFuncMat(A,B,C,D)
 */

Func Rational TransFunc(A, b, c, d)
	Matrix	A, b, c, d;
{

	return [ss2tfm(A,b,c,d)](1,1);

/*
	CoMatrix Gamma, AA, tmp;
	Polynomial num, den;
	Rational G;
	Integer	n, i;

	n = Rows(A);
	AA = (A,:);
	Gamma = Z(n, 1, AA);
	num = Polynomial((Z(1, n+1),:));
	den = Polynomial((Z(1, n+1),:));

	num(n) = d(1,1);
	den(n) = 1.0;

	Gamma(n-1, 0, AA) = I(n);
	den(n-1) = - trace(AA);

	for (i = n-2; i >= 0; i--) {
		Gamma(i, 0, AA) = AA*Gamma(i+1, 0, AA) + den(i+1)*I(n);
		den(i) = - trace(AA*Gamma(i, 0, AA)) / (n - i);
	}

	for (i = 0; i < n; i++) {
		tmp = c*Gamma(i, 0, AA)*b + den(i)*d;
		num(i) = tmp(1,1);
	}

	if (isreal(A) && isreal(b) && isreal(c) && isreal(d)) {
		G = Re(num) / Re(den);
	} else {
		G = num / den;
	}
	return G;
*/
}

Func RaMatrix TransFuncMat(A, B, C, D)
	Matrix	A, B, C, D;
{
	return ss2tfm(A,B,C,D);
/*
	CoMatrix Gamma, AA, NUM, tmp;
	Polynomial s, den;
	RaMatrix G;
	Integer	n, i;

	s = Polynomial("s");
	n = Rows(A);
	AA = (A,:);
	Gamma = Z(n, 1, AA);
	den = Polynomial((Z(1, n+1),:));

	den(n) = 1.0;

	Gamma(n-1, 0, AA) = I(n);
	den(n-1) = - trace(AA);

	for (i = n-2; i >= 0; i--) {
		Gamma(i, 0, AA) = AA*Gamma(i+1, 0, AA) + den(i+1)*I(n);
		den(i) = - trace(AA*Gamma(i, 0, AA)) / (n - i);
	}

	NUM = D * s^n;
	for (i = 0; i < n; i++) {
		tmp = C*Gamma(i, 0, AA)*B + den(i)*D;
		NUM = NUM + tmp * s^i;
	}

	if (isreal(A) && isreal(B) && isreal(C) && isreal(D)) {
		G = Re(NUM) / Re(den);
	} else {
		G = NUM / den;
	}
	return G;
*/
}
