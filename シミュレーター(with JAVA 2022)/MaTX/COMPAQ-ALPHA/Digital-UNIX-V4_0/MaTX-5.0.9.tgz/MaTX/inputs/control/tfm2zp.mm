
/* -*- MaTX -*-
 *
 *  NAME
 *      tfm2zp() - Transfer function matrix to zero-pole conversion
 *
 *  SYNOPSIS
 *      {z,p,k} = tfm2zp(G)
 *         CoMatrix z, p;
 *         Matrix k;
 *         RaMatrix G;
 *
 *      {z,p,k} = tfm2zp(G,iu)
 *         CoMatrix z, p;
 *         Matrix k;
 *         RaMatrix G;
 *         Integer iu;
 *
 *  DESCRIPTION
 *      tfm2zp() calculates the transfer function in factored form:
 *
 *                       -1           (s-z1)(s-z2)...(s-zn)
 *     	H(s) = C(sI-A) B + D =  k ---------------------
 *                                    (s-p1)(s-p2)...(s-pn)
 *      of the system:
 *
 *                  NUM(s) 
 *          G(s) = --------
 *                  den(s)
 *
 *      from the iu-th input.  G contains transfer function matrix.
 *      Vector P contains the pole locations of the denominator of the
 *      transfer function.  The numerator zeros are returned in the columns
 *      of matrix Z with as many columns as there are outputs y.  The gains 
 *      for each numerator transfer function are returned in column vector K.
 *
 *  SEE ALSO
 *      ss2tf() and tf2zp()
 */

Func List tfm2zp(G, iu, ...)
	RaMatrix G;
	Integer iu;
{
	Matrix A, B, C, D, k;
	CoMatrix p, z;
	
	error(nargchk(1, 2, nargs, "tfm2zp"));

	if (nargs == 1) {
		iu = 1;
	}

	{A,B,C,D} = tfm2ss(G,iu);
	{z,p,k} = ss2zp(A,B,C,D,1);
	return {z,p,k};
}
