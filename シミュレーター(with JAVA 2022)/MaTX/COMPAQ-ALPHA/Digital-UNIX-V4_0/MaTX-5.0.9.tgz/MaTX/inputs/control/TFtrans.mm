
/* -*- MaTX -*-
 *
 *  NAME
 *      TFtrans() -  trans a state-space system
 *
 *  SYNOPSIS
 *      {A,B,C,D} = TFtrans(S)
 *         Matrix A,B,C,D;
 *         List S;
 *         S = {A1,B1,C1,D1};
 *
 *  DESCRIPTION
 *      TFtrans() produces a state-space system of the transpose of
 *      system 1 such that  Y = Y1#.  The resulting system is:
 *         .
 *       |x1| = |A1#| |x1| + |C1#| |u|
 *
 *       |y| =  |B1#| |x1| + |D1#| |u|
 *
 */

Func List TFtrans(G1)
	List G1;
{
	Matrix A1, B1, C1, D1;

	{A1, B1, C1, D1} = G1;
	return {A1#, C1#, B1#, D1#};
}

