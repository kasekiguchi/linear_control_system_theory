
/* -*- MaTX -*-
 *
 *  NAME
 *      Ric() - Solve a riccati equation using potter and arimoto's method
 *
 *  SYNOPSIS
 *      P = Ric(A, Q, R)
 *         Matrix P;
 *         Matrix A,Q,R;
 *
 *      P = Ric(A, Q, R, tol1)
 *         Matrix P;
 *         Matrix A,Q,R;
 *         Real tol1;
 *
 *      P = Ric(A, Q, R, tol1, tol2)
 *         Matrix P;
 *         Matrix A,Q,R;
 *         Real tol1, tol2;
 *
 *  DESCRIPTION
 *      Ric(A, R, Q) solves the continuous-time Riccati equation
 *
 *        A#*P + P*A + P*R*P = Q
 *
 *      To calculate the solution of  
 *
 *        A#*P + P*A - P*R*P + Q = 0
 *
 *      call ths function as  P = Ric(A, -Q, -R).
 *
 *      If frobenius norm of the Riccati residual is greater than tol1,
 *      warning message is shown. Default tol1 is 1.0;
 *
 *      If there are jw-axis closed loop poles, warning message
 *      is shown.  Ric(..., tol2) specifies the distance from the
 *      jw-axis. Default tol2 is 1.0E-6.
 *
 */

Func Matrix Ric(A, Q, R, tol1, tol2, ...)
	Matrix A;
	Matrix Q;
	Matrix R;
	Real tol1;
	Real tol2;
{
	Matrix P, H, U, V, T, Perr, pc;
	Integer i;
	Real res, tmp;

	error(nargchk(3, 5, nargs, "Ric"));
	
	if (nargs < 4) {
		tol1 = 1.0;
	}
	if (nargs < 5) {
		tol2 = 1.0E-6;
	}

	H = [[A,  R ]
		 [Q, -A#]];

	T = eigvec(H);
	if (version() == 4) {
		U = T(0, 1, A);
		V = T(1, 1, A);
	} else {
		U = T(1, 2, A);
		V = T(2, 2, A);
	}
	P = V * U~;
	
	if (isreal(A) && isreal(Q) && isreal(R)) {
		P = Re(P);
		P = (P' + P)/2;
	} else {
		P = (P# + P)/2;
	}

	// Check redidual
	Perr = A#*P + P*A + P*R*P - Q;
	res = frobnorm(Perr);
	if (res > tol1) {
		warning("Ric(): Frobenius norm of the Riccati residual: %g\n", res);
	}

	// Check jw-axis roots:
	pc = eigval(A + R*P);
	{tmp,i} = minimum(abs(Array(Re(pc))));
	if (tmp < tol2) {
		warning("Ric(): There are jw-axis closed loop poles (%g,%g)\n",
				Re(pc(i)), Im(pc(i)));
		warning("       Results may be inaccurate !!\n");
	}

	// Check positive definiteness of P:
	pc = eigval(P);
	{tmp,i} = minimum(Re(pc));
	if (tmp < 0.0) {
		warning("Ric(): P is not positive\n");
		warning("The smallest eigenvalue of P is (%g,%g)\n",
				Re(pc(i)), Im(pc(i)));
	}
	
	return P;
}

Func Matrix ric(A, R, Q, tol1, tol2, ...)
	Matrix A;
	Matrix R;
	Matrix Q;
	Real tol1;
	Real tol2;
{
	error(nargchk(3, 5, nargs, "ric"));

	if (nargs == 3) {
		return Ric(A, Q, R);
	} else if (nargs == 4) {
		return Ric(A, Q, R, tol1);
	} else {
		return Ric(A, Q, R, tol1, tol2);
	}
}

Func Matrix Ric2(A, Q, R, tol1, tol2, ...)
	Matrix A;
	Matrix Q;
	Matrix R;
	Real tol1;
	Real tol2;
{
	Integer i, j, n;
	Matrix P, H, U, V, T, Perr, pc;
	Matrix val, vec;
	Index idxr, idxi;
	Real res, tmp;

	error(nargchk(3, 5, nargs, "Ric2"));
	
	if (nargs < 4) {
		tol1 = 1.0;
	}
	if (nargs < 5) {
		tol2 = 1.0E-6;
	}

	H = [[ A,  R]
		 [ Q, -A#]];

	if (isreal(A) && isreal(Q) && isreal(R)) {
		n = Cols(A);
		{val, vec} = eig(H);
		
		if (version() == 4) {
			val = diag2vec(val(1,1,A));			// Stable eigenvalues
		} else {
			val = diag2vec(val(2,2,A));			// Stable eigenvalues
		}
		vec = vec(:,n+1:2*n);				// Stable eigenvectors
		idxr = find(Array(Im(val)) == 0.0);	// Real eigenvalues
		idxi = find(Array(Im(val)) != 0.0);	// Complex eigenvalues

		T = Z(2*n,n);
		j = length(idxr);
		T(:,1:j) = Re(vec(:,idxr));
		for (i = 1; i <= length(idxi); i = i + 2) {
			T(:,j+i)   = Re(vec(:,idxi(i)));
			T(:,j+i+1) = Im(vec(:,idxi(i)));
		}

		U = T(1:n, :);
		V = T(n+1:2*n, :);

		P = V * U~;
		P = (P' + P)/2;
		P = Re(P);
	} else {
		T = eigvec(H);
		if (version() == 4) {
			U = T(0, 1, A);
			V = T(1, 1, A);
		} else {
			U = T(1, 2, A);
			V = T(2, 2, A);
		}
		P = V * U~;
		P = (P# + P)/2;
	}

	// Check redidual:
	Perr = A#*P + P*A + P*R*P - Q;
	res = frobnorm(Perr);
	if (res > tol1) {
		warning("Ric2(): Frobenius norm of the Riccati residual: %g\n", res);
	}

	// Check jw-axis roots:
	pc = eigval(A + R*P);
	{tmp,i} = minimum(abs(Array(Re(pc))));
	if (tmp < tol2) {
		warning("Ric2(): There are jw-axis closed loop poles (%g,%g)\n",
				Re(pc(i)), Im(pc(i)));
		warning("        Results may be incorrect !!\n");
	}

	// Check positive definiteness of P:
	pc = eigval(P);
	{tmp,i} = minimum(Re(pc));
	if (tmp < 0.0) {
		warning("Ric2(): P is not positive\n");
		warning("The smallest eigenvalue of P is (%g,%g)\n",
			Re(pc(i)), Im(pc(i)));
	}

	return P;
}
