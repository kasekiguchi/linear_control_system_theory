
/* -*- MaTX -*-
 *  
 *  NAME
 *      ctr_demo() - Demonstration of control system design toolbox
 *
 *  SYNOPSIS
 *     ctr_demo()
 *
 *  DESCRIPTION
 *    	ctr_demo() brings up a menu of the available demonstrations.
 *
 *      gnuplot is required to display graphs
 *      gnuplot is availabel by ftp from matx.ds.mei.titech.ac.jp.
 *
 */

Func void ctr_demo()
{
	Integer i;
	List mm;

	void ctr1demo(), ctr2demo(), ctr3demo();
	void ctr4demo(), ctr5demo(), ctrldemo();
	void est_idt_demo();
	
	mm = {"Demonstration of Control System Toolsbox",
		  "Transfer function and frequency response",
		  "Pole assignment",
		  "1-type servo control system",
		  "Observer",
		  "LQ optimal regulator",
		  "Estimation and Identification",
		  "Simple demonstration",
		  "Quit"};

	i = 1;
	for (;;) {
		i = menu(mm, i);
		switch (i) {
		  case 1:
			ctr1demo();
			break;
		  case 2:
			ctr2demo();
			break;
		  case 3:
			ctr3demo();
			break;
		  case 4:
			ctr4demo();
			break;
		  case 5:
			ctr5demo();
			break;
		  case 6:
			est_idt_demo();
			break;
		  case 7:
			ctrldemo();
			break;
		}
		if (i == length(mm)-1) { break; }
		i++;
	}
}

Func void est_idt_demo()
{
	Integer i;
	List mm;

	void ctr6demo(), ctr7demo(), ctr8demo();

	mm = {"Estimation and Identification",
		  "Estimation of frequency response using M series",
		  "Estimation of LTI system by least square method",
		  "Identification of LTI system by HoKalman's method",
		  "Quit"};

	i = 1;
	for (;;) {
		i = menu(mm, i);
		switch (i) {
		  case 1:
			ctr6demo();
			break;
		  case 2:
			ctr7demo();
			break;
		  case 3:
			ctr8demo();
			break;
		}
		if (i == length(mm)-1) { break; }
		i++;
	}
}

Func void ctr6demo()
{
	clear;
	print "\n";
	print "\n";
	print "Refer to FR_Mseq_test.mm\n";
	print "\n";
	print "\n";
	pause;
	clear;
}

Func void ctr7demo()
{
	clear;
	print "\n";
	print "\n";
	print "Refer to LS_RLS_test.mm\n";
	print "\n";
	print "\n";
	pause;
	clear;
}

Func void ctr8demo()
{
	clear;
	print "\n";
	print "\n";
	print "Refer to HoKalman.mm\n";
	print "\n";
	print "\n";
	pause;
	clear;
}
