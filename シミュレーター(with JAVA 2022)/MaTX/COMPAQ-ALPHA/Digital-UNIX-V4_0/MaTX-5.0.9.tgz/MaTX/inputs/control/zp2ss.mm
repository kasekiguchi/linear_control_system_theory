
/* -*- MaTX -*-
 *
 *  NAME
 *      zp2ss() - Zero-pole to state-space conversion
 *
 *  SYNOPSIS 
 *      {A,B,C,D} = zp2ss(z,p,k)
 *          Matrix A,B,C,D;
 *          CoMatrix z, p;
 *          Matrix k;
 *
 *  DESCRIPTION
 *      zp2ss() calculates a state-space representation:
 *          .
 *          x = Ax + Bu,  y = Cx + Du
 *
 *      for SIMO systems given a set of pole locations in column vector p,
 *      a matrix z with the zero locations in as many columns as there are
 *      outputs, and the gains for each numerator transfer function in
 *      vector k. The A,B,C,D matrices are returned in block diagonal form.
 *
 *  SEE ALSO
 *      ss2zp(), zp2tf() and zp2tfm()
 */

Func List zp2ss(z_, p_, k)
	CoMatrix z_, p_;
	Matrix k;
{
	CoMatrix z, p;
	Matrix A,B,C,D,a1,b1,c1,d1,den,num,t;
	Integer i,m,n,np,nz;
	Real wn;
	Index index;

	z = z_;
	p = p_;

	{m,n} = size(z);
	if (length(k) != n && (! isempty(z))) {
		error("zp2ss(): Z should be a column vector or K should be SIMO.\n");
	}
	if (n > 1) {
		// If it's multi-input, we can't use the nice algorithm
		// that follows, so use the numerically unreliable method
		// of going through polynomial form, and then return {a,b,c,d};
		{num,den} = zp2tf(z,p,k);    // Suppress compile-time diagnostics
		{A,B,C,D} = tf2ss(num,den);
		return {A,B,C,D};
	}

	// Strip infinities and throw away
	if ( ! isempty(p)) {
		p = p(abs(Array(p)) != Inf);
	}
	if ( ! isempty(z)) {
		z = z(abs(Array(z)) != Inf);
	}

	// Group into complex pairs
	np = length(p);
	nz = length(z);
	
	if ( ! isempty(p)) {
		p = cplxpair(p, 10*np*norm(p)*EPS);
	}
	if ( ! isempty(z)) {
		z = cplxpair(z, 10*nz*norm(z)*EPS);
	}

	// Initalize state-space matrices for running series
	A=[]; B=[]; C=[]; D=[1];
	
	// If odd number of poles AND zeros, convert the pole and zero
	// at the end into state-space.
	//	H(s) = (s-z1)/(s-p1) = (s + num(2)) / (s + den(2))
	if (rem(np,2) && rem(nz,2)) {
		A = [Re(p(np))];
		B = [1];
		C = [Re(p(np)) - Re(z(nz))];
		D = [1];
		np = np - 1;
		nz = nz - 1;
	}

	// If odd number of poles only, convert the pole at the
	// end into state-space.
	//  H(s) = 1/(s-p1) = 1/(s + den(2)) 
	if (rem(np,2)) {
		A = [Re(p(np))];
		B = [1];
		C = [1];
		D = [0];
		np = np - 1;
	}	

	// If odd number of zeros only, convert the zero at the
	// end, along with a pole-pair into state-space.
	//   H(s) = (s+num(2))/(s^2+den(2)s+den(3)) 
	if (rem(nz,2)) {
		num = Re(poly(z(nz)));
		den = Re(poly(p(np-1:np)));
		wn = sqrt(prod(abs(Array(p(np-1:np)))));
		if (wn == 0.0) {
			wn = 1.0;
		}
		t = vec2diag([1, 1/wn]);	// Balancing transformation
		A = t\[[-den(2), -den(3)][1 0]]*t;
		B = t\[[1][0]];
		C = [1, num(2)]*t;
		D = [0];
		nz = nz - 1;
		np = np - 2;
	}

	// Now we have an even number of poles and zeros, although not 
	// necessarily the same number - there may be more poles.
	//   H(s) = (s^2+num(2)s+num(3))/(s^2+den(2)s+den(3))
	// Loop thru rest of pairs, connecting in series to build the model.
	i = 1;
	while (i < nz) {
		index = [i:i+1];
		num = Re(poly(z(index)));
		den = Re(poly(p(index)));

		wn = sqrt(prod(abs(Array(p(index)))));
		if (wn == 0.0) {
			wn = 1.0;
		}
		t = vec2diag([1 1/wn]);	// Balancing transformation
		a1 = t\[[-den(2), -den(3)][1 0]]*t;
		b1 = t\[[1][0]];
		c1 = [num(2)-den(2), num(3)-den(3)]*t;
		d1 = [1];
		{A,B,C,D} = series(A,B,C,D,a1,b1,c1,d1);
		i = i + 2;
	}

	// Take care of any left over unmatched pole pairs.
	//   H(s) = 1/(s^2+den(2)s+den(3))
	while (i < np) {
		den = Re(poly(p(i:i+1)));
		wn = sqrt(prod(abs(Array(p(i:i+1)))));
		if (wn == 0.0) {
			wn = 1.0;
		}
		t = vec2diag([1 1/wn]);	// Balancing transformation
		a1 = t \ [[-den(2), -den(3)][1 0]]*t;
		b1 = t \ [[1][0]];
		c1 = [0 1]*t;
		d1 = [0];
		{A,B,C,D} = series(A,B,C,D,a1,b1,c1,d1);
		i = i + 2;
	}

	// Apply gain k:
	C = vec2diag(k) * C;
	D = vec2diag(k) * D;
	return {A,B,C,D};
}
