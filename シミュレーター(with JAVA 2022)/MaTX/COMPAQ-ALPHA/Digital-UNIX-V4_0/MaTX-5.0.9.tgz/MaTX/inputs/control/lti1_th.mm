
/*  -*- MaTX -*-
 *
 *  NAME
 *      lti1_th() - Convert transfer function to theta-parameter
 *
 *  SYNOPSIS
 *       th = lti1_th(G)
 *        Matrix th;
 *        RaMatrix G;
 *
 *  DESCRIPTION
 *       lti1_th(G) converts transfer function matrix G of a linear time
 *       invarient system to the theta parameter th.
 *
 *       It is assumed that all the elements of the transfer function
 *       in the same row have the common denominator such as
 *
 *       y(k) = G(q)u(k) + w(k)
 *                               or
 *       y(k) = G(z)u(k) + w(k)
 *

G(q)=[[ b1_11 q^-1 + ... + b1_1n q^-n         bm_11 q^-1 + ... + bm_1n q^-n ]
      [-------------------------------, ..., -------------------------------]
      [1 + a_11 q^-1 + ... + a_1n q^-n,      1 + a_11 q^-1 + ... + a_1n q^-n]
      [                                                                     ]
      [                                                                     ]
      [ b1_p1 q^-1 + ... + b1_pn q^-n         bm_p1 q^-1 + ... + bm_pn q^-n ]
      [-------------------------------, ..., -------------------------------]
      [1 + a_p1 q^-1 + ... + a_pn q^-n,      1 + a_p1 q^-1 + ... + a_pn q^-n]]

G(z)=[[   b1_11 z^n-1 + ... + b1_1n             bm_11 z^n-1 + ... + bm_1n   ]
      [-------------------------------, ..., -------------------------------]
      [ z^n + a_11 z^n-1 + ... + a_1n         z^n + a_11 z^n-1 + ... + a_1n ]
      [                                                                     ]
      [                                                                     ]
      [   b1_p1 z^n-1 + ... + b1_pn             bm_p1 z^n-1 + ... + bm_pn   ]
      [-------------------------------, ..., -------------------------------]
      [ z^n + a_p1 q^z-n1 + ... + a_pn        z^n + a_p1 z^n-1 + ... + a_pn ]]

 *
 *      or in polynomial form:
 * 
 *        [[y1(k)]       [[u1(k)]
 *   A(q)  [y2(k)] = B(q) [u2(k)]  + w(k)
 *         [.....]        [.....]
 *         [yp(k)]]       [um(k)]] 
 *
 * A(q) = diag(1 + a_11 q^-1 + ... a_1n q^-n,
 *                        1 + a_21 q^-1 + ... a_2n q^-n,
 *                                   .............................,
 *                                            1 + a_p1 q^-1 + ... a_pn q^-n)
 * 
 * B(q) = [[1 + b1_11 q^-1 + ... b1_1n q^-n, 1 + b1_21 q^-1 + ... b1_2n q^-n
 *          ..............................., 1 + b1_m1 q^-1 + ... b1_mn q^-n]
 *         [1 + b2_11 q^-1 + ... b2_1n q^-n, 1 + b2_21 q^-1 + ... b2_2n q^-n
 *          ..............................., 1 + b2_m1 q^-1 + ... b2_mn q^-n]
 *         [................................................................]
 *         [1 + bp_11 q^-1 + ... bp_1n q^-n, 1 + bp_21 q^-1 + ... bp_2n q^-n
 *          ..............................., 1 + bp_m1 q^-1 + ... bp_mn q^-n]]
 *
 *      or in theta-parameter form:
 *
 *        [[y1(k)]
 *         [y2(k)] = phi(k)#*th + w(k)
 *         [.....]
 *         [yp(k)]]
 *   
 *     th  : p*n*(m+1) x 1
 *     phi : p x p*n*(m+1) 
 *
 *  th = [[th1]  th1 = [[ a_11] th2 = [[ a_21]   ... thp = [[ a_p1]
 *        [th2]         [ a_12]        [ a_22]   ...        [ a_p2]
 *        [...]         [ ....]        [ ....]   ...        [ ... ]
 *        [thp]]        [ a_1n]        [ a_2n]   ...        [ a_pn]
 *                      [b1_11]        [b1_21]   ...        [b1_p2]
 *                      [b1_12]        [b1_22]   ...        [b1_p2]
 *                      [ ....]        [ ....]   ...        [ ... ]
 *                      [b1_1n]        [b1_2n]   ...        [b1_pn]
 *                      [ ....]        [ ....]   ...        [ ... ]
 *                      [bm_11]        [bm_21]   ...        [bm_p2]
 *                      [bm_12]        [bm_22]   ...        [bm_p2]
 *                      [ ....]        [ ....]   ...        [ ... ]
 *                      [bm_1n]]       [bm_2n]]  ...        [bm_pn]]
 *    
 *   phi(k) = diag([[-y_1(k-1)]  [[-y_2(k-1)]   ..., [[-y_p(k-1)]
 *                  [  ....   ]   [  ....   ]   ...,  [  ....   ]
 *                  [-y_1(k-n)]   [-y_2(k-n)]   ...,  [-y_p(k-n)]
 *                  [ u_1(k-1)]   [ u_1(k-1)]   ...,  [ u_1(k-1)]
 *                  [  ....   ]   [  ....   ]   ...,  [  ....   ]
 *                  [ u_1(k-n)]   [ u_1(k-n)]   ...,  [ u_1(k-n)]
 *                  [  ....   ]   [   ....  ]   ...,  [  ....   ]
 *                  [  ....   ]   [   ....  ]   ...,  [  ....   ]
 *                  [ u_m(k-1)]   [ u_m(k-1)]   ...,  [ u_m(k-1)]
 *                  [  ....   ]   [  ....   ]   ...,  [  ....   ]
 *                  [ u_m(k-n)]], [ u_m(k-n)]], ...,  [ u_m(k-n)]])
 *  
 */

Func Matrix lti1_th(G)
	RaMatrix G;
{
	Integer m;	// number of inputs
	Integer n;	// number of states
	Integer p;	// number of outputs
	Matrix th;	// theta parameter
	Integer i, j, ii, jj;
	Polynomial N, D;

	m = Cols(G);
	p = Rows(G);
	D = De(G(1,1));
	n = degree(D);
	
	th = Z((m+1)*n*p,1);
	
	for (i = 1; i <= p; i++) {
		D = De(G(i,1));
		ii = m*n*(i-1);
		if (version() == 4) {
			th(ii+1:ii+n,1) = [fliplr(Matrix(D))](2:n+1)#;
		} else {
			th(ii+1:ii+n,1) = [Matrix(D)](2:n+1)#;
		}
		for (j = 1; j <= m; j++) {
			N = Nu(G(i,j));
			jj = ii + n*j;
			if (version() == 4) {
				th(jj+1:jj+n,1) = [fliplr(Matrix(N))](1:n)#;
			} else {
				th(jj+1:jj+n,1) = [Matrix(N)](1:n)#;
			}
		}
	}

	return th;
}
