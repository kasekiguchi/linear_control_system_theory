
/*  -*- MaTX -*-
 *
 *  $B!ZL>A0![(B
 *      logspace() - $BBP?tEy4V3V%Y%/%H%k(B
 *
 *  $B!Z7A<0![(B
 *      y = logspace(d1, d2, n, ...)
 *         Array y;
 *         Real d1, d2;
 *         ...
 *         Integer n = 100;
 *
 *  $B!Z5!G=@bL@![(B
 *      logspace(d1,d2) $B$O!$(B10^d1 $B$H(B 10^d2 $B$rBP?tEy4V3V$G(B 50 $BJ,3d$7$?(B 50 $B8D(B
 *      $B$NCM$+$i$J$k9T%Y%/%H%k$rJV$9!#$b$7!$(Bd2 $B$,(B PI $B$J$i!$(B10^d1 $B$H(B PI $B$r(B
 *      $BBP?tEy4V3V$9$k!#(B
 *      logspace(d1,d2,N) $B$O!$(B10^d1 $B$H(B 10^d2 $B$rBP?tEy4V3V$G(B N $BJ,3d$7$?(B N $B8D$N(B
 *      $BCM$+$i$J$k9T%Y%/%H%k$rJV$9!#(B
 *
 *  $B!Z4XO"9`L\![(B
 *      linspace
 */

Func Array logspace(d1, d2, n, ...)
	Real d1, d2;
	Integer n;
{
	Array y;

	error(nargchk(2, 3, nargs, "logspace"));

	if (nargs == 2) {
		n = 50;
	}
	if (d2 == PI) {
		d2 = log10(PI);
	}
	if (abs(d1) <= 0.1 || 10.0 <= abs(d2)) {
		d1 = log10(d1);
		d2 = log10(d2);
	}

	y = 10.0 .^ [d1 .+ [0:n-2]*(d2-d1)/(n-1), Matrix(d2)];
	return y;
}
