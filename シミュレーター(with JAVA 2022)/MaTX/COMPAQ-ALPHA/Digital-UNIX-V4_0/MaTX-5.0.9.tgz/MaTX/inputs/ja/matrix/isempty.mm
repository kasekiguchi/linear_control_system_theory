
/*  -*- MaTX -*-
 *
 *  $B!ZL>A0![(B
 *      isempty() - $B6u9TNs$NH=Dj(B
 *
 *  $B!Z7A<0![(B
 *      i = isempty(X)
 *         Integer i;
 *         Matrix X;
 *
 *  $B!Z5!G=@bL@![(B
 *      X $B$,6u9TNs$N$H$-!$(Bisempty(X) $B$O(B 1 $B$r!$$=$&$G$J$$$H$-!$(B0 $B$r(B
 *      $BJV$9!#6u9TNs$H$O!$(B0 * 0 $B$N9TNs$G$"$k!#(B
 */

Func Integer isempty(x)
	Matrix x;
{
	return (length(x) == 0);
}
