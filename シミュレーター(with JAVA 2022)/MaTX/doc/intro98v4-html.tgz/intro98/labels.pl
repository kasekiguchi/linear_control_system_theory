# LaTeX2HTML 98.1p1 release (March 2nd, 1998)
# Associate labels original text with physical files.


$key = q/sec:inputs/;
$external_labels{$key} = "$URL/" . q|node20.html|; 
$noresave{$key} = "$nosave";

$key = q/sec:adap/;
$external_labels{$key} = "$URL/" . q|node36.html|; 
$noresave{$key} = "$nosave";

$key = q/sec:auto/;
$external_labels{$key} = "$URL/" . q|node29.html|; 
$noresave{$key} = "$nosave";

1;

