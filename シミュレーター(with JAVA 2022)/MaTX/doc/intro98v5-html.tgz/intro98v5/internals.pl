# LaTeX2HTML 98.1p1 release (March 2nd, 1998)
# Associate internals original text with physical files.


$key = q/sec:inputs/;
$ref_files{$key} = "$dir".q|node20.htm|; 
$noresave{$key} = "$nosave";

$key = q/sec:adap/;
$ref_files{$key} = "$dir".q|node36.htm|; 
$noresave{$key} = "$nosave";

$key = q/sec:auto/;
$ref_files{$key} = "$dir".q|node29.htm|; 
$noresave{$key} = "$nosave";

1;

