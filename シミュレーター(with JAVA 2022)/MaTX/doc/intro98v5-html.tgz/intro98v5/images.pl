# LaTeX2HTML 98.1p1 release (March 2nd, 1998)
# Associate images original text with physical files.


$key = q/{inline}mboxbullet{inline}MSF=1.6;AAT;/;
$cached_env_img{$key} = q|<IMG
 WIDTH="12" HEIGHT="14" ALIGN="BOTTOM" BORDER="0"
 SRC="img13.gif"
 ALT="$\mbox{$\bullet$}$">|; 

$key = q/{displaymath}fracy^A_i-y^B_iy^A_ileqepsilon~~(i=0,1,2,cdots){displaymath}MSF=1.6;AAT;/;
$cached_env_img{$key} = q|<IMG
 WIDTH="199" HEIGHT="46"
 SRC="img7.gif"
 ALT="\begin{displaymath}\frac{y^A_i - y^B_i}{y^A_i} \leq \epsilon ~~ (i = 0, 1,2,\cdots)
\end{displaymath}">|; 

$key = q/{leqnarray*}k_1&=&hf(x_i,y_i)k_2&=&hf(x_i+frach4,y_i+frack_14)k_3&=&hfleft(x_i+f856156430k_4-frac950k_5+frac255k_6y_i+1&=&y_i+rmDeltay_i{leqnarray*}MSF=1.6;AAT;/;
$cached_env_img{$key} = q|<IMG
 WIDTH="425" HEIGHT="379"
 SRC="img10.gif"
 ALT="\begin{leqnarray*}k_1 &=& h f(x_i, y_i) \\\\
k_2 &=& h f(x_i+\frac{h}{4}, y_i + \...
...k_5 + \frac{2}{55}k_6 \\\\
y_{i+1} &=& y_i + {\rm\Delta} y_i \\\\
\end{leqnarray*}">|; 

$key = q/{inline}H_infty{inline}MSF=1.6;AAT;/;
$cached_env_img{$key} = q|<IMG
 WIDTH="31" HEIGHT="29" ALIGN="MIDDLE" BORDER="0"
 SRC="img1.gif"
 ALT="$H_\infty $">|; 

$key = q/{displaymath}fracddtleft[arrayccx_1x_2arrayright]=left[arrayccos(x_2)sin(x_1)arrayright]{displaymath}MSF=1.6;AAT;/;
$cached_env_img{$key} = q|<IMG
 WIDTH="171" HEIGHT="54"
 SRC="img12.gif"
 ALT="\begin{displaymath}\frac{d}{dt} \left[
\begin{array}{cc}
x_1 \\\\
x_2 \\\\
\end{ar...
...begin{array}{c}
\cos(x_2) \\\\
\sin(x_1) \\\\
\end{array}\right]
\end{displaymath}">|; 

$key = q/{displaymath}rmDeltay_i=frac25216k_1+frac14082565k_3+frac21974104k_4-frac15k_5{displaymath}MSF=1.6;AAT;/;
$cached_env_img{$key} = q|<IMG
 WIDTH="277" HEIGHT="40"
 SRC="img11.gif"
 ALT="\begin{displaymath}{\rm\Delta} y_i = \frac{25}{216}k_1 + \frac{1408}{2565}k_3
+ \frac{2197}{4104}k_4 - \frac{1}{5}k_5
\end{displaymath}">|; 

$key = q/{inline}1times1{inline}MSF=1.6;AAT;/;
$cached_env_img{$key} = q|<IMG
 WIDTH="40" HEIGHT="28" ALIGN="MIDDLE" BORDER="0"
 SRC="img2.gif"
 ALT="$1\times 1$">|; 

$key = q/{displaymath}fracy^C_i-y^D_iy^C_ileqepsilon~~(i=0,1,2,cdots){displaymath}MSF=1.6;AAT;/;
$cached_env_img{$key} = q|<IMG
 WIDTH="200" HEIGHT="46"
 SRC="img9.gif"
 ALT="\begin{displaymath}\frac{y^C_i - y^D_i}{y^C_i} \leq \epsilon ~~ (i = 0, 1,2,\cdots)
\end{displaymath}">|; 

$key = q/{eqnarray*}y_i+1&=&y_i+frac16(k_0+2k_1+2k_2+k_3)k_0&=&hf(x_i,y_i)k_1&=&hfleft(x_left(x_i+frach2,y_i+frack_12right)k_3&=&hf(x_i+h,y_i+k_2){eqnarray*}MSF=1.6;AAT;/;
$cached_env_img{$key} = q|<IMG
 WIDTH="265" HEIGHT="173"
 SRC="img6.gif"
 ALT="\begin{eqnarray*}y_{i+1} &=& y_i + \frac{1}{6}(k_0 + 2 k_1 + 2 k_2 + k_3) \\\\
k_...
... y_i+ \frac{k_1}{2} \right) \\\\
k_3 &=& h f(x_i + h, y_i + k_2)
\end{eqnarray*}">|; 

$key = q/{inline}epsilon{inline}MSF=1.6;AAT;/;
$cached_env_img{$key} = q|<IMG
 WIDTH="11" HEIGHT="14" ALIGN="BOTTOM" BORDER="0"
 SRC="img8.gif"
 ALT="$\epsilon$">|; 

$key = q/{inline}widetilde{inline}MSF=1.6;AAT;/;
$cached_env_img{$key} = q|<IMG
 WIDTH="9" HEIGHT="19" ALIGN="BOTTOM" BORDER="0"
 SRC="img3.gif"
 ALT="$\widetilde{}$">|; 

$key = q/{displaymath}dotY=-Gtimes(x-a){displaymath}MSF=1.6;AAT;/;
$cached_env_img{$key} = q|<IMG
 WIDTH="126" HEIGHT="33"
 SRC="img4.gif"
 ALT="\begin{displaymath}\dot{Y} = - G \times (x - a)
\end{displaymath}">|; 

$key = q/{eqnarray*}y_i+1&=&y_i+rmDeltay~~(i=0,1,2,ldots)rmDeltay&=&lambda_0k_0+lambda_1kdotsk_p&=&hf(x_i+alpha_ph,y_i+beta_pk_0+gamma_pk_1+cdots){eqnarray*}MSF=1.6;AAT;/;
$cached_env_img{$key} = q|<IMG
 WIDTH="324" HEIGHT="229"
 SRC="img5.gif"
 ALT="\begin{eqnarray*}y_{i+1} &=& y_i + \rm {\Delta}y ~~ (i = 0, 1,2,\ldots) \\\\
\rm ...
...x_i + \alpha_p h, y_i + \beta_p k_0 + \gamma_p k_1 + \cdots) \\\\
\end{eqnarray*}">|; 

1;

