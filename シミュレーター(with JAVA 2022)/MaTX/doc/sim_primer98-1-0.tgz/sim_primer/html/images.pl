# LaTeX2HTML 97.1 (release) (July 13th, 1997)
# Associate images original text with physical files.


$key = q/{displaymath}H=left[arrayllllllbfq_r(t_0)&dotbfq_r(t_0)&ddotbfq_r(t_0)&bfq_r(t_10)&ddotT(t_0)&T(t_1)&dotT(t_1)&ddotT(t_1)arrayright]^-1{displaymath}MSF=1.6;AAT;/;
$cached_env_img{$key} = q|<IMG WIDTH="731" HEIGHT="37"
 SRC="img84.gif"
 ALT="\begin{displaymath}
H =
\left[
\begin{array}
{llllll}
{\bf q_r}(t_0) & \dot{\bf ...
 ...) & 
T(t_1) & \dot T(t_1) & \ddot T(t_1)\end{array}\right]^{-1}\end{displaymath}">|; 

$key = q/{displaymath}dotbfx(t)=Abfx(t){displaymath}MSF=1.6;AAT;/;
$cached_env_img{$key} = q|<IMG WIDTH="86" HEIGHT="31"
 SRC="img40.gif"
 ALT="\begin{displaymath}
\dot {\bf x}(t) = A {\bf x}(t)\end{displaymath}">|; 

$key = q/{displaymath}bfq(t)-bfq_r(t)=left(dotbfq(t_0)-dotbfq_r(t_0)right)(t-t_0)+bfq(t_0)-bfq_r(t_0){displaymath}MSF=1.6;AAT;/;
$cached_env_img{$key} = q|<IMG WIDTH="366" HEIGHT="31"
 SRC="img89.gif"
 ALT="\begin{displaymath}
{\bf q}(t) - {\bf q_r}(t)
=
\left( \dot{\bf q}(t_0) - \dot{\bf q_r}(t_0) \right) (t-t_0)
+ {\bf q}(t_0) - {\bf q_r}(t_0)\end{displaymath}">|; 

$key = q/{displaymath}A=left[arraycc1&-1arrayright],hspace*1cmB=left[arrayrr1&-12&-3array1cmk=10.0,hspace*1cmC=kAB=left[arraycc-10&20arrayright]{displaymath}MSF=1.6;AAT;/;
$cached_env_img{$key} = q|<IMG WIDTH="617" HEIGHT="53"
 SRC="img7.gif"
 ALT="\begin{displaymath}
A =
\left[
\begin{array}
{cc}
1 & -1 \\ \end{array}\right]
,...
 ... A B =
\left[
\begin{array}
{cc}
-10 & 20 \\ \end{array}\right]\end{displaymath}">|; 

$key = q/{displaymath}bfu(t)=J(bfq)ddotbfq_r+C(bfq,dotbfq)+Dbfq+G(bfq){displaymath}MSF=1.6;AAT;/;
$cached_env_img{$key} = q|<IMG WIDTH="251" HEIGHT="31"
 SRC="img85.gif"
 ALT="\begin{displaymath}
{\bf u}(t) =
J({\bf q})\ddot{\bf q_r} + C({\bf q},\dot{\bf q})
+ D {\bf q} + G({\bf q})\end{displaymath}">|; 

$key = q/{}includegraphics[width=7cm,clip]manip2track_plot_q_d.ps{}AAT;/;
$cached_env_img{$key} = q|<IMG WIDTH="282" HEIGHT="218" ALIGN="BOTTOM" BORDER="0"
 SRC="img100.gif"
 ALT="\includegraphics [width=7cm,clip]{manip2track_plot_q_d.ps}
">|; 

$key = q/{displaymath}J(bfq)ddotbfq+C(bfq,dotbfq)+Dbfq+G(bfq)=bfu+bfd{displaymath}MSF=1.6;AAT;/;
$cached_env_img{$key} = q|<IMG WIDTH="256" HEIGHT="31"
 SRC="img62.gif"
 ALT="\begin{displaymath}
J({\bf q})\ddot{\bf q} + C({\bf q},\dot{\bf q})
+ D {\bf q} + G({\bf q}) = {\bf u} + {\bf d}\end{displaymath}">|; 

$key = q/{displaymath}dotx(t)=-2x(t),hspace*1cmx(0)=5{displaymath}MSF=1.6;AAT;/;
$cached_env_img{$key} = q|<IMG WIDTH="207" HEIGHT="31"
 SRC="img37.gif"
 ALT="\begin{displaymath}
\dot x(t) = -2 x(t),\hspace*{1cm}x(0)=5\end{displaymath}">|; 

$key = q/{_inline}int^t_0x(t)mboxdt{_inline}MSF=1.6;AAT;/;
$cached_env_img{$key} = q|<IMG WIDTH="63" HEIGHT="35" ALIGN="MIDDLE" BORDER="0"
 SRC="img55.gif"
 ALT="$\int^{t}_0 x(t) \mbox{dt}$">|; 

$key = q/{}includegraphics[width=7cm,clip]manip2track_plot_u_d.ps{}AAT;/;
$cached_env_img{$key} = q|<IMG WIDTH="279" HEIGHT="218" ALIGN="BOTTOM" BORDER="0"
 SRC="img101.gif"
 ALT="\includegraphics [width=7cm,clip]{manip2track_plot_u_d.ps}
">|; 

$key = q/{displaymath}m=2,hspace*1zwn=3,hspace*1zwx=2.0,hspace*1zwy=3.0,hspace*1zw{displaymath}MSF=1.6;AAT;/;
$cached_env_img{$key} = q|<IMG WIDTH="253" HEIGHT="30"
 SRC="img3.gif"
 ALT="\begin{displaymath}
m = 2,\hspace*{1zw}n=3,\hspace*{1zw}
 x = 2.0,\hspace*{1zw}y=3.0,\hspace*{1zw}\end{displaymath}">|; 

$key = q/{}includegraphics[width=7cm,clip]1stdiffeqn_plot.ps{}AAT;/;
$cached_env_img{$key} = q|<IMG WIDTH="279" HEIGHT="218" ALIGN="BOTTOM" BORDER="0"
 SRC="img35.gif"
 ALT="\includegraphics [width=7cm,clip]{1stdiffeqn_plot.ps}
">|; 

$key = q/{}includegraphics[width=10cm,clip]sin.ps{}AAT;/;
$cached_env_img{$key} = q|<IMG WIDTH="405" HEIGHT="312" ALIGN="BOTTOM" BORDER="0"
 SRC="img17.gif"
 ALT="\includegraphics [width=10cm,clip]{sin.ps}
">|; 

$key = q/{_inline}dotx(t)=-2x(t){_inline}MSF=1.6;AAT;/;
$cached_env_img{$key} = q|<IMG WIDTH="98" HEIGHT="28" ALIGN="MIDDLE" BORDER="0"
 SRC="img36.gif"
 ALT="$\dot x(t) = -2 x(t)$">|; 

$key = q/{displaymath}left[arrayc12arrayright]left[arraycc3&4arrayright]=left[arraycc3&46&8arrayright]{displaymath}MSF=1.6;AAT;/;
$cached_env_img{$key} = q|<IMG WIDTH="187" HEIGHT="53"
 SRC="img2.gif"
 ALT="\begin{displaymath}
\left[
\begin{array}
{c}
 1 \\  2 \\ \end{array}\right]
\lef...
 ...left[
\begin{array}
{cc}
 3 & 4 \\  6 & 8 \\ \end{array}\right]\end{displaymath}">|; 

$key = q/{_inline}sin(2pix){_inline}MSF=1.6;AAT;/;
$cached_env_img{$key} = q|<IMG WIDTH="64" HEIGHT="28" ALIGN="MIDDLE" BORDER="0"
 SRC="img22.gif"
 ALT="$sin(2 \pi x)$">|; 

$key = q/{}includegraphics[width=10cm,clip]mck2.ps{}AAT;/;
$cached_env_img{$key} = q|<IMG WIDTH="450" HEIGHT="176" ALIGN="BOTTOM" BORDER="0"
 SRC="img44.gif"
 ALT="\includegraphics [width=10cm,clip]{mck2.ps}
">|; 

$key = q/{_inline}bfd(t)=0{_inline}MSF=1.6;AAT;/;
$cached_env_img{$key} = q|<IMG WIDTH="58" HEIGHT="28" ALIGN="MIDDLE" BORDER="0"
 SRC="img87.gif"
 ALT="${\bf d}(t)=0$">|; 

$key = q/{_inline}bfq_r(t_1){_inline}MSF=1.6;AAT;/;
$cached_env_img{$key} = q|<IMG WIDTH="42" HEIGHT="28" ALIGN="MIDDLE" BORDER="0"
 SRC="img76.gif"
 ALT="${\bf q_r}(t_1)$">|; 

$key = q/{_inline}bfq_i{_inline}MSF=1.6;AAT;/;
$cached_env_img{$key} = q|<IMG WIDTH="15" HEIGHT="24" ALIGN="MIDDLE" BORDER="0"
 SRC="img73.gif"
 ALT="${\bf q_i}$">|; 

$key = q/{displaymath}K=left[arrayrrrrr1&2&3&4&5arrayright],hspace*1zwL=left[arrayrrrrr-2.0&-1.5&cdots&2.5&3.0arrayright]{displaymath}MSF=1.6;AAT;/;
$cached_env_img{$key} = q|<IMG WIDTH="443" HEIGHT="37"
 SRC="img14.gif"
 ALT="\begin{displaymath}
K =
\left[
\begin{array}
{rrrrr}
1 & 2 & 3 & 4 & 5\\ \end{ar...
 ...
{rrrrr}
-2.0 & -1.5 & \cdots & 2.5 & 3.0 \\ \end{array}\right]\end{displaymath}">|; 

$key = q/{_inline}sin(2pix),cos(2pix){_inline}MSF=1.6;AAT;/;
$cached_env_img{$key} = q|<IMG WIDTH="128" HEIGHT="28" ALIGN="MIDDLE" BORDER="0"
 SRC="img19.gif"
 ALT="$\sin(2 \pi x),\cos(2 \pi x)$">|; 

$key = q/{displaymath}x(t)=phi(t){displaymath}MSF=1.6;AAT;/;
$cached_env_img{$key} = q|<IMG WIDTH="75" HEIGHT="31"
 SRC="img33.gif"
 ALT="\begin{displaymath}
x(t) = \phi(t)\end{displaymath}">|; 

$key = q/{_inline}sin(cdot){_inline}MSF=1.6;AAT;/;
$cached_env_img{$key} = q|<IMG WIDTH="42" HEIGHT="28" ALIGN="MIDDLE" BORDER="0"
 SRC="img21.gif"
 ALT="$sin(\cdot)$">|; 

$key = q/{_inline}3times1{_inline}MSF=1.6;AAT;/;
$cached_env_img{$key} = q|<IMG WIDTH="38" HEIGHT="24" ALIGN="MIDDLE" BORDER="0"
 SRC="img38.gif"
 ALT="$3\times 1$">|; 

$key = q/{displaymath}J(bfq)=left[arrayccJ_1+J_2+2betacosbeta_2&J_2+betacostheta_2J_2+betacostheta_2&J_2arrayright]{displaymath}MSF=1.6;AAT;/;
$cached_env_img{$key} = q|<IMG WIDTH="315" HEIGHT="53"
 SRC="img64.gif"
 ALT="\begin{displaymath}
J({\bf q}) =
\left[
\begin{array}
{cc}
J_1+J_2+2\beta \cos\b...
 ...\cos\theta_2\\ J_2+\beta\cos\theta_2 & J_2\\ \end{array}\right]\end{displaymath}">|; 

$key = q/{displaymath}x^(n)(t)=f(x^(n-1)(t),cdots,x^(0)(t),u^(n-1)(t),cdots,u^(0)(t)){displaymath}MSF=1.6;AAT;/;
$cached_env_img{$key} = q|<IMG WIDTH="378" HEIGHT="31"
 SRC="img25.gif"
 ALT="\begin{displaymath}
x^{(n)}(t) = f(x^{(n-1)}(t),\cdots,x^{(0)}(t),u^{(n-1)}(t),\cdots,u^{(0)}(t))\end{displaymath}">|; 

$key = q/{_inline}-1leqxleq1{_inline}MSF=1.6;AAT;/;
$cached_env_img{$key} = q|<IMG WIDTH="82" HEIGHT="24" ALIGN="MIDDLE" BORDER="0"
 SRC="img16.gif"
 ALT="$-1\leq x \leq 1$">|; 

$key = q/{}includegraphics[width=5cm,clip]manip2.ps{}AAT;/;
$cached_env_img{$key} = q|<IMG WIDTH="224" HEIGHT="317" ALIGN="BOTTOM" BORDER="0"
 SRC="img61.gif"
 ALT="\includegraphics [width=5cm,clip]{manip2.ps}
">|; 

$key = q/{}includegraphics[width=10cm,clip]sin2.ps{}AAT;/;
$cached_env_img{$key} = q|<IMG WIDTH="398" HEIGHT="312" ALIGN="BOTTOM" BORDER="0"
 SRC="img18.gif"
 ALT="\includegraphics [width=10cm,clip]{sin2.ps}
">|; 

$key = q/{_inline}bfq_r(t){_inline}MSF=1.6;AAT;/;
$cached_env_img{$key} = q|<IMG WIDTH="35" HEIGHT="28" ALIGN="MIDDLE" BORDER="0"
 SRC="img81.gif"
 ALT="${\bf q_r}(t)$">|; 

$key = q/{_inline}bfd(t){_inline}MSF=1.6;AAT;/;
$cached_env_img{$key} = q|<IMG WIDTH="29" HEIGHT="28" ALIGN="MIDDLE" BORDER="0"
 SRC="img69.gif"
 ALT="${\bf d}(t)$">|; 

$key = q/{displaymath}q(t):=int^t_0x(t)mboxdt,hspace*1zwq(0)=0{displaymath}MSF=1.6;AAT;/;
$cached_env_img{$key} = q|<IMG WIDTH="197" HEIGHT="44"
 SRC="img56.gif"
 ALT="\begin{displaymath}
q(t) := \int^{t}_0 x(t) \mbox{dt}
,\hspace*{1zw} q(0)=0\end{displaymath}">|; 

$key = q/{displaymath}ddotbfq=ddotbfq_r{displaymath}MSF=1.6;AAT;/;
$cached_env_img{$key} = q|<IMG WIDTH="42" HEIGHT="30"
 SRC="img88.gif"
 ALT="\begin{displaymath}
\ddot{\bf q} = \ddot{\bf q_r}\end{displaymath}">|; 

$key = q/{displaymath}K_p=4,hspace*1zwK_d=4{displaymath}MSF=1.6;AAT;/;
$cached_env_img{$key} = q|<IMG WIDTH="123" HEIGHT="32"
 SRC="img51.gif"
 ALT="\begin{displaymath}
K_p = 4,\hspace*{1zw} K_d = 4\end{displaymath}">|; 

$key = q/{displaymath}A:=left[arrayrrr0&1&00&0&1-2&-3&-2arrayright],hspace*1zwbfx(0):=left[arrayr100arrayright]{displaymath}MSF=1.6;AAT;/;
$cached_env_img{$key} = q|<IMG WIDTH="288" HEIGHT="76"
 SRC="img41.gif"
 ALT="\begin{displaymath}
A :=
\left[
\begin{array}
{rrr}
0 & 1 & 0\\ 0 & 0 & 1\\ -2 &...
 ...}(0) :=
\left[
\begin{array}
{r}
1\\ 0\\ 0\\ \end{array}\right]\end{displaymath}">|; 

$key = q/{_inline}a_i,x^(i)_0(i=0,cdots,n-1){_inline}MSF=1.6;AAT;/;
$cached_env_img{$key} = q|<IMG WIDTH="167" HEIGHT="37" ALIGN="MIDDLE" BORDER="0"
 SRC="img27.gif"
 ALT="$a_i,x^{(i)}_0(i=0,\cdots,n-1)$">|; 

$key = q/{}includegraphics[width=7cm,clip]manip2_plot_nofbdec.ps{}AAT;/;
$cached_env_img{$key} = q|<IMG WIDTH="282" HEIGHT="218" ALIGN="BOTTOM" BORDER="0"
 SRC="img70.gif"
 ALT="\includegraphics [width=7cm,clip]{manip2_plot_nofbdec.ps}
">|; 

$key = q/{_inline}bfq_f{_inline}MSF=1.6;AAT;/;
$cached_env_img{$key} = q|<IMG WIDTH="18" HEIGHT="24" ALIGN="MIDDLE" BORDER="0"
 SRC="img74.gif"
 ALT="${\bf q_f}$">|; 

$key = q/{_inline}bfq(t){_inline}MSF=1.6;AAT;/;
$cached_env_img{$key} = q|<IMG WIDTH="28" HEIGHT="28" ALIGN="MIDDLE" BORDER="0"
 SRC="img94.gif"
 ALT="${\bf q}(t)$">|; 

$key = q/{displaymath}ddotbfq=ddotbfq_r+J(bfq)^-1bfd{displaymath}MSF=1.6;AAT;/;
$cached_env_img{$key} = q|<IMG WIDTH="119" HEIGHT="31"
 SRC="img86.gif"
 ALT="\begin{displaymath}
\ddot{\bf q} = \ddot{\bf q_r} + J({\bf q})^{-1} {\bf d}\end{displaymath}">|; 

$key = q/{_inline}bfu(t){_inline}MSF=1.6;AAT;/;
$cached_env_img{$key} = q|<IMG WIDTH="30" HEIGHT="28" ALIGN="MIDDLE" BORDER="0"
 SRC="img68.gif"
 ALT="${\bf u}(t)$">|; 

$key = q/{}includegraphics[width=7cm,clip]mck_plot_nofb.ps{}AAT;/;
$cached_env_img{$key} = q|<IMG WIDTH="282" HEIGHT="218" ALIGN="BOTTOM" BORDER="0"
 SRC="img48.gif"
 ALT="\includegraphics [width=7cm,clip]{mck_plot_nofb.ps}
">|; 

$key = q/{_inline}bfx(t){_inline}MSF=1.6;AAT;/;
$cached_env_img{$key} = q|<IMG WIDTH="30" HEIGHT="28" ALIGN="MIDDLE" BORDER="0"
 SRC="img39.gif"
 ALT="${\bf x}(t)$">|; 

$key = q/{displaymath}Mddotx(t)+Cdotx(t)+Kx(t)=u(t)+d(t),hspace*1zwx(0)=x_01,dotx(0)=x_02{displaymath}MSF=1.6;AAT;/;
$cached_env_img{$key} = q|<IMG WIDTH="434" HEIGHT="31"
 SRC="img43.gif"
 ALT="\begin{displaymath}
M \ddot{x}(t) + C \dot{x}(t) + K x(t) = u(t) + d(t)
,\hspace*{1zw} x(0)=x_{01}, \dot x(0)= x_{02}\end{displaymath}">|; 

$key = q/{}includegraphics[width=7cm,clip]manip2track_plot_e.ps{}AAT;/;
$cached_env_img{$key} = q|<IMG WIDTH="282" HEIGHT="218" ALIGN="BOTTOM" BORDER="0"
 SRC="img93.gif"
 ALT="\includegraphics [width=7cm,clip]{manip2track_plot_e.ps}
">|; 

$key = q/{displaymath}bfd(t):=left[arrayl0.1sin(t)0.1sin(5t)arrayright]{displaymath}MSF=1.6;AAT;/;
$cached_env_img{$key} = q|<IMG WIDTH="151" HEIGHT="53"
 SRC="img95.gif"
 ALT="\begin{displaymath}
{\bf d}(t) :=
\left[
\begin{array}
{l}
0.1\sin(t) \\ 0.1\sin(5t) \\ \end{array}\right]\end{displaymath}">|; 

$key = q/{displaymath}bfq(t)=left[arrayrtheta_1(t)theta_2(t)arrayright],hspace*1zwbfu(t)=ht],hspace*1zwbfd(t)=left[arrayrd_1(t)d_2(t)arrayright]{displaymath}MSF=1.6;AAT;/;
$cached_env_img{$key} = q|<IMG WIDTH="393" HEIGHT="53"
 SRC="img63.gif"
 ALT="\begin{displaymath}
{\bf q}(t) =
\left[
\begin{array}
{r}
\theta_1(t) \\ \theta_...
 ...=
\left[
\begin{array}
{r}
d_1(t)\\ d_2(t)\\ \end{array}\right]\end{displaymath}">|; 

$key = q/{}includegraphics[width=10cm,clip]sin3.ps{}AAT;/;
$cached_env_img{$key} = q|<IMG WIDTH="398" HEIGHT="312" ALIGN="BOTTOM" BORDER="0"
 SRC="img20.gif"
 ALT="\includegraphics [width=10cm,clip]{sin3.ps}
">|; 

$key = q/{displaymath}dotbfx(t)=Abfx(t)+Bleft[u(t)+d(t)right]{displaymath}MSF=1.6;AAT;/;
$cached_env_img{$key} = q|<IMG WIDTH="203" HEIGHT="31"
 SRC="img45.gif"
 ALT="\begin{displaymath}
\dot {\bf x}(t) = A {\bf x}(t) + B \left[ u(t) + d(t) \right]\end{displaymath}">|; 

$key = q/{displaymath}bfq_r(t)=bfh_0+bfh_1t+cdots+bfh_5t^5=left[arrayllllbfh_0&bfh_1&cdotbfh_5arrayright]left[arrayl1tvdotst^5arrayright]=:HT(t){displaymath}MSF=1.6;AAT;/;
$cached_env_img{$key} = q|<IMG WIDTH="489" HEIGHT="108"
 SRC="img82.gif"
 ALT="\begin{displaymath}
{\bf q_r}(t) = {\bf h_0} + {\bf h_1} t + \cdots + {\bf h_5} ...
 ...
{l}
1 \\ t \\ \vdots \\ t^5 \\ \end{array}\right] \\ =: H T(t)\end{displaymath}">|; 

$key = q/{}includegraphics[width=7cm,clip]manip2track_plot_q.ps{}AAT;/;
$cached_env_img{$key} = q|<IMG WIDTH="279" HEIGHT="218" ALIGN="BOTTOM" BORDER="0"
 SRC="img91.gif"
 ALT="\includegraphics [width=7cm,clip]{manip2track_plot_q.ps}
">|; 

$key = q/{_inline}dotbfq_r(t_0)=0{_inline}MSF=1.6;AAT;/;
$cached_env_img{$key} = q|<IMG WIDTH="71" HEIGHT="28" ALIGN="MIDDLE" BORDER="0"
 SRC="img77.gif"
 ALT="$\dot {\bf q_r}(t_0) = 0$">|; 

$key = q/{displaymath}A:=left[arrayrr0&1-KM&-CMarrayright],hspace*1zwB:=left[arrayr01Marrayright]{displaymath}MSF=1.6;AAT;/;
$cached_env_img{$key} = q|<IMG WIDTH="313" HEIGHT="53"
 SRC="img46.gif"
 ALT="\begin{displaymath}
A :=
\left[
\begin{array}
{rr}
0 & 1 \\ - K/M & - C/M \\ \en...
 ...zw}
B :=
\left[
\begin{array}
{r}
0 \\ 1/M\\ \end{array}\right]\end{displaymath}">|; 

$key = q/{_inline}dotbfq_r(t_1)=0{_inline}MSF=1.6;AAT;/;
$cached_env_img{$key} = q|<IMG WIDTH="71" HEIGHT="28" ALIGN="MIDDLE" BORDER="0"
 SRC="img78.gif"
 ALT="$\dot {\bf q_r}(t_1) = 0$">|; 

$key = q/{displaymath}sin(pi4.0),hspace*1zwtan^-1(1.0),hspace*1zwe^1.0{displaymath}MSF=1.6;AAT;/;
$cached_env_img{$key} = q|<IMG WIDTH="214" HEIGHT="31"
 SRC="img5.gif"
 ALT="\begin{displaymath}
sin(\pi/4.0),\hspace*{1zw}tan^{-1}(1.0),\hspace*{1zw}e^{1.0}\end{displaymath}">|; 

$key = q/{displaymath}A^T=left[arrayr1-1arrayright],hspace*1cmB^-1=left[arrayrr1&-12&-3arrayright]^-1=left[arrayrr3&-12&-1arrayright]{displaymath}MSF=1.6;AAT;/;
$cached_env_img{$key} = q|<IMG WIDTH="396" HEIGHT="56"
 SRC="img8.gif"
 ALT="\begin{displaymath}
A^T =
\left[
\begin{array}
{r}
1 \\ -1 \\ \end{array}\right]...
 ...
\left[
\begin{array}
{rr}
3 & -1\\ 2 & -1\\ \end{array}\right]\end{displaymath}">|; 

$key = q/{displaymath}C(bfq,dotbfq)=left[arrayc-beta(2dottheta_1dottheta_2+dottheta_2^2)srayright],hspace*1zwD=left[arrayccD_1&00&D_2arrayright]{displaymath}MSF=1.6;AAT;/;
$cached_env_img{$key} = q|<IMG WIDTH="395" HEIGHT="53"
 SRC="img65.gif"
 ALT="\begin{displaymath}
C({\bf q},\dot{\bf q})
=
\left[
\begin{array}
{c}
-\beta(2\d...
 ...ft[
\begin{array}
{cc}
D_1 & 0 \\ 0 & D_2 \\ \end{array}\right]\end{displaymath}">|; 

$key = q/{}includegraphics[width=7cm,clip]mck_plot_pidx.ps{}AAT;/;
$cached_env_img{$key} = q|<IMG WIDTH="282" HEIGHT="218" ALIGN="BOTTOM" BORDER="0"
 SRC="img59.gif"
 ALT="\includegraphics [width=7cm,clip]{mck_plot_pidx.ps}
">|; 

$key = q/{}includegraphics[width=7cm,clip]manip2track_plot_u.ps{}AAT;/;
$cached_env_img{$key} = q|<IMG WIDTH="279" HEIGHT="218" ALIGN="BOTTOM" BORDER="0"
 SRC="img92.gif"
 ALT="\includegraphics [width=7cm,clip]{manip2track_plot_u.ps}
">|; 

$key = q/{displaymath}arraycx^(n)+a_n-1x^(n-1)+cdots+a_1x^(1)+a_0x^(0)=b_mu^(m)+cdotsb_1u^(1)+b_0u(t)x^(n)(0)=x^(n)_0vdotsx^(0)(0)=x^(0)_0array{displaymath}MSF=1.6;AAT;/;
$cached_env_img{$key} = q|<IMG WIDTH="496" HEIGHT="108"
 SRC="img29.gif"
 ALT="\begin{displaymath}
\begin{array}
{c}
 x^{(n)}+a_{n-1}x^{(n-1)}+\cdots+a_{1}x^{(...
 ...{(n)}(0)=x^{(n)}_0 \\ \vdots \\ x^{(0)}(0)=x^{(0)}_0\end{array}\end{displaymath}">|; 

$key = q/{displaymath}Mddotx(t)+Cdotx(t)+Kx(t)=u(t){displaymath}MSF=1.6;AAT;/;
$cached_env_img{$key} = q|<IMG WIDTH="212" HEIGHT="31"
 SRC="img30.gif"
 ALT="\begin{displaymath}
M \ddot{x}(t) + C \dot{x}(t) + K x(t) = u(t)\end{displaymath}">|; 

$key = q/{displaymath}u(t)=-K_px(t)-K_ddotx(t)-K_iint^t_0x(t)mboxdt{displaymath}MSF=1.6;AAT;/;
$cached_env_img{$key} = q|<IMG WIDTH="284" HEIGHT="44"
 SRC="img54.gif"
 ALT="\begin{displaymath}
u(t) = - K_p x(t) - K_d \dot x(t) -K_i \int^{t}_0 x(t) \mbox{dt}\end{displaymath}">|; 

$key = q/{_inline}pi{_inline}MSF=1.6;AAT;/;
$cached_env_img{$key} = q|<IMG WIDTH="12" HEIGHT="13" ALIGN="BOTTOM" BORDER="0"
 SRC="img6.gif"
 ALT="$\pi$">|; 

$key = q/{displaymath}x^(i):=fracmboxd^imboxdt^ix(t){displaymath}MSF=1.6;AAT;/;
$cached_env_img{$key} = q|<IMG WIDTH="329" HEIGHT="44"
 SRC="img23.gif"
 ALT="\begin{displaymath}
x^{(i)}:=\frac{\mbox{d}^i}{\mbox{dt}^i} x(t)\end{displaymath}">|; 

$key = q/{_inline}bfq(t)-bfq_r(t){_inline}MSF=1.6;AAT;/;
$cached_env_img{$key} = q|<IMG WIDTH="80" HEIGHT="28" ALIGN="MIDDLE" BORDER="0"
 SRC="img90.gif"
 ALT="${\bf q}(t)-{\bf q_r}(t)$">|; 

$key = q/{displaymath}dotq(t)=x(t){displaymath}MSF=1.6;AAT;/;
$cached_env_img{$key} = q|<IMG WIDTH="73" HEIGHT="31"
 SRC="img57.gif"
 ALT="\begin{displaymath}
\dot q(t) = x(t)\end{displaymath}">|; 

$key = q/{displaymath}G=left[arrayrrr0&0&00&0&0arrayright],hspace*1zwH=left[arrayrrr1&0&0ht],hspace*1zwJ=left[arrayrrr2&0&00&3&00&0&4arrayright]{displaymath}MSF=1.6;AAT;/;
$cached_env_img{$key} = q|<IMG WIDTH="422" HEIGHT="76"
 SRC="img11.gif"
 ALT="\begin{displaymath}
G =
\left[
\begin{array}
{rrr}
0 & 0 & 0 \\ 0 & 0 & 0 \\ \en...
 ...{rrr}
2 & 0 & 0 \\ 0 & 3 & 0 \\ 0 & 0 & 4 \\ \end{array}\right]\end{displaymath}">|; 

$key = q/{_inline}bfq_r(t_0){_inline}MSF=1.6;AAT;/;
$cached_env_img{$key} = q|<IMG WIDTH="42" HEIGHT="28" ALIGN="MIDDLE" BORDER="0"
 SRC="img75.gif"
 ALT="${\bf q_r}(t_0)$">|; 

$key = q/{_inline}f(cdot){_inline}MSF=1.6;AAT;/;
$cached_env_img{$key} = q|<IMG WIDTH="29" HEIGHT="28" ALIGN="MIDDLE" BORDER="0"
 SRC="img24.gif"
 ALT="$f(\cdot)$">|; 

$key = q/{displaymath}bfu(t):=J(bfq)ddotbfq_r+C(bfq,dotbfq)+Dbfq+G(bfq)-K_pleft(bfq(t)-bfq_r(t)right)-K_dleft(dotbfq(t)-dotbfq_r(t)right){displaymath}MSF=1.6;AAT;/;
$cached_env_img{$key} = q|<IMG WIDTH="521" HEIGHT="32"
 SRC="img99.gif"
 ALT="\begin{displaymath}
{\bf u}(t) := 
J({\bf q})\ddot{\bf q_r} + C({\bf q},\dot{\bf...
 ...right)
- K_d \left( \dot {\bf q}(t) - \dot {\bf q_r}(t) \right)\end{displaymath}">|; 

$key = q/{}includegraphics[width=7cm,clip]mck_plot_nofbd.ps{}AAT;/;
$cached_env_img{$key} = q|<IMG WIDTH="279" HEIGHT="218" ALIGN="BOTTOM" BORDER="0"
 SRC="img49.gif"
 ALT="\includegraphics [width=7cm,clip]{mck_plot_nofbd.ps}
">|; 

$key = q/{displaymath}m^2,hspace*1zwx^-1,hspace*1zwm+n,hspace*1zwx+y,hspace*1zwx+n,hspace*1zw,hspace*1zwxy,hspace*1zwnm{displaymath}MSF=1.6;AAT;/;
$cached_env_img{$key} = q|<IMG WIDTH="379" HEIGHT="31"
 SRC="img4.gif"
 ALT="\begin{displaymath}
m^2,\hspace*{1zw}x^{-1},\hspace*{1zw}
 m+n,\hspace*{1zw} x+y...
 ...ace*{1zw}
 x+n,\hspace*{1zw}
,\hspace*{1zw}x/y,\hspace*{1zw}n/m\end{displaymath}">|; 

$key = q/{_inline}3times3{_inline}MSF=1.6;AAT;/;
$cached_env_img{$key} = q|<IMG WIDTH="38" HEIGHT="24" ALIGN="MIDDLE" BORDER="0"
 SRC="img13.gif"
 ALT="$3\times 3$">|; 

$key = q/{}includegraphics[width=7cm,clip]mck_plot_pdx.ps{}AAT;/;
$cached_env_img{$key} = q|<IMG WIDTH="279" HEIGHT="218" ALIGN="BOTTOM" BORDER="0"
 SRC="img52.gif"
 ALT="\includegraphics [width=7cm,clip]{mck_plot_pdx.ps}
">|; 

$key = q/{displaymath}K=1.0,hspace*1zwC=0.1,hspace*1zwM=1.0,hspace*1zwu(t)=0.0,hspace*1zwd(t)=0.0,hspace*1zwbfx(0):=left[arrayrr1&0arrayright]^T{displaymath}MSF=1.6;AAT;/;
$cached_env_img{$key} = q|<IMG WIDTH="544" HEIGHT="37"
 SRC="img47.gif"
 ALT="\begin{displaymath}
K=1.0
,\hspace*{1zw}
C=0.1
,\hspace*{1zw}
M=1.0
,\hspace*{1z...
 ...bf x}(0) :=
\left[
\begin{array}
{rr}
1 & 0\end{array}\right]^T\end{displaymath}">|; 

$key = q/{}includegraphics[width=10cm,clip]mck.ps{}AAT;/;
$cached_env_img{$key} = q|<IMG WIDTH="450" HEIGHT="176" ALIGN="BOTTOM" BORDER="0"
 SRC="img31.gif"
 ALT="\includegraphics [width=10cm,clip]{mck.ps}
">|; 

$key = q/{displaymath}left[arrayc|c|cD&B&A^Tarrayright]=F=left[arrayrr|rr|r1&-1&1&-1&1-10&20&2&3&-1arrayright]{displaymath}MSF=1.6;AAT;/;
$cached_env_img{$key} = q|<IMG WIDTH="354" HEIGHT="53"
 SRC="img10.gif"
 ALT="\begin{displaymath}
\left[
\begin{array}
{c\vert c\vert c}
D & B & A^T\\ \end{ar...
 ... & -1 & 1 & -1 & 1\\ -10 & 20 & 2 & 3 & -1\\ \end{array}\right]\end{displaymath}">|; 

$key = q/{displaymath}n=2,hspace*1zwm=1,hspace*1zwa_1=fracCM,hspace*1zwa_0=fracKM,hspace*1zwb_0=frac1M{displaymath}MSF=1.6;AAT;/;
$cached_env_img{$key} = q|<IMG WIDTH="341" HEIGHT="38"
 SRC="img32.gif"
 ALT="\begin{displaymath}
n = 2,\hspace*{1zw}m=1,\hspace*{1zw}a_1 = \frac{C}{M},\hspace*{1zw}
a_0 = \frac{K}{M},\hspace*{1zw}b_0 = \frac{1}{M}\end{displaymath}">|; 

$key = q/{}includegraphics[width=7cm,clip]mck_plot_pidu.ps{}AAT;/;
$cached_env_img{$key} = q|<IMG WIDTH="282" HEIGHT="218" ALIGN="BOTTOM" BORDER="0"
 SRC="img60.gif"
 ALT="\includegraphics [width=7cm,clip]{mck_plot_pidu.ps}
">|; 

$key = q/{displaymath}G(bfq)=-left[arrayc(m_1+2m_2)l_1gsintheta_1+m_2l_2gsin(theta_1+theta_2)m_2l_2gsin(theta_1+theta_2)arrayright]{displaymath}MSF=1.6;AAT;/;
$cached_env_img{$key} = q|<IMG WIDTH="384" HEIGHT="53"
 SRC="img66.gif"
 ALT="\begin{displaymath}
G({\bf q}) =
-
\left[
\begin{array}
{c}
(m_1+2 m_2)l_1 g \si...
 ...theta_2) \\ m_2 l_2 g \sin(\theta_1+\theta_2)\end{array}\right]\end{displaymath}">|; 

$key = q/{}includegraphics[width=7cm,clip]vec3diffeqn_plot.ps{}AAT;/;
$cached_env_img{$key} = q|<IMG WIDTH="282" HEIGHT="218" ALIGN="BOTTOM" BORDER="0"
 SRC="img42.gif"
 ALT="\includegraphics [width=7cm,clip]{vec3diffeqn_plot.ps}
">|; 

$key = q/{_inline}b_i(i=0,cdots,m){_inline}MSF=1.6;AAT;/;
$cached_env_img{$key} = q|<IMG WIDTH="111" HEIGHT="28" ALIGN="MIDDLE" BORDER="0"
 SRC="img28.gif"
 ALT="$b_i(i=0,\cdots,m)$">|; 

$key = q/{_inline}ddotbfq_r(t_0)=0{_inline}MSF=1.6;AAT;/;
$cached_env_img{$key} = q|<IMG WIDTH="71" HEIGHT="28" ALIGN="MIDDLE" BORDER="0"
 SRC="img79.gif"
 ALT="$\ddot {\bf q_r}(t_0) = 0$">|; 

$key = q/{_inline}ddotbfq_r(t_1)=0{_inline}MSF=1.6;AAT;/;
$cached_env_img{$key} = q|<IMG WIDTH="71" HEIGHT="28" ALIGN="MIDDLE" BORDER="0"
 SRC="img80.gif"
 ALT="$\ddot {\bf q_r}(t_1) = 0$">|; 

$key = q/{displaymath}u(t)=-K_px(t)-K_ddotx(t)=left[arrayrr-K_p&-K_darrayright]left[arrayrx(t)dotx(t)arrayright]{displaymath}MSF=1.6;AAT;/;
$cached_env_img{$key} = q|<IMG WIDTH="371" HEIGHT="53"
 SRC="img50.gif"
 ALT="\begin{displaymath}
u(t) = - K_p x(t) - K_d \dot x(t)
= 
\left[
\begin{array}
{r...
 ...left[
\begin{array}
{r}
x(t) \\ \dot x(t) \\ \end{array}\right]\end{displaymath}">|; 

$key = q/{displaymath}dotx(t)=-2x(t),hspace*1zwx(0)=5{displaymath}MSF=1.6;AAT;/;
$cached_env_img{$key} = q|<IMG WIDTH="177" HEIGHT="31"
 SRC="img1.gif"
 ALT="\begin{displaymath}
\dot{x}(t) = - 2 x(t), \hspace*{1zw} x(0) = 5\end{displaymath}">|; 

$key = q/{}includegraphics[width=7cm,clip]manip2track_plot_e_d0.ps{}AAT;/;
$cached_env_img{$key} = q|<IMG WIDTH="282" HEIGHT="218" ALIGN="BOTTOM" BORDER="0"
 SRC="img98.gif"
 ALT="\includegraphics [width=7cm,clip]{manip2track_plot_e_d0.ps}
">|; 

$key = q/{displaymath}left[arrayllllllbfq_r(t_0)&dotbfq_r(t_0)&ddotbfq_r(t_0)&bfq_r(t_1)&(t_0)&ddotT(t_0)&T(t_1)&dotT(t_1)&ddotT(t_1)arrayright]{displaymath}MSF=1.6;AAT;/;
$cached_env_img{$key} = q|<IMG WIDTH="710" HEIGHT="37"
 SRC="img83.gif"
 ALT="\begin{displaymath}
\left[
\begin{array}
{llllll}
{\bf q_r}(t_0) & \dot{\bf q_r}...
 ...T(t_0) & 
T(t_1) & \dot T(t_1) & \ddot T(t_1)\end{array}\right]\end{displaymath}">|; 

$key = q/{displaymath}ddotx(t)=-x(t)left(u(t)+1right)-x^3(t){displaymath}MSF=1.6;AAT;/;
$cached_env_img{$key} = q|<IMG WIDTH="210" HEIGHT="31"
 SRC="img26.gif"
 ALT="\begin{displaymath}
\ddot{x}(t) = - x(t)\left(u(t)+1\right) - x^3(t)\end{displaymath}">|; 

$key = q/{displaymath}fracmboxdmboxdtleft[arraycbfqdotbfqarrayright]=left[arraycdotbfq-J(ght]+left[arrayc0J(bfq)^-1arrayright]left(bfu+bfdright){displaymath}MSF=1.6;AAT;/;
$cached_env_img{$key} = q|<IMG WIDTH="485" HEIGHT="53"
 SRC="img67.gif"
 ALT="\begin{displaymath}
\frac{\mbox{d}}{\mbox{dt}}
\left[
\begin{array}
{c}
{\bf q}\...
 ...q})^{-1} \\ \end{array}\right]
\left(
{\bf u} + {\bf d}
\right)\end{displaymath}">|; 

$key = q/{}includegraphics[width=7cm,clip]manip2track_plot_q_d0.ps{}AAT;/;
$cached_env_img{$key} = q|<IMG WIDTH="282" HEIGHT="218" ALIGN="BOTTOM" BORDER="0"
 SRC="img96.gif"
 ALT="\includegraphics [width=7cm,clip]{manip2track_plot_q_d0.ps}
">|; 

$key = q/{displaymath}u(t)=left[arrayrrr-K_p&-K_d&-K_iarrayright]left[arrayrx(t)dotx(t)q(t)arrayright]{displaymath}MSF=1.6;AAT;/;
$cached_env_img{$key} = q|<IMG WIDTH="272" HEIGHT="76"
 SRC="img58.gif"
 ALT="\begin{displaymath}
u(t) = 
\left[
\begin{array}
{rrr}
- K_p & - K_d & -K_i \\ \...
 ...egin{array}
{r}
x(t) \\ \dot x(t) \\ q(t) \\ \end{array}\right]\end{displaymath}">|; 

$key = q/{_inline}phi(t){_inline}MSF=1.6;AAT;/;
$cached_env_img{$key} = q|<IMG WIDTH="30" HEIGHT="28" ALIGN="MIDDLE" BORDER="0"
 SRC="img34.gif"
 ALT="$\phi(t)$">|; 

$key = q/{_inline}2times3{_inline}MSF=1.6;AAT;/;
$cached_env_img{$key} = q|<IMG WIDTH="38" HEIGHT="24" ALIGN="MIDDLE" BORDER="0"
 SRC="img12.gif"
 ALT="$2\times 3$">|; 

$key = q/{}includegraphics[width=7cm,clip]mck_plot_pdu.ps{}AAT;/;
$cached_env_img{$key} = q|<IMG WIDTH="282" HEIGHT="218" ALIGN="BOTTOM" BORDER="0"
 SRC="img53.gif"
 ALT="\includegraphics [width=7cm,clip]{mck_plot_pdu.ps}
">|; 

$key = q/{}includegraphics[width=7cm,clip]manip2track_plot_u_d0.ps{}AAT;/;
$cached_env_img{$key} = q|<IMG WIDTH="279" HEIGHT="218" ALIGN="BOTTOM" BORDER="0"
 SRC="img97.gif"
 ALT="\includegraphics [width=7cm,clip]{manip2track_plot_u_d0.ps}
">|; 

$key = q/{}includegraphics[width=7cm,clip]manip2track_plot_e_d.ps{}AAT;/;
$cached_env_img{$key} = q|<IMG WIDTH="291" HEIGHT="218" ALIGN="BOTTOM" BORDER="0"
 SRC="img102.gif"
 ALT="\includegraphics [width=7cm,clip]{manip2track_plot_e_d.ps}
">|; 

$key = q/{_inline}theta_1(t){_inline}MSF=1.6;AAT;/;
$cached_env_img{$key} = q|<IMG WIDTH="35" HEIGHT="28" ALIGN="MIDDLE" BORDER="0"
 SRC="img71.gif"
 ALT="$\theta_1(t)$">|; 

$key = q/{_inline}theta_2(t){_inline}MSF=1.6;AAT;/;
$cached_env_img{$key} = q|<IMG WIDTH="35" HEIGHT="28" ALIGN="MIDDLE" BORDER="0"
 SRC="img72.gif"
 ALT="$\theta_2(t)$">|; 

$key = q/{displaymath}D=left[arraycAhlineCarrayright]=left[arrayrr1&-1hline-10&20arrayrigt]=left[arrayrr|rr|r1&-1&1&-1&1-10&20&2&3&-1arrayright]{displaymath}MSF=1.6;AAT;/;
$cached_env_img{$key} = q|<IMG WIDTH="584" HEIGHT="53"
 SRC="img9.gif"
 ALT="\begin{displaymath}
D =
\left[
\begin{array}
{c}
A \\  \hline
C \\ \end{array}\r...
 ... & -1 & 1 & -1 & 1\\ -10 & 20 & 2 & 3 & -1\\ \end{array}\right]\end{displaymath}">|; 

$key = q/{displaymath}y=sin(2pix),hspace*1zw-1leqxleq1{displaymath}MSF=1.6;AAT;/;
$cached_env_img{$key} = q|<IMG WIDTH="190" HEIGHT="31"
 SRC="img15.gif"
 ALT="\begin{displaymath}
y = \sin(2 \pi x),\hspace*{1zw}-1\leq x \leq 1\end{displaymath}">|; 

1;

