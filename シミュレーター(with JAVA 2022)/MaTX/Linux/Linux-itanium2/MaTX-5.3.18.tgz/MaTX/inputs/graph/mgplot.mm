
/* -*- MaTX -*-
 *
 *  NAME
 *      mgplot()             - Linear x-y Multiple Plot
 *      mgplot_clear()       - Clear screen
 *      mgplot_cmd()         - Send any commands with "\n" to gnuplot
 *      mgplot_grid()        - Grid lines (toggle)
 *      mgplot_hold()        - Hold command (DOS, Windows95/NT)
 *      mgplot_key()         - Key lines (toggle)
 *      mgplot_parametric()  - Parametric lines (toggle)
 *      mgplot_hidden3d()    - Hidden 3D (toggle)
 *      mgplot_loglog()      - Loglog x-y plot
 *      mgplot_options()     - Set window options
 *      mgplot_out()         - Send a string to gnuplot
 *      mgplot_ps()          - Save graph as a postscript file
 *      mgplot_eps()         - Save graph as an encapsulated postscript file
 *      mgplot_psplus()      - Save graph as postscript plus file (gnuplot+)
 *      mgplot_epsplus()     - Save graph as an eps plus file (gnuplot+)
 *      mgplot_fig()         - Save the graph as a figcode file
 *      mgplot_quit()        - Quit mgplot
 *      mgplot_range()       - Set range of axes
 *      mgplot_xrange()      - Set range of x-axis
 *      mgplot_yrange()      - Set range of y-axis
 *      mgplot_zrange()      - Set range of z-axis
 *      mgplot_replot()      - Replot lines
 *      mgplot_reset()       - Reset window
 *      mgplot_semilogx()    - Semi-log x-y plot (x-axis logarithmic)
 *      mgplot_semilogy()    - Semi-log x-y plot (y-axis logarithmic)
 *      mgplot_text()        - Put text on the screen
 *      mgplot_title()       - Graph title
 *      mgplot_xlabel()      - X-axis label
 *      mgplot_x2label()     - 2nd X-axis label
 *      mgplot_ylabel()      - Y-axis label
 *      mgplot_y2label()     - 2nd Y-axis label
 *      mgplot_zlabel()      - Z-axis label
 *      mgplot_view()        - Angle og view
 *      mgplot_view_control()- Angle og view
 *      mgreplot()           - Linear x-y Multiple Plot
 *      mgreplot_loglog()    - Loglog x-y plot
 *      mgreplot_semilogx()  - Semi-log x-y plot (x-axis logarithmic)
 *      mgreplot_semilogy()  - Semi-log x-y plot (y-axis logarithmic)
 *
 *  SYNOPSIS
 *      mgplot(win, X, Y, titles, cmds1, cmds2, ...)
 *        Integer win;
 *        Array X;
 *        ...
 *        Array Y;
 *        List titles = {};
 *        List cmds1 = {};
 *        List cmds2 = {};
 *
 *      mgplot_clear(win)
 *        Integer win;
 *
 *      mgplot_cmd(win, cmd)
 *        Integer win;
 *        String cmd;
 *
 *      mgplot_hold(win, on_off, ...)
 *         Integer win;
 *         ...
 *         Integer on_off;
 *
 *      mgplot_grid(win, onoff, ...)
 *         Integer win;
 *         ...
 *         Integer onoff;
 *
 *      mgplot_key(win, onoff, ...)
 *        Integer win;
 *        ...
 *        Integer onoff;
 *
 *      mgplot_parametric(win, onoff, ...)
 *        Integer win;
 *        ...
 *        Integer onoff;
 *
 *      mgplot_hidden3d(win, onoff, ...)
 *        Integer win;
 *        ...
 *        Integer onoff;
 *
 *      mgplot_loglog(win, X, Y, titles, cmds1, cmds2, ...)
 *        Integer win;
 *        Array X, Y;
 *        ...
 *        List titles = {};
 *        List cmds1 = {};
 *        List cmds2 = {};
 *
 *      mgplot_options(win, options)
 *        Integer win;
 *        String options;
 *
 *      mgplot_out(win, str)
 *        Integer win;
 *        String str;
 *
 *      mgplot_ps(win, filename, cmd, ...)
 *         Integer win;
 *         String filename;
 *         ...
 *         String cmd = {};
 *
 *      mgplot_eps(win, filename, cmd, ...)
 *         Integer win;
 *         String filename;
 *         ...
 *         String cmd = {};
 *
 *      mgplot_psplus(win, filename, cmd, ...)
 *         Integer win;
 *         String filename;
 *         ...
 *         String cmd = {};
 *
 *      mgplot_epsplus(win, filename, cmd, ...)
 *         Integer win;
 *         String filename;
 *         ...
 *         String cmd = {};
 *
 *      mgplot_fig(win, filename, cmd, ...)
 *         Integer win;
 *         String filename;
 *         ...
 *         String cmd = {};
 *
 *      mgplot_quit(win1, win2, win3, ...)
 *         ...
 *         Integer win1, win2, win3, ...;
 *
 *      mgplot_range(win, xmin, xmax, ymin, ymax, zmin, zmax, ...)
 *        Integer win;
 *        Real xmin, xmax;
 *        ...
 *        Real ymin, ymax;
 *        Real zmin, zmax;
 *
 *      mgplot_xrange(win, min, max)
 *        Integer win;
 *        Real min, max;
 *
 *      mgplot_yrange(win, min, max)
 *        Integer win;
 *        Real min, max;
 *
 *      mgplot_zrange(win, min, max)
 *        Integer win;
 *        Real min, max;
 *
 *      mgplot_replot(win)
 *        Integer win;
 *
 *      mgplot_reset(win)
 *        Integer win;
 *
 *      mgplot_semilogx(win, X, Y, titles, cmds1, cmds2, ...)
 *        Integer win;
 *        Array X, Y;
 *        ...
 *        List titles = {};
 *        List cmds1 = {};
 *        List cmds2 = {};
 *
 *      mgplot_semilogy(win, X, Y, titles, cmds1, cmds2, ...)
 *        Integer win;
 *        Array X, Y;
 *        ...
 *        List titles = {};
 *        List cmds1 = {};
 *        List cmds2 = {};
 *
 *      mgplot_text(win, text, x, y, cmds, ...)
 *        Integer win;
 *        String text;    // if text is "", all lables are cleared
 *        Real x, y;
 *        ...
 *        String cmds = "";
 *
 *      mgplot_title(win, text)
 *        Integer win;
 *        String text;
 *
 *      mgplot_xlabel(win, text, xoff, yoff, ...)
 *        Integer win;
 *        String text;
 *        ...
 *        Integer xoff = 0;
 *        Integer yoff = 0;
 *
 *      mgplot_x2label(win, text, xoff, yoff, ...)
 *        Integer win;
 *        String text;
 *        ...
 *        Integer xoff = 0;
 *        Integer yoff = 0;
 *
 *      mgplot_ylabel(win, text, xoff, yoff, ...)
 *        Integer win;
 *        String text;
 *        ...
 *        Integer xoff = 0;
 *        Integer yoff = 0;
 *
 *      mgplot_y2label(win, text, xoff, yoff, ...)
 *        Integer win;
 *        String text;
 *        ...
 *        Integer xoff = 0;
 *        Integer yoff = 0;
 *
 *      mgplot_zlabel(win, text, xoff, yoff, ...)
 *        Integer win;
 *        String text;
 *        ...
 *        Integer xoff = 0;
 *        Integer yoff = 0;
 *
 *      mgplot_view(win, rotate_x, rotate_z, scale, scal_z)
 *        Integer win;
 *        Real rotate_x;
 *        ...
 *        Real rotate_z;
 *        Real scale;
 *        Real scale_z;
 *
 *      mgplot_view_control(win, rotate_x, rotate_z, scale, scal_z)
 *        Integer win;
 *        ...
 *        Real rotate_x;
 *        Real rotate_z;
 *        Real scale;
 *        Real scale_z;
 *
 *      mgreplot(win, X, Y, titles, cmds1, cmds2, ...)
 *        Integer win;
 *        Array X;
 *        ...
 *        Array Y;
 *        List titles = {};
 *        List cmds1 = {};
 *        List cmds2 = {};
 *
 *      mgreplot_loglog(win, X, Y, titles, cmds1, cmds2, ...)
 *        Integer win;
 *        Array X, Y;
 *        ...
 *        List titles = {};
 *        List cmds1 = {};
 *        List cmds2 = {};
 *
 *      mgreplot_semilogx(win, X, Y, titles, cmds1, cmds2, ...)
 *        Integer win;
 *        Array X, Y;
 *        ...
 *        List titles = {};
 *        List cmds1 = {};
 *        List cmds2 = {};
 *
 *      mgreplot_semilogy(win, X, Y, titles, cmds1, cmds2, ...)
 *        Integer win;
 *        Array X, Y;
 *        ...
 *        List titles = {};
 *        List cmds1 = {};
 *        List cmds2 = {};
 *
 *    DESCRIPTION
 *
 *      Example:  mgplot_options(1, "-geometry 400x300 -title afo");
 *
 */

#define MAX_WIN 100
#define MAX_FRAME 100

#define HAVE_PIPE 1
#define HAVE_LONG_FILENAME 1

#if MSVC || BCC
#undef HAVE_LONG_FILENAME
#undef HAVE_LONG_FILENAME
#endif

#ifdef DJGPP
#undef HAVE_PIPE
#undef HAVE_LONG_FILENAME
#endif

Func Integer mgplot_multiplot(win, frame, ...)
	Integer win;
	Integer frame;
{
	Integer max_win;
	static Index multiplot;

	void mgplot_datafile_remove();

//	max_win = 100;
	max_win = MAX_WIN;

	if (2 < nargs) {
		error("mgplot_multiplot(): Incorrect number of arguments\n");
	}
	
	if (length(multiplot) == 0) {
		multiplot = Z(max_win, 2);
	}

	if (nargs == 0) {
		multiplot = Z(max_win, 2);
		return 0;
	} else if (nargs == 1) {
		return multiplot(win, 1);
	} else {
		if (multiplot(win,1) != 0 && frame == 0) {
			mgplot_datafile_remove(win);
			if (mgplot_have_pipe()) {
				mgplot_out(win, "set nomultiplot;\n");
				mgplot_out(win, "set size 0.98,1.0;\n");
				mgplot_out(win, "set origin 0,0;\n");
			}
		} else if (multiplot(win,1) == 0 && 0 < frame) {
			mgplot_datafile_remove(win);
			mgplot_out(win, "set multiplot;\n");
		} else if (frame < 0) {
			return multiplot(win, 2); // max frame number */
		}
		if (multiplot(win,2) < frame || frame == 0) {
			multiplot(win,2) = frame;
		}
		multiplot(win,1) = frame;
		return multiplot(win,1);
	}
}

#if 0
Func Integer mgplot_multiplot(win, num, ...)
	Integer win;
	Integer num;
{
	Integer max_win;
	static Index multiplot;

//	max_win = 100;
	max_win = MAX_WIN;

	if (2 < nargs) {
		error("mgplot_multiplot(): Incorrect number of arguments\n");
	}
	
	if (length(multiplot) == 0) {
		multiplot = Z(1,max_win);
	}

	if (nargs == 0) {
		multiplot = Z(1,max_win);
		return 0;
	} else if (nargs == 1) {
		return multiplot(win);
	} else {
		if (multiplot(win) != 0 && num == 0 && mgplot_have_pipe()) {
			mgplot_out(win, "set nomultiplot;\n");
			mgplot_out(win, "set size 0.98,1.0;\n");
			mgplot_out(win, "set origin 0,0;\n");
		} else if (multiplot(win) == 0 && num != 0) {
			mgplot_out(win, "set multiplot;\n");
		}
		multiplot(win) = num;
		return multiplot(win);
	}
}
#endif

Func Integer mgplot_hold(win, on_off, ...)
	Integer win;
	Integer on_off;
{
	Integer max_win, id;
	static Index hold_onoff;

//	max_win = 100;
	max_win = MAX_WIN;

	if (2 < nargs) {
		error("mgplot_hold(): Incorrect number of arguments\n");
	}
	
	if (length(hold_onoff) == 0) {
		hold_onoff = Z(1,max_win);
	}

	mgplot_init(win);	// initialization

	if (mgplot_have_pipe()) {
		id = mgplot_win2id(win);
	} else if (1 <= nargs) {
		id = win;
	}

	if (nargs == 0) {
		hold_onoff = Z(1,max_win);
		return 0;
	} else if (nargs == 2) {
		if (hold_onoff(id) == 1 && on_off == 0 && mgplot_have_pipe() == 0) {
			mgplot_out(win, "plot");
		}
		hold_onoff(id) = on_off;
	}

	return hold_onoff(id);
}

Func Integer mgplot_long_filename()
{
#ifdef HAVE_LONG_FILENAME
	return 1;
#else
	return 0;
#endif
}

Func Integer mgplot_have_pipe()
{
#ifdef HAVE_PIPE
	return 1;
#else
	return 0;
#endif
}

Func Integer mgplot_running(run, ...)
	Integer run;
{
	static Integer running;
	
	if (1 < nargs) {
		error("mgplot_running(): Incorrect number of arguments");
	}
	if (nargs == 1) {
		running = 1;
		return 1;
	} else {
		return running;
	}
}

Func Integer mgplot_cur_win(win, ...)
	Integer win;
{
	static Integer current_win;
	
	if (1 < nargs) {
		error("mgplot_cur_win(): Incorrect number of arguments");
	}
	
	if (current_win == 0) {
		current_win = 1;
	}

	if (nargs == 1) {
		current_win = win;
	}

	return current_win;
}

Func Integer mgplot_data_num(id, frame, num, ...)
	Integer id;
	Integer frame;
	Integer num;
{
	Integer max_win, max_frame;
	static Index data_num;

//	max_win = 100;
//	max_frame = 100;
	max_win = MAX_WIN;
	max_frame = MAX_FRAME;

	if (3 < nargs) {
		error("mgplot_data_num(): Incorrect number of arguments");
	}

	if (length(data_num) == 0) {
		data_num = Z(max_win,max_frame);
	}
	
	if (1 <= nargs && (id < 0 || max_win < id)) {
		error("mgplot_data_num(): Incorrect id = %d", id);
	}
	if (2 <= nargs && max_frame < frame) {
		error("mgplot_data_num(): Incorrect frame = %d", frame);
	}

	if (nargs == 0) {
		data_num = Z(max_win,max_frame);
		return 0;
	} else if (nargs == 1) {
		// Only one frame
		return sum(data_num(id,:));
	} else if (nargs == 2) {
		if (frame < 0) { // Reset
			data_num(id,:) = Z(1,max_frame);
			return 0;
		} else if (frame == 0) { // Only one frame
			return data_num(id,1);
		} else {
			return data_num(id,frame);
		}
	} else {
		if (frame == 0) { // Only one frame
			data_num(id,1) = num;
		} else {
			data_num(id,frame) = num;
		}
		return num;
	}
}

Func Integer mgplot_win_ids(id, win, ...)
	Integer id;
	Integer win;
{
	Integer max_win;
	static Index win_ids;
	
//	max_win = 100;
	max_win = MAX_WIN;
	
	if (2 < nargs) {
		error("mgplot_win_ids(): Incorrect number of arguments");
	}
	
	if (length(win_ids) == 0) {
		win_ids = Z(1,max_win);
	}

	if (nargs == 0) {
		win_ids = Z(1,max_win);
		return 1;
	} else if (nargs == 1) {
		return win_ids(id);
	} else {
		win_ids(id) = win;
		return win;
	}
}

Func String mgplot_strings(win, str, ...)
	Integer win;
	String str;
{
	Integer i, max_win;
	static List strings;

//	max_win = 100;
	max_win = MAX_WIN;

	if (2 < nargs) {
		error("mgplot_strings(): Incorrect number of arguments");
	}
	
	if (length(strings) == 0) {
		strings = makelist(max_win);
	}

	if (nargs == 0) {
		strings = makelist(max_win);
		return "";
	} else if (nargs == 1) {
		if (typeof(strings,win) == Integer) {
			return "@";
		} else {
			return strings(win,String);
		}
	} else {
		strings(win) = str;
		return str;
	}
}

Func String mgplot_plot_strings(win, frame, str, ...)
	Integer win;
	Integer frame;
	String str;
{
	Integer i, max_win, max_frame;
	List frame_strings;
	static List plot_strings;

//	max_win = 100;
//	max_frame = 100;
	max_win = MAX_WIN;
	max_frame = MAX_FRAME;
	
	if (3 < nargs) {
		error("mgplot_plot_strings(): Incorrect number of arguments");
	}
	
	if (length(plot_strings) == 0) {
		plot_strings = makelist(max_frame, max_win);
	}

	if (nargs == 0) {
		plot_strings = makelist(max_frame, max_win);
		return "";
	} else if (nargs == 1) {
		plot_strings(win) = makelist(max_frame);
		return "";
	} else if (nargs == 2) {
		if (frame == 0) {
			frame = 1;
		}
		if (typeof(plot_strings, win, frame) == Integer) {
			return "";
		} else {
			return plot_strings(win,frame,String);
		}
	} else {
		if (frame == 0) {
			frame = 1;
		}
		plot_strings(win,frame) = str;
		return str;
	}
}

Func String mgplot_size_strings(win, frame, str, ...)
	Integer win;
	Integer frame;
	String str;
{
	Integer i, max_win, max_frame;
	List frame_strings;
	static List size_strings;

//	max_win = 100;
//	max_frame = 100;
	max_win = MAX_WIN;
	max_frame = MAX_FRAME;
	
	if (3 < nargs) {
		error("mgplot_size_strings(): Incorrect number of arguments");
	}
	
	if (length(size_strings) == 0) {
		size_strings = makelist(max_frame, max_win);
	}

	if (nargs == 0) {
		size_strings = makelist(max_frame, max_win);
		return "";
	} else if (nargs == 1) {
		size_strings(win) = makelist(max_frame);
		return "";
	} else if (nargs == 2) {
		if (frame == 0) {
			frame = 1;
		}
		if (typeof(size_strings, win, frame) == Integer) {
			return "";
		} else {
			return size_strings(win,frame,String);
		}
	} else {
		if (frame == 0) {
			frame = 1;
		}
		size_strings(win,frame) = str;
		return str;
	}
}

Func String mgplot_title_strings(win, frame, str, ...)
	Integer win;
	Integer frame;
	String str;
{
	Integer i, max_win, max_frame;
	List frame_strings;
	static List title_strings;

//	max_win = 100;
//	max_frame = 100;
	max_win = MAX_WIN;
	max_frame = MAX_FRAME;
	
	if (3 < nargs) {
		error("mgplot_title_strings(): Incorrect number of arguments");
	}
	
	if (length(title_strings) == 0) {
		title_strings = makelist(max_frame, max_win);
	}

	if (nargs == 0) {
		title_strings = makelist(max_frame, max_win);
		return "";
	} else if (nargs == 1) {
		title_strings(win) = makelist(max_frame);
		return "";
	} else if (nargs == 2) {
		if (frame == 0) {
			frame = 1;
		}
		if (typeof(title_strings, win, frame) == Integer) {
			return "";
		} else {
			return title_strings(win, frame, String);
		}
	} else {
		if (frame == 0) {
			frame = 1;
		}
		title_strings(win,frame) = str;
		return str;
	}
}

Func String mgplot_window_options(win, option, ...)
	Integer win;
	String option;
{
	Integer i, max_win;
	static List window_options;

//	max_win = 100;
	max_win = MAX_WIN;
	
	if (2 < nargs) {
		error("mgplot_window_options(): Incorrect number of arguments");
	}
	
	if (length(window_options) == 0) {
		window_options = makelist(max_win);
	}

	if (nargs == 0) {
		window_options = makelist(max_win);
		return "";
	} else if (nargs == 1) {
		if (typeof(window_options,win) == Integer) {
			return "";
		} else {
			return window_options(win, String);
		}
	} else {
		window_options(win) = option;
		return option;
	}
}

Func void mgplot(win, X, Y, titles, cmds1, cmds2, ...)
	Integer win;
	Array X;
	Array Y;
	List titles;
	List cmds1;
	List cmds2;
{
	Integer replotflag,frame;
	String log_mode_cmd;
	void d1_mgplot(...), d2_mgplot(...);
	
	if (nargs == 0) {
		return;
	}

	if (nargs < 2 || 6 < nargs) {
		error("mgplot(): Incorrect number of arguments.");
	}
	if (win <= 0) {
		win = 1;
	}

	mgplot_init(win);

	mgplot_cur_win(win);
	replotflag = 0;

	if ((frame = mgplot_multiplot(win))) {
		mgplot_clear(win);
	}
	
	switch (mgplot_log_mode(win,frame)) {
	  case 0:
		log_mode_cmd = "set nologscale xyz";
		break;
	  case 1:
		log_mode_cmd = sprintf("set xrange [%f:%f]; ",
							   min(X(1,:)), max(X(1,:))) +
								   "set logscale x; set nologscale yz";
		break;
	  case 2:
		log_mode_cmd = sprintf("set yrange [%f:%f]; ",
							   min(Y(1,:)), max(Y(1,:))) +
								   "set logscale y; set nologscale xz";
		break;
	  case 4:
		log_mode_cmd = sprintf("set xrange [%f:%f]; ",
					   min(X(1,:)), max(X(1,:))) +
					   sprintf("set yrange [%f:%f]; ",
					   min(Y(1,:)), max(Y(1,:))) +
					   "set logscale xy; set nologscale z";
		break;
	  default:
		error("mgplot(): Incorrect log_mode\n");
		break;
	}
	mgplot_cmd(win, log_mode_cmd);

	switch (nargs) {
	  case 2:
		d1_mgplot(win, X);
		break;
	  case 3:
		d2_mgplot(win, X, Y);
		break;
	  case 4:
		d2_mgplot(win, X, Y, titles);
		break;
	  case 5:
		d2_mgplot(win, X, Y, titles, replotflag, cmds1);
		break;
	  case 6:
		d2_mgplot(win, X, Y, titles, replotflag, cmds1, cmds2);
		break;
	}

	print "\r                      \r";
}

Func void mgreplot(win, X, Y, titles, cmds1, cmds2, ...)
	Integer win;
	Array X;
	Array Y;
	List titles;
	List cmds1;
	List cmds2;
{
	 Integer frame;
	 String log_mode_cmd;
	 void d1_mgplot(...), d2_mgplot(...);
	
	if (nargs < 1 || 6 < nargs) {
		error("mgplot(): Incorrect number of arguments.\n");
	}	

	mgplot_cur_win(win);
	
	if ((frame = mgplot_multiplot(win))) {
		mgplot_clear(win);
	}

	switch (mgplot_log_mode(win,frame)) {
	  case 0:
		log_mode_cmd = "set nologscale xyz";
		break;
	  case 1:
		log_mode_cmd = sprintf("set xrange [%f:%f]; ",
							   min(X(1,:)), max(X(1,:))) +
							   "set logscale x; set nologscale yz";
		break;
	  case 2:
		log_mode_cmd = sprintf("set yrange [%f:%f]; ",
							   min(Y(1,:)), max(Y(1,:))) +
							   "set logscale y; set nologscale xz";
		break;
	  case 4:
		log_mode_cmd = sprintf("set xrange [%f:%f]; ",
					   min(X(1,:)), max(X(1,:))) +
					   sprintf("set yrange [%f:%f]; ",
					   min(Y(1,:)), max(Y(1,:))) +
					   "set logscale xy; set nologscale z";
		break;
	  default:
		error("mgplot(): Incorrect log_mode\n");
		break;
	}
	mgplot_cmd(win, log_mode_cmd);
	
	switch (nargs)  {
	  case 1:
		mgplot_replot(win);
		break;
	  case 2:
		d1_mgplot(win, X, {}, 1);
		break;
	  case 3:
		d2_mgplot(win, X, Y, {}, 1);
		break;
	  case 4:
		d2_mgplot(win, X, Y, titles, 1);
		break;
	  case 5:
		d2_mgplot(win, X, Y, titles, 1, cmds1);
		break;
	  case 6:
		d2_mgplot(win, X, Y, titles, 1, cmds1, cmds2);
		break;
	}
}

Func void mgplot_reset(win)
	Integer win;
{
	Integer id;
	String file;
	void mgplot_reset_code();
	void mgplot_datafile_remove();

	if (win <= 0) {
		win = 1;
	}
	
	if (mgplot_isopened(win) == 0) {
		return;
	}

	mgplot_datafile_remove(win);

	if (mgplot_have_pipe() == 0) {
		file = sprintf("mgplot_%d.plt", win);
		if (access(file) == 0) {
			remove(file);
		}
		mgplot_strings(win, "");
	}

	mgplot_init(win);
	
	id = mgplot_win2id(win);
	if (id) {
		mgplot_data_num(id, -1);
	}
	mgplot_multiplot(win, 0);
	mgplot_grid(win, 0);
	mgplot_hold(win, 0);
	mgplot_key(win, 1);

	mgplot_reset_code(win);
}

Func void mgplot_reset_code(win)
	Integer win;
{
	mgplot_out(win, "set nologscale xyz;\n");
	mgplot_out(win, "set autoscale;\n");
	mgplot_out(win, "set nolabel;\n");
	mgplot_out(win, "set xlabel;\n");
	mgplot_out(win, "set ylabel;\n");
	mgplot_out(win, "set zlabel;\n");
	mgplot_out(win, "set title;\n");
	mgplot_out(win, "set zero 1e-20;\n");
	mgplot_out(win, "set data style lines;\n");
}

Func void mgplot_clear(win)
	Integer win;
{
	if (mgplot_isopened(win) == 0) {
		return;
	}

	mgplot_cmd(win, "clear");
}

Func void mgplot_replot(win)
	Integer win;
{
	Integer id;

	if (mgplot_isopened(win) == 0) {
		return;
	}

	if (mgplot_have_pipe()) {
		id = mgplot_win2id(win);
	} else {
		id = win;
	}

	if (mgplot_data_num(id) != 0 && mgplot_multiplot(win) == 0) {
		mgplot_cmd(win, "replot");
		print "\r                      \r";

		if (mgplot_have_pipe() == 0) {
			mgplot_out(win, "replot");
		}
	}
}

Func void mgplot_cmd(win, cmd)
	Integer win;
	String cmd;
{
	if (win <= 0) {
		win = 1;
	}

	mgplot_init(win);
	mgplot_out(win, cmd + ";\n");
	mgplot_cur_win(win);
}

Func void mgplot_out(win, str)
	Integer win;
	String str;
{
	Integer id;
	String file, cmd, gnuplot;

	if (mgplot_have_pipe()) {
		if (mgplot_isopened(win) == 0) {
			error("Window-%d is not opened\n", win);
		}
		fprintf(mgplot_win2id(win), "%s", str);
#ifdef DEBUG
		fprintf("mgplot.out", "%s", str);
#endif
	} else {
		if (str == "plot" || str == "replot") {
			file = sprintf("mgplot_%d.plt", win);

			if (access(file) == 0) {
				remove(file);
			}

			if ((id = fopen(file, "w")) < 0) {
				error("mgplot_out(): Can't open %s\n", file);
			}

			fprintf(id, mgplot_strings(win));
			
			if (mgplot_multiplot(win)) {
				fprintf(id, "set nomultiplot;\n");
			}				

			fprintf(id, "pause -1 \"Hit return to continue\";\n");
			fprintf(id, "quit;\n");

			fclose(id);
			if (length((gnuplot = getenv("MATXGNUPLOT"))) == 0) {
				gnuplot = "gnuplot";
			}

			system(gnuplot + " " + file);
		} else {
			mgplot_strings(win, mgplot_strings(win) + str);
		}
	}
}

Func void d1_mgplot(win, Y, titles, replotflag, cmds1_, cmds2_,  ...)
	Integer win;
	Array Y;
	List titles;
	Integer replotflag;
	List cmds1_;
	List cmds2_;
{
	Integer i, id, num, frame;
	List cmds1, cmds2;
	String datafile, str, tit, cmd1, cmd2;
	
	if (nargs < 2 || 6 < nargs) {
		error("d1_mgplot(): Incorrect number of arguments.\n");
	}
	
	if (nargs == 2) {
		titles = {};
		replotflag = 0;
		cmds1 = {};
		cmds2 = {};
	} else if (nargs == 3) {
		replotflag = 0;
		cmds1 = {};
		cmds2 = {};
	} else if (nargs == 4) {
		cmds1 = {};
		cmds2 = {};
	} else if (nargs == 5) {
		cmds1 = {};
		cmds2 = cmds1_;
	} else {
		cmds1 = cmds1_;
		cmds2 = cmds2_;
	}

	mgplot_init(win);

	if (mgplot_have_pipe()) {
		id = mgplot_win2id(win);
	} else {
		id = win;
	}

	frame = mgplot_multiplot(win);

	if (replotflag) {
		num = mgplot_data_num(id, frame);
	} else {
		num = 0;
	}

	mgplot_data_num(id, frame, num + 1);

	if (mgplot_long_filename()) {
		datafile = sprintf("mgplot-%d-w%d-f%d-l%d", PID, win, frame, num);
	} else {
		datafile = sprintf("w%df%dl%d.dat", win, frame, num);
	}

	print Y >> datafile;

	for (i = 1; i <= Rows(Y); i++) {
		if (i <= length(titles)) {
			tit = titles(i,String);
		} else {
			tit = sprintf("data-%d-%d", num+1, i);
		}

		if (i <= length(cmds1)) {
			cmd1 = cmds1(i,String);
		} else {
			cmd1 = "";
		}
		if (i <= length(cmds2)) {
			cmd2 = cmds2(i,String);
		} else {
			cmd2 = "";
		}

		str = sprintf("'%s' u 0:%d %s t '%s' %s",
					  datafile, i, cmd1, tit, cmd2);

		if (i == 1 && num == 0) {
			mgplot_plot_strings(win, frame, str);
		} else {
			mgplot_plot_strings(win, frame,
								mgplot_plot_strings(win, frame) + ", " + str);
		}
	}
	
	while (access(datafile)) {
	}

	// mgplot_out(win, "plot " + mgplot_plot_strings(win, frame) + "\n");
	str = mgplot_plot_strings(win, frame);
	// mgplot_plot_strings(win, frame, str);
	mgplot_out(win, "plot " + str  + "\n");
	
	if (mgplot_have_pipe() == 0 && mgplot_hold(win) == 0) {
		mgplot_out(win, "plot");
	}
}

Func void d2_mgplot(win, X, Y, titles, replotflag, cmds1_, cmds2_, ...)
	Integer win;
	Array X;
	Array Y;
	List titles;
	Integer replotflag;
	List cmds1_;
	List cmds2_;
{
	Integer i, m, n, id, num, frame;
	List cmds1, cmds2;
	String datafile, str, tit, cmd1, cmd2;
	
	if (nargs < 3 || 7 < nargs) {
		error("d2_mgplot(): Incorrect number of arguments.\n");
	}

	if (nargs == 3) {
		titles = {};
		replotflag = 0;
		cmds1 = {};
		cmds2 = {};
	} else if (nargs == 4) {
		replotflag = 0;
		cmds1 = {};
		cmds2 = {};
	} else if (nargs == 5) {
		cmds1 = {};
		cmds2 = {};
	} else if (nargs == 6) {
		cmds1 = {};
		cmds2 = cmds1_;
	} else {
		cmds1 = cmds1_;
		cmds2 = cmds2_;
	}

	m = Rows(X);
	n = Rows(Y);

	if (m != 1 && n != 1 && m != n) {
		error("mgplot(): Confliction of data number.\n");
	}

	mgplot_init(win);

	if (mgplot_have_pipe()) {
		id = mgplot_win2id(win);
	} else {
		id = win;
	}

	frame = mgplot_multiplot(win);

	if (replotflag) {
		num = mgplot_data_num(id, frame);
	} else {
		num = 0;
	}

	mgplot_data_num(id, frame, num + 1);

	if (mgplot_long_filename()) {
		datafile = sprintf("mgplot-%d-w%d-f%d-l%d", PID, win, frame, num);
	} else {
		datafile = sprintf("w%df%dl%d.dat", win, frame, num);
	}
	
	print [[X][Y]] >> datafile;

	for (i = 1; i <= max(m,n); i++) {
		if (i <= length(titles)) {
			tit = titles(i,String);
		} else {
			tit = sprintf("data-%d-%d", num+1, i);
		}
		if (i <= length(cmds1)) {
			cmd1 = cmds1(i,String);
		} else {
			cmd1 = "";
		}
		if (i <= length(cmds2)) {
			cmd2 = cmds2(i,String);
		} else {
			cmd2 = "";
		}

		if (m == 1) {
			str = sprintf("'%s' u 1:%d %s t '%s' %s",
						  datafile, i+1, cmd1, tit, cmd2);
		} else if (n == 1) {
  			str = sprintf("'%s' u %d:%d %s t '%s' %s",
						  datafile, i, m+1, cmd1, tit, cmd2);
		} else if (m == n) {
			str = sprintf("'%s' u %d:%d %s t '%s' %s",
						  datafile, i, m+i, cmd1, tit, cmd2);
		}

		if (i == 1 && num == 0) {
			mgplot_plot_strings(win, frame, str);
		} else {
			mgplot_plot_strings(win, frame,
								mgplot_plot_strings(win, frame) + ", " + str);
		}
	}

	while (access(datafile)) {
	}

	// mgplot_out(win, "plot " + mgplot_plot_strings(win, frame) + "\n");
	str = mgplot_plot_strings(win, frame);
	// mgplot_plot_strings(win, frame, str);
	mgplot_out(win, "plot " + str + "\n");

	if (mgplot_have_pipe() == 0 && mgplot_hold(win) == 0) {
		mgplot_out(win, "plot");
	}
}

Func Integer mgplot_newwindow()
{
	Integer i, win, max_win, num_win;
	Index wins;

	max_win = MAX_WIN;
//	max_win = 100;

	wins = Z(1,max_win);
	num_win = 0;

	for (i = 1; i <= max_win; i++) {
		win = mgplot_win_ids(i);
		if (win != 0) {
			wins(++num_win) = win;
		}
	}
	if (num_win == 0) {
		return 1;
	}

	{wins} = sort(wins(1:num_win));
	for (i = 1; i <= num_win; i++) {
		if (wins(i) != i) {
			if (i == 1) {
				return 1;
			} else {
				return wins(i-1) + 1;
			}
		}
	}
	return num_win + 1;
}

Func void mgplot_init(win, options, ...)
	Integer win;
	String options;
{
	Integer i, find, id, max_win;
	String term, disp, cmd, win_options, gnuplot;
	static String mgplot_term;

	max_win = MAX_WIN;
//	max_win = 100;

	if (nargs < 1 || 2 < nargs) {
		error("mgplot_init(): Incorrect number of arguments");
	}

	if (mgplot_running() == 0) {
		mgplot_running(1);
	}
	
	if (nargs == 1) {
		options = getenv("MGPLOT_OPTIONS");
		if (length(options)) {
			mgplot_window_options(win, options);
		}
	} else  {
		options = getenv("MGPLOT_OPTIONS") + " " + options;
		mgplot_window_options(win, options);
	}

	if (length(mgplot_term) == 0) {
		mgplot_term = getenv("MGPLOT_TERM");
		if (mgplot_term == "") {
			term = getenv("TERM");
			disp = getenv("DISPLAY");
			if (disp != "") {
				mgplot_term = "x11";
			} else if (term == "vt102") {
				mgplot_term = "kc_tek40xx";
			} else {
				mgplot_term = "windows";
			}
		}
	}

	if (mgplot_have_pipe()) {
		for (id = 1; id <= max_win; id++) {
			if (mgplot_win_ids(id) == win) {
				return;
			}
		}

#if MSVC || BCC
		gnuplot = "pgnuplot";
		// pgnuplot.exe refers MATXGNUPLOT
#else
		if (length((gnuplot = getenv("MATXGNUPLOT"))) == 0) {
			gnuplot = "gnuplot";
		}
#endif
		win_options = mgplot_window_options(win);
		if (win_options == "") {
			cmd = sprintf(gnuplot + " -geometry 380x280 -title mgplot-%d-%d",
						  win, PID);
		} else {
			cmd = sprintf(gnuplot +
						  " -geometry 380x280 -title mgplot-%d-%d %s",
						  win, PID, win_options);
		}

		id = popen(cmd);

		if (id < 0) {
			error("mgplot_init(): Can't open gnuplot\n");
		}
#if MSVC || BCC
		find = 0;
		for (i = 0; i < 20; i++) {
			if ((find = window_find("gnuplot"))) {
				break;
			}
			pause(0.1);
		}
		if (find == 0) {
			error("mgplot_init(): Can't open gnuplot\n");
		}
#endif
		mgplot_win_ids(id, win);
		mgplot_out(win, sprintf("set term %s;\n", mgplot_term));
	} else {
		if (mgplot_strings(win) != "@") {
			return;
		}
		mgplot_strings(win, "");
	}

	mgplot_reset(win);
}

Func Integer mgplot_win2id(win)
	Integer win;
{
	Integer id, max_win;

//	max_win = 100;
	max_win = MAX_WIN;

	for (id = 1; id <= max_win; id++) {
		if (mgplot_win_ids(id) == win) {
			return id;
		}
	}

	return 0;
}

Func Integer mgplot_isopened(win)
	Integer win;
{
	if (mgplot_have_pipe()) {
		return mgplot_win2id(win);
	} else {
		return mgplot_strings(win) != "@";
	}
}

Func void mgplot_destroy_all()
{
	Integer id, win, max_win;

//	max_win = 100;
	max_win = MAX_WIN;

	for (id = 1; id <= max_win; id++) {
		if (mgplot_have_pipe()) {
			win = mgplot_win_ids(id);
			if (win != 0) {
				mgplot_destroy(win);
			}
		} else {
			if (mgplot_strings(id) != "@") {
				mgplot_destroy(id);
			}
		}
	}
	mgplot_cur_win(1);
}

Func void mgplot_destroy(win)
	Integer win;
{
	Integer id, old_win;
	String file;

	void mgplot_datafile_remove();

	mgplot_datafile_remove(win);
	old_win = mgplot_cur_win();
	
	if (mgplot_have_pipe()) {
		id = mgplot_win2id(win);
		if (id) {
			mgplot_cmd(win, "quit");
			pclose(id);
		}
		mgplot_data_num(id, -1);
		mgplot_win_ids(id, 0);
	} else {
		file = sprintf("mgplot_%d.plt", win);
		if (access(file) == 0) {
			remove(file);
		}
		mgplot_strings(win, "@");
	}
	
	if (old_win == win) {
		mgplot_cur_win(1);
	} else {
		mgplot_cur_win(old_win);
	}
}

Func void mgplot_datafile_remove(win)
	Integer win;
{
	Integer i0, i, j, id, num, frame;
	String datafile;

	frame = mgplot_multiplot(win, -1);

	if (mgplot_have_pipe()) {
		id = mgplot_win2id(win);
	} else {
		id = win;
	}
	
	if (frame == 0) {
		i0 = 0;
	} else {
		i0 = 1;
	}

	for (i = i0; i <= frame; i++) {
		num = mgplot_data_num(id, i) - 1;
		for (j = 0; j <= num; j++) {
			if (mgplot_have_pipe()) {
				if (id != 0) {
					if (mgplot_long_filename()) {
						datafile = sprintf("mgplot-%d-w%d-f%d-l%d",
										   PID, win, i, j);
					} else {
						datafile = sprintf("w%df%dl%d.dat", win, i, j);
					}
					remove(datafile);
				}
			} else {
				if (mgplot_strings(win) != "@") {
					if (mgplot_long_filename()) {
						datafile = sprintf("mgplot-w%d-f%d-l%d", win, i, j);
					} else {
						datafile = sprintf("w%df%dl%d.dat", win, i, j);
					}
					remove(datafile);
				}
			}
		}
	}
}

#if 0
Func void mgplot_datafile_remove(win)
	Integer win;
{
	String datafile;

	if (mgplot_have_pipe()) {
		if (mgplot_win2id(win) != 0) {
			if (mgplot_long_filename()) {
				datafile = sprintf("mgplot-%d-w%d-f*-l*", PID, win);
			} else {
				datafile = sprintf("w%df*l*.dat", win);
			}
			system("rm -f " + datafile);
		}
	} else {
		if (mgplot_strings(win) != "@") {
			if (mgplot_long_filename()) {
				datafile = sprintf("mgplot-w%d-f*-l*", win);
			} else {
				datafile = sprintf("w%df*l*.dat", win);
			}
			system("rm " + datafile);
		}
	}
}
#endif

Func void mgplot_grid(win, on_off, ...)
	Integer win;
	Integer on_off;
{
	Integer id, max_win;
	static Index grid_onoff;

//	max_win = 100;
	max_win = MAX_WIN;
	
	if (2 < nargs) {
		error("mgplot_grid(): Incorrect number of arguments");
	}

	if (length(grid_onoff) == 0) {
		grid_onoff = Z(1,max_win);
	}

	mgplot_init(win);	// initialization
	
	if (mgplot_have_pipe()) {
		id = mgplot_win2id(win);
	} else {
		id = win;
	}

	if (nargs == 0) {
		grid_onoff = Z(1,max_win);
		return;
	} else if (nargs == 1) {
		if (grid_onoff(id) == 0) {
			mgplot_cmd(win, "set grid");
			grid_onoff(id) = 1;
		} else {
			mgplot_cmd(win, "set nogrid");
			grid_onoff(id) = 0;
		}
	} else if (nargs == 2) {
		if (on_off) {
			mgplot_cmd(win, "set grid");
		} else {
			mgplot_cmd(win, "set nogrid");
		}
		grid_onoff(id) = on_off;
	}
	
	if (mgplot_have_pipe()) {
		mgplot_replot(win);
	}
}

Func void mgplot_key(win, on_off, ...)
	Integer win;
	Integer on_off;
{
	Integer id, max_win;
	static Index key_onoff;
	
//	max_win = 100;
	max_win = MAX_WIN;
	
	if (2 < nargs) {
		error("mgplot_key(): Incorrect number of arguments.\n");
	}

	if (length(key_onoff) == 0) {
		key_onoff = ONE(1,max_win);
	}

	if (win <= 0) {
		win = 1;
	}
	
	mgplot_init(win);	// initialization
	
	if (mgplot_have_pipe()) {
		id = mgplot_win2id(win);
	} else {
		id = win;
	}

	if (nargs == 0) {
		key_onoff = ONE(1,max_win);
		return;
	} else if (nargs == 1) {
		if (key_onoff(id) == 0) {
			mgplot_cmd(win, "set key");
			key_onoff(id) = 1;
		} else {
			mgplot_cmd(win, "set nokey");
			key_onoff(id) = 0;
		}
	} else if (nargs == 2) {
		if (on_off) {
			mgplot_cmd(win, "set key");
		} else {
			mgplot_cmd(win, "set nokey");
		}
		key_onoff(id) = on_off;
	}
	
	if (mgplot_have_pipe()) {
		mgplot_replot(win);
	}
}

Func void mgplot_parametric(win, on_off, ...)
	Integer win;
	Integer on_off;
{
	Integer id, max_win;
	static Index parametric_onoff;
	
//	max_win = 100;
	max_win = MAX_WIN;
	
	if (2 < nargs) {
		error("mgplot_parametric(): Incorrect number of arguments.\n");
	}

	if (length(parametric_onoff) == 0) {
		parametric_onoff = ONE(1,max_win);
	}

	if (win <= 0) {
		win = 1;
	}
	
	mgplot_init(win);	// initialization
	
	if (mgplot_have_pipe()) {
		id = mgplot_win2id(win);
	} else {
		id = win;
	}

	if (nargs == 0) {
		parametric_onoff = ONE(1,max_win);
		return;
	} else if (nargs == 1) {
		if (parametric_onoff(id) == 0) {
			mgplot_cmd(win, "set parametric");
			parametric_onoff(id) = 1;
		} else {
			mgplot_cmd(win, "set noparametric");
			parametric_onoff(id) = 0;
		}
	} else if (nargs == 2) {
		if (on_off) {
			mgplot_cmd(win, "set parametric");
		} else {
			mgplot_cmd(win, "set noparametric");
		}
		parametric_onoff(id) = on_off;
	}
	if (mgplot_have_pipe()) {
		mgplot_replot(win);
	}
}

Func void mgplot_hidden3d(win, on_off, ...)
	Integer win;
	Integer on_off;
{
	Integer id, max_win;
	static Index hidden3d_onoff;
	
//	max_win = 100;
	max_win = MAX_WIN;
	
	if (2 < nargs) {
		error("mgplot_hidden3d(): Incorrect number of arguments.\n");
	}

	if (length(hidden3d_onoff) == 0) {
		hidden3d_onoff = ONE(1,max_win);
	}

	if (win <= 0) {
		win = 1;
	}
	
	mgplot_init(win);	// initialization
	
	if (mgplot_have_pipe()) {
		id = mgplot_win2id(win);
	} else {
		id = win;
	}

	if (nargs == 0) {
		hidden3d_onoff = ONE(1,max_win);
		return;
	} else if (nargs == 1) {
		if (hidden3d_onoff(id) == 0) {
			mgplot_cmd(win, "set hidden3d");
			hidden3d_onoff(id) = 1;
		} else {
			mgplot_cmd(win, "set nohidden3d");
			hidden3d_onoff(id) = 0;
		}
	} else if (nargs == 2) {
		if (on_off) {
			mgplot_cmd(win, "set hidden3d");
		} else {
			mgplot_cmd(win, "set nohidden3d");
		}
		hidden3d_onoff(id) = on_off;
	}
	
	if (mgplot_have_pipe()) {
		mgplot_replot(win);
	}
}

/*
 *  mode == 0 : nologscale
 *  mode == 1 : logscale x
 *  mode == 2 : logscale y
 *  mode == 3 : logscale z
 *  mode == 4 : logscale xy
 *  mode == 5 : logscale xz
 *  mode == 6 : logscale yz
 *  mode == 7 : logscale xyz
 */
Func Integer mgplot_log_mode(win, frame, mode, ...)
	 Integer win;
	 Integer frame;
	 Integer mode;
{
	 Integer max_win, max_frame;
	 static Index log_mode;

	 max_win = MAX_WIN;
	 max_frame = MAX_FRAME;

	 if (frame == 0) {
		  frame = 1;
	 }
	 
	 if (nargs < 2 || 3 < nargs ) {
		  error("mgplot_log_mode(): Incorrect number of arguments\n");
	 }
	 
	 if (length(log_mode) == 0) {
		  log_mode = Z(max_win,max_frame);
	 }

	 if (nargs == 3) {
		  log_mode(win,frame) = mode;
	 }
	 
	 return log_mode(win,frame);
}

Func void mgplot_loglog(win, X, Y, titles, cmds1_, cmds2_, ...)
	Integer win;
	Array X;
	Array Y;
	List titles;
	List cmds1_;
	List cmds2_;
{
	Index idxx, idxy;
	List cmds1, cmds2;
	
	if (nargs < 3 || 6 < nargs) {
		error("mgplot_loglog(): Incorrect number of arguments.\n");
	}
	
	if (nargs == 3) {
		titles = {};
		cmds1 = {};
		cmds2 = {};
	} else if (nargs == 4) {
		cmds1 = {};
		cmds2 = {};
	} else if (nargs == 5) {
		cmds1 = {};
		cmds2 = cmds1_;
	} else {
		cmds1 = cmds1_;
		cmds2 = cmds2_;
	}

	idxx = find(X(:,1) == 0);
	if (length(idxx) != 0) {
		X(idxx,1) = EPS*ONE(length(idxx),1);
	}

	idxy = find(Y(:,1) == 0);
	if (length(idxy) != 0) {
		Y(idxy,1) = EPS*ONE(length(idxy),1);
	}

	mgplot_grid(win, 1);
	mgplot_log_mode(win,mgplot_multiplot(win),4);
	mgplot(win, X, Y, titles, cmds1, cmds2);
	mgplot_log_mode(win,mgplot_multiplot(win),0);
}

Func void mgreplot_loglog(win, X, Y, titles, cmds1_, cmds2_, ...)
	Integer win;
	Array X;
	Array Y;
	List titles;
	List cmds1_;
	List cmds2_;
{
	Index idxx, idxy;
	List cmds1, cmds2;

	if (nargs < 3 || 6 < nargs) {
		error("mgreplot_loglog(): Incorrect number of arguments.\n");
	}

	if (nargs == 3) {
		titles = {};
		cmds1 = {};
		cmds2 = {};
	} else if (nargs == 4) {
		cmds1 = {};
		cmds2 = {};
	} else if (nargs == 5) {
		cmds1 = {};
		cmds2 = cmds1_;
	} else {
		cmds1 = cmds1_;
		cmds2 = cmds2_;
	}

	idxx = find(X(:,1) == 0);
	if (length(idxx) != 0) {
		X(idxx,1) = EPS*ONE(length(idxx),1);
	}

	idxy = find(Y(:,1) == 0);
	if (length(idxy) != 0) {
		Y(idxy,1) = EPS*ONE(length(idxy),1);
	}
	
	mgplot_grid(win, 1);
	mgplot_log_mode(win,mgplot_multiplot(win),4);
	mgreplot(win, X, Y, titles, cmds1, cmds2);
	mgplot_log_mode(win,mgplot_multiplot(win),0);
}

Func void mgplot_output_mode(win, mode)
	Integer win;
	String mode;
{
	if (mode == "ps") {
		mgplot_cmd(win, "set terminal postscript monochrome 'Times-Roman' 16");
	} else if (mode == "psplus") {
		mgplot_cmd(win, "set terminal postscript plus monochrome 'Times-Roman-Mincho' 16");
	} else if (mode == "eps") {
		mgplot_cmd(win, "set terminal postscript eps monochrome 'Times-Roman' 22");
	} else if (mode == "epsplus") {
		mgplot_cmd(win, "set terminal postscript eps plus monochrome 'Times-Roman-Mincho' 22");
	} else if (mode == "fig") {
		mgplot_cmd(win, "set terminal fig monochrome portrait fontsize 16 size 5 3");
	} else {
		error("mgplot_output_mode(): Incorrect output mode.\n");
	}
}

Func void mgplot_ps(win, filename, cmd, ...)
	Integer win;
	String filename;
	String cmd;
{
	if (nargs < 2 || 3 < nargs) {
		error("mgplot_ps(): Incorrect number of arguments.\n");
	}

	if (mgplot_multiplot(win)) {
		mgplot_cmd(win, "set nomultiplot");
	}

	mgplot_output_mode(win, "ps");

	if (nargs == 2) {
		mgplot_output_file(win, filename);
	} else {
		mgplot_output_file(win, filename, cmd);
	}
}

Func void mgplot_eps(win, filename, cmd, ...)
	Integer win;
	String filename;
	String cmd;
{
	if (nargs < 2 || 3 < nargs) {
		error("mgplot_eps(): Incorrect number of arguments.\n");
	}

	if (mgplot_multiplot(win)) {
		mgplot_cmd(win, "set nomultiplot");
	}

	mgplot_output_mode(win, "eps");

	if (nargs == 2) {
		mgplot_output_file(win, filename);
	} else {
		mgplot_output_file(win, filename, cmd);
	}
}

Func void mgplot_psplus(win, filename, cmd, ...)
	Integer win;
	String filename;
	String cmd;
{
	if (nargs < 2 || 3 < nargs) {
		error("mgplot_psplus(): Incorrect number of arguments.\n");
	}

	if (mgplot_multiplot(win)) {
		mgplot_cmd(win, "set nomultiplot");
	}

	mgplot_output_mode(win, "psplus");

	if (nargs == 2) {
		mgplot_output_file(win, filename);
	} else {
		mgplot_output_file(win, filename, cmd);
	}
}

Func void mgplot_epsplus(win, filename, cmd, ...)
	Integer win;
	String filename;
	String cmd;
{
	if (nargs < 2 || 3 < nargs) {
		error("mgplot_epsplus(): Incorrect number of arguments.\n");
	}

	if (mgplot_multiplot(win)) {
		mgplot_cmd(win, "set nomultiplot");
	}

	mgplot_output_mode(win, "epsplus");

	if (nargs == 2) {
		mgplot_output_file(win, filename);
	} else {
		mgplot_output_file(win, filename, cmd);
	}
}

Func void mgplot_fig(win, filename, cmd, ...)
	Integer win;
	String filename;
	String cmd;
{
	if (nargs < 2 || 3 < nargs) {
		error("mgplot_fig(): Incorrect number of arguments.\n");
	}

	if (mgplot_multiplot(win)) {
		mgplot_cmd(win, "set nomultiplot");
	}

	mgplot_output_mode(win, "fig");

	if (nargs == 2) {
		mgplot_output_file(win, filename);
	} else {
		mgplot_output_file(win, filename, cmd);
	}
}

Func void mgplot_psout(win, filename, cmd, ...)
	Integer win;
	String filename;
	String cmd;
{
	if (nargs < 2 || 3 < nargs) {
		error("mgplot_psout(): Incorrect number of arguments.\n");
	}

	if (mgplot_multiplot(win)) {
		mgplot_cmd(win, "set nomultiplot");
	}

	mgplot_output_mode(win, "eps");

	if (nargs == 2) {
		mgplot_output_file(win, filename);
	} else {
		mgplot_output_file(win, filename, cmd);
	}
}

Func void mgplot_figcode(win, filename, cmd, ...)
	Integer win;
	String filename;
	String cmd;
{
	if (nargs < 2 || 3 < nargs) {
		error("mgplot_figcode(): Incorrect number of arguments.\n");
	}

	if (mgplot_multiplot(win)) {
		mgplot_cmd(win, "set nomultiplot");
	}

	mgplot_output_mode(win, "fig");

	if (nargs == 2) {
		mgplot_output_file(win, filename);
	} else {
		mgplot_output_file(win, filename, cmd);
	}
}

Func void mgplot_output_file(win, filename, cmd, ...)
	Integer win;
	String filename;
	String cmd;
{
	Integer i, max_win;
	String str;

//	max_win = 100;
	max_win = MAX_WIN;

	if (nargs < 2 || 3 < nargs) {
		error("mgplot_output_file(): Incorrect number of arguments.\n");
	}

	mgplot_cmd(win, "set output '" + filename + "'");

	if (nargs == 3) {
		mgplot_cmd(win, cmd);
	}

	if (mgplot_multiplot(win)) {
		mgplot_cmd(win, "set size 1.0,1.0");
		mgplot_cmd(win, "set origin 0,0");
		mgplot_cmd(win, "set multiplot");
		for (i = 1; i <= max_win; i++) {
			str = mgplot_size_strings(win, i);
			if (length(str) > 0) {
				mgplot_out(win, str);
			}
			str = mgplot_title_strings(win, i);
			if (length(str) > 0) {
				mgplot_out(win, str);
			}
			str = mgplot_plot_strings(win, i);
			if (length(str) > 0) {
				 mgplot_out(win, "plot " + str + "\n");
				 //mgplot_out(win, str + "\n");
			}
		}
		mgplot_cmd(win, "set nomultiplot");
	} else {
		mgplot_replot(win);
	}

	// reset the window as before
	mgplot_cmd(win, "set terminal x11");
	mgplot_cmd(win, "set output");

	if (mgplot_multiplot(win)) {
		mgplot_cmd(win, "set size 0.98,1.0");
		mgplot_cmd(win, "set origin 0,0");
		mgplot_cmd(win, "set multiplot");
		for (i = 1; i <= max_win; i++) {
			str = mgplot_size_strings(win, i);
			if (length(str) > 0) {
				mgplot_out(win, str);
			}
			str = mgplot_title_strings(win, i);
			if (length(str) > 0) {
				mgplot_out(win, str);
			}
			str = mgplot_plot_strings(win, i);
			if (length(str) > 0) {
				 mgplot_out(win, "plot " + str + "\n");
				 //mgplot_out(win, str + "\n");
			}
		}
	} else {
		mgplot_replot(win);
	}
}

Func void mgplot_semilogx(win, X, Y, titles, cmds1_, cmds2_, ...)
	Integer win;
	Array X;
	Array Y;
	List titles;
	List cmds1_;
	List cmds2_;
{
	Index idx;
	List cmds1, cmds2;
	
	if (nargs < 3 || 6 < nargs) {
		error("mgplot_semilogx(): Incorrect number of arguments.\n");
	}

	if (nargs == 3) {
		titles = {};
		cmds1 = {};
		cmds2 = {};
	} else if (nargs == 4) {
		cmds1 = {};
		cmds2 = {};
	} else if (nargs == 5) {
		cmds1 = {};
		cmds2 = cmds1_;
	} else {
		cmds1 = cmds1_;
		cmds2 = cmds2_;
	}

	idx = find(X(:,1) == 0);
	if (length(idx) != 0) {
		X(idx,1) = EPS*ONE(length(idx),1);
	}

	mgplot_grid(win, 1);
	mgplot_log_mode(win,mgplot_multiplot(win),1);
	mgplot(win, X, Y, titles, cmds1, cmds2);
	mgplot_log_mode(win,mgplot_multiplot(win),0);
}

Func void mgreplot_semilogx(win, X, Y, titles, cmds1_, cmds2_, ...)
	Integer win;
	Array X;
	Array Y;
	List titles;
	List cmds1_;
	List cmds2_;
{
	Index idx;
	List cmds1, cmds2;

	if (nargs < 3 || 6 < nargs) {
		error("mgreplot_semilogx(): Incorrect number of arguments.\n");
	}

	if (nargs == 3) {
		titles = {};
		cmds1 = {};
		cmds2 = {};
	} else if (nargs == 4) {
		cmds1 = {};
		cmds2 = {};
	} else if (nargs == 5) {
		cmds1 = {};
		cmds2 = cmds1_;
	} else {
		cmds1 = cmds1_;
		cmds2 = cmds2_;
	}

	idx = find(X(:,1) == 0);
	if (length(idx) != 0) {
		X(idx,1) = EPS*ONE(length(idx),1);
	}
	
	mgplot_grid(win, 1);
	mgplot_log_mode(win,mgplot_multiplot(win),1);
	mgreplot(win, X, Y, titles, cmds1, cmds2);
	mgplot_log_mode(win,mgplot_multiplot(win),0);
}

Func void mgplot_semilogy(win, X, Y, titles, cmds1_, cmds2_, ...)
	Integer win;
	Array X;
	Array Y;
	List titles;
	List cmds1_;
	List cmds2_;
{
	Index idx;
	List cmds1, cmds2;
	
	if (nargs < 3 || 6 < nargs) {
		error("mgplot_semilogy(): Incorrect number of arguments.\n");
	}
	
	if (nargs == 3) {
		titles = {};
		cmds1 = {};
		cmds2 = {};
	} else if (nargs == 4) {
		cmds1 = {};
		cmds2 = {};
	} else if (nargs == 5) {
		cmds1 = {};
		cmds2 = cmds1_;
	} else {
		cmds1 = cmds1_;
		cmds2 = cmds2_;
	}

	idx = find(Y(:,1) == 0);
	if (length(idx) != 0) {
		Y(idx,1) = EPS*ONE(length(idx),1);
	}

	mgplot_grid(win, 1);
	mgplot_log_mode(win,mgplot_multiplot(win),2);
	mgplot(win, X, Y, titles, cmds1, cmds2);
	mgplot_log_mode(win,mgplot_multiplot(win),0);
}

Func void mgreplot_semilogy(win, X, Y, titles, cmds1_, cmds2_, ...)
	Integer win;
	Array X;
	Array Y;
	List titles;
	List cmds1_;
	List cmds2_;
{
	Index idx;
	List cmds1, cmds2;

	if (nargs < 3 || 6 < nargs) {
		error("mgreplot_semilogy(): Incorrect number of arguments.\n");
	}

	if (nargs == 3) {
		titles = {};
		cmds1 = {};
		cmds2 = {};
	} else if (nargs == 4) {
		cmds1 = {};
		cmds2 = {};
	} else if (nargs == 5) {
		cmds1 = {};
		cmds2 = cmds1_;
	} else {
		cmds1 = cmds1_;
		cmds2 = cmds2_;
	}

	idx = find(Y(:,1) == 0);
	if (length(idx) != 0) {
		Y(idx,1) = EPS*ONE(length(idx),1);
	}
	
	mgplot_grid(win, 1);
	mgplot_log_mode(win,mgplot_multiplot(win),2);
	mgreplot(win, X, Y, titles, cmds1, cmds2);
	mgplot_log_mode(win,mgplot_multiplot(win),0);
}

Func void mgplot_text(win, text, x, y, cmds, ...)
	Integer win;
	String text;
	Real x;
	Real y;
	String cmds;
{
	Integer frame;
	String str;

	if (nargs < 4 || 5 < nargs) {
		error("mgplot_text(): Incorrect number of arguments.\n");
	}
	
	if (text == "") {
		str = "set nolabel";
	} else if (nargs == 4) {
		str = sprintf("set label '%s' at %g,%g", text, x, y);
	} else if (nargs == 5) {
		str = sprintf("set label '%s' at %g,%g, %s", text,x,y,cmds);
	}

	mgplot_cmd(win, str);

	frame = mgplot_multiplot(win);
	if (frame) {
		str = mgplot_size_strings(win, frame) + str + "\n";
		mgplot_size_strings(win, frame, str);
	}
	
	if (mgplot_have_pipe()) {
		mgplot_replot(win);
	}
}

Func void mgplot_title(win, text)
	Integer win;
	String text;
{
	Integer frame;
	String str;

	str = sprintf("set title '%s'", text);

	mgplot_cmd(win, str);
	
	frame = mgplot_multiplot(win);
	if (frame) {
		mgplot_title_strings(win, frame, str + "\n");
	}

	if (mgplot_have_pipe()) {
		mgplot_replot(win);
	}
}

Func void mgplot_xlabel(win, text, xoff, yoff, ...)
	Integer win;
	String text;
	Integer xoff;
	Integer yoff;
{
	Integer frame;
	String str;

	if (nargs < 2 || 4 < nargs) {
		error("mgplot_xlabel(): Incorrect number of arguments\n");
	}
	
	if (nargs == 2) {
		str = sprintf("set xlabel '%s'", text);
	} else if (nargs == 3) {
		str = sprintf("set xlabel '%s' %d", text, xoff);
	} else {
		str = sprintf("set xlabel '%s' %d,%d", text, xoff, yoff);
	}	

	mgplot_cmd(win, str);

	frame = mgplot_multiplot(win);
	if (frame) {
		str = mgplot_size_strings(win, frame) + str + "\n";
		mgplot_size_strings(win, frame, str);
	}

	if (mgplot_have_pipe()) {
		mgplot_replot(win);
	}
}

Func void mgplot_x2label(win, text, xoff, yoff, ...)
	Integer win;
	String text;
	Integer xoff;
	Integer yoff;
{
	Integer frame;
	String str;

	if (nargs < 2 || 4 < nargs) {
		error("mgplot_x2label(): Incorrect number of arguments\n");
	}
	
	if (nargs == 2) {
		str = sprintf("set x2label '%s'", text);
	} else if (nargs == 3) {
		str = sprintf("set x2label '%s' %d", text, xoff);
	} else {
		str = sprintf("set x2label '%s' %d,%d", text, xoff, yoff);
	}	

	mgplot_cmd(win, str);

	frame = mgplot_multiplot(win);
	if (frame) {
		str = mgplot_size_strings(win, frame) + str + "\n";
		mgplot_size_strings(win, frame, str);
	}

	if (mgplot_have_pipe()) {
		mgplot_replot(win);
	}
}


Func void mgplot_ylabel(win, text, xoff, yoff, ...)
	Integer win;
	String text;
	Integer xoff;
	Integer yoff;
{
	Integer frame;
	String str;

	if (nargs < 2 || 4 < nargs) {
		error("mgplot_ylabel(): Incorrect number of arguments\n");
	}

	if (nargs == 2) {
		str = sprintf("set ylabel '%s'", text);
	} else if (nargs == 3) {
		str = sprintf("set ylabel '%s' %d", text, xoff);
	} else {
		str = sprintf("set ylabel '%s' %d,%d", text, xoff, yoff);
	}	

	mgplot_cmd(win, str);

	frame = mgplot_multiplot(win);
	if (frame) {
		str = mgplot_size_strings(win, frame) + str + "\n";
		mgplot_size_strings(win, frame, str);
	}
	
	if (mgplot_have_pipe()) {
		mgplot_replot(win);
	}
}

Func void mgplot_y2label(win, text, xoff, yoff, ...)
	Integer win;
	String text;
	Integer xoff;
	Integer yoff;
{
	Integer frame;
	String str;

	if (nargs < 2 || 4 < nargs) {
		error("mgplot_y2label(): Incorrect number of arguments\n");
	}

	if (nargs == 2) {
		str = sprintf("set y2label '%s'", text);
	} else if (nargs == 3) {
		str = sprintf("set y2label '%s' %d", text, xoff);
	} else {
		str = sprintf("set y2label '%s' %d,%d", text, xoff, yoff);
	}	

	mgplot_cmd(win, str);

	frame = mgplot_multiplot(win);
	if (frame) {
		str = mgplot_size_strings(win, frame) + str + "\n";
		mgplot_size_strings(win, frame, str);
	}
	
	if (mgplot_have_pipe()) {
		mgplot_replot(win);
	}
}

Func void mgplot_zlabel(win, text, xoff, yoff, ...)
	Integer win;
	String text;
	Integer xoff;
	Integer yoff;
{
	Integer frame;
	String str;

	if (nargs < 2 || 4 < nargs) {
		error("mgplot_zlabel(): Incorrect number of arguments\n");
	}

	if (nargs == 2) {
		str = sprintf("set zlabel '%s'", text);
	} else if (nargs == 3) {
		str = sprintf("set zlabel '%s' %d", text, xoff);
	} else {
		str = sprintf("set zlabel '%s' %d,%d", text, xoff, yoff);
	}	

	mgplot_cmd(win, str);

	frame = mgplot_multiplot(win);
	if (frame) {
		str = mgplot_size_strings(win, frame) + str + "\n";
		mgplot_size_strings(win, frame, str);
	}
	
	if (mgplot_have_pipe()) {
		mgplot_replot(win);
	}
}

Func void mgplot_view(win, rotate_x, rotate_z, scale, scale_z, ...)
	 Integer win;
	 Real rotate_x;
	 Real rotate_z;
	 Real scale;
	 Real scale_z;
{
	Integer frame;
	String str;

	if (nargs == 1) {
		 mgplot_view_control(win);
		 return;
	}

	if (nargs < 2 || 5 < nargs) {
		error("mgplot_view(): Incorrect number of arguments\n");
	}

	if (nargs == 2) {
		str = sprintf("set view %g", rotate_x);
	} else if (nargs == 3) {
		str = sprintf("set view %g,%g", rotate_x, rotate_z);
	} else if (nargs == 4) {
		str = sprintf("set view %g,%g,%g", rotate_x, rotate_z, scale);
	} else { 
		str = sprintf("set view %g,%g,%g,%g", rotate_x,rotate_z,scale,scale_z);
	}	

	mgplot_cmd(win, str);

	frame = mgplot_multiplot(win);
	if (frame) {
		str = mgplot_size_strings(win, frame) + str + "\n";
		mgplot_size_strings(win, frame, str);
	}
	
	if (mgplot_have_pipe()) {
		mgplot_replot(win);
	}
}

Func List mgplot_view_control(win, rotate_x, rotate_z, scale, scale_z, ...)
	 Integer win;
	 Real rotate_x;
	 Real rotate_z;
	 Real scale;
	 Real scale_z;
{
	 Integer end_flag;
	 String str;

	 if (nargs < 1 || 5 < nargs) {
		  error("mgplot_view_control(): Incorrect number of arguments\n");
	 }

	 if (nargs < 2) {
		  rotate_x = 60;
	 }
	 if (nargs < 3) {
		  rotate_z = 30;
	 }
	 if (nargs < 4) {
		  scale = 1;
	 }
	 if (nargs < 5) {
		  scale_z = 1;
	 }

	 end_flag = 0;

	 clear;

	 gotoxy(1,2);
	 printf(" 'q' or 'ESC' for quit");
	 gotoxy(1, 3);
	 printf(" ------------------------------------------------------------------");
	 gotoxy(1, 4);
	 printf(" | j  <--->  k    | h  <--->  l    |  -  <--->  +  |  <  <--->  > |");
	 gotoxy(1, 5);
	 printf(" |----------------+----------------+---------------+--------------|");
	 gotoxy(1, 6);
	 printf(" | rotate_x = %3g | rotate_z = %3g | scale  = %2g   | scale_z = %2g |",
			rotate_x, rotate_z, scale, scale_z);
	 gotoxy(1, 7);
	 printf(" ------------------------------------------------------------------");
	 gotoxy(1,6);

	 do {
		  switch (getch()) {
		/* 'Q' */  case 0x51:
		/* 'q' */  case 0x71:
		/* ESC */  case 0x1b: // quit
				end_flag = 1;
				break;
		/* 'H' */  case 0x48: // rotate negative z-direction
			 rotate_z = rotate_z + 5;
			 break;
		/* 'h' */  case 0x68:
			 rotate_z = rotate_z + 1;
				break;
		/* 'L' */  case 0x4c: // rotate positive z-direction
			 rotate_z = rotate_z - 5;
				break;
		/* 'l' */  case 0x6c:
			 rotate_z = rotate_z - 1;
				break;
		/* 'J' */  case 0x4a: // rotate positive x-direction
			 rotate_x = rotate_x - 5;
				break;
		/* 'j' */  case 0x6a:
			 rotate_x = rotate_x - 1;
				break;
		/* 'K' */  case 0x4b: // rotate negative x-direction
			 rotate_x = rotate_x + 5;
				break;
		/* 'k' */  case 0x6b:
			 rotate_x = rotate_x + 1;
				break;
		/* '-' */  case 0x2d:
			 scale = scale - 0.1;
				break;
		/* '+' */  case 0x2b:
			 scale = scale + 0.1;
				break;
		/* '<' */  case 0x3c:
			 scale_z = scale_z - 0.1;
				break;
		/* '>' */  case 0x3e:
			 scale_z = scale_z + 0.1;
				break;
			  default:
				break;
			}

		  str = sprintf("set view %g,%g,%g,%g",
						rotate_x,rotate_z,scale,scale_z);
		  
		  mgplot_cmd(win, str);
		  
		  if (mgplot_have_pipe()) {
			   mgplot_replot(win);
		  }

	 printf(" | rotate_x = %3g | rotate_z = %3g | scale  = %2g   | scale_z = %2g |\r",
			rotate_x, rotate_z, scale, scale_z);
	 } while ( ! end_flag);  // If end_flag != 0, END

	 gotoxy(1,8);

	 return {rotate_x, rotate_z, scale, scale_z};
}

Func void mgplot_range(win, xmin, xmax, ymin, ymax, zmin, zmax, ...)
	Integer win;
	Real xmin, xmax, ymin, ymax, zmin, zmax;
{
	Integer frame;
	String str;

	if (nargs < 3 || 7 < nargs) {
		error("mgplot_range(): Incorrect number of arguments.\n");
	}

	if (3 <= nargs) {
		str = sprintf("set xrange [%f:%f]", xmin, xmax);
	}
	if (5 <= nargs) {
		str = str + "\n" + sprintf("set yrange [%f:%f]", ymin, ymax);
	}
	if (7 == nargs) {
		str = str + "\n" + sprintf("set zrange [%f:%f]", zmin, zmax);
	}

	mgplot_cmd(win, str);

	frame = mgplot_multiplot(win);
	if (frame) {
		str = mgplot_size_strings(win, frame) + str + "\n";
		mgplot_size_strings(win, frame, str);
	}
	
	if (mgplot_have_pipe()) {
		mgplot_replot(win);
	}
}

Func void mgplot_xrange(win, min, max)
	Integer win;
	Real min, max;
{
	Integer frame;
	String str;

	str = sprintf("set xrange [%f:%f]", min, max);

	mgplot_cmd(win, str);

	frame = mgplot_multiplot(win);
	if (frame) {
		str = mgplot_size_strings(win, frame) + str + "\n";
		mgplot_size_strings(win, frame, str);
	}
	
	if (mgplot_have_pipe()) {
		mgplot_replot(win);
	}
}

Func void mgplot_yrange(win, min, max)
	Integer win;
	Real min, max;
{
	Integer frame;
	String str;

	str = sprintf("set yrange [%f:%f]", min, max);

	mgplot_cmd(win, str);

	frame = mgplot_multiplot(win);
	if (frame) {
		str = mgplot_size_strings(win, frame) + str + "\n";
		mgplot_size_strings(win, frame, str);
	}
	
	if (mgplot_have_pipe()) {
		mgplot_replot(win);
	}
}

Func void mgplot_zrange(win, min, max)
	Integer win;
	Real min, max;
{
	Integer frame;
	String str;

	str = sprintf("set zrange [%f:%f]", min, max);

	mgplot_cmd(win, str);

	frame = mgplot_multiplot(win);
	if (frame) {
		str = mgplot_size_strings(win, frame) + str + "\n";
		mgplot_size_strings(win, frame, str);
	}
	
	if (mgplot_have_pipe()) {
		mgplot_replot(win);
	}
}

Func void mgplot_quit(win1, win2, win3, win4, win5, ...)
	Integer win1, win2, win3, win4, win5;
{
	if (mgplot_running() == 0) {
		return;
	}
	
	if (nargs == 0) {
		mgplot_destroy_all();
	} else if (nargs == 1) {
		mgplot_destroy(win1);
	} else if (nargs == 2) {
		mgplot_destroy(win1);
		mgplot_destroy(win2);
	} else if (nargs == 3) {
		mgplot_destroy(win1);
		mgplot_destroy(win2);
		mgplot_destroy(win3);
	} else if (nargs == 4) {
		mgplot_destroy(win1);
		mgplot_destroy(win2);
		mgplot_destroy(win3);
		mgplot_destroy(win4);
	} else if (nargs == 5) {
		mgplot_destroy(win1);
		mgplot_destroy(win2);
		mgplot_destroy(win3);
		mgplot_destroy(win4);
		mgplot_destroy(win5);
	} else {
		error("mgplot_quit(): Incorrect number of arguments.\n");
	}

	mgplot_running(0);
}

Func void mgplot_options(win, options)
	Integer win;
	String options;
{
	void mgplot_init(...);

	mgplot_init(win, options);
}

Func void mgplot_subplot(win, rows, cols, frame, ...)
	Integer win, rows, cols, frame;
{
	Integer x, y;
	Real xorg, yorg;
	Real xsize, ysize;
	String mess;

	void mgplot_reset_code();
	
	if (nargs < 3 || 4 < nargs) {
		error("mgplot_subplot(): Incorrect number of arguments\n");
	}
	
	if (nargs == 3) {
		frame = 1;
	}
	
	if (cols < 0) {
		error("mgplot_subplot(): Number of columns must be positive\n");
	}
	if (rows < 0) {
		error("mgplot_subplot(): Number of rows must be positive\n");
	}
	if (frame < 0 || cols*rows < frame) {
		mess = sprintf("Number must be between 1 and %d\n", rows*cols);
		error("mgplot_subplot(): " + mess);
	}

	mgplot_init(win);	// initialization

	if (rows == 1 && cols == 1) {
		if (mgplot_multiplot(win)) {
			if (mgplot_have_pipe()) {
				mgplot_multiplot(win, 0);
				mgplot_cmd(win, "set size 0.98,1.0");
				mgplot_cmd(win, "set origin 0,0");
			} else {
				mgplot_strings(win, "");
				mgplot_reset_code(win);
			}
			mgplot_plot_strings(win);
			mgplot_size_strings(win);
			mgplot_title_strings(win);
		}
		return;
	} else {
		if (mgplot_have_pipe() == 0 && mgplot_multiplot(win) == 0) {
			mgplot_strings(win, "");
			mgplot_reset_code(win);
		}
		if (mgplot_multiplot(win) == 0) {
			mgplot_plot_strings(win);
		}
	}
	
	xsize = 1.0/cols;
	ysize = 1.0/rows;
	
	y = (frame - 1)/cols;
	x = frame - 1 - y*cols;
	xorg = xsize*x;
	yorg = ysize*(rows-1-y);

	if (mgplot_multiplot(win) != frame) {
		mgplot_multiplot(win, frame);
	}
	mgplot_cmd(win, sprintf("set size %g,%g", 0.98*xsize, ysize));
	mgplot_cmd(win, sprintf("set origin %g,%g", xorg, yorg));

	mgplot_size_strings(win, frame,
						sprintf("set size %g,%g\n", 0.98*xsize, ysize)
						+ sprintf("set origin %g,%g\n", xorg, yorg));
}
