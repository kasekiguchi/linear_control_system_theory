
void *rtSetTask(void (*new_task)(void));
void *rtSetBreak(void (*new_task)(void));
void *rtResetTask(void);
double rtSetClock(double stime_sec);
void rtStart(void);
void rtStop(void);
void rtOnceTry(void);
int rtIsTimeOut(void);
int rtIsOnLine(void);
int rtIsRunning(void);
int rtIsRehearsal(void);
void rtStartRehearsal(void);
void rtStopRehearsal(void);


#if MSVC || BCC
void rtInitializeCriticalSection(void);
void rtDeleteCriticalSection(void);
void rtEnterCriticalSection(int class);
void rtLeaveCriticalSection(int class);
#endif

#if BCC
void outp(unsigned short iPort, unsigned short iDatum);
void outpw(unsigned short iPort, unsigned short iDatum);
unsigned int inp(unsigned short iPort);
unsigned int inpw(unsigned short iPort);
#endif
