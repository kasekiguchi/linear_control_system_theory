
/*
 *
 * Copyright (C) 2000 Masanobu Koga
 *            All Rights Reserved.
 *
 * No part of this software may be used, copied, modified, and distributed
 * in any form or by any means, electronic, mechanical, manual, optical or
 * otherwise, without prior permission of Masanobu Koga.
 *
 */

/*
  mxstype.h : 

  $Author: koga $
  $Revision: 1.1 $
  $Date: 2000/11/23 03:57:32 $
  $Log: mxstype.h,v $
  Revision 1.1  2000/11/23 03:57:32  koga
  Initial revision

*/

#ifndef mxstype_header
#define mxstype_header

#undef STRING
#undef INTEGER
#undef REAL
#undef COMPLEX
#undef POLYNOMIAL
#undef RATIONAL
#undef MATRIX
#undef ARRAY
#undef INDEX
#undef LIST

#define STRING		((int)MXS_STRING)
#define INTEGER		((int)MXS_INTEGER)
#define REAL  		((int)MXS_REAL)
#define COMPLEX		((int)MXS_COMPLEX)
#define POLYNOMIAL	((int)MXS_POLYNOMIAL)
#define RATIONAL  	((int)MXS_RATIONAL)
#define MATRIX		((int)MXS_MATRIX)
#define ARRAY 		((int)MXS_ARRAY)
#define INDEX 		((int)MXS_INDEX)
#define LIST  		((int)MXS_LIST)

#endif
