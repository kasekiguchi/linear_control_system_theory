Matrix	P_MatDef(char *name, int m, int n);
Matrix	P_MatNonNameDef(int m, int n);
Matrix	P_MatSameDef(Matrix a);
Matrix	P_MatTransDef(Matrix a);
Matrix	P_MatMulDef(Matrix a, Matrix b);
Matrix	P_MatIDef(int n);
Matrix	P_MatIDef2(int m, int n);
Matrix	P_MatOneDef(int m, int n);
Matrix	P_MatSameSizeFillDef(Matrix a, Polynomial p);
Matrix	P_MatFillDef(int m, int n, Polynomial p);
Matrix	P_MatZDef(int n);
Matrix	P_MatZDef2(int m, int n);
#ifdef HAVE_STDARG
Matrix	P_MatDiagDef(int n, ...);
#else
Matrix	P_MatDiagDef();
#endif
#ifdef HAVE_STDARG
Matrix	P_MatVander(int n, ...);
#else
Matrix	P_MatVander();
#endif

Matrix	P_MatCopy(Matrix b, Matrix a);
Matrix	P_MatEdit(Matrix a);
Matrix	P_MatInput(char *name);
Matrix	P_MatSetValue(Matrix	a, int row, int column, Polynomial p);
Matrix	P_MatFillValue(Matrix a, Polynomial p);
Matrix	P_MatSetVecValue(Matrix a, int number, Polynomial p);
Matrix	P_MatSetVar(Matrix a, char *var);
Matrix	P_Mat_ChangeColumn(Matrix a, int i, int j);
Matrix	P_Mat_ChangeRow(Matrix a, int i, int j);
void	P_MatSwap(Matrix b, Matrix a);

Polynomial P_MatDeterm(Matrix a);
Polynomial P_MatScalarProduct(Matrix a, Matrix b);
Polynomial P_MatTrace(Matrix a);
Polynomial P_MatSumElem(Matrix a);
Polynomial P_MatMeanElem(Matrix a);
Polynomial P_MatProdElem(Matrix a);

Polynomial P_MatGetValue(Matrix a, int row, int column);
Polynomial P_MatGetValueOne(Matrix a, int row, int column);
Polynomial P_MatGetPtr(Matrix a, int row, int column);
Polynomial P_MatGetVecValue(Matrix a, int number);
Polynomial P_MatGetVecPtr(Matrix a, int number);

void	P_Mat_Print(Matrix a);

Matrix	P_MatRealPart(Matrix a);
Matrix	P_MatImagPart(Matrix a);
#ifdef HAVE_STDARG
Matrix	P_MatColumnVec(int n, ...);
Matrix	P_MatRowVec(int n, ...);
#else
Matrix	P_MatColumnVec();
Matrix	P_MatRowVec();
#endif

Matrix	P_Mat_Add(Matrix c, Matrix a, Matrix b);
Matrix	P_Mat_Add_double(Matrix c, Matrix a, double sc);
Matrix	P_Mat_Add_Complex(Matrix c, Matrix a, Complex sc);
Matrix	P_Mat_Add_Polynomial(Matrix c, Matrix a, Polynomial sc);
Matrix	P_Mat_Sub(Matrix c, Matrix a, Matrix b);
Matrix	P_Mat_Sub_double(Matrix c, Matrix a, double sc, int flag);
Matrix	P_Mat_Sub_Complex(Matrix c, Matrix a, Complex sc, int flag);
Matrix	P_Mat_Sub_Polynomial(Matrix c, Matrix a, Polynomial sc, int flag);
Matrix	P_Mat_Mul(Matrix c, Matrix a, Matrix b);
Matrix	P_Mat_MulElem(Matrix c, Matrix a, Matrix b);
Matrix	P_Mat_DivElem(Matrix c, Matrix a, Matrix b);
Matrix	P_Mat_InvElem(Matrix b, Matrix a);
Matrix	P_Mat_Trans(Matrix b, Matrix a);
Matrix	P_Mat_FlipLR(Matrix b, Matrix a);
Matrix	P_Mat_FlipUD(Matrix b, Matrix a);
Matrix	P_Mat_ShiftLeft(Matrix b, Matrix a, int m);
Matrix	P_Mat_ShiftRight(Matrix b, Matrix a, int m);
Matrix	P_Mat_ShiftUp(Matrix b, Matrix a, int m);
Matrix	P_Mat_ShiftDown(Matrix b, Matrix a, int m);
Matrix	P_Mat_RotateLeft(Matrix b, Matrix a, int m);
Matrix	P_Mat_RotateRight(Matrix b, Matrix a, int m);
Matrix	P_Mat_RotateUp(Matrix b, Matrix a, int m);
Matrix	P_Mat_RotateDown(Matrix b, Matrix a, int m);
Matrix	P_Mat_Negate(Matrix b, Matrix a);
Matrix	P_Mat_SetZero(Matrix a);
Matrix	P_Mat_RoundToZero(Matrix b, Matrix a, double tol);
Matrix	P_Mat_Conj(Matrix b, Matrix a);
Matrix	P_Mat_ConjTrans(Matrix b, Matrix a);
Matrix	P_Mat_Pow(Matrix b, Matrix a, int m);
Matrix	P_Mat_PowElem(Matrix b, Matrix a, int m);
Matrix	P_Mat_PowElemEach(Matrix c, Matrix a, Matrix b);
Matrix	P_Mat_CompareElem(Matrix c, Matrix a, Matrix b, char *opt);
Matrix	P_Mat_Scale(Matrix b, Matrix a, double scale);
Matrix	P_Mat_ScaleSelf(Matrix a, double scale);
Matrix	P_Mat_ScaleC(Matrix b, Matrix a, Complex scale);
Matrix	P_Mat_ScaleP(Matrix b, Matrix a, Polynomial scale);
Matrix	P_Mat_ScaleR(Matrix b, Matrix a, Rational scale);
Matrix	P_Mat_Eval(Matrix b, Matrix a, double dd);
Matrix	P_Mat_EvalC(Matrix b, Matrix a, Complex c);
Matrix	P_Mat_EvalP(Matrix b, Matrix a, Polynomial p);
Matrix	P_Mat_EvalR(Matrix b, Matrix a, Rational r);
Matrix	P_Mat_EvalM(Matrix c, Matrix a, Matrix b);
Matrix	P_Mat_EvalMElem(Matrix c, Matrix a, Matrix b);
Matrix	P_Mat_Apply(Matrix b, Matrix a, Polynomial (*func)(Polynomial aa));
Matrix	P_Mat_ApplyPolyFunc(Matrix b, Matrix a, Polynomial poly);
Matrix	P_Mat_ApplyRatFunc(Matrix b, Matrix a, Rational rat);
Matrix	P_Mat_Put(Matrix a, int sr, int sc, Matrix b);
Matrix	P_Mat_Cut(Matrix b, Matrix a, int sr, int sc, int er, int ec);
Matrix  P_Mat_GetSubMatrix(Matrix a, Matrix rows, Matrix columns, Matrix c);
Matrix  P_Mat_GetVecSubMatrix(Matrix a, Matrix cols, Matrix c);
Matrix	P_Mat_SetSubMatrix(Matrix a, Matrix rows, Matrix columns, Matrix c);
Matrix	P_Mat_SetVecSubMatrix(Matrix a, Matrix cols, Matrix c);
Matrix  P_Mat_GetBlockSubMatrix(Matrix a, Matrix rows, Matrix columns,
								int pr, int pc, Matrix c);
Matrix	P_Mat_SetBlockSubMatrix(Matrix a, Matrix rows, Matrix columns,
								int pr, int pc, Matrix c);
Matrix	P_Mat_AreaCopy(Matrix a, int ar, int ac,
					   Matrix b, int br1, int bc1, int br2, int bc2);
Matrix	P_Mat_RealPart(Matrix b, Matrix a);
Matrix	P_Mat_ImagPart(Matrix b, Matrix a);
Matrix	P_Mat_RealAndImag(Matrix c, Matrix a, Matrix b);
Matrix	P_Mat_RealToComp(Matrix b, Matrix a);
Matrix	P_Mat_RealToPoly(Matrix b, Matrix a);
Matrix	P_Mat_CompToPoly(Matrix b, Matrix a);
Matrix	P_Mat_CatColumn(Matrix c, Matrix a, Matrix b);
Matrix	P_Mat_CatRow(Matrix c, Matrix a, Matrix b);
Matrix	P_Mat_VectorProduct(Matrix c, Matrix a, Matrix b);
Matrix	P_Mat_VectorSquare(Matrix c, Matrix a);
Matrix	P_Mat_Derivative(Matrix c, Matrix a, int m);
Matrix	P_Mat_Integral(Matrix c, Matrix a, int m);
Matrix	P_Mat_LowerShift(Matrix c, Matrix a, int m);
Matrix	P_Mat_HigherShift(Matrix c, Matrix a, int m);
Matrix	P_Mat_Sum(Matrix b, Matrix a);
Matrix	P_Mat_Mean(Matrix b, Matrix a);
Matrix	P_Mat_CumSum(Matrix b, Matrix a);
Matrix	P_Mat_CumSumElem(Matrix b, Matrix a);
Matrix	P_Mat_CumProd(Matrix b, Matrix a);
Matrix	P_Mat_CumProdElem(Matrix b, Matrix a);
Matrix	P_Mat_Prod(Matrix b, Matrix a);
