Matrix	C_MatDef(char *name, int m, int n);
Matrix	C_MatNonNameDef(int m, int n);
Matrix	C_MatSameDef(Matrix a);
Matrix	C_MatTransDef(Matrix a);
Matrix	C_MatMulDef(Matrix a, Matrix b);
Matrix	C_MatIDef(int n);
Matrix	C_MatIDef2(int m, int n);
Matrix	C_MatOneDef(int m, int n);
Matrix	C_MatSameSizeFillDef(Matrix a, Complex c);
Matrix	C_MatFillDef(int m, int n, Complex c);
Matrix	C_MatZDef(int n);
Matrix	C_MatZDef2(int m, int n);
#ifdef HAVE_STDARG
Matrix	C_MatDiagDef(int n, ...);
#else
Matrix	C_MatDiagDef();
#endif
Matrix	C_MatNormalRand(int m, int n);
Matrix	C_MatUniformRand(int m, int n);
Matrix	C_Mat_HouseVector(Matrix x, int n);
#ifdef HAVE_STDARG
Matrix	C_MatVander(int n, ...);
#else
Matrix	C_MatVander();
#endif

Matrix	C_MatCopy(Matrix b, Matrix a);
Matrix	C_MatSetValue(Matrix a, int row, int column, Complex c);
Matrix	C_MatFillValue(Matrix a, Complex c);
Matrix	C_MatSetVecValue(Matrix a, int number, Complex c);
Complex	C_MatDeterm(Matrix a);
Complex	C_MatScalarProduct(Matrix a, Matrix b);
Complex	C_MatTrace(Matrix a);
Complex	C_MatMaxElem(Matrix a);
Complex	C_MatMinElem(Matrix a);
Complex	C_MatMaximumElem(Matrix a, int *ii, int *jj);
Complex	C_MatMinimumElem(Matrix a, int *ii, int *jj);
Complex	C_MatSumElem(Matrix a);
Complex	C_MatProdElem(Matrix a);
Complex	C_MatMeanElem(Matrix a);
double	C_MatStdDevElem(Matrix a);

Complex		 C_MatGetValue(Matrix a, int row, int column);
Complex		 C_MatGetValueOne(Matrix a, int row, int column);
Complex		 C_MatGetVecValue(Matrix a, int number);
ComplexValue C_MatGetPtr(Matrix	a, int row, int column);
ComplexValue C_MatGetVecPtr(Matrix a, int number);

void	C_Mat_Print(Matrix a);
void	C_MatSwap(Matrix b, Matrix a);
Matrix	C_Mat_ChangeColumn(Matrix a, int i, int j);
Matrix	C_Mat_ChangeRow(Matrix a, int i, int j);

Matrix	C_MatRealPart(Matrix a);
Matrix	C_MatImagPart(Matrix a);
#ifdef HAVE_STDARG
Matrix	C_MatColumnVec(int n, ...);
Matrix	C_MatRowVec(int n, ...);
#else
Matrix	C_MatColumnVec();
Matrix	C_MatRowVec();
#endif

Matrix	C_Mat_Add(Matrix c, Matrix a, Matrix b);
Matrix	C_Mat_Add_double(Matrix c, Matrix a, double sc);
Matrix	C_Mat_Add_Complex(Matrix c, Matrix a, Complex sc);
Matrix	C_Mat_AddSelf(Matrix a, Matrix b);
Matrix	C_Mat_Sub(Matrix c, Matrix a, Matrix b);
Matrix	C_Mat_Sub_double(Matrix c, Matrix a, double sc, int flag);
Matrix	C_Mat_Sub_Complex(Matrix c, Matrix a, Complex sc, int flag);
Matrix	C_Mat_SubSelf(Matrix a, Matrix b);
Matrix	C_Mat_Mul(Matrix c, Matrix a, Matrix b);
Matrix	C_Mat_MulElem(Matrix c, Matrix a, Matrix b);
Matrix	C_Mat_MulElemSelf(Matrix a, Matrix b);
Matrix	C_Mat_DivElem(Matrix c, Matrix a, Matrix b);
Matrix	C_Mat_DivElemSelf(Matrix a, Matrix b);
Matrix	C_Mat_Inv(Matrix b, Matrix a, Complex det, double tol);
Matrix	C_Mat_InvElem(Matrix b, Matrix a);
Matrix	C_Mat_InvElemSelf(Matrix a);
Matrix	C_Mat_PseudoInv(Matrix b, Matrix a, double tol);
Matrix	C_Mat_Trans(Matrix b, Matrix a);
Matrix	C_Mat_FlipLR(Matrix b, Matrix a);
Matrix	C_Mat_FlipUD(Matrix b, Matrix a);
Matrix	C_Mat_ShiftLeft(Matrix b, Matrix a, int m);
Matrix	C_Mat_ShiftRight(Matrix b, Matrix a, int m);
Matrix	C_Mat_ShiftUp(Matrix b, Matrix a, int m);
Matrix	C_Mat_ShiftDown(Matrix b, Matrix a, int m);
Matrix	C_Mat_RotateLeft(Matrix b, Matrix a, int m);
Matrix	C_Mat_RotateRight(Matrix b, Matrix a, int m);
Matrix	C_Mat_RotateUp(Matrix b, Matrix a, int m);
Matrix	C_Mat_RotateDown(Matrix b, Matrix a, int m);
Matrix	C_Mat_Sort(Matrix b, Matrix idx, Matrix a, int all_row);
Matrix	C_Mat_Negate(Matrix b, Matrix a);
Matrix	C_Mat_SetZero(Matrix a);
Matrix	C_Mat_RoundToZero(Matrix b, Matrix a, double tol);
Matrix	C_Mat_Exp(Matrix b, Matrix a);
Matrix	C_Mat_Conj(Matrix b, Matrix a);
Matrix	C_Mat_ConjTrans(Matrix b, Matrix a);
Matrix	C_Mat_Pow(Matrix b, Matrix a, int m);
Matrix	C_Mat_PowElem(Matrix b, Matrix a, int m);
Matrix	C_Mat_PowElemToReal(Matrix b, Matrix a, double dd);
Matrix	C_Mat_PowElemToComp(Matrix b, Matrix a, Complex c);
Matrix	C_Mat_PowElemEach(Matrix c, Matrix a, Matrix b);
Matrix	C_Mat_CompareElem(Matrix c, Matrix a, Matrix b, char *opt);
Matrix	C_Mat_FiniteElem(Matrix b, Matrix a);
Matrix	C_Mat_NaNElem(Matrix b, Matrix a);
Matrix	C_Mat_InfElem(Matrix b, Matrix a);
Matrix	C_Mat_Scale(Matrix b, Matrix a, double scale);
Matrix	C_Mat_ScaleSelf(Matrix a, double scale);
Matrix	C_Mat_ScaleSelfC(Matrix a, Complex scale);
Matrix	C_Mat_ScaleC(Matrix b, Matrix a, Complex scale);
Matrix	C_Mat_Put(Matrix a, int sr, int sc, Matrix b);
Matrix	C_Mat_Cut(Matrix b, Matrix a, int sr, int sc, int er, int ec);
Matrix	C_Mat_GetSubMatrix(Matrix a, Matrix rows, Matrix columns, Matrix c);
Matrix	C_Mat_GetVecSubMatrix(Matrix a, Matrix cols, Matrix c);
Matrix	C_Mat_SetSubMatrix(Matrix a, Matrix rows, Matrix columns, Matrix c);
Matrix	C_Mat_SetVecSubMatrix(Matrix a, Matrix cols, Matrix c);
Matrix	C_Mat_GetBlockSubMatrix(Matrix a, Matrix rows, Matrix columns,
								int pr, int pc, Matrix c);
Matrix	C_Mat_SetBlockSubMatrix(Matrix a, Matrix rows, Matrix columns,
								int pr, int pc, Matrix c);
Matrix	C_Mat_AreaCopy(Matrix a, int ar, int ac,
					   Matrix b, int br1, int bc1, int br2, int bc2);
Matrix	C_Mat_RealPart(Matrix b, Matrix a);
Matrix	C_Mat_ImagPart(Matrix b, Matrix a);
Matrix	C_Mat_CatColumn(Matrix c, Matrix a, Matrix b);
Matrix	C_Mat_CatRow(Matrix c, Matrix a, Matrix b);
Matrix	C_Mat_RealAndImag(Matrix c, Matrix a, Matrix b);
Matrix	C_Mat_RealToComp(Matrix b, Matrix a);
Matrix	C_Mat_VectorProduct(Matrix c, Matrix a, Matrix b);
Matrix	C_Mat_VectorSquare(Matrix c, Matrix a);
Matrix	C_Mat_EigVal(Matrix val, Matrix a);
Matrix	C_Mat_EigVec(Matrix vec, Matrix a);
Matrix	C_Mat_EigValVec(Matrix b, Matrix a);
Matrix	C_Mat_GEigVal(Matrix val, Matrix a, Matrix b);
Matrix	C_Mat_GEigVec(Matrix vec, Matrix a, Matrix b);
Matrix	C_Mat_GEigValVec(Matrix c, Matrix a, Matrix b);
Matrix	C_Mat_Integral(Matrix c, Matrix a, int m);
Matrix	C_Mat_HigherShift(Matrix c, Matrix a, int m);
Matrix	C_Mat_Apply(Matrix b, Matrix a, Complex (*func)(Complex aac));
Matrix	C_Mat_ApplyTwo(Matrix c, Matrix a, Matrix b, Complex (*func)(Complex aac, Complex bbc));
Matrix	C_Mat_Apply2(Matrix b, Matrix a, double (*func)(Complex aac));
Matrix	C_Mat_ApplyPolyFunc(Matrix b, Matrix a, Polynomial poly);
Matrix	C_Mat_ApplyC_PolyFunc(Matrix b, Matrix a, Polynomial poly);
Matrix	C_Mat_ApplyRatFunc(Matrix b, Matrix a, Rational rat);
Matrix	C_Mat_ApplyC_RatFunc(Matrix b, Matrix a, Rational rat);
Matrix	C_Mat_RungeKutta4(Matrix yout, double x, Matrix y, Matrix (*diff)(),
						  Matrix u, double h, int void_flag);
Matrix	C_Mat_RungeKutta4Link(Matrix yout, double x, Matrix y, 
							  Matrix (*diff)(), Matrix (*link)(),
							  double h, int void_flag);
Matrix	C_Mat_RKF45(Matrix yout, double x, Matrix y, Matrix (*diff)(),
					Matrix u, double h, int void_flag);
Matrix	C_Mat_RKF45Link(Matrix yout, double x, Matrix y, Matrix (*diff)(),
						Matrix (*link)(), double h, int void_flag);
Matrix	C_Mat_ForSub(Matrix x, Matrix l, Matrix b, double tol);
Matrix	C_Mat_BackSub(Matrix x, Matrix u, Matrix b, double tol);
Matrix	C_Mat_LUSolve(Matrix x, Matrix a, Matrix b, double tol);
Matrix	C_Mat_FFT(Matrix b, Matrix a);
Matrix	C_Mat_IFFT(Matrix b, Matrix a);
Matrix	C_Mat_All(Matrix b, Matrix a);
Matrix	C_Mat_Any(Matrix b, Matrix a);
Matrix	C_Mat_Max(Matrix b, Matrix a);
Matrix	C_Mat_Min(Matrix b, Matrix a);
Matrix	C_Mat_Maximum(Matrix b, Matrix a, Matrix idx);
Matrix	C_Mat_Minimum(Matrix b, Matrix a, Matrix idx);
Matrix	C_Mat_Sum(Matrix b, Matrix a);
Matrix	C_Mat_Prod(Matrix b, Matrix a);
Matrix	C_Mat_CumSum(Matrix b, Matrix a);
Matrix	C_Mat_CumSumElem(Matrix b, Matrix a);
Matrix	C_Mat_CumProd(Matrix b, Matrix a);
Matrix	C_Mat_CumProdElem(Matrix b, Matrix a);
Matrix	C_Mat_Mean(Matrix b, Matrix a);
Matrix	C_Mat_StdDev(Matrix b, Matrix a);
Matrix	C_Mat_FrobNorms(Matrix b, Matrix a);
Matrix	C_Mat_HousePreMul(Matrix a, Matrix v);
Matrix	C_Mat_HousePostMul(Matrix a, Matrix v);

int		C_Mat_Eig(Matrix a, Matrix val, Matrix vec);
int		C_Mat_GEig(Matrix a, Matrix b, Matrix val, Matrix vec);
void	C_Mat_LU(Matrix a, Matrix l, Matrix u, Matrix p);
void	C_Mat_LU_piv(Matrix a, Matrix l, Matrix u, int *piv);
void	C_Mat_Hessenberg(Matrix a, Matrix h, Matrix q);
int		C_Mat_Schur(Matrix a, 	Matrix t, Matrix u);
int		C_Mat_SVD(Matrix a, Matrix val, Matrix lvec, Matrix rvec);
void	C_Mat_QR(Matrix a, Matrix q, Matrix r, Matrix p, int pflag);
void	C_Mat_QR_piv(Matrix a, Matrix q, Matrix r,
					 int *piv, int *rrkk, int pflag);
int		C_Mat_QZ(Matrix a, Matrix b, Matrix s, Matrix t,
				 Matrix q, Matrix z, Matrix vec);
void	C_Mat_Balance(Matrix a, Matrix d, Matrix b);
int		C_Mat_Ode(Matrix x_out, Matrix y_out, Matrix u_out, double x1,
				  double x2, Matrix y, Matrix (*diff)(), Matrix (*link)(),
				  double eps_h, double dxmin, double dxmax, double dxsav,
				  int auto_step, int void_flag);
int		C_Mat_Ode45(Matrix x_out, Matrix y_out, Matrix u_out, double x1,
					double x2, Matrix y, Matrix (*diff)(), Matrix (*link)(),
					double eps_h, double dxmin, double dxmax, double dxsav,
					int auto_step, int void_flag);
int		C_Mat_OdeHybrid(Matrix x_out, Matrix y_out, Matrix u_out, double x1,
						double x2, double dx, Matrix y, Matrix (*diff)(),
						Matrix (*link)(), double eps_h, double dxmin,
						double dxmax, double dxsav, int auto_step,
						int void_flag);
int		C_Mat_Ode45Hybrid(Matrix x_out, Matrix y_out, Matrix u_out,
						  double x1, double x2, double dx, Matrix y,
						  Matrix (*diff)(), Matrix (*link)(), double eps_h,
						  double dxmin, double dxmax, double dxsav,
						  int auto_step, int void_flag);
void	C_Mat_HermitEig(Matrix a, Matrix val, Matrix vec);
