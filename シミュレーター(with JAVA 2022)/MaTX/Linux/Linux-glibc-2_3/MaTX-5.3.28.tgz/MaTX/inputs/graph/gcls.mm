
/* -*- MaTX -*-
 *
 *  NAME
 *      gcls() - Clear the graphical screen for Tektro emulation
 *
 */

Func void gcls()
{
	system("gcls");
}
