
/* -*- MaTX -*-
 *
 *  NAME
 *      gplot3()                - 3D Plot
 *      gplot3_logx()           -    (x-axis logarithmic)
 *      gplot3_logy()           -    (y-axis logarithmic)
 *      gplot3_logz()           -    (z-axis logarithmic)
 *      gplot3_logxy()          -    (x-y-axis logarithmic)
 *      gplot3_logxz()          -    (x-z-axis logarithmic)
 *      gplot3_logyz()          -    (y-z-axis logarithmic)
 *      gplot3_logxyz()         -    (x-y-z-axis logarithmic)
 *      gplot3_surface()        - 2D surface in 3D plot
 *      gplot3_logx_surface()   -    (x-axis logarithmic)
 *      gplot3_logy_surface()   -    (y-axis logarithmic)
 *      gplot3_logz_surface()   -    (z-axis logarithmic)
 *      gplot3_logxy_surface()  -    (x-y-axis logarithmic)
 *      gplot3_logxz_surface()  -    (x-z-axis logarithmic)
 *      gplot3_logyz_surface()  -    (y-z-axis logarithmic)
 *      gplot3_logxyz_surface() -    (x-y-z-axis logarithmic)
 *
 *  SYNOPSIS
 *      gplot3(XX, YY, ZZ, titles, cmds1, cmds2, ...)
 *        Array XX, YY, ZZ;
 *        List titles;
 *        List cmds1, cmds2;
 *
 *      gplot3_logx(XX, YY, ZZ, titles, cmds1, cmds2, ...)
 *        Array XX, YY, ZZ;
 *        List titles;
 *        List cmds1, cmds2;
 *
 *      gplot3_logy(XX, YY, ZZ, titles, cmds1, cmds2, ...)
 *        Array XX, YY, ZZ;
 *        List titles;
 *        List cmds1, cmds2;
 *
 *      gplot3_logz(XX, YY, ZZ, titles, cmds1, cmds2, ...)
 *        Array XX, YY, ZZ;
 *        List titles;
 *        List cmds1, cmds2;
 *
 *      gplot3_logxy(XX, YY, ZZ, titles, cmds1, cmds2, ...)
 *        Array XX, YY, ZZ;
 *        List titles;
 *        List cmds1, cmds2;
 *
 *      gplot3_logxz(XX, YY, ZZ, titles, cmds1, cmds2, ...)
 *        Array XX, YY, ZZ;
 *        List titles;
 *        List cmds1, cmds2;
 *
 *      gplot3_logyz(XX, YY, ZZ, titles, cmds1, cmds2, ...)
 *        Array XX, YY, ZZ;
 *        List titles;
 *        List cmds1, cmds2;
 *
 *      gplot3_logxyz(XX, YY, ZZ, titles, cmds1, cmds2, ...)
 *        Array XX, YY, ZZ;
 *        List titles;
 *        List cmds1, cmds2;
 *
 *      gplot3_surface(XX, YY, ZZ, title, cmd1, cmd2, ...)
 *        Array XX, YY, ZZ;
 *        String title;
 *        String cmd1, cmd2;
 *
 *      gplot3_logx_surface(XX, YY, ZZ, title, cmd1, cmd2, ...)
 *        Array XX, YY, ZZ;
 *        String title;
 *        String cmd1, cmd2;
 *
 *      gplot3_logy_surface(XX, YY, ZZ, title, cmd1, cmd2, ...)
 *        Array XX, YY, ZZ;
 *        String title;
 *        String cmd1, cmd2;
 *
 *      gplot3_logz_surface(XX, YY, ZZ, title, cmd1, cmd2, ...)
 *        Array XX, YY, ZZ;
 *        String title;
 *        String cmd1, cmd2;
 *
 *      gplot3_logxy_surface(XX, YY, ZZ, title, cmd1, cmd2, ...)
 *        Array XX, YY, ZZ;
 *        String title;
 *        String cmd1, cmd2;
 *
 *      gplot3_logxz_surface(XX, YY, ZZ, title, cmd1, cmd2, ...)
 *        Array XX, YY, ZZ;
 *        String title;
 *        String cmd1, cmd2;
 *
 *      gplot3_logyz_surface(XX, YY, ZZ, title, cmd1, cmd2, ...)
 *        Array XX, YY, ZZ;
 *        String title;
 *        String cmd1, cmd2;
 *
 *      gplot3_logxyz_surface(XX, YY, ZZ, title, cmd1, cmd2, ...)
 *        Array XX, YY, ZZ;
 *        String title;
 *        String cmd1, cmd2;
 *
 *    DESCRIPTION
 *
 *    EXAMPLE
 *      z = [0:PI/50:10*PI];
 *      gplot3(sin(z), cos(z), z);
 *
 *      z = rand(10);
 *      gplot3_surface(z);
 */

Func void gplot3(XX, YY, ZZ, titles, cmds1, cmds2, ...)
	 Array XX, YY, ZZ;
	 List titles;
	 List cmds1, cmds2;
{
	 switch (nargs) {
	 case 1: 
		  mgplot3(mgplot_cur_win(), XX);
		  break;
	 case 2:
		  mgplot3(mgplot_cur_win(), XX, YY);
		  break;
	 case 3: 
		  mgplot3(mgplot_cur_win(), XX, YY, ZZ);
		  break;
	 case 4:
		  mgplot3(mgplot_cur_win(), XX, YY, ZZ, titles);
		  break;
	 case 5:
		  mgplot3(mgplot_cur_win(), XX, YY, ZZ, titles, cmds1);
		  break;
	 case 6:
		  mgplot3(mgplot_cur_win(), XX, YY, ZZ, titles, cmds1, cmds2);
		  break;
	 default:
		  error("gplot3(): Incorrect number of arguments.\n");
		  break;
	 }
}

Func void gplot3_logx(XX, YY, ZZ, titles, cmds1, cmds2, ...)
	 Array XX, YY, ZZ;
	 List titles;
	 List cmds1, cmds2;
{
	 switch (nargs) {
	 case 1: 
		  mgplot3_logx(mgplot_cur_win(), XX);
		  break;
	 case 2: 
		  mgplot3_logx(mgplot_cur_win(), XX, YY);
		  break;
	 case 3: 
		  mgplot3_logx(mgplot_cur_win(), XX, YY, ZZ);
		  break;
	 case 4: 
		  mgplot3_logx(mgplot_cur_win(), XX, YY, ZZ, titles);
		  break;
	 case 5: 
		  mgplot3_logx(mgplot_cur_win(), XX, YY, ZZ, titles, cmds1);
		  break;
	 case 6: 
		  mgplot3_logx(mgplot_cur_win(), XX, YY, ZZ, titles, cmds1, cmds2);
		  break;
	 default:
		  error("gplot3_logx(): Incorrect number of arguments.\n");
		  break;
	 }
}

Func void gplot3_logy(XX, YY, ZZ, titles, cmds1, cmds2, ...)
	 Array XX, YY, ZZ;
	 List titles;
	 List cmds1, cmds2;
{
	if (nargs == 1) {
		mgplot3_logy(mgplot_cur_win(), XX);
	} else if (nargs == 2) {
		mgplot3_logy(mgplot_cur_win(), XX, YY);
	} else if (nargs == 3) {
		mgplot3_logy(mgplot_cur_win(), XX, YY, ZZ);
	} else if (nargs == 4) {
		mgplot3_logy(mgplot_cur_win(), XX, YY, ZZ, titles);
	} else if (nargs == 5) {
		mgplot3_logy(mgplot_cur_win(), XX, YY, ZZ, titles, cmds1);
	} else if (nargs == 6) {
		mgplot3_logy(mgplot_cur_win(), XX, YY, ZZ, titles, cmds1, cmds2);
	} else {
		error("gplot3_logy(): Incorrect number of arguments.\n");
	}
}

Func void gplot3_logz(XX, YY, ZZ, titles, cmds1, cmds2, ...)
	 Array XX, YY, ZZ;
	 List titles;
	 List cmds1, cmds2;
{
	if (nargs == 1) {
		mgplot3_logz(mgplot_cur_win(), XX);
	} else if (nargs == 2) {
		mgplot3_logz(mgplot_cur_win(), XX, YY);
	} else if (nargs == 3) {
		mgplot3_logz(mgplot_cur_win(), XX, YY, ZZ);
	} else if (nargs == 4) {
		mgplot3_logz(mgplot_cur_win(), XX, YY, ZZ, titles);
	} else if (nargs == 5) {
		mgplot3_logz(mgplot_cur_win(), XX, YY, ZZ, titles, cmds1);
	} else if (nargs == 6) {
		mgplot3_logz(mgplot_cur_win(), XX, YY, ZZ, titles, cmds1, cmds2);
	} else {
		error("gplot3_logz(): Incorrect number of arguments.\n");
	}
}

Func void gplot3_logxy(XX, YY, ZZ, titles, cmds1, cmds2, ...)
	 Array XX, YY, ZZ;
	 List titles;
	 List cmds1, cmds2;
{
	if (nargs == 1) {
		mgplot3_logxy(mgplot_cur_win(), XX);
	} else if (nargs == 2) {
		mgplot3_logxy(mgplot_cur_win(), XX, YY);
	} else if (nargs == 3) {
		mgplot3_logxy(mgplot_cur_win(), XX, YY, ZZ);
	} else if (nargs == 4) {
		mgplot3_logxy(mgplot_cur_win(), XX, YY, ZZ, titles);
	} else if (nargs == 5) {
		mgplot3_logxy(mgplot_cur_win(), XX, YY, ZZ, titles, cmds1);
	} else if (nargs == 6) {
		mgplot3_logxy(mgplot_cur_win(), XX, YY, ZZ, titles, cmds1, cmds2);
	} else {
		error("gplot3_logxy(): Incorrect number of arguments.\n");
	}
}

Func void gplot3_logxz(XX, YY, ZZ, titles, cmds1, cmds2, ...)
	 Array XX, YY, ZZ;
	 List titles;
	 List cmds1, cmds2;
{
	if (nargs == 1) {
		mgplot3_logxz(mgplot_cur_win(), XX);
	} else if (nargs == 2) {
		mgplot3_logxz(mgplot_cur_win(), XX, YY);
	} else if (nargs == 3) {
		mgplot3_logxz(mgplot_cur_win(), XX, YY, ZZ);
	} else if (nargs == 4) {
		mgplot3_logxz(mgplot_cur_win(), XX, YY, ZZ, titles);
	} else if (nargs == 5) {
		mgplot3_logxz(mgplot_cur_win(), XX, YY, ZZ, titles, cmds1);
	} else if (nargs == 6) {
		mgplot3_logxz(mgplot_cur_win(), XX, YY, ZZ, titles, cmds1, cmds2);
	} else {
		error("gplot3_logxz(): Incorrect number of arguments.\n");
	}
}

Func void gplot3_logyz(XX, YY, ZZ, titles, cmds1, cmds2, ...)
	 Array XX, YY, ZZ;
	 List titles;
	 List cmds1, cmds2;
{
	if (nargs == 1) {
		mgplot3_logyz(mgplot_cur_win(), XX);
	} else if (nargs == 2) {
		mgplot3_logyz(mgplot_cur_win(), XX, YY);
	} else if (nargs == 3) {
		mgplot3_logyz(mgplot_cur_win(), XX, YY, ZZ);
	} else if (nargs == 4) {
		mgplot3_logyz(mgplot_cur_win(), XX, YY, ZZ, titles);
	} else if (nargs == 5) {
		mgplot3_logyz(mgplot_cur_win(), XX, YY, ZZ, titles, cmds1);
	} else if (nargs == 6) {
		mgplot3_logyz(mgplot_cur_win(), XX, YY, ZZ, titles, cmds1, cmds2);
	} else {
		error("gplot3_logyz(): Incorrect number of arguments.\n");
	}
}

Func void gplot3_logxyz(XX, YY, ZZ, titles, cmds1, cmds2, ...)
	 Array XX, YY, ZZ;
	 List titles;
	 List cmds1, cmds2;
{
	if (nargs == 1) {
		mgplot3_logxyz(mgplot_cur_win(), XX);
	} else if (nargs == 2) {
		mgplot3_logxyz(mgplot_cur_win(), XX, YY);
	} else if (nargs == 3) {
		mgplot3_logxyz(mgplot_cur_win(), XX, YY, ZZ);
	} else if (nargs == 4) {
		mgplot3_logxyz(mgplot_cur_win(), XX, YY, ZZ, titles);
	} else if (nargs == 5) {
		mgplot3_logxyz(mgplot_cur_win(), XX, YY, ZZ, titles, cmds1);
	} else if (nargs == 6) {
		mgplot3_logxyz(mgplot_cur_win(), XX, YY, ZZ, titles, cmds1, cmds2);
	} else {
		error("gplot3_logxyz(): Incorrect number of arguments.\n");
	}
}

Func void gplot3_surface(XX, YY, ZZ, title, cmd1, cmd2, ...)
	 Array XX, YY, ZZ;
	 String title;
	 String cmd1, cmd2;
{
	if (nargs == 1) {
		mgplot3_surface(mgplot_cur_win(), XX);
	} else if (nargs == 2) {
		mgplot3_surface(mgplot_cur_win(), XX, YY);
	} else if (nargs == 3) {
		mgplot3_surface(mgplot_cur_win(), XX, YY, ZZ);
	} else if (nargs == 4) {
		mgplot3_surface(mgplot_cur_win(), XX, YY, ZZ, title);
	} else if (nargs == 5) {
		mgplot3_surface(mgplot_cur_win(), XX, YY, ZZ, title, cmd1);
	} else if (nargs == 6) {
		mgplot3_surface(mgplot_cur_win(), XX, YY, ZZ, title, cmd1, cmd2);
	} else {
		error("gplot3_surface(): Incorrect number of arguments.\n");
	}
}

Func void gplot3_logx_surface(XX, YY, ZZ, title, cmd1, cmd2, ...)
	 Array XX, YY, ZZ;
	 String title;
	 String cmd1, cmd2;
{
	if (nargs == 1) {
		mgplot3_logx_surface(mgplot_cur_win(), XX);
	} else if (nargs == 2) {
		mgplot3_logx_surface(mgplot_cur_win(), XX, YY);
	} else if (nargs == 3) {
		mgplot3_logx_surface(mgplot_cur_win(), XX, YY, ZZ);
	} else if (nargs == 4) {
		mgplot3_logx_surface(mgplot_cur_win(), XX, YY, ZZ, title);
	} else if (nargs == 5) {
		mgplot3_logx_surface(mgplot_cur_win(), XX, YY, ZZ, title, cmd1);
	} else if (nargs == 6) {
		mgplot3_logx_surface(mgplot_cur_win(), XX, YY, ZZ, title, cmd1, cmd2);
	} else {
		error("gplot3_logx_surface(): Incorrect number of arguments.\n");
	}
}


Func void gplot3_logy_surface(XX, YY, ZZ, title, cmd1, cmd2, ...)
	 Array XX, YY, ZZ;
	 String title;
	 String cmd1, cmd2;
{
	if (nargs == 1) {
		mgplot3_logy_surface(mgplot_cur_win(), XX);
	} else if (nargs == 2) {
		mgplot3_logy_surface(mgplot_cur_win(), XX, YY);
	} else if (nargs == 3) {
		mgplot3_logy_surface(mgplot_cur_win(), XX, YY, ZZ);
	} else if (nargs == 4) {
		mgplot3_logy_surface(mgplot_cur_win(), XX, YY, ZZ, title);
	} else if (nargs == 5) {
		mgplot3_logy_surface(mgplot_cur_win(), XX, YY, ZZ, title, cmd1);
	} else if (nargs == 6) {
		mgplot3_logy_surface(mgplot_cur_win(), XX, YY, ZZ, title, cmd1, cmd2);
	} else {
		error("gplot3_logy_surface(): Incorrect number of arguments.\n");
	}
}

Func void gplot3_logz_surface(XX, YY, ZZ, title, cmd1, cmd2, ...)
	 Array XX, YY, ZZ;
	 String title;
	 String cmd1, cmd2;
{
	if (nargs == 1) {
		mgplot3_logz_surface(mgplot_cur_win(), XX);
	} else if (nargs == 2) {
		mgplot3_logz_surface(mgplot_cur_win(), XX, YY);
	} else if (nargs == 3) {
		mgplot3_logz_surface(mgplot_cur_win(), XX, YY, ZZ);
	} else if (nargs == 4) {
		mgplot3_logz_surface(mgplot_cur_win(), XX, YY, ZZ, title);
	} else if (nargs == 5) {
		mgplot3_logz_surface(mgplot_cur_win(), XX, YY, ZZ, title, cmd1);
	} else if (nargs == 6) {
		mgplot3_logz_surface(mgplot_cur_win(), XX, YY, ZZ, title, cmd1, cmd2);
	} else {
		error("gplot3_logz_surface(): Incorrect number of arguments.\n");
	}
}

Func void gplot3_logxy_surface(XX, YY, ZZ, title, cmd1, cmd2, ...)
	 Array XX, YY, ZZ;
	 String title;
	 String cmd1, cmd2;
{
	if (nargs == 1) {
		mgplot3_logxy_surface(mgplot_cur_win(), XX);
	} else if (nargs == 2) {
		mgplot3_logxy_surface(mgplot_cur_win(), XX, YY);
	} else if (nargs == 3) {
		mgplot3_logxy_surface(mgplot_cur_win(), XX, YY, ZZ);
	} else if (nargs == 4) {
		mgplot3_logxy_surface(mgplot_cur_win(), XX, YY, ZZ, title);
	} else if (nargs == 5) {
		mgplot3_logxy_surface(mgplot_cur_win(), XX, YY, ZZ, title, cmd1);
	} else if (nargs == 6) {
		mgplot3_logxy_surface(mgplot_cur_win(), XX, YY, ZZ, title, cmd1, cmd2);
	} else {
		error("gplot3_logxy_surface(): Incorrect number of arguments.\n");
	}
}

Func void gplot3_logxz_surface(XX, YY, ZZ, title, cmd1, cmd2, ...)
	 Array XX, YY, ZZ;
	 String title;
	 String cmd1, cmd2;
{
	if (nargs == 1) {
		mgplot3_logxz_surface(mgplot_cur_win(), XX);
	} else if (nargs == 2) {
		mgplot3_logxz_surface(mgplot_cur_win(), XX, YY);
	} else if (nargs == 3) {
		mgplot3_logxz_surface(mgplot_cur_win(), XX, YY, ZZ);
	} else if (nargs == 4) {
		mgplot3_logxz_surface(mgplot_cur_win(), XX, YY, ZZ, title);
	} else if (nargs == 5) {
		mgplot3_logxz_surface(mgplot_cur_win(), XX, YY, ZZ, title, cmd1);
	} else if (nargs == 6) {
		mgplot3_logxz_surface(mgplot_cur_win(), XX, YY, ZZ, title, cmd1, cmd2);
	} else {
		error("gplot3_logxz_surface(): Incorrect number of arguments.\n");
	}
}

Func void gplot3_logyz_surface(XX, YY, ZZ, title, cmd1, cmd2, ...)
	 Array XX, YY, ZZ;
	 String title;
	 String cmd1, cmd2;
{
	if (nargs == 1) {
		mgplot3_logyz_surface(mgplot_cur_win(), XX);
	} else if (nargs == 2) {
		mgplot3_logyz_surface(mgplot_cur_win(), XX, YY);
	} else if (nargs == 3) {
		mgplot3_logyz_surface(mgplot_cur_win(), XX, YY, ZZ);
	} else if (nargs == 4) {
		mgplot3_logyz_surface(mgplot_cur_win(), XX, YY, ZZ, title);
	} else if (nargs == 5) {
		mgplot3_logyz_surface(mgplot_cur_win(), XX, YY, ZZ, title, cmd1);
	} else if (nargs == 6) {
		mgplot3_logyz_surface(mgplot_cur_win(), XX, YY, ZZ, title, cmd1, cmd2);
	} else {
		error("gplot3_logyz_surface(): Incorrect number of arguments.\n");
	}
}

Func void gplot3_logxyz_surface(XX, YY, ZZ, title, cmd1, cmd2, ...)
	 Array XX, YY, ZZ;
	 String title;
	 String cmd1, cmd2;
{
	if (nargs == 1) {
		mgplot3_logxyz_surface(mgplot_cur_win(), XX);
	} else if (nargs == 2) {
		mgplot3_logxyz_surface(mgplot_cur_win(), XX, YY);
	} else if (nargs == 3) {
		mgplot3_logxyz_surface(mgplot_cur_win(), XX, YY, ZZ);
	} else if (nargs == 4) {
		mgplot3_logxyz_surface(mgplot_cur_win(), XX, YY, ZZ, title);
	} else if (nargs == 5) {
		mgplot3_logxyz_surface(mgplot_cur_win(), XX, YY, ZZ, title, cmd1);
	} else if (nargs == 6) {
		mgplot3_logxyz_surface(mgplot_cur_win(), XX, YY, ZZ, title, cmd1, cmd2);
	} else {
		error("gplot3_logxyz_surface(): Incorrect number of arguments.\n");
	}
}




