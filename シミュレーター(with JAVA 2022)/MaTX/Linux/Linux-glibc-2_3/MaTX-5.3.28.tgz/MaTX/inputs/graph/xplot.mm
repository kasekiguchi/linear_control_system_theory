
/* -*- MaTX -*-
 *
 *  NAME
 *      xplot()          - Linear x-y Plot with XPLOT
 *      xplot_grid()     - Draws grid lines on the current plot
 *      xplot_init()     - Initialization for xplot()
 *      xplot_reset()    - Reset for xplot()
 *      xplot_semilogx() - SemiLog Plot with XPLOT
 *      xplot_title()    - Text as a title at the bottom
 *      xplot_xlabel()   - Text beneath the x-axis
 *      xplot_xsplit()   - Split the x-axis
 *      xplot_ylabel()   - Text side of the y-axis
 *      xplot_ysplit()   - Split the y-axis
 *
 *  SYNOPSIS
 *      xplot(X1, Y1, X2, Y2, X3, Y3, X4, Y4, X5, Y5, ...)
 *        Array X1;
 *        ...
 *        Array Y1, X2, Y2, X3, Y3, X4, Y4, X5, Y5;
 *
 *      xplot_grid(onoff, ...)
 *        ...
 *        Integer onoff;
 *
 *      xplot_init()
 *
 *      xplot_reset()
 *
 *      xplot_semilogx(X1, Y1, X2, Y2, X3, Y3, X4, Y4, X5, Y5, ...)
 *        Array X1, Y1;
 *        ...
 *        Array X2, Y2, X3, Y3, X4, Y4, X5, Y5;
 *
 *      xplot_title(text)
 *        String text;
 *
 *      xplot_xlabel(text)
 *        String text;
 *
 *      xplot_xsplit(n)
 *        Integer n;
 *
 *      xplot_ylabel(text)
 *        String text;
 *
 *      xplot_ysplit(n)
 *        Integer n;
 *
 */

void xplot_init() require "graph/xplot.mm";
Integer xplot_d1_count(...), xplot_d2_count(...) require "graph/xplot.mm";
Integer xplot_semilogx_count(...), xplot_splot() require "graph/xplot.mm";

Func void xplot(X1, Y1, X2, Y2, X3, Y3, X4, Y4, X5, Y5, ...)
	Array X1, X2, X3, X4, X5;
	Array Y1, Y2, Y3, Y4, Y5;
{
	Integer line_style;
	void xplot_d1();
	Integer xplot_d2();

	if (nargs == 1) {
		xplot_d1(X1);
	} else if (nargs == 2) {
		xplot_d2(X1, Y1, 0);
	} else if (nargs == 4) {
		line_style = xplot_d2(X1, Y1, 0);
		line_style = xplot_d2(X2, Y2, line_style);
	} else if (nargs == 6) {
		line_style = xplot_d2(X1, Y1, 0);
		line_style = xplot_d2(X2, Y2, line_style);
		line_style = xplot_d2(X3, Y3, line_style);
	} else if (nargs == 8) {
		line_style = xplot_d2(X1, Y1, 0);
		line_style = xplot_d2(X2, Y2, line_style);
		line_style = xplot_d2(X3, Y3, line_style);
		line_style = xplot_d2(X4, Y4, line_style);
	} else if (nargs == 10) {
		line_style = xplot_d2(X1, Y1, 0);
		line_style = xplot_d2(X2, Y2, line_style);
		line_style = xplot_d2(X3, Y3, line_style);
		line_style = xplot_d2(X4, Y4, line_style);
		line_style = xplot_d2(X5, Y5, line_style);
	} else {
		error("xplot(): Incorrect number of arguments.\n");
	}
}

Func Integer xplot_d2(X, Y, old_canvas)
	Array X;
	Array Y;
	Integer old_canvas;
{
	Integer i, m, n, fd;
	String filename;
	void xplot_init();

	m = Rows(X);
	n = Rows(Y);

	if (m != 1 && n != 1 && m != n) {
		error("xplot_d2(): Confliction of data number.\n");
	}

	filename = sprintf("xplot-%d", PID);
	xplot_init();
	fd = fopen(filename, "a");

	if (xplot_d2_count() == 0) {
		fprintf(fd, "Open2DInfo()\n");
	}
	xplot_d2_count(xplot_d2_count() + 1);

	print [[X][Y]] >> "xplot-d2data-" + String(xplot_d2_count());
	fprintf(fd, "a = ReadData(\"%s\")\n",
			"xplot-d2data-" + String(xplot_d2_count()));

	if (old_canvas == 0) {
		fprintf(fd, "b = Open2DCanvas()\n");
	}
	fprintf(fd, "c = Make2DLines(%d)\n", max(m,n));

	for (i = 1; i <= max(m,n); i++) {
		if (m == 1) {
			fprintf(fd, "Select2DLine(c+%d, a, 1, a, %d)\n", i-1, i+1);
		} else if (n == 1) {
			fprintf(fd, "Select2DLine(c+%d, a, %d, a, %d)\n",i-1,i,m+1);
		} else if (m == n) {
			fprintf(fd, "Select2DLine(c+%d, a, %d, a, %d)\n",i-1,i,m+i);
		}
		fprintf(fd, "SetStyle2DLine(c+%d-1, %d)\n", i, rem(i+old_canvas,13));
		fprintf(fd, "Active2DLine(c+%d-1)\n", i);
	}

	if (old_canvas == 0) {
		fprintf(fd, "ScaleOn2DCanvas(b)\n");
	}

	fclose(fd);
	return old_canvas + max(m,n);
}

Func void xplot_d1(Y)
	Array Y;
{
	Integer i, n, fd;
	String filename;

	void xplot_init();

	n = Rows(Y);
	filename = sprintf("xplot-%d", PID);
	xplot_init();

	xplot_d1_count(xplot_d1_count() + 1);
	print Y >> "xplot-d1data-" + String(xplot_d1_count());

	fd = fopen(filename, "a");
	fprintf(fd, "a = ReadData(\"%s\")\n",
			"xplot-d1data-" + String(xplot_d1_count()));

	fprintf(fd, "b = Open1DCanvas()\n");
	for (i = 1; i <= n ; i++) {
		fprintf(fd, "SetStyle1DLine(a, %d, %d)\n", i, rem(i,13));
		fprintf(fd, "Active1DLine(a, %d)\n", i);
	}
	fprintf(fd, "ScaleOn1DCanvas(b)\n");
	fclose(fd);
}

Func void xplot_init()
{
	static Integer running;
	String command, filename;

	if (running) {
		return;
	} else {
		running = 1;
		xplot_d1_count(0);
		xplot_d2_count(0);
		xplot_semilogx_count(0);
	}

	filename = sprintf("xplot-%d", PID);
	command = sprintf("/bin/rm -f %s", filename);
	system(command);
	command = sprintf("touch %s", filename);
	system(command);
	command = sprintf("xplot -silent -via %s &", filename);
	system(command);
}

Func void xplot_reset()
{
	xplot_d1_count(0);
	xplot_d2_count(0);
	xplot_semilogx_count(0);
}

Func void xplot_grid(onoff, ...)
	Integer onoff;
{
	Integer fd;
	String filename;
	static Integer grid_on_off;

	filename = sprintf("xplot-%d", PID);
	fd = fopen(filename, "a");

	if (nargs > 2) {
		error("xplot_grid(): Incorrect number of arguments");
	}

	if (nargs == 1) {
		if (onoff) {
			grid_on_off = 1;
			fprintf(fd, "GridOn()\n");
		} else {
			grid_on_off = 0;
			fprintf(fd, "GridOff()\n");
		}
	} else {
		if (grid_on_off) {
			grid_on_off = 0;
			fprintf(fd, "GridOff()\n");
		} else {
			grid_on_off = 1;
			fprintf(fd, "GridOn()\n");
		}
	}

	fclose(fd);
}

Func void xplot_semilogx(X1, Y1, X2, Y2, X3, Y3, X4, Y4, X5, Y5, ...)
	Array X1, X2, X3, X4, X5;
	Array Y1, Y2, Y3, Y4, Y5;
{
	Integer line_style;

	if (nargs == 2) {
		xplot_splot(X1, Y1, 0);
	} else if (nargs == 4) {
		line_style = xplot_splot(X1, Y1, 0);
		line_style = xplot_splot(X2, Y2, line_style);
	} else if (nargs == 6) {
		line_style = xplot_splot(X1, Y1, 0);
		line_style = xplot_splot(X2, Y2, line_style);
		line_style = xplot_splot(X3, Y3, line_style);
	} else if (nargs == 8) {
		line_style = xplot_splot(X1, Y1, 0);
		line_style = xplot_splot(X2, Y2, line_style);
		line_style = xplot_splot(X3, Y3, line_style);
		line_style = xplot_splot(X4, Y4, line_style);
	} else if (nargs == 10) {
		line_style = xplot_splot(X1, Y1, 0);
		line_style = xplot_splot(X2, Y2, line_style);
		line_style = xplot_splot(X3, Y3, line_style);
		line_style = xplot_splot(X4, Y4, line_style);
		line_style = xplot_splot(X5, Y5, line_style);
	} else {
		error("xplot_semilogx(): Incorrect number of arguments.\n");
	}
}

Func Integer xplot_splot(X, Y, old_canvas)
	Array X;
	Array Y;
	Integer old_canvas;
{
	Integer i, m, n, fd;
	String filename;

	m = Rows(X);
	n = Rows(Y);

	if (m != 1 && m != n) {
		error("xplot_splot(): Confliction of data number.\n");
	}

	filename = sprintf("xplot-%d", PID);
	xplot_init();

	fd = fopen(filename, "a");
	if (xplot_semilogx_count() == 0) {
		fprintf(fd, "OpenSemiLogInfo()\n");
	}
	xplot_semilogx_count(xplot_semilogx_count() + 1);

	print [[X][Y]] >> "xplot-spdata-" + String(xplot_semilogx_count());
	fprintf(fd, "a = ReadData(\"%s\")\n",
			"xplot-spdata-" + String(xplot_semilogx_count()));

	if (old_canvas == 0) {
		fprintf(fd, "b = OpenSemiLogCanvas()\n");
	}
	fprintf(fd, "c = MakeSemiLogLines(%d)\n", n);

	for (i = 1; i <= n ; i++) {
		if (m == 1) {
			fprintf(fd, "SelectSemiLogLine(c+%d, a, 1, a, %d)\n",
					i-1, i+1);
		} else {
			fprintf(fd, "SelectSemiLogLine(c+%d, a, %d, a, %d)\n",
					i-1, i, n+i);
		}
		fprintf(fd, "SetStyleSemiLogLine(c+%d, %d)\n",
				i-1, rem(i+old_canvas,13));
		fprintf(fd, "ActiveSemiLogLine(c+%d)\n", i-1);
	}
	if (old_canvas == 0) {
		fprintf(fd, "ScaleOnSemiLogCanvas(b)\n");
	}

	fclose(fd);
	return old_canvas + max(m,n);
}

Func void xplot_title(text)
	String text;
{
	Integer fd;
	String filename;

	filename = sprintf("xplot-%d", PID);
	fd = fopen(filename, "a");
	fprintf(fd, "SetTitle(\"%s\")\n", text);
	fclose(fd);
}

Func void xplot_xlabel(text)
	String text;
{
	Integer fd;
	String filename;

	filename = sprintf("xplot-%d", PID);
	fd = fopen(filename, "a");
	fprintf(fd, "SetXLabel(\"%s\")\n", text);
	fclose(fd);
}

Func void xplot_ylabel(text)
	String text;
{
	Integer fd;
	String filename;

	filename = sprintf("xplot-%d", PID);
	fd = fopen(filename, "a");
	fprintf(fd, "SetYLabel(\"%s\")\n", text);
	fclose(fd);
}

Func void xplot_xsplit(n)
	Integer n;
{
	Integer fd;
	String filename;

	filename = sprintf("xplot-%d", PID);
	fd = fopen(filename, "a");
	fprintf(fd, "SetXSplit(%d)\n", n);
	fclose(fd);
}

Func void xplot_ysplit(n)
	Integer n;
{
	Integer fd;
	String filename;

	filename = sprintf("xplot-%d", PID);
	fd = fopen(filename, "a");
	fprintf(fd, "SetYSplit(%d)\n", n);
	fclose(fd);
}

Func Integer xplot_d1_count(c, ...)
	Integer c;
{
	static Integer d1_count;

	if (1 < nargs) {
		error("xplot_d1_count(): Incorrect number of arguments.");
	}
	
	if (nargs == 0) {
		return d1_count;
	} else {
		d1_count = c;
		return c;
	}
}

Func Integer xplot_d2_count(c, ...)
	Integer c;
{
	static Integer d2_count;

	if (1 < nargs) {
		error("xplot_d2_count(): Incorrect number of arguments.");
	}
	
	if (nargs == 0) {
		return d2_count;
	} else {
		d2_count = c;
		return c;
	}
}

Func Integer xplot_semilogx_count(c, ...)
	Integer c;
{
	static Integer semilogx_count;

	if (1 < nargs) {
		error("xplot_semilogx_count(): Incorrect number of arguments.");
	}
	
	if (nargs == 0) {
		return semilogx_count;
	} else {
		semilogx_count = c;
		return c;
	}
}
