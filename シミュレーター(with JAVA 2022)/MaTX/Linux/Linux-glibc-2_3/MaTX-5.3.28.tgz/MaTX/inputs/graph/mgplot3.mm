
/* -*- MaTX -*-
 *
 *  NAME
 *      mgplot3()         - 3D Plot
 *      mgplot3_logx()    -    (x-axis logarithmic)
 *      mgplot3_logy()    -    (y-axis logarithmic)
 *      mgplot3_logz()    -    (z-axis logarithmic)
 *      mgplot3_logxy()   -    (x-y-axis logarithmic)
 *      mgplot3_logxz()   -    (x-z-axis logarithmic)
 *      mgplot3_logyz()   -    (y-z-axis logarithmic)
 *      mgplot3_logxyz()  -    (x-y-z-axis logarithmic)
 *
 *      mgplot3_surface()        - 2D surface in 3D Plot
 *      mgplot3_logx_surface()   -    (x-axis logarithmic)
 *      mgplot3_logy_surface()   -    (y-axis logarithmic)
 *      mgplot3_logz_surface()   -    (z-axis logarithmic)
 *      mgplot3_logxy_surface()  -    (x-y-axis logarithmic)
 *      mgplot3_logxz_surface()  -    (x-z-axis logarithmic)
 *      mgplot3_logyz_surface()  -    (y-z-axis logarithmic)
 *      mgplot3_logxyz_surface() -    (x-y-z-axis logarithmic)
 * 
 *  SYNOPSIS
 *      mgplot3(win, XX, YY, ZZ, titles, cmds1, cmds2, ...)
 *        Integer win;
 *        Array XX, YY, ZZ;
 *        List titles;
 *        List cmds1, cmds2;
 *
 *      mgplot3_logx(win, XX, YY, ZZ, titles, cmds1, cmds2, ...)
 *        Integer win;
 *        Array XX, YY, ZZ;
 *        List titles;
 *        List cmds1, cmds2;
 *
 *      mgplot3_logy(win, XX, YY, ZZ, titles, cmds1, cmds2, ...)
 *        Integer win;
 *        Array XX, YY, ZZ;
 *        List titles;
 *        List cmds1, cmds2;
 *
 *      mgplot3_logz(win, XX, YY, ZZ, titles, cmds1, cmds2, ...)
 *        Integer win;
 *        Array XX, YY, ZZ;
 *        List titles;
 *        List cmds1, cmds2;
 *
 *      mgplot3_logxy(win, XX, YY, ZZ, titles, cmds1, cmds2, ...)
 *        Integer win;
 *        Array XX, YY, ZZ;
 *        List titles;
 *        List cmds1, cmds2;
 *
 *      mgplot3_logxz(win, XX, YY, ZZ, titles, cmds1, cmds2, ...)
 *        Integer win;
 *        Array XX, YY, ZZ;
 *        List titles;
 *        List cmds1, cmds2;
 *
 *      mgplot3_logyz(win, XX, YY, ZZ, titles, cmds1, cmds2, ...)
 *        Integer win;
 *        Array XX, YY, ZZ;
 *        List titles;
 *        List cmds1, cmds2;
 *
 *      mgplot3_logxyz(win, XX, YY, ZZ, titles, cmds1, cmds2, ...)
 *        Integer win;
 *        Array XX, YY, ZZ;
 *        List titles;
 *        List cmds1, cmds2;
 *
 *      mgplot3_surface(win, XX, YY, ZZ, title, cmd1, cmd2, ...)
 *        Integer win;
 *        Array XX, YY, ZZ;
 *        String title;
 *        String cmd1, cmd2;
 *
 *      mgplot3_logx_surface(win, XX, YY, ZZ, title, cmd1, cmd2, ...)
 *        Integer win;
 *        Array XX, YY, ZZ;
 *        String title;
 *        String cmd1, cmd2;
 *
 *      mgplot3_logy_surface(win, XX, YY, ZZ, title, cmd1, cmd2, ...)
 *        Integer win;
 *        Array XX, YY, ZZ;
 *        String title;
 *        String cmd1, cmd2;
 *
 *      mgplot3_logz_surface(win, XX, YY, ZZ, title, cmd1, cmd2, ...)
 *        Integer win;
 *        Array XX, YY, ZZ;
 *        String title;
 *        String cmd1, cmd2;
 *
 *      mgplot3_logxy_surface(win, XX, YY, ZZ, title, cmd1, cmd2, ...)
 *        Integer win;
 *        Array XX, YY, ZZ;
 *        String title;
 *        String cmd1, cmd2;
 *
 *      mgplot3_logyz_surface(win, XX, YY, ZZ, title, cmd1, cmd2, ...)
 *        Integer win;
 *        Array XX, YY, ZZ;
 *        String title;
 *        String cmd1, cmd2;
 *
 *      mgplot3_logxyz_surface(win, XX, YY, ZZ, title, cmd1, cmd2, ...)
 *        Integer win;
 *        Array XX, YY, ZZ;
 *        String title;
 *        String cmd1, cmd2;
 *
 *    DESCRIPTION
 *
 *    EXAMPLE
 *      z = [0:PI/50:10*PI];
 *      mgplot3(1, sin(z), cos(z), z);
 *
 *      z = rand(10);
 *      mgplot3_surface(1, z);
 */

Func void mgplot3(win, XX, YY, ZZ, titles, cmds1, cmds2, ...)
	 Integer win;
	 Array XX, YY, ZZ;
	 List titles;
	 List cmds1, cmds2;
{
  Integer frame;
  String log_mode_cmd;
  void d3_mgplot(...);

	if (nargs == 0) {
		return;
	}

	if (nargs < 4 || 7 < nargs) {
		error("mgplot3(): Incorrect number of arguments.\n");
	}

	if (win <= 0) {
		win = 1;
	}

	mgplot_init(win);
	mgplot_cur_win(win);

	if ((frame = mgplot_multiplot(win))) {
		mgplot_clear(win);
	}
	
	switch (mgplot_log_mode(win,frame)) {
	  case 0:
		log_mode_cmd = "set nologscale xyz";
		break;
	  case 1:
		log_mode_cmd = sprintf("set xrange [%f:%f]; ",
							   min(XX), max(XX)) +
								   "set logscale x; set nologscale yz";
		break;
	  case 2:
		log_mode_cmd = sprintf("set yrange [%f:%f]; ",
							   min(YY), max(YY)) +
								   "set logscale y; set nologscale xz";
		break;
	  case 3:
		log_mode_cmd = sprintf("set zrange [%f:%f]; ",
							   min(ZZ), max(ZZ)) +
								   "set logscale z; set nologscale xy";
		break;
	  case 4:
		log_mode_cmd = sprintf("set xrange [%f:%f]; ",
					   min(XX), max(XX)) +
					   sprintf("set yrange [%f:%f]; ",
					   min(YY), max(YY)) +
					   "set logscale xy; set nologscale z";
		break;
	  case 5:
		log_mode_cmd = sprintf("set xrange [%f:%f]; ",
					   min(XX), max(XX)) +
					   sprintf("set zrange [%f:%f]; ",
					   min(ZZ), max(ZZ)) +
					   "set logscale xz; set nologscale y";
		break;
	  case 6:
		log_mode_cmd = sprintf("set yrange [%f:%f]; ",
					   min(YY), max(YY)) +
					   sprintf("set zrange [%f:%f]; ",
					   min(ZZ), max(ZZ)) +
					   "set logscale yz; set nologscale x";
		break;
	  case 7:
		log_mode_cmd = sprintf("set xrange [%f:%f]; ",
					   min(XX), max(XX)) +
					   sprintf("set yrange [%f:%f]; ",
					   min(YY), max(YY)) +
					   sprintf("set zrange [%f:%f]; ",
					   min(ZZ), max(ZZ)) +
					   "set logscale xyz";
		break;
	  default:
		error("mgplot3(): Incorrect log_mode\n");
		break;
	}
	mgplot_cmd(win, log_mode_cmd);

	switch (nargs) {
	case 4:
	  d3_mgplot(win, XX, YY, ZZ);
	  break;
	case 5:
	  d3_mgplot(win, XX, YY, ZZ, titles);
	  break;
	case 6:
	  d3_mgplot(win, XX, YY, ZZ, titles, cmds1);
	  break;
	case 7:
	  d3_mgplot(win, XX, YY, ZZ, titles, cmds1, cmds2);
	  break;
	}
}

Func void d3_mgplot(win, XX, YY, ZZ, titles, cmds1, cmds2, ...)
	 Integer win;
	 Array XX, YY, ZZ;
	 List titles;
	 List cmds1, cmds2;
{
	Integer i, j, id, m, n, fd, num, frame;
	String datafile, str, cmd, tit, cmd1, cmd2;

	if (nargs < 4 || 7 < nargs) {
		error("d3_mgplot(): Incorrect number of arguments.\n");
	}

	{m,n} = size(ZZ);

	if (nargs < 5) {
		 titles = {""} * m;
	}
	if (nargs < 6) {
		 cmds1 = {""} * m;
	}
	if (nargs < 7) {
		 cmds2 = {""} * m;
	}

	mgplot_init(win);

	if (mgplot_have_pipe()) {
		id = mgplot_win2id(win);
	} else {
		id = win;
	}

	frame = mgplot_multiplot(win);
	num = 0; 
	mgplot_data_num(id, frame, num+1);

	if (mgplot_long_filename()) {
		datafile = sprintf("mgplot-%d-w%d-f%d-l%d", PID, win, frame, num);
	} else {
		datafile = sprintf("w%df%dl1.dat%d", win, frame, num);
	}

	if ((fd = fopen(datafile, "w")) < 0) {
		 error("d3_mgplot(): Can't open " + datafile + "\n");
	}

	for (i = 1; i <= m; i++) {
		 for (j = 1; j <= n; j++) {
			  fprintf(fd, "%g %g %g\n", XX(i,j), YY(i,j), ZZ(i,j));
		 }
		 fprintf(fd, "\n\n");
	}
	fclose(fd);

	mgplot_cmd(win, "set parametric");

	str = "";
	for (i = 1; i <= m; i++) {
		 if (i <= length(titles)) {
			  tit = titles(i,String);
		 } else {
			  tit = sprintf("data-%d-%d", num, i);
		 }
		 if (i <= length(cmds1)) {
			  cmd1 = cmds1(i,String);
		 } else {
			  cmd1 = "";
		 }
		 if (i <= length(cmds2)) {
			  cmd2 = cmds2(i,String);
		 } else {
			  cmd2 = "";
		 }
		 
		cmd = sprintf("'%s' index %d %s t '%s' %s",
					  datafile, i-1, cmd1, tit, cmd2);
		if (length(str) == 0) {
			 str = cmd;
		} else {
			 str = str + ", " + cmd;
		}
	}
	str = "splot " + str;

	mgplot_plot_strings(win, frame, str);
	mgplot_out(win, str + "\n");

	if (mgplot_have_pipe() == 0 && mgplot_hold(win) == 0) {
		 mgplot_out(win, "plot");
	}
}

Func void mgplot3_logx(win, XX, YY, ZZ, titles, cmds1, cmds2, ...)
	 Integer win;
	 Array XX, YY, ZZ;
	 List titles;
	 List cmds1, cmds2;
{
	if (nargs < 4 || 7 < nargs) {
		error("mgplot3_logx(): Incorrect number of arguments.\n");
	}

	mgplot_log_mode(win,mgplot_multiplot(win),1);
	switch (nargs) {
	case 4:
		 mgplot3(win, XX, YY, ZZ);
		 break;
	case 5:
		 mgplot3(win, XX, YY, ZZ, titles);
		 break;
	case 6:
		 mgplot3(win, XX, YY, ZZ, titles, cmds1);
		 break;
	case 7:
		 mgplot3(win, XX, YY, ZZ, titles, cmds1, cmds2);
		 break;
	}
	mgplot_log_mode(win,mgplot_multiplot(win),0);
}

Func void mgplot3_logy(win, XX, YY, ZZ, titles, cmds1, cmds2, ...)
	 Integer win;
	 Array XX, YY, ZZ;
	 List titles;
	 List cmds1, cmds2;
{
	if (nargs < 4 || 7 < nargs) {
		error("mgplot3_logy(): Incorrect number of arguments.\n");
	}

	mgplot_log_mode(win,mgplot_multiplot(win),2);
	switch (nargs) {
	case 4:
		 mgplot3(win, XX, YY, ZZ);
		 break;
	case 5:
		 mgplot3(win, XX, YY, ZZ, titles);
		 break;
	case 6:
		 mgplot3(win, XX, YY, ZZ, titles, cmds1);
		 break;
	case 7:
		 mgplot3(win, XX, YY, ZZ, titles, cmds1, cmds2);
		 break;
	}
	mgplot_log_mode(win,mgplot_multiplot(win),0);
}

Func void mgplot3_logz(win, XX, YY, ZZ, titles, cmds1, cmds2, ...)
	 Integer win;
	 Array XX, YY, ZZ;
	 List titles;
	 List cmds1, cmds2;
{
	if (nargs < 4 || 7 < nargs) {
		error("mgplot3_logz(): Incorrect number of arguments.\n");
	}

	mgplot_log_mode(win,mgplot_multiplot(win),3);
	switch (nargs) {
	case 4:
		 mgplot3(win, XX, YY, ZZ);
		 break;
	case 5:
		 mgplot3(win, XX, YY, ZZ, titles);
		 break;
	case 6:
		 mgplot3(win, XX, YY, ZZ, titles, cmds1);
		 break;
	case 7:
		 mgplot3(win, XX, YY, ZZ, titles, cmds1, cmds2);
		 break;
	}
	mgplot_log_mode(win,mgplot_multiplot(win),0);
}

Func void mgplot3_logxy(win, XX, YY, ZZ, titles, cmds1, cmds2, ...)
	 Integer win;
	 Array XX, YY, ZZ;
	 List titles;
	 List cmds1, cmds2;
{
	if (nargs < 4 || 7 < nargs) {
		error("mgplot3_logxy(): Incorrect number of arguments.\n");
	}

	mgplot_log_mode(win,mgplot_multiplot(win),4);
	switch (nargs) {
	case 4:
		 mgplot3(win, XX, YY, ZZ);
		 break;
	case 5:
		 mgplot3(win, XX, YY, ZZ, titles);
		 break;
	case 6:
		 mgplot3(win, XX, YY, ZZ, titles, cmds1);
		 break;
	case 7:
		 mgplot3(win, XX, YY, ZZ, titles, cmds1, cmds2);
		 break;
	}
	mgplot_log_mode(win,mgplot_multiplot(win),0);
}

Func void mgplot3_logxz(win, XX, YY, ZZ, titles, cmds1, cmds2, ...)
	 Integer win;
	 Array XX, YY, ZZ;
	 List titles;
	 List cmds1, cmds2;
{
	if (nargs < 4 || 7 < nargs) {
		error("mgplot3_logxz(): Incorrect number of arguments.\n");
	}

	mgplot_log_mode(win,mgplot_multiplot(win),5);
	switch (nargs) {
	case 4:
		 mgplot3(win, XX, YY, ZZ);
		 break;
	case 5:
		 mgplot3(win, XX, YY, ZZ, titles);
		 break;
	case 6:
		 mgplot3(win, XX, YY, ZZ, titles, cmds1);
		 break;
	case 7:
		 mgplot3(win, XX, YY, ZZ, titles, cmds1, cmds2);
		 break;
	}
	mgplot_log_mode(win,mgplot_multiplot(win),0);
}

Func void mgplot3_logyz(win, XX, YY, ZZ, titles, cmds1, cmds2, ...)
	 Integer win;
	 Array XX, YY, ZZ;
	 List titles;
	 List cmds1, cmds2;
{
	if (nargs < 4 || 7 < nargs) {
		error("mgplot3_logyz(): Incorrect number of arguments.\n");
	}

	mgplot_log_mode(win,mgplot_multiplot(win),6);
	switch (nargs) {
	case 4:
		 mgplot3(win, XX, YY, ZZ);
		 break;
	case 5:
		 mgplot3(win, XX, YY, ZZ, titles);
		 break;
	case 6:
		 mgplot3(win, XX, YY, ZZ, titles, cmds1);
		 break;
	case 7:
		 mgplot3(win, XX, YY, ZZ, titles, cmds1, cmds2);
		 break;
	}
	mgplot_log_mode(win,mgplot_multiplot(win),0);
}

Func void mgplot3_logxyz(win, XX, YY, ZZ, titles, cmds1, cmds2, ...)
	 Integer win;
	 Array XX, YY, ZZ;
	 List titles;
	 List cmds1, cmds2;
{
	if (nargs < 4 || 7 < nargs) {
		error("mgplot3_logxyz(): Incorrect number of arguments.\n");
	}

	mgplot_log_mode(win,mgplot_multiplot(win),7);
	switch (nargs) {
	case 4:
		 mgplot3(win, XX, YY, ZZ);
		 break;
	case 5:
		 mgplot3(win, XX, YY, ZZ, titles);
		 break;
	case 6:
		 mgplot3(win, XX, YY, ZZ, titles, cmds1);
		 break;
	case 7:
		 mgplot3(win, XX, YY, ZZ, titles, cmds1, cmds2);
		 break;
	}
	mgplot_log_mode(win,mgplot_multiplot(win),0);
}

Func void mgplot3_surface(win, XX, YY, ZZ, title, cmd1, cmd2, ...)
	 Integer win;
	 Array XX, YY, ZZ;
	 String title;
	 String cmd1, cmd2;
{
	 Integer frame;
	 String log_mode_cmd;
	 void d3_mgplot_surface(...);

	if (nargs == 0) {
		return;
	}

	if ( ! (nargs == 2 || (4 <= nargs && nargs <= 7))) {
		 error("mgplot3_surface(): Incorrect number of arguments.\n");
	}

	if (win <= 0) {
		win = 1;
	}

	mgplot_init(win);
	mgplot_cur_win(win);

	if ((frame = mgplot_multiplot(win))) {
		mgplot_clear(win);
	}
	
	switch (mgplot_log_mode(win,frame)) {
	  case 0:
		log_mode_cmd = "set nologscale xyz";
		break;
	  case 1:
		   if (nargs == 2) {
				log_mode_cmd = "set logscale x; set nologscale yz";
		   } else {
				log_mode_cmd = sprintf("set xrange [%f:%f]; ",
									   min(XX), max(XX)) +
					 "set logscale x; set nologscale yz";
		   }
		break;
	  case 2:
		   if (nargs == 2) {
				log_mode_cmd = "set logscale y; set nologscale xz";
		   } else {
				log_mode_cmd = sprintf("set yrange [%f:%f]; ",
									   min(YY), max(YY)) +
					 "set logscale y; set nologscale xz";
		   }
		break;
	  case 3:
		   if (nargs == 2) {
				log_mode_cmd = sprintf("set zrange [%f:%f]; ",
									   min(XX), max(XX)) +
					 "set logscale z; set nologscale xy";
		   } else {
				log_mode_cmd = sprintf("set zrange [%f:%f]; ",
									   min(ZZ), max(ZZ)) +
					 "set logscale z; set nologscale xy";
		   }
		break;
	  case 4:
		   if (nargs == 2) {
				log_mode_cmd = "set logscale xy; set nologscale z";
		   } else {
				log_mode_cmd = sprintf("set xrange [%f:%f]; ",
									   min(XX), max(XX)) +
					 sprintf("set yrange [%f:%f]; ",
							 min(YY), max(YY)) +
					 "set logscale xy; set nologscale z";
		   }
		break;
	  case 5:
		   if (nargs == 2) {
				log_mode_cmd = sprintf("set zrange [%f:%f]; ",
							 min(XX), max(XX)) +
					   "set logscale xz; set nologscale y";
		   } else {
				log_mode_cmd = sprintf("set xrange [%f:%f]; ",
									   min(XX), max(XX)) +
					 sprintf("set zrange [%f:%f]; ",
							 min(ZZ), max(ZZ)) +
					   "set logscale xz; set nologscale y";
		   }
		break;
	  case 6:
		   if (nargs == 2) {
				log_mode_cmd = sprintf("set zrange [%f:%f]; ",
							 min(XX), max(XX)) +
					 "set logscale yz; set nologscale x";
		   } else {
				log_mode_cmd = sprintf("set yrange [%f:%f]; ",
									   min(YY), max(YY)) +
					 sprintf("set zrange [%f:%f]; ",
							 min(ZZ), max(ZZ)) +
					 "set logscale yz; set nologscale x";
		   }
		break;
	  case 7:
		   if (nargs == 2) {
				log_mode_cmd = sprintf("set zrange [%f:%f]; ",
							 min(XX), max(XX)) +
					 "set logscale xyz";
		   } else {
				log_mode_cmd = sprintf("set xrange [%f:%f]; ",
									   min(XX), max(XX)) +
					 sprintf("set yrange [%f:%f]; ",
							 min(YY), max(YY)) +
					 sprintf("set zrange [%f:%f]; ",
							 min(ZZ), max(ZZ)) +
					 "set logscale xyz";
		   }
		break;
	  default:
		error("mgplot3_surface(): Incorrect log_mode\n");
 		break;
	}
	mgplot_cmd(win, log_mode_cmd);

	switch (nargs) {
	case 2:
	  d3_mgplot_surface(win, XX);
	  break;
	case 4:
	  d3_mgplot_surface(win, XX, YY, ZZ);
	  break;
	case 5:
	  d3_mgplot_surface(win, XX, YY, ZZ, title);
	  break;
	case 6:
	  d3_mgplot_surface(win, XX, YY, ZZ, title, cmd1);
	  break;
	case 7:
	  d3_mgplot_surface(win, XX, YY, ZZ, title, cmd1, cmd2);
	  break;
	}
}


Func void d3_mgplot_surface(win, XX_, YY_, ZZ_, title, cmd1, cmd2, ...)
	 Integer win;
	 Array XX_, YY_, ZZ_;
	 String title;
	 String cmd1, cmd2;
{
	 Integer i, j, m, n, fd, id, frame, num;
	 String datafile, str;
	 Array XX, YY, ZZ;
	 
	 if ( ! (nargs == 2 || (4 <= nargs && nargs <= 7))) {
		  error("d3_mgplot_surface(): Incorrect number of arguments.\n");
	 }

	 {m,n} = size(XX_);
	 
	 if (nargs == 2) {
		  XX = Z(m,n);
		  for (i = 1; i <= m; i++) {
			   XX(i,:) = [1:n];
		  }
		  // revised at 2003.10.27
		  YY = Z(n,m);
		  for (i = 1; i <= n; i++) {
			   YY(i,:) = [1:m];
		  }
		  YY = trans(YY);
		  // revised at 2003.10.27
		  // YY = trans(XX);
		  ZZ = XX_;
	 } else {
		  XX = XX_;
		  YY = YY_;
		  ZZ = ZZ_;
	 }
	 
	 if (nargs < 5) {
		  title = "";
	 }
	 if (nargs < 6) {
		  cmd1 = "";
	 }
	 if (nargs < 7) {
		  cmd2 = "";
	 }
	 
	 mgplot_init(win);
	 
	 if (mgplot_have_pipe()) {
		  id = mgplot_win2id(win);
	 } else {
		  id = win;
	 }
	 
	 frame = mgplot_multiplot(win);
	 num = 0; 
	 mgplot_data_num(id, frame, num+1);
	 
	 
	 if (mgplot_long_filename()) {
		  datafile = sprintf("mgplot-%d-w%d-f%d-l%d", PID, win, frame, num);
	 } else {
		  datafile = sprintf("w%df%dl1.dat%d", win, frame, num);
	 }
	 
	 if ((fd = fopen(datafile, "w")) < 0) {
		  error("d3_mgplot_surface(): Can't open " + datafile + "\n");
	 }
	 
	 for (i = 1; i <= m; i++) {
		  for (j = 1; j <= n; j++) {
			   fprintf(fd, "%g %g %g\n", XX(i,j), YY(i,j), ZZ(i,j));
		  }
		  fprintf(fd, "\n");
	 }
	 fclose(fd);

	 mgplot_cmd(win, "set parametric");
	 mgplot_cmd(win, "set hidden3d");
	 
	 str = sprintf("'%s' %s t '%s' %s", datafile, cmd1, title, cmd2);
	 str = "splot " + str;
	 mgplot_plot_strings(win, frame, str);
	 mgplot_out(win, str + "\n");
	 
	 if (mgplot_have_pipe() == 0 && mgplot_hold(win) == 0) {
		  mgplot_out(win, "plot");
	 }
}

Func void mgplot3_logx_surface(win, XX, YY, ZZ, title, cmd1, cmd2, ...)
	 Integer win;
	 Array XX, YY, ZZ;
	 String title;
	 String cmd1, cmd2;
{
	 if ( ! (nargs == 2 || (4 <= nargs && nargs <= 7))) {
		  error("mgplot3_logx_surface(): Incorrect number of arguments.\n");
	 }
	 
	 mgplot_log_mode(win,mgplot_multiplot(win),1);
	 switch (nargs) {
	 case 2:
		  mgplot3_surface(win, XX);
		  break;
	 case 4:
		  mgplot3_surface(win, XX, YY, ZZ);
		  break;
	 case 5:
		  mgplot3_surface(win, XX, YY, ZZ, title);
		  break;
	 case 6:
		  mgplot3_surface(win, XX, YY, ZZ, title, cmd1);
		  break;
	 case 7:
		  mgplot3_surface(win, XX, YY, ZZ, title, cmd1, cmd2);
		  break;
	 }
	 mgplot_log_mode(win,mgplot_multiplot(win),0);
}

Func void mgplot3_logy_surface(win, XX, YY, ZZ, title, cmd1, cmd2, ...)
	 Integer win;
	 Array XX, YY, ZZ;
	 String title;
	 String cmd1, cmd2;
{
	 if ( ! (nargs == 2 || (4 <= nargs && nargs <= 7))) {
		  error("mgplot3_logy_surface(): Incorrect number of arguments.\n");
	 }

	mgplot_log_mode(win,mgplot_multiplot(win),2);
	switch (nargs) {
	case 2:
		 mgplot3_surface(win, XX);
		 break;
	case 4:
		 mgplot3_surface(win, XX, YY, ZZ);
		 break;
	case 5:
		 mgplot3_surface(win, XX, YY, ZZ, title);
		 break;
	case 6:
		 mgplot3_surface(win, XX, YY, ZZ, title, cmd1);
		 break;
	case 7:
		 mgplot3_surface(win, XX, YY, ZZ, title, cmd1, cmd2);
		 break;
	}
	mgplot_log_mode(win,mgplot_multiplot(win),0);
}

Func void mgplot3_logz_surface(win, XX, YY, ZZ, title, cmd1, cmd2, ...)
	 Integer win;
	 Array XX, YY, ZZ;
	 String title;
	 String cmd1, cmd2;
{
	 if ( ! (nargs == 2 || (4 <= nargs && nargs <= 7))) {
		  error("mgplot3_logz_surface(): Incorrect number of arguments.\n");
	 }

	mgplot_log_mode(win,mgplot_multiplot(win),3);
	switch (nargs) {
	case 2:
		 mgplot3_surface(win, XX);
		 break;
	case 4:
		 mgplot3_surface(win, XX, YY, ZZ);
		 break;
	case 5:
		 mgplot3_surface(win, XX, YY, ZZ, title);
		 break;
	case 6:
		 mgplot3_surface(win, XX, YY, ZZ, title, cmd1);
		 break;
	case 7:
		 mgplot3_surface(win, XX, YY, ZZ, title, cmd1, cmd2);
		 break;
	}
	mgplot_log_mode(win,mgplot_multiplot(win),0);
}

Func void mgplot3_logxy_surface(win, XX, YY, ZZ, title, cmd1, cmd2, ...)
	 Integer win;
	 Array XX, YY, ZZ;
	 String title;
	 String cmd1, cmd2;
{
	 if ( ! (nargs == 2 || (4 <= nargs && nargs <= 7))) {
		  error("mgplot3_logxy_surface(): Incorrect number of arguments.\n");
	 }

	mgplot_log_mode(win,mgplot_multiplot(win),4);
	switch (nargs) {
	case 2:
		 mgplot3_surface(win, XX);
		 break;
	case 4:
		 mgplot3_surface(win, XX, YY, ZZ);
		 break;
	case 5:
		 mgplot3_surface(win, XX, YY, ZZ, title);
		 break;
	case 6:
		 mgplot3_surface(win, XX, YY, ZZ, title, cmd1);
		 break;
	case 7:
		 mgplot3_surface(win, XX, YY, ZZ, title, cmd1, cmd2);
		 break;
	}
	mgplot_log_mode(win,mgplot_multiplot(win),0);
}

Func void mgplot3_logxz_surface(win, XX, YY, ZZ, title, cmd1, cmd2, ...)
	 Integer win;
	 Array XX, YY, ZZ;
	 String title;
	 String cmd1, cmd2;
{
	 if ( ! (nargs == 2 || (4 <= nargs && nargs <= 7))) {
		  error("mgplot3_logxz_surface(): Incorrect number of arguments.\n");
	 }

	mgplot_log_mode(win,mgplot_multiplot(win),5);
	switch (nargs) {
	case 2:
		 mgplot3_surface(win, XX);
		 break;
	case 4:
		 mgplot3_surface(win, XX, YY, ZZ);
		 break;
	case 5:
		 mgplot3_surface(win, XX, YY, ZZ, title);
		 break;
	case 6:
		 mgplot3_surface(win, XX, YY, ZZ, title, cmd1);
		 break;
	case 7:
		 mgplot3_surface(win, XX, YY, ZZ, title, cmd1, cmd2);
		 break;
	}
	mgplot_log_mode(win,mgplot_multiplot(win),0);
}

Func void mgplot3_logyz_surface(win, XX, YY, ZZ, title, cmd1, cmd2, ...)
	 Integer win;
	 Array XX, YY, ZZ;
	 String title;
	 String cmd1, cmd2;
{
	 if ( ! (nargs == 2 || (4 <= nargs && nargs <= 7))) {
		  error("mgplot3_logyz_surface(): Incorrect number of arguments.\n");
	 }

	mgplot_log_mode(win,mgplot_multiplot(win),6);
	switch (nargs) {
	case 2:
		 mgplot3_surface(win, XX);
		 break;
	case 4:
		 mgplot3_surface(win, XX, YY, ZZ);
		 break;
	case 5:
		 mgplot3_surface(win, XX, YY, ZZ, title);
		 break;
	case 6:
		 mgplot3_surface(win, XX, YY, ZZ, title, cmd1);
		 break;
	case 7:
		 mgplot3_surface(win, XX, YY, ZZ, title, cmd1, cmd2);
		 break;
	}
	mgplot_log_mode(win,mgplot_multiplot(win),0);
}

Func void mgplot3_logxyz_surface(win, XX, YY, ZZ, title, cmd1, cmd2, ...)
	 Integer win;
	 Array XX, YY, ZZ;
	 String title;
	 String cmd1, cmd2;
{
	 if ( ! (nargs == 2 || (4 <= nargs && nargs <= 7))) {
		  error("mgplot3_logxyz_surface(): Incorrect number of arguments.\n");
	 }

	mgplot_log_mode(win,mgplot_multiplot(win),7);
	switch (nargs) {
	case 2:
		 mgplot3_surface(win, XX);
		 break;
	case 4:
		 mgplot3_surface(win, XX, YY, ZZ);
		 break;
	case 5:
		 mgplot3_surface(win, XX, YY, ZZ, title);
		 break;
	case 6:
		 mgplot3_surface(win, XX, YY, ZZ, title, cmd1);
		 break;
	case 7:
		 mgplot3_surface(win, XX, YY, ZZ, title, cmd1, cmd2);
		 break;
	}
	mgplot_log_mode(win,mgplot_multiplot(win),0);
}
