
/* -*- MaTX -*-
 *
 *  NAME
 *      tfn2zp() - Transfer function to zero-pole conversion
 *
 *  SYNOPSIS
 *      {z,p,k} = tfn2zp(g)
 *         CoMatrix z,p;
 *         Matrix k;
 *         Rational g;
 *
 *  DESCRIPTION
 *       tf2zp(g) finds the zeros, poles, and gains of the system whose
 *       transfer function is given by
 *
 *                        (s-z1)(s-z2)...(s-zn)
 *              g(s) =  k ---------------------
 *                        (s-p1)(s-p2)...(s-pn)
 *
 *      z and p contains zeros and poles, and k contains the gains for 
 *      each numerator of transfer function.
 *
 *  SEE ALSO
 *      tfn2tf, tfn2tfm, tfn2ss, and zp2tfn
 */

Func List tfn2zp(g)
	Rational g;
{
	CoMatrix z,p;
	Matrix NUM, den, k;

	{NUM,den} = tfn2tf(g);
	{z,p,k} = tf2zp(NUM, den);

	return {z,p,k};
}
