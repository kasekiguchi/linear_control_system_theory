
/* -* MaTX -*-
 *
 *  NAME
 *      c2d() - Continuous-time to discrete-time transformation
 *
 *  SYNOPSIS
 *      {Ad,Bd} = c2d(A,B,dt)
 *         Matrix Ad,Bd;
 *         Matrix A,B;
 *         Real dt;
 *
 *  DESCRIPTION
 *       c2d(A,B,dt) converts the continuous-time system:
 *      	.
 *      	x = Ax + Bu
 *
 *       to the discrete-time system:
 *
 *      	x[n+1] = Ad * x[n] + Bd * u[n]
 *
 *       assuming a zero-order hold on the inputs and sampling interval dt.
 *
 *      Discretize() is obsolite.
 *
 *  SEE ALSO
 *      d2c
 */

Func List c2d(A,B,dt)
	Matrix A,B;
	Real dt;
{
	Integer m,n;
	String msg;
	Matrix Bd, Ad, S;

	if (length((msg = abcdchk(A, B))) > 0) {
		error("c2d(): " + msg);
	}

	n = Rows(A);
	m = Cols(B);
	S = exp([[  A,  B ]
			 [Z(m,m+n)]]*dt);

	Ad = S(1:n,1:n);
	Bd = S(1:n,n+1:n+m);

	return {Ad,Bd};
}

Func List Discretize(A,B,dt)
	Matrix A,B;
	Real dt;
{
	return c2d(A,B,dt);
}
