
/* -*- MaTX -*-
 *
 *  NAME
 *      faddeev() - Characteristic polynomial by Faddeev's algorithm
 *
 *  SYNOPSIS
 *      {NN,dd} = faddeev(A)
 *        Matrix NN;
 *        Polynomial dd;
 *        Matrix A;
 *
 *  DESCRIPTION
 *      fadeev(A) returns the numerator and of denominator of the 
 *      resolvent matrix
 *
 *          NN(s)   NN_(n-1) s^(n-1) + ... + NN1 s + NN0                   -1
 *          ----- = -------------------------------------------  = (s*I - A)
 *          dd(s)   s^n + dd_(n-1) s^(n-1) + ... + dd1 s + dd0
 *
 *      of matrix A. 
 *
 *      NN contains the coefficients of numerator.
 *
 *          NN = [NN_0, NN_1, ..., NN_(n-1)]
 *
 *  SEE ALSO
 *      makepoly, resolvent, and charpoly
 */

Func List faddeev(A)
	Matrix	A;
{
	Integer	i, n;
	Polynomial dd;
	Matrix NN, AA;

	n = Rows(A);
	AA = (A,:);
	NN = Z(1, n, AA);
	dd = Polynomial((Z(1,n+1),:));

	dd(n) = 1.0;
	
	if (version() == 4) {
		NN(0, n-1, AA) = I(n);
	} else {
		NN(1, n, AA) = I(n);
	}
	dd(n-1) = - trace(AA);
	
	if (version() == 4) {
		for (i = n-2; i >= 0; i--) {
			NN(0, i, AA) = AA*NN(0, i+1, AA) + dd(i+1)*I(n);
			dd(i) = - trace(AA*NN(0, i, AA)) / (n - i);
		}
	} else {
		for (i = n-2; i >= 0; i--) {
			NN(1, i+1, AA) = AA*NN(1, i+2, AA) + dd(i+1)*I(n);
			dd(i) = - trace(AA*NN(1, i+1, AA)) / (n - i);
		}
	}

	if (isreal(A)) {
		return {Re(NN), dd};
	} else {
		return {NN, dd};
	}
}
