
/* -*- MaTX -*-
 *
 *  NAME
 *      tfm2tf() - Transfer function matrix to transfer function conversion
 *
 *  SYNOPSIS
 *     {NUM,den} = tfm2tf(G)
 *        Matrix NUM, den;
 *        RaMatrix G;
 *
 *     {NUM,den} = tfm2tf(G,i)
 *        Matrix NUM, den;
 *        RaMatrix G;
 *        Integer i;
 *
 *  DESCRIPTION
 *      ss2tf(G,i) returns the numerator coefficients NUM and the
 *      denominator coefficients den of the transfer function matrix
 *
 *                  NUM(s) 
 *         G(s) = --------
 *                  den(s)
 *
 *      from the i'th input.  
 *
 *  SEE ALSO
 *      tfm2ss, tfm2zp, tfm2tfn, tf2tfm
 */

Func List tfm2tf(G,i, ...)
	RaMatrix G;
	Integer i;
{
	Matrix A,B,C,D,NUM,den;

	error(nargchk(1, 2, nargs, "tfm2tf"));
	
	if (nargs == 1) {
		i = 1;
	}

	{A,B,C,D} = tfm2ss(G,i);
	{NUM,den} = ss2tf(A,B,C,D,i);
	return {NUM,den};
}
