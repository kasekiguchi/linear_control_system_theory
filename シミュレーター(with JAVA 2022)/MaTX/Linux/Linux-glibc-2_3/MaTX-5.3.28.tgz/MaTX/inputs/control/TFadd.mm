
/* -*- MaTX -*-
 *
 *  NAME
 *      TFadd() - Parallel connection of two state-space systems
 *
 *  SYNOPSIS
 *      {A,B,C,D} = TFadd(S1, S2)
 *         Matrix A,B,C,D;
 *         List S1, S2;
 *         S1 = {A1,B1,C1,D1}
 *         S2 = {A2,B2,C2,D2}
 *
 *  DESCRIPTION
 *      TFadd produces a state-space system consisting of the add connection
 *      of systems 1 and 2 such that Y = Y1 + Y2.  The resulting system is:
 *      	 .
 *      	|x1| = |A1 0| |x1| + |B1||u|
 *      	|x2|   |0 A2| |x2| + |B2|
 *
 *      	|y| = y1+y2 = |C1 C2| |x1| + |D1 + D2| |u|
 *                                |x2|
 *            G = G1 + G2
 *
 *                  +----+     
 *              +-->| G1 |--+  
 *              |   +----+  |	    
 *              |           + v 
 *          ----+     	    o---->
 *              |           + ^ 
 *              |   +----+  |	 
 *        	    +-->| G2 |--+ 
 *        	        +----+     
 *  SEE ALSO
 *      parallel, TFsub and, TFmul
 */

Func List TFadd(S1, S2)
	List S1, S2;
{
	Matrix a1, b1, c1, d1;
	Matrix a2, b2, c2, d2;
	Matrix A, B, C, D;

	{a1, b1, c1, d1} = S1;
	{a2, b2, c2, d2} = S2;

	if (Cols(b1) != Cols(b2)) {
		error("TFadd(): Input number is incorrect.\n");
	} else if (Rows(c1) != Rows(c2)) {
		error("TFadd(): Output number is incorrect.\n");
	}

	A = diag(a1, a2);
	B = [[b1]
		 [b2]];
	C = [c1 c2];
	D = [d1 + d2];

	return {A, B, C, D};
}

