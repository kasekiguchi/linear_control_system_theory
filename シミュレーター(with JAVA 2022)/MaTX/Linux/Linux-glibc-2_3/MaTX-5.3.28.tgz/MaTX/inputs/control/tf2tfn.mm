
/* -*- MaTX -*-
 *
 *  NAME
 *      tf2tfn() -  Transfer function to transfer function conversion
 *
 *  SYNOPSIS
 *      g = tf2tfn(NUM,den)
 *         Rational g;
 *         Matrix NUM,den;
 *
 *      g = tf2tfn(NUM,den,i)
 *         Rational g;
 *         Matrix NUM,den;
 *         Integer i;
 *
 *  DESCRIPTION
 *      tf2tfn(num,den) returns the transfer function
 *
 *                  num(s) 
 *          g(s) = -------
 *                  den(s)
 *
 *      for the SISO system, given the coefficients of the numerator num
 *      and coefficients of the denominator den.
 *
 *      tf2tfn(NUM,den,i) returns the transfer function for the i-th
 *      output of the SIMO system.
 *
 *  SEE ALSO
 *      tf2tfm, tf2ss, tf2zp, and tfn2tf
 */

Func Rational tf2tfn(NUM, den, i, ...)
	Matrix NUM, den;
	Integer i;
{
	Rational g;
	Polynomial nn, dd;

	if (nargs < 2 || 3 < nargs) {
		 error("tf2tfn(): Incorrect number of arguments\n");
	}

	if (nargs == 2) {
		 i = 1;
	}

	if (version() == 4) {
		nn = Polynomial(fliplr(NUM(i,:)));
		dd = Polynomial(fliplr(den));
	} else {
		nn = Polynomial(NUM(i,:));
		dd = Polynomial(den);
	}

	g = nn/dd;

	return g;
}
