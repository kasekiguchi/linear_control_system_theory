
/* -*- MaTX -*-
 *
 *  NAME
 *      zp2tfn() - Zero-pole to transfer function conversion
 *
 *  SYNOPSIS
 *      g = zp2tf(z,p,k,i)
 *         Rational g;
 *         CoMatrix z,p;
 *         Matrix k;
 *         ...
 *         i = 1;
 *
 *  DESCRIPTION
 *      zp2tfn(z,p,k) returns the transfer function 
 *
 *                   (s-z1)(s-z2)...(s-zn)
 *         g(s) =  k ---------------------
 *                   (s-p1)(s-p2)...(s-pn)
 *
 *      for the SISO system, given a set of pole and zero in p and z,
 *      and each gain of the numerator of the transfer function in k.
 *
 *      zp2tfn(z,p,k,i) returns the transfer function for the i-th
 *      output of the SIMO system.
 *
 *  SEE ALSO  
 *      zp2tf, zp2tfm, zp2ss, and tfn2zp
 */

Func Rational zp2tfn(z,p,k,i,...)
	CoMatrix z,p;
	Matrix k;
	Integer i;
{
	Rational g;
	Matrix num,den;

	if (nargs < 3 || 4 < nargs) {
		 error("zp2tfn(): Incorrect number of arguments\n");
	}

	if (nargs == 3) {
		 i = 1;
	}

	{num,den} = zp2tf(z(:,i),p,[k(i)]);
	g = tf2tfn(num,den);
	return g;
}
