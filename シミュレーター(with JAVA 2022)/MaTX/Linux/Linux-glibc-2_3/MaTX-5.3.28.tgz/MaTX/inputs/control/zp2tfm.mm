
/* -*- MaTX -*-
 *
 *  NAME
 *      zp2tfm() - Zero-pole to transfer function matrix conversion
 *
 *  SYNOPSIS  
 *      G = zp2tfm(z,p,k)
 *        RaMatrix G;
 *        CoMatrix z,p;
 *        Matrix k;
 *
 *  DESCRIPTION
 *      zp2tfm(z,p,k) returns the transfer function matrix
 *
 *                  (s-z1)(s-z2)...(s-zn)
 *        G(s) =  k ---------------------
 *                  (s-p1)(s-p2)...(s-pn)
 *
 *      for SIMO systems, given a set of pole and zero locations in p and z,
 *      and the gains for each numerator of transfer function in k.
 *
 *  SEE ALSO
 *      zp2tf, zp2tfn, zp2ss, tfm2zp
 */

Func RaMatrix zp2tfm(z,p,k)
	CoMatrix z,p;
	Matrix k;
{
	Matrix den,NUM;
	RaMatrix G;

	{NUM,den} = zp2tf(z,p,k);
	G = tf2tfm(NUM,den);
	return G;
}
