
/* -*- MaTX -*-
 *
 *  NAME
 *      TFinv() -  Inverse a state-space system
 *
 *  SYNOPSIS
 *     {A,B,C,D} = TFinv(S1)
 *        Matrix A,B,C,D;
 *        List S1;
 *        S1 = {A1,B1,C1,D1}
 *
 *  DESCRIPTION
 *      TFinv() produces a state-space system of the inverse of system 1
 *      such that S = S1^(-1). 
 *
 *  SEE ALSO
 *      TFmul
 */

Func List TFinv(S1)
	List S1;
{
	Matrix a1, b1, c1, d1;
	Matrix A, B, C, D;

	{a1, b1, c1, d1} = S1;

	A = a1 - b1*(d1\c1);
	B = b1*d1~;
	C = - d1\c1;
	D = d1~;

	return {A, B, C, D};
}

