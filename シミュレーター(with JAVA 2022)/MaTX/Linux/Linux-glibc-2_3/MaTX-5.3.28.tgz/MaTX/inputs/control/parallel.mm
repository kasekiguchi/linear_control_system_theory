
/* -*- MaTX -*-
 *
 *  NAME
 *      paralell() -  Parallel connection of two systems
 *
 *  SYNOPSIS
 *     {A,B,C,D} = parallel(A1,B1,C1,D1,A2,B2,C2,D2)
 *        Matrix A,B,C,D;
 *        Matrix A1,B1,C1,D1,A2,B2,C2,D2
 *
 *  DESCRIPTION
 *       parallel() generates a paralle connected system consisting of 
 *       system-1 
 *          .
 *          x1 = A1 x1 + B1 u1
 *          y1 = C1 x1 + D1 u1
 *
 *       and system-2 
 *          .
 *          x2 = A2 x2 + B2 u2
 *          y2 = C2 x2 + D2 u2
 *
 *       such that y = y1 + y2.  The resulting system is:
 *      	 .
 *          [x1] = [A1 0] [x1] + [B1 0]
 *          [x2]   [0 A2] [x2] + [0 B2]
 *
 *      	 y = y1 + y2 = [C1 C2] [x1] + [D1 D2] [u1]
 *                                 [x2]           [u2]
 *  SEE ALSO
 *      series and TFadd
 */

Func List parallel(A1,B1,C1,D1,A2,B2,C2,D2)
	Matrix A1,B1,C1,D1,A2,B2,C2,D2;
{
	Matrix A,B,C,D;
	String msg;

	if (length((msg = abcdchk(A1, B1, C1, D1))) > 0) {
		error("parallel(): " + msg);
	}
	if (length((msg = abcdchk(A2, B2, C2, D2))) > 0) {
		error("parallel(): " + msg);
	}

	A = diag(A1,A2);
	B = diag(B1,B2);
	C = [C1 C2];
	D = [D1 D2];

	return {A,B,C,D};
}
