
/* -*- MaTX -*-
 *
 *  NAME
 *      tfn2tf() -  Transfer function to transfer function conversion
 *
 *  SYNOPSIS
 *      {num,den} = tfn2tf(g)
 *         Matrix num,den;
 *         Rational g;
 *
 *  DESCRIPTION
 *      tfn2tf(g) returns coefficients of the numerator num
 *      and coefficients of the denominator den of the transfer function
 *
 *                 num(s)
 *          g(s) = ------
 *                 den(s)
 *
 *      for of the given system.
 *
 *  SEE ALSO
 *      tfn2tfm, tfn2zp, tfn2ss, and tf2tfn
 */

Func List tfn2tf(g)
	Rational g;
{
	Matrix num,den;
	
	if (version() == 4) {
		num = fliplr(Matrix(Nu(g)));
		den = fliplr(Matrix(De(g)));
	} else {
		num = Matrix(Nu(g));
		den = Matrix(De(g));
	}
	
	return {num,den};
}
