
/* -*- MaTX -*-
 *
 *  NAME
 *      ltifr() - Frequency response of LTI system
 *
 *  SYNOPSIS
 *      G = ltifr(A,B,s)
 *         CoArray G;
 *         Matrix A, B;
 *         CoArray s;
 *
 *  DESCRIPTION
 *      ltifr() calculates the freqency response of LTI, i.e.,
 *
 *        (s*I - A) \ B
 *
 *      s must contain the complex numbers at which the equation is 
 *      to be evaluated.
 *
 *  SEE ALSO
 *      ltitr
 */

Func CoMatrix ltifr(A, B, s_)
	Matrix A;
	Matrix B;
	CoMatrix s_;
{
	Integer i, n, m;
	CoMatrix G, s;
	String msg;

	if (length((msg = abcdchk(A, B))) > 0) {
		error("ltifr(): " + msg);
	}
	
	if (Rows(s_) > Cols(s_)) {
		s = trans(s_);
	} else {
		s = s_;
	}

	n = Rows(A);
	m = Cols(B);
	G = Z(n, m, s);

	for (i = 1; i <= length(s); i++) {
		G(:,(i-1)*m+1:i*m) = (s(i)*I(A) - A) \ B;
	}

	return G;
}
