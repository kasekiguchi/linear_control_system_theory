
/* -*- MaTX -*-
 *
 *  NAME
 *      tfn2tfm() -  Transfer function to transfer function matrix conversion
 *
 *  SYNOPSIS
 *      G = tfn2tfm(g)
 *         RaMatrix G;
 *         Rational g;
 *
 *  DESCRIPTION
 *      tf2tfm(g) returns the transfer function matrix representation
 *      of the system, whose transfer function is g.
 *
 *  SEE ALSO
 *      tfn2tf, tfn2ss, tfn2zp, and tfm2tfn
 */

Func RaMatrix tfn2tfm(g)
	Rational g;
{
	return [g];
}
