
/* -*- MaTX -*-
 *
 *  NAME
 *      dlqe() - Discrete-time linear quadratic estimator
 *
 *  SYNOPSIS
 *      {L,M,P} = dlqe(A,G,C,Q,R)
 *         Matrix L,M,P;
 *         Matrix A,G,C,Q,R;
 *
 *  DESCRIPTION
 *       Given the discrete-time system:
 *
 *         x[n+1] = Ax[n] + Bu[n] + Gw[n]
 *         z[n]   = Cx[n] + Du[n] +  v[n]
 *
 *       with process noise and measurement noise covariances:
 *
 *         E[w] = E[v] = 0,  E[ww'] = Q,  E[vv'] = R
 *
 *       dlqe() returns the gain matrix L of the Kalman filter
 *  	      		
 *         xb[n+1] = A xh[n] + B u[n]
 *           xh[n] = xb[n] + L(z[n] - H xb[n] - D u[n])
 *
 *       which generates an LQG optimal estimate of x.
 *
 *       dlqe() also returns the Riccati equation solution M and the 
 *       estimate error covariance P.
 *
 *  SEE ALSO
 *      lqe and dlqr
 */

Func List dlqe(A,G,C,Q,R)
	Matrix A,G,C,Q,R;
{
	Matrix L,M,P,K,S;

	{K,S} = dlqr(A#, C#, G*Q*G#, R);
	M = S#;
	L = S*C#/(C*S*C# + R);
	P = A \ (M - G*Q*G#)/A#;

	return {L,M,P};
}
