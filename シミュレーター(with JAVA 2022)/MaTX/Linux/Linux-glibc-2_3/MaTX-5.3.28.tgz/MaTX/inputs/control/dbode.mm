
/* -*- MaTX -*-
 *
 *  NAME
 *      dbode_ss()      - Discrete-time Bode response 
 *      dbode_plot_ss() - Plot discrete-time Bode response
 *
 *  SYNOPSIS
 *      {Mag,Phase,w} = dbode_ss(A,B,C,D,dt)
 *          Array Mag, Phase;
 *          Matrix A,B,C,D;
 *          Real dt;
 *
 *      {Mag,Phase,w} = dbode_ss(A,B,C,D,dt,iu)
 *          Array Mag, Phase;
 *          Matrix A,B,C,D;
 *          Real dt;
 *          Integer iu;
 *
 *      {Mag,Phase,w} = dbode_ss(A,B,C,D,dt,iu,w)
 *          Array Mag, Phase;
 *          Matrix A,B,C,D;
 *          Real dt;
 *          Integer iu;
 *          Array w;
 *
 *      {mag,phase,w} = dbode_tf(num,den,dt)
 *         Array mag,phase;
 *         Array w;
 *         Matrix num, den;
 *         Real dt;
 *
 *      {mag,phase,w} = dbode_tf(num,den,dt,w)
 *         Array mag,phase;
 *         Array w;
 *         Matrix num,den;
 *         Real dt;
 *
 *      {mag,phase,w} = dbode_tfn(g,dt)
 *         Array mag,phase;
 *         Arrwy w;
 *         Rational g;
 *         Real dt;
 *
 *      {mag,phase,w} = dbode_tfn(g,dt,w)
 *         Array mag,phase;
 *         Array w;
 *         Rational g;
 *         Real dt;
 *
 *      {mag,phase,w} = dbode_tfm(G,dt)
 *         Array mag, phase;
 *         Array w;
 *         RaMatrix G;
 *         Real dt;
 *
 *      {mag,phase,w} = dbode_tfm(G,dt,iu)
 *         Array mag, phase;
 *         Array w;
 *         RaMatrix G;
 *         Real dt;
 *         Integer iu;
 *
 *      {mag,phase,w} = dbode_tfm(G,dt,iu,w)
 *         Array mag, phase;
 *         Array w;
 *         RaMatrix G;
 *         Real dt;
 *         Integer iu;
 *
 *      dbode_plot_ss(A,B,C,D,dt)
 *          Matrix A,B,C,D;
 *          Real dt;
 *
 *      dbode_plot_ss(A,B,C,D,dt,iu)
 *          Matrix A,B,C,D;
 *          Real dt;
 *          Integer iu;
 *
 *      dbode_plot_ss(A,B,C,D,dt,iu,w)
 *          Matrix A,B,C,D;
 *          Real dt;
 *          Integer iu;
 *          Array w;
 *
 *      dbode_plot_tf(num,den,dt)
 *         Matrix num, den;
 *         Real dt;
 *
 *      dbode_plot_tf(num,den,dt,w)
 *         Matrix num,den;
 *         Real dt;
 *         Array w;
 *
 *      dbode_plot_tfn(g,dt)
 *         Rational g;
 *         Real dt;
 *
 *      dbode_plot_tfn(g,dt,w)
 *         Rational g;
 *         Real dt;
 *         Array w;
 *
 *      dbode_plot_tfm(G,dt)
 *         RaMatrix G;
 *         Real dt;
 *
 *      dbode_plot_tfm(G,dt,iu)
 *         RaMatrix G;
 *         Real dt;
 *         Integer iu;
 *
 *      dbode_plot_tfm(G,dt,iu,w)
 *         RaMatrix G;
 *         Real dt;
 *         Integer iu;
 *         Array w;
 *
 *  DESCRIPTION
 *       dbode_ss() calculates the frequency response of the system:
 *
 *         x[n+1] = Ax[n] + Bu[n]                     -1
 *         y[n]   = Cx[n] + Du[n]        G(z) = C(zI-A) B + D
 *
 *         mag(w) = abs(G(exp(jw))),   phase(w) = angle(G(exp(jw)))
 *
 *       from the iu'th input.  dt is the sampling interval. w must 
 *       contain the frequencies (in radians/s), at which the transfer function
 *       is to be evaluated.
 *
 *       dbode_ss() returns Mag (absolute value) and Phase (in degrees) 
 *       with (# of outputs)-by-(length(w)).
 *
 *       dbode_plot_xx() plots gain (absolute value) and phase (in degree).
 *
 *  SEE ALSO
 *       logspace and bode
 */

Func List dbode(a, b, c, d, dt, iu, w, ...)
	Matrix a, b, c, d;
	Real dt;
	Integer iu;
	Array w;
{
	Array Mag, Phase, w2;

	error(nargchk(5, 7, nargs, "dbode"));

	if (nargs == 5) {
		{Mag,Phase,w2} = dbode_ss(a,b,c,d,dt);
	} else if (nargs == 6) {
		{Mag,Phase,w2} = dbode_ss(a,b,c,d,dt,iu);
	} else {
		{Mag,Phase,w2} = dbode_ss(a,b,c,d,dt,iu,w);
	}
	
	return {Mag,Phase,w2};
}

Func List dbode_ss(a, b, c, d, dt, iu, w, ...)
	Matrix a, b, c, d;
	Real dt;
	Integer iu;
	Array w;
{
	Integer p, nw;
	Complex j;
	String msg;
	Matrix A, B, C, D, H, T;
	Array Mag, Phase, G;

	error(nargchk(4, 7, nargs, "dbode_ss"));

	if (length((msg = abcdchk(a, b, c, d))) > 0) {
		error("dbode_ss(): " + msg);
	}

	if (nargs < 5) {
		dt = 1.0;
	}
	if (nargs < 6) {
		iu = 1;
	}
	if (nargs < 7) {
		w = logspace(-2.0, 3.0);
	}
	
	j = (0,1);
	p = Rows(c);
	nw = Cols(w);

	/// Balance A
	{T, A} = balance(a);
	B = T \ b;
	C = c * T;

	{H, A} = hess(A);
	B = H# * B(:,iu);
	C = C * H;
	D = d(:,iu);

	// Frequency response
	G = ltifr(A, B, exp(j*w*dt));
	G = C*Matrix(G) + vec2diag(D)*ONE(p,nw);

//	Mag = 20*log10(abs(G));
	Mag = abs(G);
	Phase = 180/PI*unwrap_row(Im(log(G)));

	return {Mag, Phase, w};
}

Func List dbode_tf(num, den, dt, w, ...)
	Matrix num, den;
	Real dt;
	Array w;
{
	Rational g;
	Array gain, phase_;

	error(nargchk(2, 3, nargs, "dbode_tf"));

	g = tf2tfn(num, den);
	
	if (nargs == 2) {
		{gain, phase_, w} = dbode_tfn(g, dt);
	} else {
		{gain, phase_, w} = dbode_tfn(g, dt, w);
	}

	return {gain, phase_, w};
}

Func List dbode_tfn(g, dt, w, ...)
	Rational g;
	Real dt;
	Array w;
{
	Complex j;
	Array data, gain, phase_;
	Index idx;

	error(nargchk(2, 3, nargs, "dbode_tfn"));

	if (nargs == 2) {
		w = logspace(-2.0, 3.0);
	}

	j = (0,1);
	data = eval(g, exp(j*w*dt));

	gain = abs(data);
//	gain = 20*log10(abs(data));
	phase_ = 180/PI*unwrap_row(Im(log(data)));

    // Correct phase for plants with integrators by subtracting 360 deg
	idx = find(phase_ .> 0 && eval(De(g), 0*w) .== 0);
	phase_(idx) = phase_(idx) .- 360;

	return {gain, phase_, w};
}

Func List dbode_tfm(G, dt, iu, w, ...)
	RaMatrix G;
	Real dt;
	Integer iu;
	Array w;
{
	Complex j;
	Array data, gain, phase_;
	Index idx;

	error(nargchk(2, 4, nargs, "dbode_tfm"));
	
	if (nargs < 3) {
		iu = 1;
	}
	if (nargs < 4) {
		w = logspace(-2.0, 3.0);
	}

	j = (0,1);
	data = eval(G, exp(j*w*dt));

	gain = abs(data);
//	gain = 20*log10(abs(data));
	phase_ = 180/PI*unwrap_row(Im(log(data)));

	return {gain, phase_, w};
}

Func void dbode_plot_ss(A, B, C, D, dt, iu, w, ...)
	Matrix A, B, C, D;
	Real dt;
	Integer iu;
	Array w;
{
	Integer i, p, win;
	Array gain, phase, dB0, deg180;
	List name1, name2;
	
	if (nargs < 4 || 7 < nargs) {
		error("dbode_plot_ss(): Incorrect number of arguments.\n");
	}
	if (nargs < 5) {
		iu = 1;
	}
	if (nargs < 6) {
		w = logspace(-2.0, 3.0);
	}
	if (nargs < 7) {
		dt = 1.0;
	}

    dB0 = 0.00001*Z(w);
    deg180 = -180*ONE(w);
	{gain, phase} = dbode_ss(A, B, C, D, dt, iu, w);
	gain = 20*log10(gain);

	p = Rows(C);
	name1 = makelist(p+1);
	name2 = makelist(p+1);
	for (i = 1; i <= p; i++) {
		name1(i) = sprintf("gain-%d", i);
		name2(i) = sprintf("phase-%d", i);
	}
	name1(p+1) = "";
	name2(p+1) = "";

	win = mgplot_cur_win();
	mgplot_subplot(win,2,1,1);
    mgplot_xlabel(win, "w [rad/sec]");
    mgplot_ylabel(win, "gain [dB]");
	mgplot_title(win, "Bode Plot (gain)");
	mgplot_semilogx(win, w, [[gain][dB0]], name1);

	mgplot_subplot(win,2,1,2);
	mgplot_title(win, "Bode Plot (phase)");
    mgplot_xlabel(win, "w [rad/sec]");
    mgplot_ylabel(win, "phase [deg]");
	mgplot_semilogx(win, w, [[phase][deg180]], name2);

	mgplot_reset(win);
}

Func void dbode_plot_tf(num, den, dt, w, ...)
	Matrix num, den;
	Real dt;
	Array w;
{
	Rational g;

	error(nargchk(3, 4, nargs, "dbode_plot_tf"));

	g = tf2tfn(num, den);
	
	if (nargs == 2) {
		dbode_plot_tfn(g, dt);
	} else {
		dbode_plot_tfn(g, dt, w);
	}
}

Func void dbode_plot_tfn(g, dt, w, ...)
	Rational g;
	Real dt;
	Array w;
{
	Integer win;
	Array gain, phase_, dB0, deg180;

	error(nargchk(2, 3, nargs, "dbode_plot_tfn"));

	if (nargs == 2) {
		w = logspace(-2.0, 3.0);
	}

	dB0 = 0.00001*Z(w);
	deg180 = -180*ONE(w);
	{gain, phase_} = dbode_tfn(g, dt, w);
	gain = 20*log10(gain);

	win = mgplot_cur_win();
	mgplot_reset(win);

	mgplot_hold(win, 1);

	mgplot_subplot(win, 2, 1, 1);
	mgplot_xlabel(win, "w [rad/sec]");
	mgplot_ylabel(win, "gain [dB]");
	mgplot_semilogx(win, w, [[gain][dB0]], {"gain", ""});

	mgplot_subplot(win, 2, 1, 2);
	mgplot_xlabel(win, "w [rad/sec]");
	mgplot_ylabel(win, "phase [deg]");
	mgplot_semilogx(win, w, [[phase_][deg180]], {"phase", ""});

	mgplot_hold(win, 0);
}

Func void dbode_plot_tfm(G, dt, iu, w, ...)
	RaMatrix G;
	Real dt;
	Integer iu;
	Array w;
{
	Integer win;
	Array gain, phase_, dB0, deg180;

	error(nargchk(2, 4, nargs, "dbode_plot_tfm"));
	
	if (nargs < 3) {
		iu = 1;
	}
	if (nargs < 4) {
		w = logspace(-2.0, 3.0);
	}

	dB0 = 0.00001*Z(w);
	deg180 = -180*ONE(w);
	{gain, phase_} = dbode_tfm(G, dt, w);
	gain = 20*log10(gain);

	win = mgplot_cur_win();
	mgplot_reset(win);

	mgplot_hold(win, 1);

	mgplot_subplot(win, 2, 1, 1);
	mgplot_xlabel(win, "w [rad/sec]");
	mgplot_ylabel(win, "gain [dB]");
	mgplot_semilogx(win, w, [[gain][dB0]], {"gain", ""});

	mgplot_subplot(win, 2, 1, 2);
	mgplot_xlabel(win, "w [rad/sec]");
	mgplot_ylabel(win, "phase [deg]");
	mgplot_semilogx(win, w, [[phase_][deg180]], {"phase", ""});

	mgplot_hold(win, 0);
}
