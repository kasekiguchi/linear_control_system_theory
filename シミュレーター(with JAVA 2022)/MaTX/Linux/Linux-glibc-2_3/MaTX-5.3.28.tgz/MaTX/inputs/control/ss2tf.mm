
/* -*- MaTX -*-
 *
 *  NAME
 *      ss2tf()	- State-space to transfer function conversion
 *
 *  SYNOPSIS
 *      {NUM,den} = ss2tf(A,B,C,D)
 *         Matrix NUM,den;
 *         Matrix A,B,C,D;
 *
 *      {NUM,den} = ss2tf(A,B,C,D,i)
 *         Matrix NUM,den;
 *         Matrix A,B,C,D;
 *         Integer i;
 *
 *  DESCRIPTION
 *      ss2tf(A,B,C,D,i) returns the numerator coefficients NUM and the
 *      denominator coefficients den of the transfer function
 *
 *                  NUM(s)          -1
 *          G(s) = -------- = C(sI-A) B + D
 *                  den(s)
 *
 *      of the system:
 *          .
 *          x = Ax + Bu
 *          y = Cx + Du
 *
 *      from the i'th input.
 *
 *      NUM is Rows(C)-by-Rows(A) and den is 1-by-Rows(A).
 *
 *  SEE ALSO
 *      ss2tfm, ss2tfn, ss2zp, and tf2ss
 */

Func List ss2tf(A,B,C,D,i, ...)
	Matrix A,B,C,D;
	Integer i;
{
	Integer j,p;
	Matrix den,NUM,Bi,Di;
	String msg;
	
	error(nargchk(4, 5, nargs, "ss2tf"));

	if (length((msg = abcdchk(A, B, C, D))) > 0) {
		error("ss2tf(): " + msg);
	}

	if (nargs == 4) {
		i = 1;
	}

	p = Rows(C);

	if (isreal(A) && isreal(B) && isreal(C) && isreal(D)) {
		NUM = Z(p,Rows(A)+1);
	} else {
		NUM = (Z(p,Rows(A)+1),:);
	}

	Bi = B(:,i);
	Di = D(:,i);
	den = Matrix(makepoly(A));

	for (j = 1; j <= p; j++) {
		if (length(C) == 0) {
			NUM(j,1) = Di(j);
		} else {
			NUM(j,:) = Matrix(makepoly(A-Bi*C(j,:))) + (Di(j)-1)*den;
		}
	}
	return {NUM,den};
}
