
/* -*- MaTX -*-
 *
 *  NAME
 *      ss2tfm() - State-space to transfer function matrix conversion
 *
 *  SYNOPSIS
 *      G = ss2tfm(A,B,C,D)
 *        RaMatrix G;
 *        Matrix A,B,C,D;
 *
 *      G = ss2tfm(A,B,C,D,i)
 *        RaMatrix G;
 *        Matrix A,B,C,D;
 *        Integer i;
 *
 *  DESCRIPTION
 *       ss2tfm(A,B,C,D) returns the transfer function matrix
 *                       -1
 *          G(s) = C(sI-A) B + D
 *
 *       of the system:
 *          .
 *          x = Ax + Bu
 *          y = Cx + Du
 *
 *       as a rational polynomial matrix.
 *
 *       ss2tfm(...,i) returns the transfer function matrix
 *
 *                       -1
 *          G(s) = C(sI-A) B(:,i) + D(:,i)
 *
 *       of the system:
 *          .
 *          x = Ax + Bu
 *          y = Cx + Du
 *
 *      from the i'th input.
 *
 *      TransFunc() and TransFuncMat are obsolete.
 *      Use  g = [ss2tfm(A,b,c,d)](1,1)  for  g = TransFunc(A,b,c,d)
 *      Use  G = ss2tfm(A,b,c,d)  for  G = TransFuncMat(A,B,C,D)
 *
 *  SEE ALSO
 *      ss2tf, ss2tfn, ss2zp, and tfm2ss
 */

Func RaMatrix ss2tfm(A, B, C, D, i, ...)
	Matrix A, B, C, D;
	Integer i;
{
	Integer j, m, p;
	Matrix den, NUM;
	Polynomial s;
	RaMatrix G;
	String msg;

	error(nargchk(4, 5, nargs, "ss2tfm"));

	if (length((msg = abcdchk(A, B, C, D))) > 0) {
		error("ss2tfm(): " + msg);
	}
	
	if (nargs == 5) {
		{NUM, den} = ss2tf(A, B, C, D, i);
		G = tf2tfm(NUM, den);
	} else {
		p = Rows(D);
		m = Cols(D);

		s = Polynomial("s");
		if (isreal(A) && isreal(B) && isreal(C) && isreal(D)) {
			G = Z(p,m,1/s);
		} else {
			G = (Z(p,m,1/s),:);
		}
		for (j = 1; j <= m; j++) {
			{NUM, den} = ss2tf(A, B, C, D, j);
			G(:,j) = tf2tfm(NUM, den);
		}
	}

	return G;
}

Func Rational TransFunc(A, b, c, d)
	Matrix	A, b, c, d;
{

	return [ss2tfm(A,b,c,d)](1,1);
}

Func RaMatrix TransFuncMat(A, B, C, D)
	Matrix	A, B, C, D;
{
	return ss2tfm(A,B,C,D);
}
