
/* -*- MaTX -*-
 *
 *  NAME
 *      impulse_ss()  - Impulse response of continuous-time linear system
 *      impulse_tf()  - Impulse response of continuous-time linear system
 *      impulse_tfn() - Impulse response of continuous-time linear system
 *      impulse_tfm() - Impulse response of continuous-time linear system
 *
 *      impulse_plot_ss()  - Plot Impulse response of cont-time linear system
 *      impulse_plot_tf()  - Plot Impulse response of cont-time linear system
 *      impulse_plot_tfn() - Plot Impulse response of cont-time linear system
 *      impulse_plot_tfm() - Plot Impulse response of cont-time linear system
 *
 *  SYNOPSIS
 *      {Y,X} = impulse_ss(A,B,C,D,iu,T)
 *          Matrix X,Y;
 *          Matrix A,B,C,D;
 *          Integer iu;
 *          Matrix T;
 *
 *      {Y,X} = impulse_tf(num,den,T)
 *         Matrix X,Y;
 *         Matrix num,den;
 *         Matrix T;
 *
 *      {Y,X} = impulse_tfn(g,T)
 *         Matrix X,Y;
 *         Rational g;
 *         Matrix T;
 *
 *      {Y,X} = impulse_tfm(G,iu,T)
 *         Matrix X,Y;
 *         RaMatrix G;
 *         Integer iu;
 *         Matrix T;
 *
 *      impulse_plot_ss(A,B,C,D,iu,T)
 *         Matrix A,B,C,D;
 *         Integer iu;
 *         Matrix T;
 *
 *      impulse_plot_tf(num,den,T)
 *         Matrix num,den;
 *         Matrix T;
 *
 *      impulse_plot_tfn(g,T)
 *         Rational g;
 *         Matrix T;
 *
 *      impulse_plot_tfm(G,iu,T)
 *         RaMatrix G;
 *         Integer iu;
 *         Matrix T;
 *
 *  DESCRIPTION
 *       impulse_ss(A,B,C,D,iu,T) calculates the response of the system:
 *      	.
 *      	x = Ax + Bu
 *      	y = Cx + Du
 *
 *       to an unit impulse applied to the iu'th input.  T is a regularly 
 *       spaced time vector which specifies the time axis.
 * 
 *       impulse_ss() returns the Rows(y)-by-length(T) output-history matrix
 *       Y and the state-history matrix X.
 *
 *       If iu == 0, impulse_ss() returns matrices
 *
 *       [[Y for 1st input]          [[X for 1st input]
 *        [Y for 2nd input]           [X for 2nd input]
 *        [...............]           [...............]
 *        [Y for m'th input]]  and    [Y for m'th input]].
 *
 *      impulse_plot_xxx() plots the impulse response.
 *
 *  SEE ALSO
 *      step and dimpulse
 */

Func List impulse(A,B,C,D,iu,T)
	Matrix A,B,C,D;
	Integer iu;
	Matrix T;
{
	Matrix XX,YY;

	{YY,XX} = impulse_ss(A,B,C,D,iu,T);
	return {YY,XX};
}

Func List impulse_ss(A,B,C,D,iu,T)
	Matrix A,B,C,D;
	Integer iu;
	Matrix T;
{
	Integer i,m,N;
	Real dt;
	Matrix Ad,Bd,b,x0,X,Y,XX,YY,U;
	String msg;

	if (length((msg = abcdchk(A, B, C, D))) > 0) {
		error("impulse_ss(): " + msg);
	}

	N = length(T);
	U = Z(1,N);
	dt = T(2) - T(1);

	if (iu == 0) {
		m = Cols(B);
		YY = Z(Rows(C)*m,N);
		XX = Z(Rows(A)*m,N);

		for (i = 1; i <= m; i++) {
			x0 = b = B(:,i);
			{Ad, Bd} = c2d(A, b, dt);
			X = ltitr(Ad, Bd, U, x0);
			Y = C*X;
			
			if (version() == 4) {
				YY(i-1,0,Y) = Y;
				XX(i-1,0,X) = X;
			} else {
				YY(i,1,Y) = Y;
				XX(i,1,X) = X;
			}
		}
	} else {
		x0 = b = B(:,iu);
		{Ad, Bd} = c2d(A, b, dt);
		XX = ltitr(Ad, Bd, U, x0);
		YY = C*XX;
	}

	return {YY,XX};
}

Func List impulse_tfn(g, T)
	Rational g;
	Matrix T;
{
	Matrix A,B,C,D;
	Matrix X, Y;
	
	{A, B, C, D} = tfn2ss(g);
	{Y, X} = impulse_ss(A, B, C, D, 1, T); 
	return {Y,X};
}

Func List impulse_tfm(G, iu, T)
	RaMatrix G;
	Integer iu;
	Matrix T;
{
	Matrix A,B,C,D;
	Matrix X, Y;
	
	if (iu == 0) {
		{A, B, C, D} = tfm2ss(G);
		{Y, X} = impulse_ss(A, B, C, D, iu, T); 
	} else {
		{A, B, C, D} = tfm2ss(G, iu);
		{Y, X} = impulse_ss(A, B, C, D, 1, T); 
	}
	return {Y, X};
}

Func List impulse_tf(num, den, T)
	Matrix num, den;
	Matrix T;
{
	Matrix A,B,C,D;
	Matrix X, Y;
	
	{A, B, C, D} = tf2ss(num,den);
	{Y, X} = impulse_ss(A, B, C, D, 1, T); 
	return {Y, X};
}

Func void impulse_plot_tfn(g, T)
	Rational g;
	Matrix T;
{
	Integer win;
	Matrix Y;

	win = 1;

	{Y} = impulse_tfn(g, T);

	mgplot_reset(win);

	mgplot_grid(win,1);
	mgplot_xlabel(win, "t [sec]");
	mgplot_ylabel(win, "y");
	mgplot(win, T, Y, {"y"});
}

Func void impulse_plot_tf(num, den, T)
	Matrix num, den;
	Matrix T;
{
	Rational g;

	g = tf2tfn(num, den);
	impulse_plot_tfn(g, T);
}

Func void impulse_plot_tfm(G, iu, T)
	RaMatrix G;
	Integer iu;
	Matrix T;
{
	Integer i,p,win;
	Matrix Y;
	List yy;

	win = 1;
	p = Rows(G);

	{Y} = impulse_tfm(G, iu, T);

	yy = makelist(p);
	for (i = 1; i <= p; i++) {
		if (p == 1) {
			yy(i) = "y";
		} else {
			yy(i) = sprintf("y%d", i);
		}
	}

	mgplot_reset(win);
	mgplot_grid(win,1);
	mgplot_xlabel(win, "t [sec]");
	mgplot_ylabel(win, "y");
	mgplot(win, T, Y, yy);
}

Func void impulse_plot_ss(A,B,C,D,iu,T)
	Matrix A,B,C,D;
	Integer iu;
	Matrix T;
{
	Integer i,p,n,win;
	Matrix X,Y;
	List xx,yy;

	win = 1;
	n = Rows(A);
	p = Rows(C);

	{Y,X} = impulse_ss(A, B, C, D, iu, T);

	yy = makelist(p);
	for (i = 1; i <= p; i++) {
		if (p == 1) {
			yy(i) = "y";
		} else {
			yy(i) = sprintf("y%d", i);
		}
	}

	mgplot_reset(win);

	mgplot_hold(win, 1);

	mgplot_subplot(win, 2, 1, 1);
	mgplot_grid(win,1);
	mgplot_xlabel(win, "t [sec]");
	mgplot_ylabel(win, "y");
	mgplot(win, T, Y, yy);

	xx = makelist(n);
	for (i = 1; i <= n; i++) {
		xx(i) = sprintf("x%d", i);
	}

	mgplot_subplot(win, 2, 1, 2);
	mgplot_grid(win,1);
	mgplot_xlabel(win, "t [sec]");
	mgplot_ylabel(win, "x");
	mgplot(win, T, X, xx);

	mgplot_hold(win, 0);
}
