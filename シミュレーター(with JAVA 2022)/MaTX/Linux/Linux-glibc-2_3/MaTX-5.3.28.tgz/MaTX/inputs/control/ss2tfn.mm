
/* -*- MaTX -*-
 *
 *  NAME
 *      ss2tfn() -  State-space to transfer function conversion
 *
 *  SYNOPSIS
 *      g = ss2tfn(A,B,C,D)
 *         Rational g;
 *         Matrix A,B,C,D;
 *
 *      g = ss2tfn(A,B,C,D,i)
 *         Rational g;
 *         Matrix A,B,C,D;
 *         Integer i;
 *
 *      g = ss2tfn(A,B,C,D,i,j)
 *         Rational g;
 *         Matrix A,B,C,D;
 *         Integer i,j;
 *
 *  DESCRIPTION
 *      ss2tfn(A,B,C,D) returns the transfer function:
 *
 *                       -1
 *          g(s) = C(sI-A) B + D
 *
 *      of the SISO system:
 *          .
 *          x = Ax + Bu
 *          y = Cx + Du
 *
 *      ss2tfn(A,B,C,D,i) returns the transfer function of the MISO
 *      system from the i'th input.
 *
 *      ss2tfn(A,B,C,D,i,j) returns the transfer function of the MIMO
 *      system from the i'th input to the j'th output.
 *
 *  SEE ALSO
 *      ss2tf, ss2tfm, ss2zp, and tfn2ss
 */

Func Rational ss2tfn(A,B,C,D,i,j, ...)
	Matrix A,B,C,D;
	Integer i,j;
{
	Matrix num,den;
	Rational g;
	String msg;
	
	error(nargchk(4, 6, nargs, "ss2tfn"));

	if (length((msg = abcdchk(A, B, C, D))) > 0) {
		error("ss2tfn(): " + msg);
	}

	if (nargs == 4) {
		 i = j = 1;
	}
	if (nargs == 5) {
		 j = 1;
	}
	
	{num,den} = ss2tf(A,B(:,i),C(j,:),[D(j,i)]);
	g = tf2tfn(num,den);
	return g;
}
