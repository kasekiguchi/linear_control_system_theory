
/* -*- MaTX -*-
 *
 *  NAME
 *      TFmul() -  Series connection of two state-space systems
 *
 *  SYNOPSIS
 *      {A,B,C,D} = TFmul(S1, S2)
 *          Matrix A,B,C,D;
 *          List S1, S2;
 *          S1 = {A1,B1,C1,D1};
 *          S2 = {A2,B2,C2,D2};
 *
 *  DESCRIPTION
 *      TFmul() produces an aggregate state-space system with the outputs
 *      of system 2 connected to the inputs of system 1.  An error results
 *      if there are different numbers of rows in (C1,D1) than columns in
 *      (B2,D2).
 *                  S = S1 S2
 *
 *               +----+    +----+
 *          ---->| S2 |--->| S1 |--->
 *               +----+    +----+
 *
 *  SEE ALSO
 *      series and TFinv
 */

Func List TFmul(S1, S2)
	List S1, S2;
{	
	Matrix a1, b1, c1, d1;
	Matrix a2, b2, c2, d2;
	Integer n1, m1, p1;
	Integer n2, m2, p2;
	Matrix A, B, C, D;

	{a1, b1, c1, d1} = S1;
	{a2, b2, c2, d2} = S2;

	n1 = Cols(a1);
	m1 = Cols(b1);
	p1 = Rows(c1);

	n2 = Cols(a2);
	m2 = Cols(b2);
	p2 = Rows(c2);

	if (m1 != p2) {
		error("TFmul(): Input-output number is incorrect.\n");
	}

	A = [[  a1      b1*c2]
		 [Z(n2,n1)    a2 ]];
	B = [[b1*d2]
		 [  b2 ]];
	C = [c1 d1*c2];
	D = d1*d2;

	return {A, B, C, D};
}
