
/* -*- MaTX -*-
 *
 *  NAME
 *      dstep_ss()  - Step response of discrete-time linear systems
 *      dstep_tf()  - Step response of discrete-time linear systems
 *      dstep_tfn() - Step response of discrete-time linear systems
 *      dstep_tfm() - Step response of discrete-time linear systems
 *
 *      dstep_plot_ss()  - Plot Step response of disc-time linear system
 *      dstep_plot_tf()  - Plot Step response of disc-time linear system
 *      dstep_plot_tfn() - Plot Step response of disc-time linear system
 *      dstep_plot_tfm() - Plot Step response of disc-time linear system
 *
 *  SYNOPSIS
 *      {Y,X} = dstep_ss(A,B,C,D,iu,N)
 *         Matrix Y,X;
 *         Matrix A,B,C,D;
 *         Integer iu,N;
 *
 *      {Y,X} = dstep_tf(num,den,N)
 *         Matrix X,Y;
 *         Matrix num,den;
 *         Integer N;
 *
 *      {Y,X} = dstep_tfn(g,N)
 *         Matrix X,Y;
 *         Rational g;
 *         Integer N;
 *
 *      {Y,X} = dstep_tfm(G,iu,N)
 *         Matrix X,Y;
 *         RaMatrix G;
 *         Integer iu,N;
 *
 *      dstep_plot_ss(A,B,C,D,iu,N)
 *         Matrix A,B,C,D;
 *         Integer iu,N;
 *
 *      dstep_plot_tf(num,den,N)
 *         Matrix num,den;
 *         Integer N;
 *
 *      dstep_plot_tfn(g,N)
 *         Rational g;
 *         Integer N;
 *
 *      dstep_plot_tfm(G,iu,N)
 *         RaMatrix G;
 *         Integer iu,N;
 *
 *  DESCRIPTION
 *       dstep_ss(A,B,C,D,iu,N) calculates the response of the system:
 *
 *      	x[n+1] = Ax[n] + Bu[n]
 *      	y[n]   = Cx[n] + Du[n]
 *
 *       to an unit step applied to the iu'th input.
 *
 *       dimpulse_ss() returns the Rows(y)-by-N output-history matrix Y and
 *       the state-history matrix X.
 *
 *       If iu = 0, dstep_ss() returns matrices
 *
 *       [[Y for 1st input]          [[X for 1st input]
 *        [Y for 2nd input]           [X for 2nd input]
 *        [...............]           [...............]
 *        [Y for m'th input]]  and    [Y for m'th input]].
 *
 *      dstep_plot_xxx() plots the impulse response.
 *
 *  SEE ALSO
 *      step and dimpuse
 */

Func List dstep(A,B,C,D,iu,N)
	Matrix A,B,C,D;
	Integer iu,N;
{
	Matrix XX,YY;

	{YY,XX} = dstep_ss(A,B,C,D,iu,N);
	return {YY,XX};
}

Func List dstep_ss(A, B, C, D, iu, N)
	Matrix A, B, C, D;
	Integer iu, N;
{
	Integer i,m;
	Matrix X,Y,XX,YY;
	String msg;

	if (length((msg = abcdchk(A,B,C,D))) > 0) {
		error("dstep(): " + msg);
	}

	if (iu == 0) {
		m = Cols(B);
		YY = Z(Rows(C)*m,N);
		XX = Z(Rows(A)*m,N);
		if (version() == 4) {
			for (i = 1; i <= m; i++) {
				{Y,X} = dlsim(A, B(:,i), C, D(:,i), ONE(1,N));
				YY(i-1,0,Y) = Y;
				XX(i-1,0,X) = X;
			}
		} else {
			for (i = 1; i <= m; i++) {
				{Y,X} = dlsim(A, B(:,i), C, D(:,i), ONE(1,N));
				YY(i,1,Y) = Y;
				XX(i,1,X) = X;
			}
		}
	} else {
		{YY,XX} = dlsim(A, B(:,iu), C, D(:,iu), ONE(1,N));
	}
	return {YY,XX};
}

Func List dstep_tfn(g, N)
	Rational g;
	Integer N;
{
	Matrix A,B,C,D;
	Matrix X, Y;
	
	{A, B, C, D} = tfn2ss(g);
	{Y, X} = dstep_ss(A, B, C, D, 1, N); 
	return {Y,X};
}

Func List dstep_tfm(G, iu, N)
	RaMatrix G;
	Integer iu,N;
{
	Matrix A,B,C,D;
	Matrix X, Y;
	
	if (iu == 0) {
		{A, B, C, D} = tfm2ss(G);
		{Y, X} = dstep_ss(A, B, C, D, iu, N); 
	} else {
		{A, B, C, D} = tfm2ss(G, iu);
		{Y, X} = dstep_ss(A, B, C, D, 1, N); 
	}
	return {Y, X};
}

Func List dstep_tf(num, den, N)
	Matrix num, den;
	Integer N;
{
	Matrix A,B,C,D;
	Matrix X, Y;
	
	{A, B, C, D} = tf2ss(num,den);
	{Y, X} = dstep_ss(A, B, C, D, 1, N); 
	return {Y, X};
}

Func void dstep_plot_tfn(g, N)
	Rational g;
	Integer N;
{
	Integer win;
	Matrix Y;

	win = 1;

	{Y} = dstep_tfn(g, N);

	mgplot_reset(win);
	mgplot_grid(win,1);
	mgplot_xlabel(win, "k");
	mgplot_ylabel(win, "y");
	mgplot(win, [1:N], Y, {"y"});
}

Func void dstep_plot_tf(num, den, N)
	Matrix num, den;
	Integer N;
{
	Rational g;

	g = tf2tfn(num, den);
	dstep_plot_tfn(g, N);
}

Func void dstep_plot_tfm(G, iu, N)
	RaMatrix G;
	Integer iu,N;
{
	Integer i,p,win;
	Matrix Y;
	List yy;

	win = 1;
	p = Rows(G);

	{Y} = dstep_tfm(G, iu, N);

	yy = makelist(p);
	for (i = 1; i <= p; i++) {
		if (p == 1) {
			yy(i) = "y";
		} else {
			yy(i) = sprintf("y%d", i);
		}
	}

	mgplot_reset(win);
	mgplot_grid(win,1);
	mgplot_xlabel(win, "k");
	mgplot_ylabel(win, "y");
	mgplot(win, [1:N], Y, yy);
}

Func void dstep_plot_ss(A,B,C,D,iu,N)
	Matrix A,B,C,D;
	Integer iu,N;
{
	Integer i,p,n,win;
	Matrix X,Y;
	List xx,yy;

	win = 1;
	n = Rows(A);
	p = Rows(C);

	{Y,X} = dstep_ss(A, B, C, D, iu, N);

	yy = makelist(p);
	for (i = 1; i <= p; i++) {
		if (p == 1) {
			yy(i) = "y";
		} else {
			yy(i) = sprintf("y%d", i);
		}
	}

	mgplot_reset(win);

	mgplot_hold(win, 1);

	mgplot_subplot(win, 2, 1, 1);
	mgplot_grid(win,1);
	mgplot_xlabel(win, "k");
	mgplot_ylabel(win, "y");
	mgplot(win, [1:N], Y, yy);

	xx = makelist(n);
	for (i = 1; i <= n; i++) {
		xx(i) = sprintf("x%d", i);
	}

	mgplot_subplot(win, 2, 1, 2);
	mgplot_grid(win,1);
	mgplot_xlabel(win, "k");
	mgplot_ylabel(win, "x");
	mgplot(win, [1:N], X, xx);

	mgplot_hold(win, 0);
}
