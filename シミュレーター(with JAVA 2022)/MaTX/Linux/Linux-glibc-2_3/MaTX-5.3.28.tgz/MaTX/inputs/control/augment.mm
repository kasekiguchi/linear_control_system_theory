
/* -*- MaTX -*-
 *
 *  NAME
 *      augment() - Augmented system 
 *
 *  SYNOPSIS
 *     {A,B,C,D} = augment(A1,B1,C1,D1,A2,B2,C2,D2)
 *        Matrix A,B,C,D;
 *        Matrix A1,B1,C1,D1,A2,B2,C2,D2;
 *
 *  DESCRIPTION
 *       augment() generates an aggregate system consisting of
 *       the systems 1 and system 2.  The resulting system is:
 *      	 .
 *      	[x1] = [A1 0] [x1] + |B1 0] |u1]
 *      	[x2]   [0 A2] [x2] + [0 B2] |u2]
 *
 *      	[y1] = [C1 0] [x1] + |D1 0] |u1]
 *      	[y2]   [0 C2] [x2] + [0 D2] |u2]
 *
 *  SEE ALSO
 *      series and parallel
 */

Func List augment(A1,B1,C1,D1,A2,B2,C2,D2)
	Matrix A1,B1,C1,D1,A2,B2,C2,D2;
{
	Matrix A,B,C,D;
	String msg;

	if (length((msg = abcdchk(A1, B1, C1, D1))) > 0) {
		error("augment(): " + msg);
	}
	if (length((msg = abcdchk(A2, B2, C2, D2))) > 0) {
		error("augment(): " + msg);
	}

	A = diag(A1,A2);
	B = diag(B1,B2);
	C = diag(C1,C2);
	D = diag(D1,D2);

	return {A,B,C,D};
}
