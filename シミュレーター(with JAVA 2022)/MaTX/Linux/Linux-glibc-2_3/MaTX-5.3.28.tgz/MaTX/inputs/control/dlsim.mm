
/* -*- MaTX -*-
 *
 *  NAME
 *      dlsim()      - Response of disc-time linear systems to given input
 *      dlsim_plot() - Plot response of disc-time linear systems
 *
 *  SYNOPSIS
 *      {Y,X} = dlsim(A,B,C,D,U)
 *         Matrix Y, X;
 *         Matrix A,B,C,D;
 *         Matrix U;
 *
 *      {Y,X} = dlsim(A,B,C,D,U,x0)
 *         Matrix Y, X;
 *         Matrix A,B,C,D;
 *         Matrix U;
 *         Matrix x0;
 *
 *      dlsim_plot(A,B,C,D,U)
 *         Matrix A,B,C,D;
 *         Matrix U;
 *
 *      dlsim_plot(A,B,C,D,U,x0)
 *         Matrix A,B,C,D;
 *         Matrix U;
 *         Matrix x0;
 *
 *  DESCRIPTION
 *       dlsim() calculates the time response of the discrete-time system:
 *		
 *         x[n+1] = Ax[n] + Bu[n]
 *         y[n]   = Cx[n] + Du[n]
 *
 *       to the input sequence U, where Rows(U) = Rows(u).  Each column of 
 *       U corresponds to a time point.
 *
 *       dlsim() returns the Rows(y)-by-Cols(U) output-history matrix Y,
 *       and the state-history matrix X.
 *
 *      dlsim(..., x0) uses x0 to specify the initial conditions. 
 *
 *      dlsim_plot() plots the response.
 *
 *  SEE ALSO
 *      lsim
 */

Func List dlsim(A, B, C, D, U, x0_, ...)
	Matrix A, B, C, D, x0_;
	Matrix U;
{
	String msg;
	Matrix X, Y, x0;

	error(nargchk(5, 6, nargs, "dlsim"));

	if (length((msg = abcdchk(A, B, C, D))) > 0) {
		error("dlsim(): " + msg);
	}

	if (nargs == 5) {
		x0 = Z(Rows(A),1);
	} else {
		x0 = x0_;
	}

	X = ltitr(A, B, U, x0);
	Y = C*X + D*U;
	return {Y,X};
}

Func void dlsim_plot(A, B, C, D, U, x0, ...)
	Matrix A, B, C, D, x0;
	Matrix U;
{
	Integer i,p,n,win,N;
	String msg;
	Matrix X, Y;
	List xx,yy;

	error(nargchk(5, 6, nargs, "dlsim_plot"));

	if (length((msg = abcdchk(A, B, C, D))) > 0) {
		error("dlsim_plot(): " + msg);
	}

	if (nargs == 5) {
		{Y,X} = dlsim(A,B,C,D,U);
	} else {
		{Y,X} = dlsim(A,B,C,D,U,x0);
	}

	win = 1;
	n = Rows(A);
	p = Rows(C);
	N = Cols(U);

	mgplot_reset(win);

	yy = makelist(p);
	for (i = 1; i <= p; i++) {
		if (p == 1) {
			yy(i) = "y";
		} else {
			yy(i) = sprintf("y%d", i);
		}
	}

	mgplot_hold(win, 1);

	mgplot_subplot(win, 2, 1, 1);
	mgplot_grid(win,1);
	mgplot_xlabel(win, "k");
	mgplot_ylabel(win, "y");
	mgplot(win, [1:N], Y, yy);

	xx = makelist(n);
	for (i = 1; i <= n; i++) {
		xx(i) = sprintf("x%d", i);
	}

	mgplot_subplot(win, 2, 1, 2);
	mgplot_grid(win,1);
	mgplot_xlabel(win, "k");
	mgplot_ylabel(win, "x");
	mgplot(win, [1:N], X, xx);

	mgplot_hold(win, 1);
}
