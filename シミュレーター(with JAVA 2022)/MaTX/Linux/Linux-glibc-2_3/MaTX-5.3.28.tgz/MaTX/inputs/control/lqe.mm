
/* -*- MaTX -*-
 *
 *  NAME
 *      lqe() - Continuous-time linear quadratic estimator
 *
 *  SYNOPSIS
 *     {L,P} = lqe(A,G,C,Q,R)
 *        Matrix L,P;
 *        Matrix A,G,C,Q,R;
 *
 *  DESCRIPTION
 *      Given the continuous-time system:
 *      	.
 *      	x = Ax + Bu + Gw
 *      	z = Cx + Du + v
 *
 *      with process noise and measurement noise covariances:
 *
 *      	E[w] = E[v] = 0,  E[ww#] = Q,  E[vv#] = R
 *
 *      lqe() returns the gain matrix L of the Kalman filter
 *      	.
 *      	x = Ax + Bu + L(z - Hx - Du)
 *
 *      which generates an LQG optimal estimate of x.
 *
 *      lqe() also returns Riccati equation solution P which is the estimate
 *      error covariance.
 *
 *  SEE ALSO
 *      lqr and dlqe
 */

Func List lqe(A, G, C, Q, R)
	Matrix A, G, C, Q, R;
{
	Matrix L, P;

	{L,P} = lqr(A#, C#, G*Q*G#, R);
	L = L#;
	P = P#;

	return {L,P};
}
