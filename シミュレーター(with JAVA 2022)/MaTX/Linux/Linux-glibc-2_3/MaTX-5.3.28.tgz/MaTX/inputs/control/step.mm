
/* -*- MaTX -*-
 *
 *  NAME
 *      step_ss()  - Step response of continuous-time linear systems
 *      step_tf()  - Step response of continuous-time linear systems
 *      step_tfn() - Step response of continuous-time linear systems
 *      step_tfm() - Step response of continuous-time linear systems
 *
 *      step_plot_ss()  - Plot Step response of continuous-time linear systems
 *      step_plot_tf()  - Plot Step response of continuous-time linear systems
 *      step_plot_tfn() - Plot Step response of continuous-time linear systems
 *      step_plot_tfm() - Plot Step response of continuous-time linear systems
 *
 *  SYNOPSIS
 *      {Y,X} = step_ss(A,B,C,D,iu,T)
 *         Matrix X,Y;
 *         Matrix A,B,C,D;
 *         Integer iu;
 *         Matrix T;
 *
 *      {Y,X} = step_tf(num,den,T)
 *         Matrix X,Y;
 *         Matrix num,den;
 *         Matrix T;
 *
 *      {Y,X} = step_tfn(g,T)
 *         Matrix X,Y;
 *         Rational g;
 *         Matrix T;
 *
 *      {Y,X} = step_tfm(G,iu,T)
 *         Matrix X,Y;
 *         RaMatrix G;
 *         Integer iu;
 *         Matrix T;
 *
 *      step_plot_ss(A,B,C,D,iu,T)
 *         Matrix A,B,C,D;
 *         Integer iu;
 *         Matrix T;
 *
 *      step_plot_tf(num,den,T)
 *         Matrix num,den;
 *         Matrix T;
 *
 *      step_plot_tfn(g,T)
 *         Rational g;
 *         Matrix T;
 *
 *      step_plot_tfm(G,iu,T)
 *         RaMatrix G;
 *         Integer iu;
 *         Matrix T;
 *
 *  DESCRIPTION
 *       step_ss(A,B,C,D,iu,T) returns the response of the system:
 *      	.
 *      	x = Ax + Bu
 *      	y = Cx + Du
 *
 *       to an unit step applied to the iu-th input.  T is a regularly 
 *       spaced time vector which specifies the time axis.
 *
 *       step_ss() returns the Rows(y)-by-length(T) output-history matrix Y
 *       and the state-history matrix X.
 *
 *       If iu == 0, step_ss() returns matrices
 *
 *       [[Y for 1st input]          [[X for 1st input]
 *        [Y for 2nd input]           [X for 2nd input]
 *        [...............]           [...............]
 *        [Y for m'th input]]  and    [Y for m'th input]].
 *
 *      step_plot_xxx() plots the step response.
 *
 *  SEE ALSO
 *      impluse and dstep
 */

Func List step(A,B,C,D,iu,T)
	Matrix A,B,C,D;
	Integer iu;
	Matrix T;
{
	Matrix XX,YY;

	{YY,XX} = step_ss(A,B,C,D,iu,T);
	return {YY,XX};
}

Func List step_ss(A,B,C,D,iu,T)
	Matrix A,B,C,D;
	Integer iu;
	Matrix T;
{
	Integer i,m,N;
	Matrix X,Y,XX,YY;
	Matrix A2,B2,C2,D2;
	String msg;

	if (length((msg = abcdchk(A, B, C, D))) > 0) {
		error("step_ss(): " + msg);
	}

	if (iu == 0) {
		m = Cols(B);
		N = length(T);
		YY = Z(Rows(C)*m,N);
		XX = Z(Rows(A)*m,N);
		for (i = 1; i <= m; i++) {
			{A2,B2,C2,D2} = series([0],[1],[1],[0],A,B(:,i),C,D(:,i));
			{Y,X} = impulse(A2,B2,C2,D2,1,T);
			X = X(2:,:); // remove the state of integrator

			if (version() == 4) {
				YY(i-1,0,Y) = Y;
				XX(i-1,0,X) = X;
			} else {
				YY(i,1,Y) = Y;
				XX(i,1,X) = X;
			}
		}
	} else {
		{A2,B2,C2,D2} = series([0],[1],[1],[0],A,B(:,iu),C,D(:,iu));
		{YY,XX} = impulse(A2,B2,C2,D2,1,T);
		XX = XX(2:,:); // remove the state of integrator
	}

	return {YY,XX};
}

Func List step_tfn(g, T)
	Rational g;
	Matrix T;
{
	Matrix A,B,C,D;
	Matrix X, Y;
	
	{A, B, C, D} = tfn2ss(g);
	{Y, X} = step_ss(A, B, C, D, 1, T); 
	return {Y,X};
}

Func List step_tfm(G, iu, T)
	RaMatrix G;
	Integer iu;
	Matrix T;
{
	Matrix A,B,C,D;
	Matrix X, Y;
	
	if (iu == 0) {
		{A, B, C, D} = tfm2ss(G);
		{Y, X} = step_ss(A, B, C, D, iu, T); 
	} else {
		{A, B, C, D} = tfm2ss(G, iu);
		{Y, X} = step_ss(A, B, C, D, 1, T); 
	}
	return {Y, X};
}

Func List step_tf(num, den, T)
	Matrix num, den;
	Matrix T;
{
	Matrix A,B,C,D;
	Matrix X, Y;
	
	{A, B, C, D} = tf2ss(num,den);
	{Y, X} = step_ss(A, B, C, D, 1, T); 
	return {Y, X};
}

Func List Step_tf(g, T)
	Rational g;
	Matrix T;
{
	Matrix XX,YY;

	pause "Step_tf() is bosolete.  Use step_tfn()", 1;
	print "\n";

	{YY,XX} = step_tfn(g,1,T);
	return {YY,XX};
}

Func List Step_tfm(G, iu, T)
	RaMatrix G;
	Integer iu;
	Matrix T;
{
	Matrix XX, YY;

	pause "Step_tfm() is bosolete.  Use step_tfm()", 1;
	print "\n";

	{YY,XX} = step_tfm(G,iu,T);
	return {YY,XX};
}

Func void step_plot_tfn(g, T)
	Rational g;
	Matrix T;
{
	Integer win;
	Matrix Y;

	{Y} = step_tfn(g, T);

	win = mgplot_cur_win();
	mgplot_reset(win);
	
	mgplot_hold(win, 1);

	mgplot_grid(win,1);
	mgplot_title(win,"Step response");
	mgplot_xlabel(win, "t [sec]");
	mgplot_ylabel(win, "y");
	mgplot(win, T, Y, {"y"});

	mgplot_hold(win, 0);
}

Func void step_plot_tf(num, den, T)
	Matrix num, den;
	Matrix T;
{
	Rational g;

	g = tf2tfn(num, den);
	step_plot_tfn(g, T);
}

Func void step_plot_tfm(G, iu, T)
	RaMatrix G;
	Integer iu;
	Matrix T;
{
	Integer i,p,win;
	Matrix Y;
	List yy;

	p = Rows(G);

	{Y} = step_tfm(G, iu, T);

	yy = makelist(p);
	for (i = 1; i <= p; i++) {
		if (p == 1) {
			yy(i) = "y";
		} else {
			yy(i) = sprintf("y%d", i);
		}
	}

	win = mgplot_cur_win();
	mgplot_reset(win);

	mgplot_hold(win, 1);

	mgplot_grid(win,1);
	mgplot_title(win,"Step response");
	mgplot_xlabel(win, "t [sec]");
	mgplot_ylabel(win, "y");
	mgplot(win, T, Y, yy);

	mgplot_hold(win, 0);
}

Func void step_plot_ss(A,B,C,D,iu,T)
	Matrix A,B,C,D;
	Integer iu;
	Matrix T;
{
	Integer i,p,n,win;
	Matrix X,Y;
	List xx,yy;

	n = Rows(A);
	p = Rows(C);

	{Y,X} = step_ss(A, B, C, D, iu, T);

	yy = makelist(p);
	for (i = 1; i <= p; i++) {
		if (p == 1) {
			yy(i) = "y";
		} else {
			yy(i) = sprintf("y%d", i);
		}
	}

	win = mgplot_cur_win();
	mgplot_reset(win);

	mgplot_hold(win, 1);

	mgplot_subplot(win, 2, 1, 1);
	mgplot_grid(win,1);
	mgplot_xlabel(win, "t [sec]");
	mgplot_ylabel(win, "y");
	mgplot_title(win,"Step response");
	mgplot(win, T, Y, yy);

	xx = makelist(n);
	for (i = 1; i <= n; i++) {
		xx(i) = sprintf("x%d", i);
	}

	mgplot_subplot(win, 2, 1, 2);
	mgplot_grid(win,1);
	mgplot_title(win,"");
	mgplot_xlabel(win, "t [sec]");
	mgplot_ylabel(win, "x");
	mgplot(win, T, X, xx);

	mgplot_hold(win, 0);
}

