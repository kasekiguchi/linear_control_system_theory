
/* -*- MaTX -*-
 *
 *  NAME
 *      d2c() - Discrete-time to continuous-time transformation
 *
 *  SYNOPSIS
 *      {A,B} = d2c(Ad,Bd,dt)
 *          Matrix A,B;
 *          Matrix Ad, Bd;
 *          Real dt;
 *
 *  DESCRIPTION
 *       d2c(Ad,Bd,dt) transforms the discrete-time system:
 *
 *      	x[n+1] = Ad * x[n] + Bd * u[n]
 *
 *       to the continuous-time system:
 *      	.
 *      	x = Ax + Bu
 *
 *       assuming a zero-order hold on the inputs and sampling interval dt.
 *
 *  SEE ALSO
 *      c2d and log
 */

Func List d2c(Ad,Bd,dt)
	Matrix Ad,Bd;
	Real dt;
{
	Integer m,n;
	String msg;
	Matrix A,B,S;

	if (length((msg = abcdchk(Ad, Bd))) > 0) {
		error("d2c(): " + msg);
	}

	n = Rows(Ad);
	m = Cols(Bd);

	if (n == 1) {
		if (Ad == [1]) {
			A = [0];
			B = Bd/dt;
			return {A, B};
		}
	}

	S = Re(log([[  Ad ,    Bd]
				[Z(m,n), I(m)]]))/dt;
	A = S(1:n,1:n);
	B = S(1:n,n+1:n+m);
	return {A,B};
}
