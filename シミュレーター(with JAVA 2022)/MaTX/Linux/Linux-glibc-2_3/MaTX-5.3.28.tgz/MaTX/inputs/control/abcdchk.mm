
/* -*- MaTX -*-
 *
 *  NAME
 *      abcdchk() - Check the dimensions of the system matrices
 *
 *  SYNOPSIS
 *      msg = abcdchk(A)
 *         String msg;
 *         Matrix A;
 *
 *      msg = abcdchk(A,B)
 *         String msg;
 *         Matrix A,B;
 *
 *      msg = abcdchk(A,B,C)
 *         String msg;
 *         Matrix A,B,C;
 *
 *      msg = abcdchk(A,B,C,D)
 *         String msg;
 *         Matrix A,B,C,D;
 *
 *  DESCRIPTION
 *      abcdchk() checks that dimensions of A, B, C, and D are consistent,
 *      and returns empty string if they are, or an error message string if 
 *      they are not.
 *
 *  SEE ALSO
 *      error, warning, and nargchk
 */

Func String abcdchk(A,B,C,D, ...)
	Matrix A,B,C,D;
{
	String msg;
	Integer ma,mb,mc,md,na,nb,nc,nd;

	error(nargchk(1, 4, nargs, "abcdchk"));

	msg = "";
	{ma,na} = size(A);

	if (ma != na) {
		msg = sprintf("A(%dx%d) matrix must be square.\n", ma, na);
	}

	if (nargs > 1) {
		{mb,nb} = size(B);
		if (ma != mb) {
			msg = sprintf("A(%dx%d) and B(%dx%d) matrices must have the same number of rows.\n", ma, na, mb, nb);
		}
	}
	if (nargs > 2) {
		{mc,nc} = size(C);
		if (nc != ma) {
			msg = sprintf("A(%dx%d) and C(%dx%d) matrices must have the same number of columns.\n", ma, na, mc, nc);
		}
	}
	if (nargs > 3) {
		{md,nd} = size(D);
		if (ma+mb+mc == 0) {
			return msg;
		}
		if (md != mc) {
			msg = sprintf("C(%dx%d) and D(%dx%d) matrices must have the same number of rows.\n", mc, nc, md, nd);
		}
		if (nd != nb) {
			msg = sprintf("B(%dx%d) and D(%dx%d) matrices must have the same number of columns.\n", mb, nb, md, nd);
		}
	}

	return msg;
}
