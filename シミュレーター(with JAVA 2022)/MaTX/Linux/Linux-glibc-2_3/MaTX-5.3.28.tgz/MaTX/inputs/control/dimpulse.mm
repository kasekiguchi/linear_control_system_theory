
/* -*- MaTX -*-
 *
 *  NAME
 *      dimpulse_ss()  - Impulse response of discrete-time linear systems
 *      dimpulse_tf()  - Impulse response of discrete-time linear systems
 *      dimpulse_tfn() - Impulse response of discrete-time linear systems
 *      dimpulse_tfm() - Impulse response of discrete-time linear systems
 *
 *      dimpulse_plot_ss()  - Plot Impulse response of disc-time linear system
 *      dimpulse_plot_tf()  - Plot Impulse response of disc-time linear system
 *      dimpulse_plot_tfn() - Plot Impulse response of disc-time linear system
 *      dimpulse_plot_tfm() - Plot Impulse response of disc-time linear system
 *
 *  SYNOPSIS
 *      {Y,X} = dimpulse_ss(A,B,C,D,iu,N)
 *        Matrix Y, X;
 *        Matrix A,B,C,D;
 *        Integer iu,N;
 *
 *      {Y,X} = dimpulse_tf(num,den,N)
 *         Matrix X,Y;
 *         Matrix num,den;
 *         Integer N;
 *
 *      {Y,X} = dimpulse_tfn(g,N)
 *         Matrix X,Y;
 *         Rational g;
 *         Integer N;
 *
 *      {Y,X} = dimpulse_tfm(G,iu,N)
 *         Matrix X,Y;
 *         RaMatrix G;
 *         Integer iu,N;
 *
 *      dimpulse_plot_ss(A,B,C,D,iu,N)
 *         Matrix A,B,C,D;
 *         Integer iu,N;
 *
 *      dimpulse_plot_tf(num,den,N)
 *         Matrix num,den;
 *         Integer N;
 *
 *      dimpulse_plot_tfn(g,N)
 *         Rational g;
 *         Integer N;
 *
 *      dimpulse_plot_tfm(G,iu,N)
 *         RaMatrix G;
 *         Integer iu,N;
 *
 *  DESCRIPTION
 *       dimpulse_ss(A,B,C,D,iu,N) calculates the response of the system:
 *
 *         x[n+1] = Ax[n] + Bu[n]
 *         y[n]   = Cx[n] + Du[n]
 *
 *       to an unit impulse applied to the iu'th input.
 *
 *       dimpulse_ss() returns the Rows(y)-by-N output-history matrix Y, and
 *       the state-history matrix X.
 *
 *       If iu = 0, dimpuse_ss() returns matrices
 *
 *       [[Y for 1st input]          [[X for 1st input]
 *        [Y for 2nd input]           [X for 2nd input]
 *        [...............]           [...............]
 *        [Y for m'th input]]  and    [Y for m'th input]].
 *
 *      dimpulse_plot_xxx() plots the impulse response.
 *
 *  SEE ALSO
 *      impulse and dstep
 */

Func List dimpulse(A,B,C,D,iu,N)
	Matrix A,B,C,D;
	Integer iu,N;
{
	Matrix XX,YY;

	{YY,XX} = dimpulse_ss(A,B,C,D,iu,N);
	return {YY,XX};
}

Func List dimpulse_ss(A,B,C,D,iu,N)
	Matrix A,B,C,D;
	Integer iu,N;
{
	Integer i,m;
	Matrix X,Y,XX,YY;
	String msg;

	msg = abcdchk(A, B, C, D);
	if (length(msg) > 0) {
		error("dimpulse_ss(): " + msg);
	}
	
	if (iu == 0) {
		m = Cols(B);
		YY = Z(Rows(C)*m,N);
		XX = Z(Rows(A)*m,N);
		if (version() == 4) {
			for (i = 1; i <= m; i++) {
				{Y,X} = dlsim(A, B(:,i), C, D(:,i), [ONE(1), Z(1,N-1)]);
				YY(i-1,0,Y) = Y;
				XX(i-1,0,X) = X;
			}
		} else {
			for (i = 1; i <= m; i++) {
				{Y,X} = dlsim(A, B(:,i), C, D(:,i), [ONE(1), Z(1,N-1)]);
				YY(i,1,Y) = Y;
				XX(i,1,X) = X;
			}
		}
	} else {
		{YY,XX} = dlsim(A, B(:,iu), C, D(:,iu), [ONE(1), Z(1,N-1)]);
	}

	return {YY,XX};
}

Func List dimpulse_tfn(g, N)
	Rational g;
	Integer N;
{
	Matrix A,B,C,D;
	Matrix X, Y;
	
	{A, B, C, D} = tfn2ss(g);
	{Y, X} = dimpulse_ss(A, B, C, D, 1, N); 
	return {Y,X};
}

Func List dimpulse_tfm(G, iu, N)
	RaMatrix G;
	Integer iu,N;
{
	Matrix A,B,C,D;
	Matrix X, Y;
	
	if (iu == 0) {
		{A, B, C, D} = tfm2ss(G);
		{Y, X} = dimpulse_ss(A, B, C, D, iu, N); 
	} else {
		{A, B, C, D} = tfm2ss(G, iu);
		{Y, X} = dimpulse_ss(A, B, C, D, 1, N); 
	}
	return {Y, X};
}

Func List dimpulse_tf(num, den, N)
	Matrix num, den;
	Integer N;
{
	Matrix A,B,C,D;
	Matrix X, Y;
	
	{A, B, C, D} = tf2ss(num,den);
	{Y, X} = dimpulse_ss(A, B, C, D, 1, N); 
	return {Y, X};
}

Func void dimpulse_plot_tfn(g, N)
	Rational g;
	Integer N;
{
	Integer win;
	Matrix Y;

	win = 1;

	{Y} = dimpulse_tfn(g, N);

	mgplot_reset(win);
	mgplot_grid(win,1);
	mgplot_xlabel(win, "k");
	mgplot_ylabel(win, "y");
	mgplot(win, [1:N], Y, {"y"});
}

Func void dimpulse_plot_tf(num, den, N)
	Matrix num, den;
	Integer N;
{
	Rational g;

	g = tf2tfn(num, den);
	dimpulse_plot_tfn(g, N);
}

Func void dimpulse_plot_tfm(G, iu, N)
	RaMatrix G;
	Integer iu,N;
{
	Integer i,p,win;
	Matrix Y;
	List yy;

	win = 1;
	p = Rows(G);

	{Y} = dimpulse_tfm(G, iu, N);

	yy = makelist(p);
	for (i = 1; i <= p; i++) {
		if (p == 1) {
			yy(i) = "y";
		} else {
			yy(i) = sprintf("y%d", i);
		}
	}

	mgplot_reset(win);
	mgplot_grid(win,1);
	mgplot_xlabel(win, "k");
	mgplot_ylabel(win, "y");
	mgplot(win, [1:N], Y, yy);
}

Func void dimpulse_plot_ss(A,B,C,D,iu,N)
	Matrix A,B,C,D;
	Integer iu,N;
{
	Integer i,p,n,win;
	Matrix X,Y;
	List xx,yy;

	win = 1;
	n = Rows(A);
	p = Rows(C);

	{Y,X} = dimpulse_ss(A, B, C, D, iu, N);

	yy = makelist(p);
	for (i = 1; i <= p; i++) {
		if (p == 1) {
			yy(i) = "y";
		} else {
			yy(i) = sprintf("y%d", i);
		}
	}

	mgplot_reset(win);

	mgplot_hold(win, 1);

	mgplot_subplot(win, 2, 1, 1);
	mgplot_grid(win,1);
	mgplot_xlabel(win, "k");
	mgplot_ylabel(win, "y");
	mgplot(win, [1:N], Y, yy);

	xx = makelist(n);
	for (i = 1; i <= n; i++) {
		xx(i) = sprintf("x%d", i);
	}

	mgplot_subplot(win, 2, 1, 2);
	mgplot_grid(win,1);
	mgplot_xlabel(win, "k");
	mgplot_ylabel(win, "x");
	mgplot(win, [1:N], X, xx);

	mgplot_hold(win, 0);
}
