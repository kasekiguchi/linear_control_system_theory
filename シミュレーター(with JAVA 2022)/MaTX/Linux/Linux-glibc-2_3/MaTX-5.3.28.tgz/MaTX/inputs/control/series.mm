
/* -*- MaTX -*-
 *
 *  NAME
 *      series() - Series connection of two systems
 *
 *  SYNOPSIS
 *      {A,B,C,D} = series(A1,B1,C1,D1,A2,B2,C2,D2)
 *         Matrix A,B,C,D;
 *         Matrix A1,B1,C1,D1,A2,B2,C2,D2;
 *
 *  DESCRIPTION
 *       series() generates an system with the outputs of system-1 
 *         .
 *         x1 = A1 x1 + B1 u1
 *         y1 = C1 x1 + D1 u1
 *
 *       connected to the inputs of system-2
 *         .
 *         x2 = A2 x2 + B2 u2
 *         y2 = C2 x2 + D2 u2
 *
 *                       -1                                 -1
 *     u1 ---> C1(sI - A1)B1 ---> y1 ---> u2 ---> C2(sI - A2)B2 ---> y2
 *
 *  SEE ALSO
 *      parallel and TFmul
 */

Func List series(A1,B1,C1,D1,A2,B2,C2,D2)
	Matrix A1,B1,C1,D1,A2,B2,C2,D2;
{
	Integer n1,n2;
	Matrix A,B,C,D;
	String msg;

	if (length((msg = abcdchk(A1, B1, C1, D1))) > 0) {
		error("series(): " + msg);
	}
	if (length((msg = abcdchk(A2, B2, C2, D2))) > 0) {
		error("series(): " + msg);
	}

	n1 = Rows(A1);
	n2 = Rows(A2);
	
	if (n1 == 0) {
		A = A2;
		B = B2;
		C = C2;
		D = D1*D2;
	} else if (n2 == 0) {
		A = A1;
		B = B1;
		C = C1;
		D = D1*D2;
	} else {
		A = [[  A1 ,Z(n1,n2)]
			 [B2*C1,  A2    ]];
		B = [[  B1 ]
			 [B2*D1]];
		C = [D2*C1 C2];
		D = D2*D1;
	}
	return {A,B,C,D};
}
