
/* -*- MaTX -*-
 *
 *  NAME
 *      riccati() - Solution of continous-time Riccati equation
 *
 *  SYNOPSIS
 *      P = riccati(A,B,Q,R)
 *         Matrix P;
 *         Matrix A,B,Q,R;
 *
 *  DESCRIPTION
 *      riccati(A,B,Q,R) returns the solution of the continous-time
 *      Riccati equation:
 *
 *        A#*P + P*A + Q - P*B*R~*B#*P = 0
 *
 *  SEE ALSO
 *      are, ric, and lqr
 */

Func Matrix riccati(A,B,Q,R)
	Matrix A, B, Q, R;
{
	return ric(A, Q, B*R~*B#);
}

Func Matrix Riccati(A,B,Q,R)
	Matrix A, B, Q, R;
{
	return riccati(A,B,Q,R);
}
