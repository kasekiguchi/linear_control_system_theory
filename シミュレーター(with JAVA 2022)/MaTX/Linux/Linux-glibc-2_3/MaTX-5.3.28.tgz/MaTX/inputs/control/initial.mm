
/* -*- MaTX -*-
 *
 *  NAME
 *      initial_ss()  - Initial response of continuous-time linear system
 *      initial_tf()  - Initial response of continuous-time linear system
 *      initial_tfn() - Initial response of continuous-time linear system
 *      initial_tfm() - Initial response of continuous-time linear system
 *
 *      initial_plot_ss()  - Plot Initial response of cont-time linear system
 *      initial_plot_tf()  - Plot Initial response of cont-time linear system
 *      initial_plot_tfn() - Plot Initial response of cont-time linear system
 *      initial_plot_tfm() - Plot Initial response of cont-time linear system
 *
 *  SYNOPSIS
 *      {Y,X} = initial_ss(A,B,C,D,x0,T)
 *          Matrix X,Y;
 *          Matrix A,B,C,D;
 *          Matrix x0;
 *          Array T;
 *
 *      {Y,X} = initial_tf(num,den,x0,T)
 *         Matrix X,Y;
 *         Matrix num,den;
 *         Matrix 0;
 *         Array T;
 *
 *      {Y,X} = initial_tfn(g,x0,T)
 *         Matrix X,Y;
 *         Rational g;
 *         Matrix x0;
 *         Array T;
 *
 *      {Y,X} = initial_tfm(G,x0,T)
 *         Matrix X,Y;
 *         RaMatrix G;
 *         Matrix x0;
 *         Array T;
 *
 *      initial_plot_ss(A,B,C,D,x0,T)
 *         Matrix A,B,C,D;
 *         Matrix x0;
 *         Array T;
 *
 *      initial_plot_tf(num,den,x0,T)
 *         Matrix num,den;
 *         Matrix x0;
 *         Array T;
 *
 *      initial_plot_tfn(g,x0,T)
 *         Rational g;
 *         Matrix x0;
 *         Array T;
 *
 *      initial_plot_tfm(G,x0,T)
 *         RaMatrix G;
 *         Matrix x0;
 *         Array T;
 *
 *  DESCRIPTION
 *       initial_ss(A,B,C,D,x0,T) calculates the initial response of the 
 *       system:
 *      	.
 *      	x = Ax + Bu
 *      	y = Cx + Du
 *
 *       , where initial state is given by x0;
 *
 *       T is a regularly spaced time vector which specifies the time axis.
 * 
 *       initial_ss() returns the Rows(y)-by-length(T) output-history matrix
 *       Y and the state-history matrix X.
 *
 *       initial_plot_xxx() plots the initial response.
 *
 *  SEE ALSO
 *      impulse, step, dinitial
 */

Func List initial(A, B, C, D, x0, T)
	Matrix A, B, C, D;
	Matrix x0;
	Array T;
{
	Array X,Y;

	{Y,X} = initial_ss(A,B,C,D,x0,T);
	return {Y,X};
}

Func List initial_ss(A, B, C, D, x0, T)
	Matrix A, B, C, D;
	Matrix x0;
	Array T;
{
	Matrix Ad, Bd;
	Array X, Y;
	String msg;

	if (length((msg = abcdchk(A, B, C, D))) > 0) {
		error("initial_ss(): " + msg);
	}

	{Ad, Bd} = c2d(A, B, T(2) - T(1));
	{Y, X} = dinitial_ss(Ad, Bd, C, D, x0, T);
	return {Y, X};
}

Func List initial_tfn(g, x0, T)
	Rational g;
	Matrix x0;
	Array T;
{
	Matrix A,B,C,D;
	Array X, Y;
	
	{A, B, C, D} = tfn2ss(g);
	{Y, X} = initial_ss(A, B, C, D, x0, T); 
	return {Y,X};
}

Func List initial_tfm(G, x0, T)
	RaMatrix G;
	Matrix x0;
	Array T;
{
	Matrix A,B,C,D;
	Array X, Y;
	
	{A, B, C, D} = tfm2ss(G);
	{Y, X} = initial_ss(A, B, C, D, x0, T); 
	return {Y, X};
}

Func List initial_tf(num, den, x0, T)
	Matrix num, den;
	Matrix x0;
	Array T;
{
	Matrix A,B,C,D;
	Array X, Y;
	
	{A, B, C, D} = tf2ss(num,den);
	{Y, X} = initial_ss(A, B, C, D, x0, T); 
	return {Y, X};
}

Func void initial_plot_tfn(g, x0, T)
	Rational g;
	Matrix x0;
	Array T;
{
	Integer win;
	Array Y;

	win = 1;

	{Y} = initial_tfn(g, x0, T);

	mgplot_reset(win);

	mgplot_grid(win,1);
	mgplot_xlabel(win, "t [sec]");
	mgplot_ylabel(win, "y");
	mgplot(win, T, Y, {"y"});
}

Func void initial_plot_tf(num, den, x0, T)
	Matrix num, den;
	Matrix x0;
	Array T;
{
	Rational g;

	g = tf2tfn(num, den);
	initial_plot_tfn(g, x0, T);
}

Func void initial_plot_tfm(G, x0, T)
	RaMatrix G;
	Matrix x0;
	Array T;
{
	Integer i,p,win;
	Array Y;
	List yy;

	win = 1;
	p = Rows(G);

	{Y} = initial_tfm(G, x0, T);

	yy = makelist(p);
	for (i = 1; i <= p; i++) {
		if (p == 1) {
			yy(i) = "y";
		} else {
			yy(i) = sprintf("y%d", i);
		}
	}

	mgplot_reset(win);
	mgplot_grid(win,1);
	mgplot_xlabel(win, "t [sec]");
	mgplot_ylabel(win, "y");
	mgplot(win, T, Y, yy);
}

Func void initial_plot_ss(A,B,C,D,x0,T)
	Matrix A,B,C,D;
	Matrix x0;
	Array T;
{
	Integer i,p,n,win;
	Array X,Y;
	List xx,yy;

	win = 1;
	n = Rows(A);
	p = Rows(C);

	{Y,X} = initial_ss(A, B, C, D, x0, T);

	yy = makelist(p);
	for (i = 1; i <= p; i++) {
		if (p == 1) {
			yy(i) = "y";
		} else {
			yy(i) = sprintf("y%d", i);
		}
	}

	mgplot_reset(win);

	mgplot_hold(win, 1);

	mgplot_subplot(win, 2, 1, 1);
	mgplot_grid(win,1);
	mgplot_xlabel(win, "t [sec]");
	mgplot_ylabel(win, "y");
	mgplot(win, T, Y, yy);

	xx = makelist(n);
	for (i = 1; i <= n; i++) {
		xx(i) = sprintf("x%d", i);
	}

	mgplot_subplot(win, 2, 1, 2);
	mgplot_grid(win,1);
	mgplot_xlabel(win, "t [sec]");
	mgplot_ylabel(win, "x");
	mgplot(win, T, X, xx);

	mgplot_hold(win, 0);
}
