
/* -*- MaTX -*-
 *
 *  NAME
 *      charpoly() - Characteristic polynomial
 *
 *  SYNOPSIS
 *      p = charpoly(A)
 *        Polynomial p;
 *        Matrix A;
 *
 *  DESCRIPTION
 *      charpoly(A) returns a characteristic polynomail of matrix A.
 *
 *  SEE ALSO
 *      makepoly and faddeev
 */

Func Polynomial charpoly(A)
	Matrix	A;
{
	return makepoly(A);
}
