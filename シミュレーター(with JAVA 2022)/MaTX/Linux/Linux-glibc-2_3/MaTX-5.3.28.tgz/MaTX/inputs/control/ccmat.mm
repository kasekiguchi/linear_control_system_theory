
/* -*- MaTX -*-
 *
 *  NAME
 *      ccmat() - Transformation matrix for controlable canonical form
 *
 *  SYNOPSIS
 *      T = ccmat(A,b)
 *         Matrix T;
 *         Matrix A,b;
 *
 *  DESCRIPTION
 *      ccmat(A,b) returns the transformation matrix to transforms the
 *      system
 *          .
 *          x = Ax + bu
 *
 *      into controlable canonical form.
 *
 *      T is the matrix for the transformation, x = Tz
 *
 *      CoCanMat() is obsolete.  Use ccmat(A,b).
 *
 *  SEE ALSO
 *      canon
 */

Func Matrix ccmat(A,b)
	Matrix A,b;
{
	Matrix T,Vi;

	Vi = inv(ctrm(A, b));
	T = inv(obsm(A, Vi(Rows(A),:)));

	return T;
}

Func Matrix CoCanMat(A,b)
	Matrix A,b;
{
	return ccmat(A,b);
}
