
/* -*- MaTX -*-
 *
 *  NAME
 *      tfn2ss() -  Transfer function to state-space conversion
 *
 *  SYNOPSIS
 *      {A,B,C,D} = tfn2ss(g)
 *          Matrix A,B,C,D;
 *          Rational g;
 *
 *  DESCRIPTION
 *      tfn2ss(g) returns the state-space representation:
 *           .
 *           x = Ax + Bu
 *           y = Cx + Du
 *
 *      of the system, whose transfer function is g.
 *
 *      The A,B,C,D matrices are returned in controller canonical form.  
 *
 *  SEE ALSO
 *      tfn2tf, tfn2tfm, tfn2zp, and ss2tfn 
 */

Func List tfn2ss(g)
	Rational g;
{
	Matrix num,den;
	Matrix A,B,C,D;
	
	if (version() == 4) {
		num = fliplr(Matrix(Nu(g)));
		den = fliplr(Matrix(De(g)));
	} else {
		num = Matrix(Nu(g));
		den = Matrix(De(g));
	}
	
	{A,B,C,D} = tf2ss(num,den);

	return {A,B,C,D};
}
