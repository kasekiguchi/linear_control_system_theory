
/* -*- MaTX -*-
 *
 *  NAME
 *      tf2tfm() -  Transfer function to transfer function matrix conversion
 *
 *  SYNOPSIS
 *      G = tf2tfm(NUM,den)
 *         RaMatrix G;
 *         Matrix NUM, den;
 *
 *  DESCRIPTION
 *       tf2tfm() calculates the transfer function matrix representation:
 *
 *                  NUM(s) 
 *          G(s) = --------
 *                  den(s)
 *
 *      of the system SIMO.
 *
 *      den contains the coefficients of the denominator and NUM contains
 *      the numerator coefficients.
 *
 *      The elements of G(s) have the same denominator.
 *
 *  SEE ALSO
 *      tf2tfn, tf2ss, tf2zp, and tfm2tf
 */

Func RaMatrix tf2tfm(NUM, den)
	Matrix NUM, den;
{
	Integer i, p;
	Polynomial dd;
	PoMatrix N;

	p = Rows(NUM);
	if (version() == 4) {
		dd = Polynomial(fliplr(den));
	} else {
		dd = Polynomial(den);
	}
	N  = PoMatrix(Z(p,1));
	
	for (i = 1; i <= p; i++) {
		if (version() == 4) {
			N(i) = Polynomial(fliplr(NUM(i,:)));
		} else {
			N(i) = Polynomial(NUM(i,:));
		}
	}

	return N/dd;
}
