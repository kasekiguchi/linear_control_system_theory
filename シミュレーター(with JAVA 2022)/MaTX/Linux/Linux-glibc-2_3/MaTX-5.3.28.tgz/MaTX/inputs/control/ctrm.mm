
/*  -*- MaTX -*-
 *
 *  NAME
 *      ctrm() - Controllability matrix
 *
 *  SYNOPSIS
 *      V = ctrm(A,B)
 *         Matrix V;
 *         Matrix A,B;
 *
 *  DESCRIPTION
 *      ctrm() returns the controllability matrix 
 *
 *          V = [B AB A^2B ...]
 *
 *      ConMat() is obsolete.  Use ctrm()
 *
 *  SEE ALSO
 *      obsm and ctrf
 */

Func Matrix ctrm(A, B)
	Matrix A, B;
{
	Integer i, n;
	String msg;
	Matrix V;

	if (length((msg = abcdchk(A, B))) > 0) {
		error("ctrm(): " + msg);
	}

	n = Cols(A);
	if (isreal(A) && isreal(B)) {
		V = Z(1,n,B);
	} else {
		V = (Z(1,n,B),:);
	}

	if (version() == 4) {
		V(0,0,B) = B;
		for (i = 1; i <= n-1; i++) {
			V(0,i,B) = A*V(0,i-1,B);
		}
	} else {
		V(1,1,B) = B;
		for (i = 1; i <= n-1; i++) {
			V(1,i+1,B) = A*V(1,i,B);
		}
	}

	return V;
}

Func Matrix ConMat(A, B)
	Matrix A, B;
{
	return ctrm(A,B);
}
