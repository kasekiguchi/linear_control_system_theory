
/* -*- MaTX -*-
 *
 *  NAME
 *      obsm() - Observability matrix 
 *
 *  SYNOPSIS
 *      N = obsm(A,C)
 *         Matrix N;
 *         Matrix A,C;
 *
 *  DESCRIPTION
 *      obsm(A,C) returns the observability matrix
 *
 *          N = [[C][CA][CA^2 ...]]
 *
 *  SEE ALSO
 *      ctrm and obsf
 */

Func Matrix obsm(A,C)
	Matrix A, C;
{
	return ctrm(A#,C#)#;
}
