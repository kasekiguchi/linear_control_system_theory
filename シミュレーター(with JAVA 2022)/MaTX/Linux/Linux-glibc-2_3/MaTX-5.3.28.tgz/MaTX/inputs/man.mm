
/* -*- MaTX -*-
 *
 *  NAME
 *      man() - Show manual
 *
 *  SYNOPSIS
 *      man()
 *
 */

Func void man()
{
    String cmd;
	
#if MSVC || BCC || DJGPP
    cmd = "start " + getenv("MATXDIR") + "\\help\\help.htm";
#else
    cmd = "netscape " + getenv("MATXDIR") + "/help/help.htm &";
#endif
    system(cmd);
}
