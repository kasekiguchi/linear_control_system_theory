
/*  -*- MaTX -*-
 *
 *  $B!ZL>A0![(B
 *      leq_pre() - $B@:EYJ]>ZIU$-9TNsJ}Dx<0$N2r(B
 *
 *  $B!Z7A<0![(B
 *      {x,err} = leq_pre(A,b)
 *         Matrix x,err;
 *         Matrix A,b;
 *
 *  $B!Z5!G=@bL@![(B
 *      leq_pre(A,b) $B$O!$9TNsJ}Dx<0(B
 *
 *          A*x = b
 *
 *      $B$K??$N2r$,B8:_$9$k$+H=JL$7!$$b$7B8:_$9$l$P!$2r$H@.J,Kh$N(B
 *      $B8m:9I>2A$,JV$5$l$k!#(B
 *
 *  $B!Z%"%k%4%j%:%`![(B
 *      $BJ88%#1$N%"%k%4%j%:%`$r;HMQ!#(B
 *
 *  $B!ZJ88%![(B
 *      $B?tCM7W;;%D!<%k!$Bg@P?J0l!$%3%m%J<R!$(B2000
 *
 *  $B!ZNcBj![(B
 *      >> A = [[1, 2, -3][-2, 3, 4][3, -4, 5]];
 *      >> b = trans([1, 2, -3.3]);
 *      >> {x,err} = leq_pre(A,b);
 *      >> print x, err;
 *      ===  x  (   3  x   1)  Matrix  ===
 *                 (  1)     
 *      (  1) -2.70512821E-01
 *      (  2)  5.56410256E-01
 *      (  3) -5.25641026E-02
 *      ===  err  (   3  x   1)  Matrix  ===
 *                 (  1)     
 *      (  1)  3.84307970E-16
 *      (  2)  1.36642834E-16
 *      (  3)  1.46606374E-16
 *
 *  $B!Z4XO"9`L\![(B
 *      lu, inv
 */

#ifdef DEBUG
Func void leq_pre_test()
{
	Matrix A,b,x,err;

	List leq_pre();

	A = [[ 1,    2, -3,   5, 9]
		 [-2,    3,  5,   7, 1]
		 [ 9, -8.5,  3,   2, 1]
		 [-1,   -3,  7, 3.5, 1]
		 [-2,    3, -1,   1, 1]];

	b = trans([1, 2, -3, -5, -1]);

	{x,err} = leq_pre(A,b);
	print x, err;

	print "\n";

	A = [[ 1,  2, -3]
		 [-2,  3,  4]
		 [ 3, -4,  5]];

	b = trans([1, 2, -3.3]);

	{x,err} = leq_pre(A,b);
	print x, err;
}
#endif

Func List leq_pre(A,b)
	Matrix A;
	Matrix b;
{
	Integer n,m;
	Real D, R_norm, G_norm, Rr_norm, err, nerror;
	Matrix R,x,Gd,Gu,Rru,Rrd;
	Matrix rd,ru,center,radius,kappa,err2;

	R = inv(A);
	x = R*b;
	{n,m} = size(A);

	fpu_round_down();

	Gd = abs(R*A - I(n));
	rd = A*x - b;

	fpu_round_up();

	Gu = abs(R*A - I(n));
	ru = A*x - b;

	center = (ru + rd)/2;
	radius = center - rd;

	Rru = abs(R*center + abs(R)*radius);

	fpu_round_down();

	Rrd = abs(R*center - abs(R)*radius);

	D = 1 - norm(max(Gd,Gu), Inf);
	
	if (D > 0) { 
		fpu_round_up();

		Rru = max(Rrd, Rru);
		Rr_norm = norm(Rru, Inf);
		err = Rr_norm/D;
		kappa = Gu*ONE(n,1);
		err2 = Rru + (err*kappa);
		nerror = max(err2);
	} else {
		fpu_round_near();
		error("leq_pre(): No solution.\n");
	}
	
	fpu_round_near();
	return {x,err2};
}

