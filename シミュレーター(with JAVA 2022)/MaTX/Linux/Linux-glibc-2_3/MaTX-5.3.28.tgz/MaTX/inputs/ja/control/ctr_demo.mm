
/* -*- MaTX -*-
 *  
 *  ��̾����
 *      ctr_demo() - ������߷ץġ���ܥå����ǥ�󥹥ȥ졼�����
 *
 *  �ڷ�����
 *      ctr_demo()
 *
 *  �ڵ�ǽ������
 *      �ǥ�󥹥ȥ졼�����Υ�˥塼��ɽ�����롣
 */

Func void ctr_demo()
{
	Integer i;
	List mm;

	void ctr_demo_transfer_function(), ctr_demo_poleassign();
	void ctr_demo_servo(), ctr_demo_observer(), ctr_demo_lqr();
	
	mm = {"������߷ץġ���ܥå���",
		  "��ã�ؿ��ȼ��ȿ�����",
		  "����������",
		  "1 �������ܷϤ��߷�",
		  "�����֥��֥����Ф��߷�",
		  "�����󼡷�����Ŭ�쥮��졼��",
		  "��  λ"};

	i = 1;
	for (;;) {
		i = menu(mm, i);
		switch (i) {
		  case 1:
			ctr_demo_transfer_function();
			break;
		  case 2:
			ctr_demo_poleassign();
			break;
		  case 3:
			ctr_demo_servo();
			break;
		  case 4:
			ctr_demo_observer();
			break;
		  case 5:
			ctr_demo_lqr();
			break;
		}
		if (i == length(mm)-1) { break; }
		i++;
	}
}

Func void ctr_demo_transfer_function()
{
	Integer win;
	Matrix A, B, C, D, P;
	Matrix num, den, kk;
	Rational g;
	Polynomial s;
	Array w, ga, ph, re, im, k, t, y;
	CoMatrix po, ze, ro;

	win = mgplot_cur_win();

	clear;
	print "\n";
	print "������ã�ؿ���ץ��ȤˤĤ��ƹͤ��롣\n";
	print "                   2                    \n";
	print "              0.2 s  +  0.3 s  +  1     \n";
	print "H(s)  =  -------------------------------\n";
	print "           2                            \n";
	print "         (s  +  0.4 s  +  1) (s  +  0.5)\n";
	print "\n";
	print "�ޤ���¿�༰�ѿ� 's' �����������ã�ؿ������Ϥ��롣\n";
	print "\n";
	print "\ts = Polynomial(\"s\");\n";
	print "\tg = (0.2*s^2 + 0.3*s + 1)/((s^2 + 0.4*s + 1)*(s + 0.5));\n";
	print "\n";
	pause;

	s = Polynomial("s");
	g = (0.2*s^2 + 0.3*s + 1)/((s^2 + 0.4*s + 1)*(s + 0.5));

	print "��ã�ؿ���ʬ��¿�༰��ʬ��¿�༰�η�������롣\n";
	print "\n";
	print "\t{num,den} = tfn2tf(g);\n";
	print "\tprint num, den;\n";
	print "\n";
	pause;

	{num,den} = tfn2tf(g);
	print num, "\n", den, "\n";

	print "���ֶ���ɽ��:\n";
	print "\t.           \n";
	print "\tx = Ax + Bu \n";
	print "\ty = Cx + Du \n";
	print "\n";
	print "\t{A,B,C,D} = tf2ss(num,den);\n";
	print "\tprint A,B,C,D;\n";
	print "\n";
	pause;

	{A,B,C,D} = tf2ss(num,den);
	print A,B,C,D;

	print "\n";
	print "�ˡ�������, ������:\n";
	print "\n";
	print "\t{ze,po,kk} = ss2zp(A,B,C,D);\n";
	print "\tprint po,ze;\n";
	print "\n";
	pause;

	{ze,po,kk} = ss2zp(A,B,C,D);
	print po,"\n",ze;

	print "\n";
	print "Ϳ����줿��ã�ؿ�\n";
	print "\n";
	print "\tg = ss2tfn(A, B, C, D)\n";
	print "\n";
	pause;

	print g = ss2tfn(A, B, C, D);

	// ������

	print "\n";
	print "������:\n";
	print "\n";
	print "\tk = [0:0.5:10];\n";
	print "\trlocus_plot_tf(num,den,k);\n";
/*
	print "\tro = rlocus(num,den,k);\n";
	print "\n";
	print "\tmgplot(win,Re(ro),Im(ro));\n";
	print "\tmgplot_title(win,\"Root-locus\");\n";
	print "\tmgplot_xlabel(win,\"Real part\");\n";
	print "\tmgplot_ylabel(win,\"Imag part\");\n";
*/
	print "\n";
	pause;

	k = [0:.5:10];
	rlocus_plot_tf(num,den,k);
/*
	ro = rlocus_tf(num,den,k);

	mgplot_reset(win);
	mgplot_title(win,"Root-locus");
	mgplot_xlabel(win,"Real part");
	mgplot_ylabel(win,"Imag part");
	mgplot(win,Re(ro),Im(ro),{"","",""},{"1","1","1"});
*/
	// ���ֱ���

	print "���ƥåױ���\n";
	print "\n";
	print "\tt = [0:0.3:15];\n";
	print "\tstep_plot_ss(A,B,C,D,1,t);\n";
/*
	print "\t{y} = step(A,B,C,D,1,t);\n";
	print "\n";
	print "\tmgplot(win,t,y,{\"y\"});\n";
	print "\tmgplot_title(win,\"Step response\");\n";
	print "\tmgplot_xlabel(win,\"time(sec)\");\n";
*/
	print "\n";
	pause;

	t = [0:0.3:15];
	step_plot_ss(A,B,C,D,1,t);
/*
	{y} = step_ss(A,B,C,D,1,t);

	mgplot_reset(win);
	mgplot(win,t,y,{"y"});
	mgplot_title(win,"Step response");
	mgplot_xlabel(win,"time(sec)");
*/
	// ���ȿ�����

	print "�ܡ�������(���ȿ�����)\n";
	print "\n";
	print "\tw = logspace(0.01, 100.0);\n";
	print "\tbode_plot_tfn(g,w);\n";
/*
	print "\t{ga,ph} = bode_tfn(g,w);\n";
	print "\tga = 20*log10(ga);\n";
	print "\n";
	print "\tmgplot_subplot(win,2,1,1);\n";
	print "\tmgplot_semilogx(win,w,ga,{\"gain\"});\n";
	print "\tmgplot_xlabel(win,\"Rad/s\");\n";
	print "\n";
	print "\tmgplot_subplot(win,2,1,2);\n";
	print "\tmgplot_semilogx(win,w,ph,{\"phase\"});\n";
	print "\tmgplot_xlabel(win,\"Rad/s\");\n";
*/
	print "\n";
	pause;

	w = logspace(0.001, 1000.0, 1000);
	bode_plot_tfn(g,w);
/*
	{ga,ph} = bode_tfn(g,w);
	ga = 20*log10(ga);

	win = mgplot_cur_win();
	mgplot_reset(win);
	mgplot_hold(win, 1);
	mgplot_subplot(win,2,1,1);
	mgplot_cmd(win, "set lmargin 10");
	mgplot_semilogx(win,w,ga,{"gain"});
	mgplot_xlabel(win,"Rad/s");

	mgplot_subplot(win,2,1,2);
	mgplot_cmd(win, "set lmargin 10");
	mgplot_semilogx(win,w,ph,{"phase"});
	mgplot_xlabel(win,"Rad/s");
	mgplot_hold(win, 0);
*/
	print "�ʥ�����������\n";
	print "\n";
	print "\tnyquist_plot_tfn(g, w);\n";
/*
	print "\t{re, im} = nyquist_tfn(g, w);\n";
	print "\n";
	print "\tmgplot_subplot(win, 1, 1);\n";
	print "\tmgplot_cmd(win, \"set xrange [-3:1]\");\n";
	print "\tmgplot_cmd(win, \"set yrange [-2:1]\");\n";
	print "\tmgplot_grid(win);\n";
	print "\tmgplot(win, re, im, {\"nyquist\"});\n";
*/
	print "\n";
	pause;

	nyquist_plot_tfn(g, w);

/*
	{re, im} = nyquist_tfn(g, w);

	mgplot_reset(win);
	mgplot_hold(win, 1);
	mgplot_subplot(win, 1, 1);
	mgplot_cmd(win, "set xrange [-3:1]");
	mgplot_cmd(win, "set yrange [-3:1]");
	mgplot_grid(win);
	mgplot(win, re, im, {"nyquist"});
	mgplot_hold(win, 0);
*/
	pause;
}

/*
 * ����������
 */
Func void ctr_demo_poleassign()
{
	Complex i;
	Matrix A, B, C, D;
	Matrix V, N, T, JA, J, JJ, F;
	Polynomial p, pc;

	print "\n";
	print "���� A, B, C, D�����Ϥ���\n";
	print "\n";
	print "\tA = [[ 0    1   0]\n";
	print "\t     [ 0    0   1]\n";
	print "\t     [-6, -11, -6]]\n";
	print "\tB = [[0]\n";
	print "\t     [0]\n";
	print "\t     [10]]\n";
	print "\tC = [1 0 0]\n";
	print "\tD = [0]\n";
	print "\n";
	pause;

	A = [[ 0    1   0]
		 [ 0    0   1]
		 [-6, -11, -6]];
	B = [[0]
		 [0]
		 [10]];
	C = [1 0 0];
	D = [0];

	print "\n��������� V ��׻�����\n";
	print "\n";
	print "\tV = ctrm(A, B)\n";
	print "\n";
	pause;

	print V = ctrm(A, B);

	print "\n";
	print "����������Ĵ�٤�\n";
	print "\n";
	print "\trank(V)\n";
	print "\n";
	pause;

	print rank(V);

	print "\n";
	print "���� A ������¿�༰\n";
	print "\n";
	print "\tp = makepoly(A)\n";
	print "\n";
	pause;

	print p = makepoly(A);

	print "\n";
	print "������������ؤ��Ѵ����� T\n";
	print "\n";
	print "\tN = [[p(1) p(2) 1]\n";
	print "\t     [p(2)  1   0]\n";
	print "\t     [ 1    0   0]];\n";
	print "\tT = V*N\n";
	print "\n";
	pause;

	N = [[p(1) p(2) 1]
		 [p(2)  1   0]
		 [ 1    0   0]];

	print T = V*N;

	print "\n";
	print "˾�ޤ����ˤ����ĥ롼�׷Ϥ�����¿�༰\n";
	print "\n";
	print "\ti = (0,1);\n";
	print "\tpc = Re(makepoly([-2+3*i, -2-3*i, -10.0]))\n";
	print "\n";
	pause;

	i = (0,1);
	print pc = Re(makepoly([-2+3*i, -2-3*i, -10.0]));

	print "\n";
	print "���֥ե����ɥХå���������� F \n";
	print "\n";
	print "\tF = [pc(0)-p(0), pc(1)-p(1), pc(2)-p(2)]*inv(T)\n";
	print "\n";
	pause;

	print F = [pc(0)-p(0), pc(1)-p(1), pc(2)-p(2)]*inv(T);

	print "\n";
	print "�ĥ롼�׷Ϥζˤ�Ĵ�٤�\n";
	print "\n";
	print "\teigval(A - B*F)\n";
	print "\n";
	pause;

	print eigval(A - B*F);

	print "\n";
	pause;
}

/*
 * �����ܷϤ��߷�
 */
Func void ctr_demo_servo()
{
	Integer win;
	Real Fi;
	Complex i;
	Matrix A, B, C, D, F;
	Matrix Aa, Ba, Ca, Da, Fa, V, P;
	Matrix Ac, Bc, Cc, Dc;
	Array T, X, Y;

	print "\n";
	print "���� A, B, C, D �����Ϥ��롣\n";
	print "\n";
	print "\tA = [[   0 1 0 0]\n";
	print "\t     [  20 0 0 0]\n";
	print "\t     [   0 0 0 1]\n";
	print "\t     [-0.5 0 0 0]];\n";
	print "\tB = [[ 0 ]\n";
	print "\t     [ -1]\n";
	print "\t     [ 0 ]\n";
	print "\t     [0.5]];\n";
	print "\tC = [0 0 1 0];\n";
	print "\tD = [0];\n";
	print "\n";
	pause;

	A = [[   0 1 0 0]
		 [  20 0 0 0]
		 [   0 0 0 1]
		 [-0.5 0 0 0]];
	B = [[0][-1][0][0.5]];
	C = [0 0 1 0];
	D = [0];

	print "��ĥ��:\n";
	print "\n";
	print "\tAa = [[ A, Z(4,1)]\n";
	print "\t      [-C,   Z(1)]]\n";
	print "\tBa = [[B]\n";
	print "\t      [0]]\n";
	print "\n";
	pause;

	print Aa = [[ A Z(4,1)]
				[-C, Z(1)]];
	print Ba = [[B][0]];

	print "\n";
	print "����Ϥβ��������\n";
	print "\n";
	print "\tV = ctrm(Aa, Ba)\n";
	print "\n";
	pause;

	print V = ctrm(Aa, Ba);

	print "\n";
	print "����Ϥβ���������Ĵ�٤�\n";
	print "\n";
	print "\trank(V)\n";
	print "\n";
	pause;

	print rank(V);

	print "\n";
	print "�ĥ롼�׷Ϥζˤ���ʤ�٥��ȥ�\n";
	print "\n";
	print "\ti = (0,1);\n";
	print "\tP = [[-1+sqrt(3)*i]\n";
	print "\t     [-1-sqrt(3)*i]\n";
	print "\t     [      -5    ]\n";
	print "\t     [      -5    ]\n";
	print "\t     [      -5    ]]\n";
	print "\n";
	pause;

	i = (0,1);
	print P = [[-1+sqrt(3)*i]
			   [-1-sqrt(3)*i]
			   [    -5      ]
			   [    -5      ]
			   [    -5      ]];

	print "\n";
	print "������������\n";
	print "\n";
	print "\tFa = pplace(Aa, Ba, P)\n";
	print "\tFi = - Fa(5);\n";
	print "\n";
	pause;

	print Fa = pplace(Aa, Ba, P);
	print "\n";
	print Fi = - Fa(5);
	print "\n";
	pause;

	print "���֥ե����ɥХå����������\n";
	print "\n";
	print "\tF = Fa(1:4)\n";
	print "\n";
	pause;

	print F = Fa(1:4);

	print "\n";
	print "�ĥ롼�׷�:\n";
	print "\n";
	print "\tAc = [[ A - B*F, B*Fi]\n";
	print "\t      [   -C   , Z(1)]];\n";
	print "\tBc = [[0]\n";
	print "\t      [0]\n";
	print "\t      [0]\n";
	print "\t      [1]];\n";
	print "\tCc = [C Z(1)];\n";
	print "\tDc = [0];\n";
	print "\n";
	pause;

	print Ac = [[A - B*F, B*Fi]
				[  -C   , Z(1)]];
	print Bc = [[0][0][0][0][1]];
	print Cc = [C Z(1)];
	print Dc = [0];

	print "\n���ƥåױ�����׻�����\n";
	print "\n";
    print "\tT = linspace(0.0, 5.0);\n";
	print "\t{Y, X} = step_ss(Ac, Bc, Cc, Dc, 1, T);\n";
	print "\n";
	pause;

	T = linspace(0.0, 5.0);
	{Y, X} = step_ss(Ac, Bc, Cc, Dc, 1, T);

	print "���ƥåױ�����ץ��åȤ��� (y vs t)\n";
	print "\n";
	print "\tmgplot_subplot(win, 2, 1, 1);\n";
	print "\tmgplot_grid(win, 1);\n";
	print "\tmgplot_title(win, \"Output y versus Time t\");\n";
	print "\tmgplot_xlabel(win, \"Sec\");\n";
	print "\tmgplot_ylabel(win, \"Output y = x3\");\n";
	print "\tmgplot(win, T, Y, {\"y\"});\n";
	print "\n";
	pause;

	win = mgplot_cur_win();
	mgplot_reset(win);
	mgplot_subplot(win, 2, 1, 1);
	mgplot_grid(win, 1);
	mgplot_title(win, "Output y versus Time t");
	mgplot_xlabel(win, "Sec");
	mgplot_ylabel(win, "Output y = x3");
	mgplot(win, T, Y, {"y"});

	print "\n";
	print "���ƥåױ�����ץ��åȤ��� (x vs t)\n";
	print "\n";
	print "\tmgplot_subplot(win, 2, 1, 2);\n";
	print "\tmgplot_grid(win, 1);\n";
	print "\tmgplot_title(win, \"Response Curves for x1, x2, x3, x4, x5\");\n";
	print "\tmgplot_xlabel(win, \"Sec\");\n";
	print "\tmgplot_ylabel(win, \"x1, x2, x3, x4, x5\");\n";
	print "\tmgplot_text(win, \"x1\", 1.2,  0.05);\n";
	print "\tmgplot_text(win, \"x2\", 1.2, -0.32);\n";
	print "\tmgplot_text(win, \"x3\", 1.2,  0.33);\n";
	print "\tmgplot_text(win, \"x4\", 2.2,  0.25);\n";
	print "\tmgplot_text(win, \"x5\", 1.5,  1.28);\n";
	print "\tmgplot(win, T, X, {\"x1\", \"x2\", \"x3\", \"x4\", \"x5\"});\n";
	print "\n";
	pause;

	mgplot_subplot(win, 2, 1, 2);
	mgplot_grid(win, 1);
	mgplot_title(win, "Response Curves for x1, x2, x3, x4, x5");
	mgplot_xlabel(win, "Sec");
	mgplot_ylabel(win, "x1, x2, x3, x4, x5");
	mgplot_text(win, "x1", 1.2,  0.05);
	mgplot_text(win, "x2", 1.2, -0.32);
	mgplot_text(win, "x3", 1.2,  0.33);
	mgplot_text(win, "x4", 2.2,  0.25);
	mgplot_text(win, "x5", 1.5,  1.28);
	mgplot(win, T, X, {"x1", "x2", "x3", "x4", "x5"});

	pause;
}

/*
 * �����ִ�¬����߷�
 */
Func void ctr_demo_observer()
{
	Complex i;
	Matrix A, C, N, W, T, Fo;
	Polynomial p, po;

	print "\n";
	print "���� A, C �����Ϥ���\n";
	print "\n";
	print "\tA = [[ 0    1   0]\n";
	print "\t     [ 0    0   1]\n";
	print "\t     [-5, -10, -5]]\n";
	print "\tC = [1 0 0]\n";
	print "\n";
	pause;

	A = [[ 0    1   0]
		 [ 0    0   1]
		 [-5, -10, -5]];
	C = [1 0 0];

	print "�Ĵ�¬����:\n";
	print "\n";
	print "\tN = obsm(A,C)\n";
	print "\n";
	pause;

	print N = obsm(A,C);

	print "\n";
	print "�Ĵ�¬����Ĵ�٤�\n";
	print "\n";
	print "\trank(N)\n";
	print "\n";
	pause;

	print rank(N);

	print "\n";
	print "���� A ������¿�༰\n";
	print "\n";
	print "\tp = makepoly(A)\n";
	print "\n";
	pause;

	print p = makepoly(A);

	print "\n";
	print "�Ĵ�¬������ؤ��Ѵ�����\n";
	print "\n";
	print "\tW = [[p(1) p(2) 1]\n";
	print "\t     [p(2)  1   0]\n";
	print "\t     [ 1    0   0]];\n";
	print "\tT = W*N'\n";
	print "\n";
	pause;

	W = [[p(1) p(2) 1]
		 [p(2)  1   0]
		 [ 1    0   0]];

	print T = W*N';

	print "\n";
	print "���֥����Фζˤ�������¿�༰:\n";
	print "\n";
	print "\ti = (0,1);\n";
	print "\tpo = Re(makepoly([-2+i, -2-i, -5]))\n";
	print "\n";
	pause;

	i = (0,1);
	print po = Re(makepoly([-2+i, -2-i, -5]));

	print "\n";
	print "���֥����ФΥ�����\n";
	print "\n";
	print "\tFo = T \\ [po(0)-p(0), po(1)-p(1), po(2)-p(2)]'\n";
	print "\n";
	pause;

	print Fo = T \ [po(0)-p(0), po(1)-p(1), po(2)-p(2)]';
	print "\n";

	pause;
}

/*
 * ��Ŭ�쥮��졼�����߷�
 */
Func void ctr_demo_lqr()
{
	Integer win;
	Matrix A, B, C, D, Ac, Cc;
	Matrix Q, R, F, P;
	CoMatrix pc;
	Array to, xo, yo, tc, xc, yc;

	print "\n";
	print "���� A, B �����Ϥ���\n";
	print "\n";
	print "\tA = [[  0    1   0]\n";
	print "\t     [  0    0   1]\n";
	print "\t     [-35, -27, -9]]\n";
	print "\tB = [[0]\n";
	print "\t     [0]\n";
	print "\t     [1]]\n";
	print "\tC = I(3);\n";
	print "\tD = Z(3,1);\n";
	print "\n";
	pause;

	A = [[  0    1   0]
		 [  0    0   1]
		 [-35, -27, -9]];
	B = [[0][0][1]];
	C = I(3);
	D = Z(3,1);

	print "�Ť߹��� Q �� R �����Ϥ���\n";
	print "\n";
	print "\tQ = 100 * I(3)\n";
	print "\tR = [1]\n";
	print "\n";
	pause;

	Q = 100 * I(3);
	R = [1];

	print "��Ŭ���֥ե����ɥХå�������:\n";
	print "\n";
	print "\t{F} = lqr(A,B,Q,R);\n";
	print "\n";
	pause;

	{F} = lqr(A,B,Q,R);
	print F;

	print "\n";
	print "�ĥ롼�׷Ϥζˤ���ޤ�\n";
	print "\n";
	print "\tpc = eigval(A - B*F)\n";
	print "\n";
	pause;

	print pc = eigval(A - B*F);

	print "\n";
	print "���롼�׷ϤΥ��ƥåױ���\n";
	print "\n";
	print "\tC = I(3);\n";
	print "\tD = Z(3,1);\n";
	print "\tto = linspace(0.0, 5.0);\n";
	print "\t{yo, xo} = step_ss(A, B, C, D, 1, to);\n";
	print "\n";
	pause;

	to = linspace(0.0, 5.0);
	{yo, xo} = step_ss(A, B, C, D, 1, to);

	print "���ƥåױ�����ץ��åȤ��� (yo1 vs t)\n";
	print "\n";
	print "\tmgplot_subplot(win, 3, 1, 1);\n";
	print "\tmgplot_grid(win, 1);\n";
	print "\tmgplot_title(win, \"Output yo1\");\n";
	print "\tmgplot(win, t, yo(1,:), {\"yo1\"});\n";
	print "\n";
	pause;

	win = mgplot_cur_win();
	mgplot_reset(win);

	mgplot_subplot(win, 3, 1, 1);
	mgplot_grid(win, 1);
	mgplot_title(win, "Output yo1");
	mgplot(win, to, yo(1,:), {"yo1"});

	print "���ƥåױ�����ץ��åȤ��� (yo2 vs t)\n";
	print "\n";
	print "\tmgplot_grid(win, 1);\n";
	print "\tmgplot_title(win, \"Output yo2\");\n";
	print "\tmgplot(win, t, yo(2,:), {\"yo2\"});\n";
	print "\n";
	pause;

	mgplot_subplot(win, 3, 1, 2);
	mgplot_grid(win, 1);
	mgplot_title(win, "Output yo2");
	mgplot(win, to, yo(2,:), {"yo2"});

	print "���ƥåױ�����ץ��åȤ��� (yo3 vs t)\n";
	print "\n";
	print "\tmgplot_subplot(win, 3, 1, 3);\n";
	print "\tmgplot_grid(win, 1);\n";
	print "\tmgplot_title(win, \"Output yo3\");\n";
	print "\tmgplot(win, t, yo(3,:), {\"yo3\"});\n";
	print "\n";
	pause;

	mgplot_subplot(win, 3, 1, 3);
	mgplot_grid(win, 1);
	mgplot_title(win, "Output yo3");
	mgplot(win, to, yo(3,:), {"yo3"});

	print "�ĥ롼�׷ϤΥ��ƥåױ���\n";
	print "\n";
	print "\tAc = A - B*F;\n";
	print "\tCc = C - D*F;\n";
	print "\ttc = linspace(0.0, 5.0);\n";
	print "\t{yc, xc} = step_ss(Ac, B, Cc, D, 1, tc);\n";
	print "\n";
	pause;

	Ac = A - B*F;
	Cc = C - D*F;
	tc = linspace(0.0, 5.0);
	{yc, xc} = step_ss(Ac, B, Cc, D, 1, tc);

	print "���ƥåױ�����ץ��åȤ��� (yc1 vs t)\n";
	print "\n";
	print "\tmgplot_subplot(win, 3, 1, 1);\n";
	print "\tmgplot_grid(win, 1);\n";
	print "\tmgplot_title(win, \"Output yo1 and yc1\");\n";
	print "\tmgreplot(win, t, yc(1,:), {\"yc1\"});\n";
	print "\n";
	pause;

	mgplot_subplot(win, 3, 1, 1);
	mgplot_grid(win, 1);
	mgplot_title(win, "Output yo1 and yc1");
	mgreplot(win, tc, yc(1,:), {"yc1"});

	print "���ƥåױ�����ץ��åȤ��� (yc2 vs t)\n";
	print "\n";
	print "\tmgplot_subplot(win, 3, 1, 2);\n";
	print "\tmgplot_grid(win, 1);\n";
	print "\tmgplot_title(win, \"Output yo2 and yc2\");\n";
	print "\tmgreplot(win, t, yc(2,:), {\"yc2\"});\n";
	print "\n";
	pause;

	mgplot_subplot(win, 3, 1, 2);
	mgplot_grid(win, 1);
	mgplot_title(win, "Output yo2 and yc2");
	mgreplot(win, tc, yc(2,:), {"yc2"});

	print "���ƥåױ�����ץ��åȤ��� (yc3 vs t)\n";
	print "\n";
	print "\tmgplot_subplot(win, 3, 1, 3);\n";
	print "\tmgplot_grid(win, 1);\n";
	print "\tmgplot_title(win, \"Output yo3 and yc3\");\n";
	print "\tmgreplot(win, t, yc(3,:), {\"yc3\"});\n";
	print "\n";
	pause;

	mgplot_subplot(win, 3, 1, 3);
	mgplot_grid(win, 1);
	mgplot_title(win, "Output yo3 and yc3");
	mgreplot(win, tc, yc(3,:), {"yc3"});
	pause;
}
