
/*  -*- MaTX -*-
 *
 *  $B!ZL>A0![(B
 *      linspace() - $B@~7AEy4V3V%Y%/%H%k(B
 *
 *  $B!Z7A<0![(B
 *      y = linspace(x1, x2, n, ...)
 *         Array y;
 *         Real x1, x2;
 *         ...
 *         Integer n = 100;
 *
 *  $B!Z5!G=@bL@![(B
 *      linspace(x1,x2) $B$O!$(Bx1 $B$H(B x2 $B$rEy4V3V$G(B 100 $BJ,3d$7$?(B 100 $B8D$N(B
 *      $BCM$+$i$J$k9T%Y%/%H%k$rJV$9!#(B
 *      linspace(x1,x2,N) $B$O!$(Bx1 $B$H(B x2 $B$rEy4V3V$G(B N $BJ,3d$7$?(B N $B8D$N(B
 *      $BCM$+$i$J$k9T%Y%/%H%k$rJV$9!#(B
 *
 *  $B!Z4XO"9`L\![(B
 *      logspace
 */

Func Array linspace(x1, x2, n, ...)
	Real x1, x2;
	Integer n;
{
	Array y;
	
	error(nargchk(2, 3, nargs, "linspace"));

	if (nargs == 2) {
		n = 100;
	} 

	y = [x1 .+ [0:n-2]*(x2-x1)/(n-1), x2];
	return y;
}
