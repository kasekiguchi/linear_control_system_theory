
/*  -*- MaTX -*-
 *
 *  $B!ZL>A0![(B
 *      logspace() - $BBP?tEy4V3V%Y%/%H%k(B
 *
 *  $B!Z7A<0![(B
 *      y = logspace(x1, x2, n, ...)
 *         Array y;
 *         Real x1, x2;
 *         ...
 *         Integer n = 100;
 *
 *  $B!Z5!G=@bL@![(B
 *      logspace(x1,x2) $B$O!$(B10^x1 $B$H(B 10^x2 $B$rBP?tEy4V3V$G(B 50 $BJ,3d$7$?(B 50 $B8D(B
 *      $B$NCM$+$i$J$k9T%Y%/%H%k$rJV$9!#$b$7!$(Bx2 $B$,(B PI $B$J$i!$(B10^x1 $B$H(B PI $B$r(B
 *      $BBP?tEy4V3V$9$k!#(B
 *      logspace(x1,x2,N) $B$O!$(B10^x1 $B$H(B 10^x2 $B$rBP?tEy4V3V$G(B N $BJ,3d$7$?(B N $B8D$N(B
 *      $BCM$+$i$J$k9T%Y%/%H%k$rJV$9!#(B
 *
 *  $B!Z4XO"9`L\![(B
 *      linspace
 */

Func Array logspace(x1, x2, n, ...)
	Real x1, x2;
	Integer n;
{
	Array y;

	error(nargchk(2, 3, nargs, "logspace"));

	if (nargs == 2) {
		n = 50;
	}
	if (x2 == PI) {
		x2 = log10(PI);
	}
	if (0 < x1 && 0 < x2 && (abs(x1) <= 0.1 || 10.0 <= abs(x2))) {
		x1 = log10(x1);
		x2 = log10(x2);
	}

	y = 10.0 .^ [x1 .+ [0:n-2]*(x2-x1)/(n-1), x2];
	return y;
}
