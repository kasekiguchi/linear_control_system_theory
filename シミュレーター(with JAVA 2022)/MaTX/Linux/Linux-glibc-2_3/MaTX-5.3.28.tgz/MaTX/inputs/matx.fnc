< Builtin Function >>

** First Step **

  demo: Demonstration
  help: Help message
  man:  Manual
  quit: Exit from MaTX

** Managing variables and functions

  clear:   Clear variables
  gets:    Read one line from standard input
  install: install a function in the dynamic link library
  kbhit:   Check if there exists a data in standard input
  load:    Read (MM-files|shared object files)
  print:   Display variables
  printf:  Display formatted data to standard output
  read:    Input variables from standard input
  save:    Save varialbes as an MM-file
  scanf:   Input formatted data from standard input
  what:    List registered functions
  which:   Display information of functions
  who:     List registered variables
  whos:    Display information of variables

** Working with files and operating system

  chdir:   Change the working directory
  getenv:  Get environment variable
  mkdir:   Make a directory
  pclose:  Close a pipe
  popen:   Open a pipe
  remove:  Remove a file
  rename:  Rename a file
  rmdir:   Remove a directory
  setenv:  Set environment variable
  system:  Execute operating system command
   !       Execute operating system command

** Networking with socket (Not available for MaTX-DJGPP)

  socket_accept:   Accept a connection on a socket
  socket_bind:     Bind a name to a socket
  socket_close:    Close a socket
  socket_connect:  Initiate a connection on a socket
  socket_gets:     Input a string from a TCP-socket
  socket_listen:   Listen for connection on a socket
  socket_open:     Create an endpoint for communication
  socket_puts:     Output a string to a TCP-socket
  socket_read:     Receive data from a TCP-socket
  socket_recvfrom: Receive a string from a UDP-socket
  socket_sendto:   Send a string to a UDP-socket
  socket_shutdown: Shut down part of a full-duplex connection
  socket_write:    Send data to a TCP-socket

  udp_demo_client: Sample of client (UDP socket)
  udp_demo_server: Sample of server (UDP socket)
  tcp_demo_client: Sample of client (TCP socket)
  tcp_demo_server: Sample of server (TCP socket)

  http_get:        Sample to get a file by HTTP

** Controlling the screen **

  clear:   Clear the screen
  gotoxy:  Move the cursor on the screen

** Special variables **

  ans:   Most recent answer
  NaN:   Not-a-Number
  EPS:   Floating point relative accuracy
  nargs: Number orf function input arguments
  Inf:   Infinity
  PI:    3.1415926535897

** Operators and Special Characters

    +: Plus              
   .+: Array Plus        
   ++: Increment with 1  
    -: Minus             
   .-: Array Minus       
   --: Decrement with 1  
    *: Multiplication 
   .*: Multiplication (element-wise)   
    /: Right division
   ./: Right division (element-wise)
    \: Left division
   .\: Left division (element-wise)
    ^: Power
   .^: Array Power
    ~: Inverse
   .~: Inverse (element-wise)
    #: Complex conjugate transpose
    ': Transpose
    =: Assignemnt
   ==: Equality
  .==: Equality (element-wise)
   !=: Nonequality
  .!=: Nonequality (element-wise)
    >: Greater
   .>: Greater (element-wise)
   >=: Greater or equal
  .>=: Greater or equal (element-wise)
    <: Less
   .<: Less (element-wise)
   <=: Less or equal
  .<=: Less or equal (element-wise)
   &&: Logical AND
  .&&: Logical AND (element-wise)
   ||: Logical OR
  .||: Logical OR (element-wise)
    !: Logical NOT
   .!: Logical NOT (element-wise)
    :: Colon, case
   (): Parentheses
   []: Vector, Matrix
   {}: Function, List
   "": String
  (,): Complex Value
   >>: Save matrix to MAT-format file
   <<: Load matrix from MAT-format file
   ->: Save data to MX-format file
   <-: Load data from MX-format file
    .: Decimal point
  ...: Function with varying number of arguments
    ,: Comma
    ;: End of statement
   //: One line comment
   /*: Beginning of block comment
   */: End of block comment
    !: Execute operating system command

** Logical functions **

  all:       1 if all elements of matrix are not zero
  all_col:   1 if all elements of each column are not zero
  all_row:   1 if all elements of each row are not zero
  any:       1 if any element of matrix is not zero
  any_col:   1 if any element of each column is not zero
  any_row:   1 if any element of each row is not zero
  exist:     Check if variable exist
  find:      Find indices of non-zero elements
  iscomplex: 1 for complex value
  isempty:   1 for empty matrix
  isfinite:  1 for finite element
  isinf:     1 for infinite element
  isnan:     1 for Not-A-Number
  isreal:    1 for real value

** Declaration and definition of variables and functions **

  extern:  Declaration of variables in other files
  Func:    Definition of function
  nargs:   Number of the arguments of the function
  require: Relation of function and mm-file
  static:  Declaration of static variable

** Control flow **

  break:    Terminate execution of loop
  case:     Case of selection
  continue: Restart the loop
  default:  Default case
  do:       Loop
  else:     Conditionaly execute statements
  else if:  Conditionaly execute statements
  error:    Display error messages and abort execution
  exit:     Terminate execution
  for:      Repeat statements util the condition is true
  if:       Conditionaly execute statements
  return:   Return to invoking function
  switch:   Selection
  while:    Repeat statements until the condition is true

** Interactive input **

  bell:     Ring the bell
  kbhit:    Check if there exists a data in standard input
  menu:     Generate menu of choices
  pause:    Wait for user response
  warning:  Display warning message

** Time and date **

  clock:    Current date and time
  settimer: Reset the interval timer
  gettimer: Get the time of interval timer

** Elementary function **

  abs:     Absolute value         
  acos:    Inverse cosine         
  acosh:   Inverse hyperbolic cosine
  arg:     Phase angle
  asin:    Inverse sine
  asinh:   Inverse hyperbolic sine
  atan:    Inverse tangent
  atan2:   Four quadrant inverse tangent
  atanh:   Inverse hyperbolic tangent
  ceil:    Round towards plus infinity
  conj:    Complex conjugate
  cos:     Cosine
  cosh:    Hyerbolic cosine
  exp:     Exponential
  fact:    Factorial
  fix:     Round towards zero
  floor:   Round towards minus infinity
  Im:      Complex imaginary part
  inv:     Inverse
  log:     Natural logarithm
  log10:   Common logarithm
  pow:     Power
  Re:      Complex real part
  rem:     Remainder after division
  round:   Round towards nearest integer
  round2z: Round towards zero
  sgn:     Signum function
  sin:     Sine
  sinh:    Hyperbolic sine
  sqrt:    Square root
  tan:     Tangent
  tanh:    Hyperbolic tangent

** Bit operation **

  bit_and:        bit-wise AND 
  bit_or:         bit-wise OR
  bit_xor:        bit-wise exclusive OR
  bit_comp:       bit-wise reverse(complement of 1)
  bit_lshift:     bit-wise left-shift
  bit_rshift:     bit-wise right-shift
  machine_endian: Endian of binary data

  fpu_round_down:  round to minus infinity 
  fpu_round_near:  round to nearest representative number
  fpu_round_up:    round to plus infinity 
  fpu_round_zero:  round to zero (trancate)
  fpu_round_mode:  rounding mode

** Elementary matrix **

  I:        Identify matrix
  linspace: Linearly spaced vector
  logpsace: Logarithmically spaced vector
  ONE:      Onese matrix
  rand:     Uniformly distributed random numbers
  randn:    Normally distributed random numbers
  Z:        Zeros matrix

** Attribute of matrix **

  size:    Number of rows and number of columns
  Cols:    Number of columns
  Rows:    Number of rows
  length:  Maximum of number of rows and number of columns
  isempty: Check if empty matrix

** Matrix manipulation **

  Array:       Translation to array
  conj:        Complex conjugate
  conjtrans:   Complex conjugate transpose
  De:          Denominator array
  diag:        Diagonal matrix
  diag2vec:    Create vector from diagonal elements
  vec2diag:    Create diagonal matrix from a vector
  fliplr:      Flip matrix in the left/right direction
  flipud:      Flip matrix in the up/down direction
  Im:          Imaginary part of complex matrix
  Index:       Translation to index
  Matrix:      Translation to matrix
  Nu:          Numerator array
  Re:          Real part of complex matrix
  reshape:     Change size
  rot90:       Rorate matrix 90 degrees
  rotateDown:  Rotate matrix in the down direction
  rotateLeft:  Rotate matrix in the left direction
  rotateRight: Rotate matrix in the right direction
  rotateUp:    Rotate matrix in the up direction
  diag_vec:    Exchange diagonal matrix and vector
  shiftDown:   Shift matrix elements in the down direction
  shiftLeft:   Shift matrix elements in the left direction
  shiftRight:  Shift matrix elements in the right direction
  shiftUp:     Shift matrix elements in the up direction
  trans:       Transpose
  tril:        Extract lower triangular part
  triu:        Extract upper triangular part
    
** Matrix analysis **

  cond:     Matrix condition number
  det:      Determinant
  norm:     Matrix or vector norm of matrix
  kernel:   Span of kernel space
  rank:     Number of linearly independent rows or columns
  trace:    Sum of diagonal elements

** Linear equations **

  / and \:        Linear equation solution
  chol:           Cholesky factorization
  inv:            Matrix inverse
  lu:             LU factorization
  lu_p:           LU factorization with permutation
  pseudoinv:      Pseudoinverse
  qr:             QR factorization
  qr_p:           QR factorization with permutation

** Eigenvalues and singular values **

  balance:      Diagonal scaling to improve eigenvalue accuracy
  eig:          Eigenvalues and eigenvectors
  eigval:       Eigenvalues
  eigvec:       Eiegenvectors
  hess:         Hessenberg form
  maxsing:      Maximum singular value
  minsing:      Minimum singular value
  qz:           QZ factorization
  singleftvec:  Left transformation matrix for SVD
  singrightvec: Right transformation matrix for SVD
  singval:      Singular values
  schur:        Schur decomposition
  svd:          Singular value decomposition

** Matrix functions **

  exp:  Matrix exponential
  log:  Matrix logarithm
  sqrt: Matrix square root
  funm: Evaluate general matrix function

** Data analysis **

  cumprod:      Cumulative products of all elements
  cumprod_col:  Cumulative products of each column
  cumprod_row:  Cumulative products of each row
  cumsum:       Cumulative sum of all elements
  cumsum_col:   Cumulative sum of each column
  cumsum_row:   Cumulative sum of each row
  frobnorm:     Frobenius norm of all elements
  frobnorm_col: Frobenius norm of each column
  frobnorm_row: Frobenius norm of each row
  max:          Largest component among all elements
  max_col:      Largest component among each column
  max_row:      Largest component among each row
  maximum:      Largest component and the index among all elements
  maximum_col:  Largest component and the index among each column
  maximum_row:  Largest component and the index among each row
  mean:         Average or mean value of all elements
  mean_col:     Average or mean value of each column
  mean_row:     Average or mean value of each row
  median:       Median value of all elements
  median_col:   Median value of each column
  median_row:   Median value of each row
  min:          Smallest component of all elements
  min_col:      Smallest component of each column
  min_row:      Smallest component of row column
  minimum:      Smallest component and the index of all elements
  minimum_col:  Smallest component and the index of each column
  minimum_row:  Smallest component and the index of each row
  prod:         Product of all elements
  prod_col:     Product of each column
  prod_row:     Product of each row
  sort:         Sort in ascending order of all elements
  sort_col:     Sort in ascending order of each column
  sort_row:     Sort in ascending order of each row
  std:          Standard deviation of all elements
  std_col:      Standard deviation of each column
  std_row:      Standard deviation of each row
  sum:          Sum of all elements
  sum_col:      Sum of each column
  sum_row:      Sum of each row
                   
** Difference and correlation **

  diff:          Difference of all elements
  diff_col:      Difference of each column
  diff_row:      Difference of each row
  corrcoef:      Correlation coefficients of all elements
  corrcoef_col:  Correlation coefficients of each column
  corrcoef_row:  Correlation coefficients of each row
  cov:           Covariance matrix of all elements
  cov_col:       Covariance matrix of each column
  cov_row:       Covariance matrix of each row
  hist:          Histgram of all elements
  hist_col:      Histgram of each column
  hist_row:      Histgram of each row

** Simulation **

  rngkut4:         Solve ODE by Runge-Kutta method
  rkf45:           Solve ODE by RKF45 method
  Ode:             Solve ODE by RK with constant step size
  OdeAuto:         Solve ODE by RK with specified accuracy
  OdeHybrid:       Solve ODE by RK with constant step size, where the
                   External signal is constant for sampling interval
  OdeHybridAuto:   Solve ODE by RK with specified accuracy, where the
                   External signal is constant for the sampling interval
  Ode45:           Solve ODE by RKF45 with constant step size
  Ode45Auto:       Solve ODE by RKF45 with specified accuracy
  Ode45Hybrid:     Solve ODE by RKF45 with constant step size, where the
                   External signal is constant for sampling interval
  Ode45HybridAuto: Solve ODE by RKF45 with specified accuracy, where the
                   External signal is constant for sampling interval
  OdeStop:         Stop simulation
  OdeXY:           Get past signal

** Fourier Transforms **

  abs:         Magnitude
  arg:         Phase angle
  fft:         Discrete Fourier transfrom of all elements
  fft_col:     Discrete Fourier transfrom of each column
  fft_row:     Discrete Fourier transfrom of each row
  fftshift:    Shift FFT
  ifft:        Inverse discrete Fourier transform of all elements
  ifft_col:    Inverse discrete Fourier transform of each column
  ifft_row:    Inverse discrete Fourier transform of each row
  unwrap:      Remove phase angle jumps across 360 degrees boundaries
  unwrap_col:  Remove phase angle jumps of each column
  unwrap_row:  Remove phase angle jumps of each row

** Polynomial and rational polynomial **

  CoPolynomial: Translation to complex polynomial
  CoRational:   Translation to complex rational polynomial
  De:           Denominator polynomial
  derivativ:    Derivative
  degree:       Degree of polynomial
  higher:       Shift coefficients toward high order
  Im:           Imaginary part
  integral:     Indefinite integral
  lower:        Shift coefficients toward the lower order
  eval:         Evaluation of polynomial and rational polynomial
  Matrix:       Create vector from coefficients of polynomial
  Nu:           Numerator polynomial
  poles:        Poles (roots of denominator polynomial)
  Polynomial:   Translation to polynomial
  Rational:     Translation to rational polynomial
  Re:           Real part
  roots:        Roots of polynomial
  simplify:     Cancelation of common factor of rational polynomial
  zeros:        Zeros(roots of numerator polynomial)

** String **

  eval:    Interpret strings containing MaTX expressions
  length:  Length of string
  Matrix:  Create vector from a string
  sprintf: Make formatted data to a string
  sscanf:  Read string under format control
  strchr:  Location of a character in the string (from head)
  strrchr: Location of a character in the string (from tail)
  String:  Translation to string

** List **

  length:   Number of elements
  List:     Translation to list
  makelist: Make a list
  typeof:   Type of elements of list

** File input/output functions **

  access:  Determine accessibility of file
  fclose:  Close file
  feof:    Check end of file
  fgets:   Get a string from file
  fread:   Read binary data from file as specified precision
  fopen:   Open file
  fprintf: Convert, format and write data to file
  fscanf:  Read data from a file with format
  fwrite:  Write binary data to file as specified precision
  load:    Read MM-file
  print:   Save variable as MX-format or MAT-format
  read:    Read variables MX-format or MAT-format data from file
  save:    Save variables as MM-file

** Interface to hardware **

  Inport:   Read 1 word data from IO port
  Inportb:  Read 1 byte data from IO port
  Outport:  Write 1 word data to IO port
  Outportb: Write 1 byte data to IO port

<< Matrix Toolbox >>

 mat_demo:        Demonstration of matrix toolbox

 angle:           Phase angles in radians
 bar:             Data for bar graph
 barp:            Plot Bar graph
 cdf2rdf:         Complex diagonal form to real diagonal form
 ccpair:          Make complex conjugate pairs
 dec2hex:         Decimal to hexadecimal number conversion
 deconv:          Deconvolution
 dft:             Discrete Fourier transform
 dft_plot:        Plot the data of discrete fourier transform 
 erf:             Error function
 gammac:          Complete Gamma function
 gammaf:          Complete and incomplete Gamma functions
 gammai:          Incomplete Gamma function
 givens:          Givens rotation matrix
 hadamard:        Hadamard matrix
 hankel:          Hankel matrix
 hex2dec:         Hexadecimal to decimal number conversion
 hex2num:         IEEE hexidecimal to double precision number conversion
 hilbert:         Hilbert matrix
 idft:            Inverse Discrete Fourier Transform
 idft_plot:       Plot the data of inverse discrete fourier transform
 ihilbert:        Inverse Hilbert matrix
 inverf:          Inverse Error function
 kronprod:        Kronecker product
 kronsum:         Kronecker sum
 magicsq:         Magic square
 makecolv:        Make a column vector
 makerowv:        Make a row vector
 makepoly:        Characteristic polynomial
 mat2tex:         Save a matrix to a file in tex-form
 mat2texf:        Generate the tex-form of a matrix
 matlab_read:     Load matrices from a file saved as matlab4 mat-format
 matlab_write:    Save matrices from a file saved as matlab4 mat-format
 mseq:            M sequence
 nargchk:         Check number of input arguments
 null:            Null space basis
 orth:            Orthogonal basis
 rsf2csf:         Real Schur form to complex Schur form conversion
 schord:          Ordered schur decomposition
 simplify:        Cancellation of rational polynomials
 toeplitz:        Toeplitz matrix
 vander:          Vandermonde matrix
 vconnect:        Connect some vectors to a vector
 vchop:           Chop a vector to some vectors

<< Signal Toolbox >>

 sig_demo:        Demonstration of signal toolbox

 bartlett:        Bartlett window
 bilinear:        Bilinear transformation
 blackman:        Blackman window
 boxcar:          Rectangular window
 cceps:           Complex cepstrum
 detrend:         Same as detrend_row()
 detrend_col:     Remove a linear trend for each column
 detrend_row:     Remove a linear trend for each row
 filter:          Digital filter
 freqs:           Analog filter frequency response
 freqz:           Digital filter frequency response
 freqzw:          Digital filter frequency response
 hamming:         Hamming window
 hanning:         Hanning window
 rceps:           Real cepstrum
 sawtooth:        Sawtooth wave
 square:          Square wave
 triang:          N-point triangular window
 xcorr:           Cross-correlation function
 xcov:            Cross-covariance function

<< Control Toolbox >>

 ctr_demo:        Demonstration program for control toolbox

 abcdchk:           Check the dimensions of A,B,C,D
 are:               Solution of continuous-time Riccati equation
 augment:           Augmented system 
 balreal:           Balanced state-space realization
 bode_ss:           Bode response of cont-time linear systems
 bode_tf:           Bode response of cont-time linear systems
 bode_tfn:          Bode response of cont-time linear systems
 bode_tfm:          Bode response of cont-time linear systems
 bode_plot_ss:      Plot Bode response of continuous-time linear system
 bode_plot_tf:      Plot Bode response of continuous-time linear system
 bode_plot_tfn:     Plot Bode response of continuous-time linear system
 bode_plot_tfm:     Plot Bode response of continuous-time linear system
 charpoly:          Characteristic polynomial
 ctrm:              Controllability matrix
 ctrf:              Controllable-uncontrollable decomposition
 c2d:               Continuous-time to discrete time conversion
 canon:             State-space to canonical form transformation
 dbode_ss:          Discrete-time Bode response 
 dbode_plot_ss:     Plot discrete-time Bode response 
 dhinf:             Solve H_infinity Problem (Discrete-time case)
 dimpulse_ss:       Impulse response of discrete-time linear systems
 dimpulse_tf:       Impulse response of discrete-time linear systems
 dimpulse_tfn:      Impulse response of discrete-time linear systems
 dimpulse_tfm:      Impulse response of discrete-time linear systems
 dimpulse_plot_ss:  Plot Impulse response of discrete-time linear systems
 dimpulse_plot_tf:  Plot Impulse response of discrete-time linear systems
 dimpulse_plot_tfn: Plot Impulse response of discrete-time linear systems
 dimpulse_plot_tfm: Plot Impulse response of discrete-time linear systems
 dinitial_ss:       Initial response of discrete-time linear systems
 dinitial_tf:       Initial response of discrete-time linear systems
 dinitial_tfn:      Initial response of discrete-time linear systems
 dinitial_tfm:      Initial response of discrete-time linear systems
 dinitial_plot_ss:  Plot Initial response of discrete-time linear systems
 dinitial_plot_tf:  Plot Initial response of discrete-time linear systems
 dinitial_plot_tfn: Plot Initial response of discrete-time linear systems
 dinitial_plot_tfm: Plot Initial response of discrete-time linear systems
 dlqe:              Discrete linear quadratic estimator design
 dlqr:              Linear quadratic regulator design for discrete-time systems
 dlsim:             Simulation of discrete-time linear systems
 dlsim_plot:        Plot simulation result of discrete-time linear systems
 dlyap:             Discrete-time Lyapunov equation solution
 dric:              Discrete-time Riccati equation
 dstep_ss:          Step response of discrete-time linear systems
 dstep_tf:          Step response of discrete-time linear systems
 dstep_tfn:         Step response of discrete-time linear systems
 dstep_tfm:         Step response of discrete-time linear systems
 dstep_plot_ss:     Plot Step response of discrete-time linear systems
 dstep_plot_tf:     Plot Step response of discrete-time linear systems
 dstep_plot_tfn:    Plot Step response of discrete-time linear systems
 dstep_plot_tfm:    Plot Step response of discrete-time linear systems
 d2c:               Conversion from discrete to continuous time
 dbalreal:          Discrete balanced realization and model reduction
 dgramian:          Discrete-time controllability and observability gramians
 faddeev:           Resolvent matrix by Faddeev's method
 feedback:          Connect two state-space systems using feedback
 feedbk:            State-space closed-loop transfer function
 gmargin:           Gain margin and crossover frequencies
 gramian:           Controllability and observability gramians
 hinf:              Solve H_infinity problem (Continuous-time case)
 impulse_ss:        Impulse response of continuous-time linear systems
 impulse_tf:        Impulse response of continuous-time linear systems
 impulse_tfn:       Impulse response of continuous-time linear systems
 impulse_tfm:       Impulse response of continuous-time linear systems
 impulse_plot_ss:   Plot Impulse response of continuous-time linear systems
 impulse_plot_tf:   Plot Impulse response of continuous-time linear systems
 impulse_plot_tfn:  Plot Impulse response of continuous-time linear systems
 impulse_plot_tfm:  Plot Impulse response of continuous-time linear systems
 initial_ss:        Initial response of continuous-time linear systems
 initial_tf:        Initial response of continuous-time linear systems
 initial_tfn:       Initial response of continuous-time linear systems
 initial_tfm:       Initial response of continuous-time linear systems
 initial_plot_ss:   Plot Initial response of continuous-time linear systems
 initial_plot_tf:   Plot Initial response of continuous-time linear systems
 initial_plot_tfn:  Plot Initial response of continuous-time linear systems
 initial_plot_tfm:  Plot Initial response of continuous-time linear systems
 lqe:               Linear quadratic estimator design for the cont- system
 lqr:               Linear quadratic regulator design for cont- systems
 lqrs:              Linear-quadratic regulator design for cont- systems
 lqry:              Linear quadratic regulator design with output weighting
 lsim:              Simulation of continuous-time linear systems
 lsim_plot:         Plot simulation result of continuous-time linear systems
 ltifr:             Frequency response of linear time-invarient system
 ltitr:             Linear time-invariant time response
 lyap:              Solution of Lyapunov equation
 margin:            Gain margin, phase margin, and crossover frequencies
 minreal:           Minimal realization and pole-zero cancellation
 mseqfr:            Frequency response of a system by M sequence
 nicholsp:          Nichols chart
 nyquist_ss:        Nyquist response of cont- linear state-space systems
 nyquist_tf:        Nyquist response of cont- linear state-space systems
 nyquist_tfn:       Nyquist response of cont- linear state-space systems
 nyquist_tfm:       Nyquist response of cont- linear state-space systems
 nyquist_plot_ss:   Plot Nyquist response of continuous-time systems
 nyquist_plot_tf:   Plot Nyquist response of continuous-time systems
 nyquist_plot_tfn:  Plot Nyquist response of continuous-time systems
 nyquist_plot_tfm:  Plot Nyquist response of continuous-time systems
 obsg:              Minimal order observer by Gopinath's method
 obsf:              Observable-unobservable decomposition
 obsm:              Observability matrix
 parallel:          Parallel connection of two state-space systems
 pplace:            Pole placement
 pmargin:           Phase margin and crossover frequencies
 resolvent:         Resolvent matrix (s*I - A)^(-1) of matrix A
 ric:               Riccati equation using Potter and Arimoto's method
 riccati:           Riccati equation (Continuous-time case)
 rlocus_ss:         Root locus
 rlocus_tf:         Root locus
 rlocus_tfn:        Root locus
 rlocus_tfm:        Root locus
 rlocus_plot_ss:    Plot Root locus
 rlocus_plot_tf:    Plot Root locus
 rlocus_plot_tfn:   Plot Root locus
 rlocus_plot_tfm:   Plot Root locus
 series:            Series connection of two state-space systems
 svfr:              Singular value frequency response
 ss2tf:             State-space to transfer function conversion
 ss2tfn:            State-space to transfer function conversion
 ss2tfm:            State-space to transfer function matrix conversion
 ss2zp:             State-space to zero-pole conversion
 step_ss:           Step response of continuous-time linear systems
 step_tf:           Step response of continuous-time linear systems
 step_tfn:          Step response of continuous-time linear systems
 step_tfm:          Step response of continuous-time linear systems
 step_plot_ss:      Plot Step response of continuous-time linear systems
 step_plot_tf:      Plot Step response of continuous-time linear systems
 step_plot_tfn:     Plot Step response of continuous-time linear systems
 step_plot_tfm:     Plot Step response of continuous-time linear systems
 TFadd:             Parallel connection of two state-space systems
 TFinv:             Inverse a state-space system
 TFmul:             Series connection of two state-space systems
 TFnegate:          Negate a state-space system
 TFsub:             Parallel connection of two state-space systems
 TFtrans:           Trans a state-space system
 tfm2ss:            Transfer function matrix to state-space conversion
 tfm2tf:            Transfer function matrix to transfer function conversion
 tfm2tfn:           Transfer function matrix to transfer function conversion
 tfm2zp:            Transfer function matrix to zero-pole conversion
 tf2ss:             Transfer function to state-space conversion
 tf2tfn:            Transfer function to transfer function conversion
 tf2tfm:            Transfer function to transfer function matrix conversion
 tf2zp:             Transfer function to zero-pole conversion
 tfn2ss:            Transfer function to state-space conversion
 tfn2tf:            Transfer function to transfer function conversion
 tfn2tfm:           Transfer function to transfer function matrix conversion
 tfn2zp:            Transfer function to zero-pole conversion
 tzero:             Transmission zeros
 zp2ss:             Zero-pole to state-space conversion
 zp2tf:             Zero-pole to transfer function conversion
 zp2tfn:            Zero-pole to transfer function conversion
 zp2tfm:            Zero-pole to transfer function matrix conversion

<< Graph Toolbox >>

 ( GNUPLOT for the current window) 
 gcls:               Clear the graphical screen for Tektro emulation
 gplot:              Linear x-y Plot with GNUPLOT
 gplot_clear:        Clear screen
 gplot_cmd:          Send any commands with "\n" to gnuplot
 gplot_eps:          Save the graph as an encapsulated postscript file
 gplot_epsplus:      Save the graph as an eps plus file
 gplot_fig:          Save the graph as a FIG code
 gplot_grid:         Grid lines
 gplot_hidden3d:     Hidden3d mode
 gplot_hold:         Hold command (DOS, Windows95/NT)
 gplot_key:          Key lines
 gplot_loglog:       Loglog x-y plot
 gplot_options:      Set gnuplot options
 gplot_out:          Send any commands to gnuplot
 gplot_parametric:   Parametric mode
 gplot_ps:           Save the graph as a postscript file
 gplot_psplus:       Save the graph as a postscript file with psplus facility
 gplot_quit:         Quit mgplot
 gplot_replot:       Replot lines
 gplot_reset:        Initialize window
 gplot_semilogx:     Semi-log x-y plot (x-axis logarithmic)
 gplot_semilogy:     Semi-log x-y plot (y-axis logarithmic)
 gplot_text:         Put text on the screen
 gplot_title:        Graph title
 gplot_view:         View angle and scale
 gplot_view_control: Control view angle and scale
 gplot_xlabel:       X-axis label
 gplot_x2label:      2nd X-axis label
 gplot_y2label:      2nd Y-axis label
 gplot_ylabel:       Y-axis label
 gplot_zlabel:       Z-axis label
 gplot_z2label:      2nd Z-axis label
 greplot:            Linear x-y rePlot with GNUPLOT
 greplot_loglog:     Loglog x-y replot
 greplot_semilogx:   Semi-log x-y replot (x-axis logarithmic)
 greplot_semilogy:   Semi-log x-y replot (y-axis logarithmic)

 gplot3:                3D Plot
 gplot3_logx:           3D Plot (x-axis logarithmic)
 gplot3_logy:           3D Plot (y-axis logarithmic)
 gplot3_logz:           3D Plot (z-axis logarithmic)
 gplot3_logxy:          3D Plot (x-y-axis logarithmic)
 gplot3_logxz:          3D Plot (x-z-axis logarithmic)
 gplot3_logyz:          3D Plot (y-z-axis logarithmic)
 gplot3_logxyz:         3D Plot (x-y-z-axis logarithmic)
 gplot3_surface:        2D surface in 3D plot
 gplot3_logx_surface:   2D surface in 3D plot (x-axis logarithmic)
 gplot3_logy_surface:   2D surface in 3D plot (y-axis logarithmic)
 gplot3_logz_surface:   2D surface in 3D plot (z-axis logarithmic)
 gplot3_logxy_surface:  2D surface in 3D plot (x-y-axis logarithmic)
 gplot3_logxz_surface:  2D surface in 3D plot (x-z-axis logarithmic)
 gplot3_logyz_surface:  2D surface in 3D plot (y-z-axis logarithmic)
 gplot3_logxyz_surface: 2D surface in 3D plot (x-y-z-axis logarithmic)

 ( GNUPLOT for the specified window) 
 mgplot:              Linear x-y Multiple Plot
 mgplot_clear:        Clear screen
 mgplot_cur_win:      Current window number
 mgplot_cmd:          Send any commands with "\n" to gnuplot
 mgplot_eps:          Save the graph as an encapsulated postscript file
 mgplot_epsplus:      Save the graph as an eps plus file
 mgplot_fig:          Save the graph as a FIG code
 mgplot_grid:         Grid lines
 mgplot_hidden3d:     Hidden3d mode
 mgplot_hold:         Hold command (DOS, Windows95/NT)
 mgplot_key:          Key lines
 mgplot_loglog:       Loglog x-y plot
 mgplot_options:      Set gnuplot options
 mgplot_out:          Send any commands to gnuplot
 mgplot_parametric:   Parametric mode
 mgplot_ps:           Save the graph as a postscript file
 mgplot_psplus:       Save the graph as a postscript file with psplus facility
 mgplot_quit:         Quit mgplot
 mgplot_replot:       Replot lines
 mgplot_reset:        Initialize window
 mgplot_semilogx:     Semi-log x-y plot (x-axis logarithmic)
 mgplot_semilogy:     Semi-log x-y plot (y-axis logarithmic)
 mgplot_subplot:      Multi frame plot
 mgplot_text:         Put text on the screen
 mgplot_title:        Graph title
 mgplot_view:         View angle and scale
 mgplot_view_control: Control view angle and scale
 mgplot_xlabel:       X-axis label
 mgplot_x2label:      2nd X-axis label
 mgplot_ylabel:       Y-axis label
 mgplot_y2label:      2nd Y-axis label
 mgplot_zlabel:       Z-axis label
 mgplot_z2label:      2nd Z-axis label
 mgreplot:            Linear x-y Multiple rePlot
 mgreplot_loglog:     Loglog x-y replot
 mgreplot_semilogx:   Semi-log x-y replot (x-axis logarithmic)
 mgreplot_semilogy:   Semi-log x-y replot (y-axis logarithmic)

 mgplot3:                3D Plot
 mgplot3_logx:           3D Plot (x-axis logarithmic)
 mgplot3_logy:           3D Plot (y-axis logarithmic)
 mgplot3_logz:           3D Plot (z-axis logarithmic)
 mgplot3_logxy:          3D Plot (x-y-axis logarithmic)
 mgplot3_logxz:          3D Plot (x-z-axis logarithmic)
 mgplot3_logyz:          3D Plot (y-z-axis logarithmic)
 mgplot3_logxyz:         3D Plot (x-y-z-axis logarithmic)
 mgplot3_surface:        2D surface in 3D plot
 mgplot3_logx_surface:   2D surface in 3D plot (x-axis logarithmic)
 mgplot3_logy_surface:   2D surface in 3D plot (y-axis logarithmic)
 mgplot3_logz_surface:   2D surface in 3D plot (z-axis logarithmic)
 mgplot3_logxy_surface:  2D surface in 3D plot (x-y-axis logarithmic)
 mgplot3_logxz_surface:  2D surface in 3D plot (x-z-axis logarithmic)
 mgplot3_logyz_surface:  2D surface in 3D plot (y-z-axis logarithmic)
 mgplot3_logxyz_surface: 2D surface in 3D plot (x-y-z-axis logarithmic)

 -- For help on any topic, type 'help' followed by the name of the topic --

