
/*  -*- MaTX -*-
 *
 *  NAME
 *      linspace() - Linearly spaced array
 *
 *  SYNOPSIS
 *      y = linspace(x1, x2)
 *         Array y;
 *         Real x1, x2;
 *
 *      y = linspace(x1, x2, n)
 *         Array y;
 *         Real x1, x2;
 *         Integer n;
 *
 *  DESCRIPTION
 *      linspace(x1,x2) produces a row vector of 100 linearly equally 
 *      spaced points between x1 and x2.
 *
 *      linspace(x1,x2,n) returns n-point data between x1 and x2.
 *
 *  SEE ALSO
 *      logspace
 */

Func Array linspace(x1, x2, n, ...)
	Real x1, x2;
	Integer n;
{
	Array y;

	error(nargchk(2, 3, nargs, "linspace"));
	
	if (nargs == 2) {
		n = 100;
	} 

	y = [x1 .+ [0:n-2]*(x2-x1)/(n-1), x2];
	return y;
}
