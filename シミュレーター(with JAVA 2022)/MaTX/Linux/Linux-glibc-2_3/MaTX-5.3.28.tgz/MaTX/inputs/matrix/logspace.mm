
/*  -*- MaTX -*-
 *
 *  NAME
 *      logspace() - Logarithmically spaced array
 *
 *  SYNOPSIS
 *      y = logspace(x1, x2)
 *         Array y;
 *         Real x1, x2;
 *
 *      y = logspace(x1, x2, n)
 *         Array y;
 *         Real x1, x2;
 *         Integer n;
 *
 *  DESCRIPTION
 *      logspace(x1,x2) returns a row vector of 50 logarithmically
 *      equally spaced points between decades 10^x1 and 10^x2.
 *
 *      If x2 is PI, then the points are between 10^x2 and PI.
 *
 *      logspace(x1,x2,n) generates n-point data.
 *
 *  SEE ALSO
 *      linspace
 */

Func Array logspace(x1, x2, n, ...)
	Real x1, x2;
	Integer n;
{
	Array y;

	error(nargchk(2, 3, nargs, "logspace"));

	if (nargs == 2) {
		n = 50;
	}
	if (x2 == PI) {
		x2 = log10(PI);
	}
	if (0 < x1 && 0 < x2 && (abs(x1) <= 0.1 || 10.0 <= abs(x2))) {
		x1 = log10(x1);
		x2 = log10(x2);
	}

	y = 10.0 .^ [x1 .+ [0:n-2]*(x2-x1)/(n-1), x2];
	return y;
}
