
/*  -*- MaTX -*-
 *
 *  NAME
 *      inverf() - Inverse Error function
 *
 *  SYNOPSIS
 *      b = inverf(x)
 *         Array b;
 *         Array x;
 *
 *      b = inverf(x, tol)
 *         Array b;
 *         Array x;
 *         Real tol;
 *
 *  DESCRIPTION
 *      inverf(x) calculates the inverse error function for all elements 
 *      of x, accurate to about 1E-5.
 *
 *      inverf(x,tol) calculates the inverse error function
 *      for all elements of x, accurate to about tol.
 *
 *      The error function is the integral of the normal probability 
 *      distribution function from 0 to x:
 *
 *       erfnc(x) = 2/sqrt(PI) integral(0,x) exp(-t^2)
 *
 *  SEE ALSO
 *      erfnc().
 *
 */

Func Array inverf(x, tol, ...)
	Array x;
	Real tol;
{
	Array b,b0,fd,f;
	Real t0;

	if (nargs < 1 || 2 < nargs) {
		 error("inverf(): Incorrect number of arguments\n");
	}
	if (nargs == 1) {
		 tol = 0.00001;
	}

	t0 = 1/sqrt(2*PI);
	b0 = ONE(x);
	b = Z(x);

	// Newton-Raphson iteration
	while (any(abs(b - b0) > tol)) {
		b0 = b;
		f = (erf(b0) - x)/2;
		fd = exp(-0.5*b0*b0)*t0;
		b = b0 - f/fd;
	}
	return b;
}
