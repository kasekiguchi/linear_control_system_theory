
/*  -*- MaTX -*-
 *
 *  NAME
 *      mseq() - M sequence
 *
 *  SYNOPSIS
 *      M = mseq(n, smp)
 *       Integer n;  (number of reigser)
 *       Integer m;  (number of consecutive points with the same value)
 *       Array M;
 *
 *  DESCRIPTION
 *      mseq(n) generates a row vector of an M-sequcne
 */

Func Array mseq(n, smp, ...)
	Integer n;
	Integer smp;

{
	Integer k, N;
	Array x, M, one;

	void mseq_update_register();

	error(nargchk(1, 2, nargs, "mseq"));

	if (nargs == 1) {
		smp = 1;
	}

	// Initialization of registers
	switch (n) {
	  case 2:
		x = [1, 1];
		break;
	  case 3:
		x = [1, -1, 1];
		break;
	  case 4:
		x = [1, -1, -1, 1];
		break;
	  case 5:
		x = [-1, 1, -1, -1, 1];
		break;
	  case 6:
		x = [1, -1, -1, -1, -1, 1];
		break;
	  case 7:
		x = [1, -1, -1, -1, -1, -1, 1];
		break;
	  case 9:
		x = [-1, -1, -1, 1, -1, -1, -1, -1, 1];
		break;
	  case 10:
		x = [-1, -1, 1, -1, -1, -1, -1, -1, -1, 1];
		break;
	  case 11:
		x = [-1, 1, -1, -1, -1, -1, -1, -1, -1, -1, 1];
		break;
	  case 15:
		x = [1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, 1];
		break;
	  default:
		error("mseq(): Incorrect number of registers.\n");
		break;
	}

	N = 2^n - 1;
	M = Z(1, N*smp);
	one = ONE(1,smp);

	for (k = 1; k <= N; k++) {
		M(1, (k-1)*smp+1:k*smp) = x(n)*one;
		mseq_update_register(x);
	}

	return M;
}

Func void mseq_update_register(x)
	Array x;
{
	Integer n;
	Real x1;

	n = Cols(x);

	switch (n) {
	  case 2:
		if (x(1) == x(2)) {
			x1 = -1.0;
		} else {
			x1 = 1.0;
		}
		break;
	  case 3:
		if (x(1) == x(3)) {
			x1 = -1.0;
		} else {
			x1 = 1.0;
		}
		break;
	  case 4:
		if (x(1) == x(4)) {
			x1 = -1.0;
		} else {
			x1 = 1.0;
		}
		break;
	  case 5:
		if (x(2) == x(5)) {
			x1 = -1.0;
		} else {
			x1 = 1.0;
		}
		break;
	  case 6:
		if (x(1) == x(6)) {
			x1 = -1.0;
		} else {
			x1 = 1.0;
		}
		break;
	  case 7:
		if (x(1) == x(7)) {
			x1 = -1.0;
		} else {
			x1 = 1.0;
		}
		break;
	  case 9:
		if (x(4) == x(9)) {
			x1 = -1.0;
		} else {
			x1 = 1.0;
		}
		break;
	  case 10:
		if (x(3) == x(10)) {
			x1 = -1.0;
		} else {
			x1 = 1.0;
		}
		break;
	  case 11:
		if (x(2) == x(11)) {
			x1 = -1.0;
		} else {
			x1 = 1.0;
		}
		break;
	  case 15:
		if (x(1) == x(15)) {
			x1 = -1.0;
		} else {
			x1 = 1.0;
		}
		break;
	  default:
		error("mseq(): Incorrect number of registers.\n");
		break;
	}

	x(2:n) = x(1:n-1);
	x(1) = x1;
}
