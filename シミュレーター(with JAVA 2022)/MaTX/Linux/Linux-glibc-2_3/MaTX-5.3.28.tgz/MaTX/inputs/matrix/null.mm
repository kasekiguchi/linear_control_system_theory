
/*  -*- MaTX -*-
 *
 *  NAME
 *      null() - Null space basis
 *
 *  SYNOPSIS
 *      Q = null(A)
 *         Matrix Q;
 *         Matrix A;
 *
 *      Q = null(A,tol)
 *         Matrix Q;
 *         Matrix A;
 *         Real tol;
 *
 *  DESCRIPTION
 *      null(A) returns an orthonormal basis for the null space of A.
 *      The columns of Q span the null sapce of A, and the number of 
 *      columns of Q is the (Rows(A) - rank(A)).
 *
 *      tol is used to determine the dimension of the null space.
 *
 *  SEE ALSO
 *      orth, kernel, and rank
 */

Func Matrix null(A, tol, ...)
	Matrix A;
	Real tol;
{
	Matrix P,R,Q;
	Index idx;

	error(nargchk(1, 2, nargs, "null"));
	
	if (nargs == 1) {
		tol = EPS*norm(A,"fro");
	}

	{Q,R,P} = qr_p(A#);

	if (min(Cols(A), Rows(A)) > 1) {
		idx = find(sum_row(abs(R))# .<= tol);
	} else {
		idx = find([abs(R(1))] .<= tol);
	}

	if (length(idx) > 0) {
		Q = Q(:,idx);
	} else {
		Q = [];
	}
	return Q;
}
