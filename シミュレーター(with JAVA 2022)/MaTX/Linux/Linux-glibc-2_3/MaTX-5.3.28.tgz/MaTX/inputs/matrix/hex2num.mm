
/*  -*- MaTX -*-
 *
 *  NAME
 *      hex2num() - IEEE hexidecimal to double precision number conversion
 *
 *  SYNOPSIS
 *      x = hex2num(s)
 *         Real x;
 *         String s;
 *
 *  DESCRIPTION
 *      hex2num(s) returns a real number (IEEE double precision floating 
 *      point number), where s is a 16 character string containing a 
 *      hexidecimal number.  Fewer than 16 characters are padded with zeros.
 *
 *  EXAMPLE
 *      hex2num("400921fb54442d18") returns Pi
 *      hex2num("bff")              returns -1
 *
 *  SEE ALSO
*      hex2dec
 */

Func Real hex2num(s)
	String s;
{
	Integer i,z,a,nf,n;
	Real x,e,f;
	Array d;

	d = Z(1,16);
	n = length(s);
	z = Integer([abs("0")](1));
	a = Integer([abs("a")](1));

	d(1:n) = Array(s) .- z;
	
	d = d + (z + 10 - a) * (d > 10);
	nf = d(1) > 7;

	if (nf)  {
		d(1)= d(1) - 8;
	}

	e = 16*(16*(d(1)-4) + d(2)) + d(3) + 1;
	f = 0;
	for (i = 16; i >= 4; i--) {
		f = (f + d(i))/16;
	}

	if (e > 1023) {
		if (f == 0.0) {
			x = Inf;
		} else {
			x = NaN;
		}
	} else if (e < -1022) {
		x = f * 2^(-1022);
	} else {
		x = (1 + f) * 2^e;
	}

	if (nf) {
		x = -x;
	}
	return x;
}
	
