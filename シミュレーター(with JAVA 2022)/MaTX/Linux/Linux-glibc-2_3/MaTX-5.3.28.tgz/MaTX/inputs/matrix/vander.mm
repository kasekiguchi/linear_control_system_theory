
/*  -*- MaTX -*-
 *
 *  NAME
 *      vander() - Vandermonde matrix
 *
 *  SYNOPSIS
 *      V = vander(x)
 *         Matrix V;
 *         Matrix x;
 *
 *  DESCRIPTION
 *      vander(x) returns the Vandermonde matrix whose second to
 *      last column is x. 
 *
 *  SEE ALSO
 *      toeplitz and hankel
 */

Func Matrix vander(x)
	Matrix x;
{
	Matrix V,y;
	Integer i,n;

	n = length(x);
	y = makecolv(x);
	V = ONE(n);
	for (i = 1; i <= n; i++) {
		V(:,i) = y .^ (n-i);
	}
	return V;
}
