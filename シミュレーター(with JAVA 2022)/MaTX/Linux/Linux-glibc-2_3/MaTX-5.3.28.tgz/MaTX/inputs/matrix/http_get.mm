
/*  -*- MaTX -*-
 *
 *  NAME
 *      http_get() - HTTP client
 *
 *  SYNOPSIS
 *      http_get(http_url)
 *        String http_url;
 *
 *  DESCRIPTION
 *
 *  DEMO
 *      http_get("http://www.matx.org/MaTX.html");
 *
 *	SEE ALSO
 */

Func void http_get(http_url, ...)
	 String http_url;
{
  Integer i, sd;
  String  path, host, host_path, mess;

  if (1 < nargs) {
	   error("http_get(): Incorrect number of arguments\n");
  }
  if (nargs == 0) {
	   http_url = "http://localhost";
  }

  host_path = "";
  if (7 <= length(http_url) && http_url(1:7) == "http://") {
	   {host_path} = sscanf(http_url, "http://%s");
  }

  i = strchr(host_path, "/");
  if (i == 0) {
	   host = host_path;
	   path = "/";
  } else {
	   host = host_path(1:i-1);
	   path = host_path(i:length(host_path));
  }

  if ((sd = socket_open("TCP")) < 0) {
	error("httpdemo(): Can't open socket\n");
  }

  if (socket_connect(sd, 80, host) < 0) {
	error("httpdemo(): Can't connect socket\n");
  }

  socket_puts(sd, sprintf("GET %s HTTP/1.0\r\n\r\n", path));

  while (1) {
	   mess = socket_gets(sd,1024);
	   if (length(mess) == 0) {
			break;
	   }
	   printf("%s", mess);
  }

  socket_close(sd);
}



