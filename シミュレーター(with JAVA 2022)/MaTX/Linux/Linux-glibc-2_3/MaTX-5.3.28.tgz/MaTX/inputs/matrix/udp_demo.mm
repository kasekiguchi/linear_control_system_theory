
/*  -*- MaTX -*-
 *
 *  NAME
 *      udp_demo_server() - Server for UDP demonstration
 *      udp_demo_client() - Server for UDP demonstration
 *
 *  SYNOPSIS
 *      udp_demo_server()
 *
 *      udp_demo_server(port)
 *         Integer port;
 *         
 *      udp_demo_client(host)
 *         String host;
 *
 *      udp_demo_server(host, port)
 *         String host;
 *         Integer port;
 *
 *  DESCRIPTION
 *
 *  DEMO
 *      host-A: udp_demo_server(8000);
 *
 *      host-B: udp_demo_client("host-A", 8000);
 *
 *	SEE ALSO
 *      tcp_demo_server, tcp_demo_client
 */

Func void udp_demo_server(port, ...)
	 Integer port;
{
  Integer sd;
  String mess, host;

  if (1 < nargs) {
	error("udp_demo_server(): Incorrect number of arguments\n");
  }

  if (nargs < 1) {
	port = 8000;
  }

  if ((sd = socket_open("UDP")) < 0) {
	error("udp_demo_server(): Can't open socket\n");
  }

  if (socket_bind(sd, port) < 0) {
	error("udp_demo_server(): Can't bind socket\n");
  }

  while (1) {
	{mess,host} = socket_recvfrom(sd);
	printf("mess = %s (from %s)\n", mess, host);
	if (4 == length(mess) && mess(1:4) == "quit") {
		 break;
	}
  }

  socket_close(sd);
}


Func void udp_demo_client(host, port, ...)
	 String host;
	 Integer port;
{
  Integer sd;
  String mess;

  if (nargs < 1 || 2 < nargs) {
	error("udp_demo_client(): Incorrect number of arguments\n");
  }

  if (nargs < 2) {
	port = 8000;
  }

  if ((sd = socket_open("UDP")) < 0) {
	error("udp_demo_client(): Can't open socket\n");
  }

  if (socket_bind(sd) < 0) {
	error("udp_demo_client(): Can't bind socket\n");
  }

  while (1) {
	print "mess = ";
	mess = gets();
	socket_sendto(sd, port, host, mess);
	if (mess == "quit") {
	  break;
	}
  }

  socket_close(sd);
}
