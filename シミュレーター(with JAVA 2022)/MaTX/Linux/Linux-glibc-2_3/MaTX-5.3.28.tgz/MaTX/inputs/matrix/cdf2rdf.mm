
/*  -*- MaTX -*-
 *
 *  NAME
 *      cdf2rdf() - Complex diagonal form to real diagonal form
 *
 *  SYNOPSIS
 *      {Vr,Dr} = cdf2rdf(Vc,Dc)
 *         Matrix Vr,Dr;
 *         CoMatrix Vc,Dc;
 *
 *  DESCRIPTION
 *      cdf2rdf(Vc,Dc) transforms the matrix in complex diagonal form to a 
 *      real diagonal form.
 *
 *      In complex diagonal form, Dc has complex eigenvalues on the
 *      diagonal.  In real diagonal form, the complex eigenvalues are 
 *      in 2-by-2 blocks on the diagonal. 
 *
 *      Complex eigenvalue pairs are assumed to be next to one another
 *      in Dc.  Vc consists of eigenvectors corresponding to the eigenvalues.
 *
 *   EXAMPLE
 *      A = Matrix(rand(4));
 *      {Dc,Vc} = eig(A);
 *      {Vr,Dr} = cdf2rdf(Vc,Dc);
 *
 *   SEE ALSO
 *      eig
 */
 
Func List cdf2rdf(Vc, Dc)
	CoMatrix Vc, Dc;
{
	Integer i,n,k;
	Complex j;
	Matrix Dr,Vr;
	CoMatrix jj,T;
	Index idx,idx2;

	j = (0,1);
	T = (I(Rows(Dc)),:);
	jj = [[1 1][j, -j]];
	idx = find(trans(Im(diag2vec(Dc))));
	n = length(idx);
	idx = idx(1:2:n);

	for (k = 1; k <= n; k++) {
		i = idx(k);
		T(i:i+1,i:i+1) = jj;
	}	

	Vr = Re(Vc/T);
	Dr = Re(T*Dc/T);
	return {Vr,Dr};
}
