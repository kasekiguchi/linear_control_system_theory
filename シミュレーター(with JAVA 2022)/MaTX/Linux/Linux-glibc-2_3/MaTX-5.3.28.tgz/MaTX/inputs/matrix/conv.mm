
/*  -*- MaTX -*-
 *
 *  NAME
 *      conv() - Convolution
 *
 *  SYNOPSIS
 *      C = conv(x,y)
 *         Array C;
 *         Array x,y;
 *
 *  DESCRIPTION
 *      conv(x,y) produces the convolution of the elements of x and y.  
 *      The resulting vector is of length (length(x)+length(y)-1).
 *
 *  SEE ALSO
 *      xcorr and deconv
 */

Func Array conv(x, y)
	Array x, y;
{
	if (version() == 4) {
		return fliplr(Array(Polynomial(fliplr(x))*Polynomial(fliplr(y))));
	} else {
		return Array(Polynomial(x) * Polynomial(y));
	}
}
