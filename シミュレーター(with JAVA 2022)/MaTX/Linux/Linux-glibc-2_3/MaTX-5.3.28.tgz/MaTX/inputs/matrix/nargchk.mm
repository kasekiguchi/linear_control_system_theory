
/* -*- MaTX -*-
 *
 *  NAME
 *      nargchk() - Check number of input arguments
 *
 *  SYNOPSIS
 *      mess = nargchk(nmin, nmax, n)
 *         String mess;
 *         Integer nmin, nmax, n;
 *
 *      mess = nargchk(nmin, nmax, n, fname)
 *         String mess;
 *         Integer nmin, nmax, n;
 *         String fname;
 *
 *  DESCRIPTION
 *      nargchk() checks the number of input arguments and returns error 
 *      message if not between nmin and nmax.  If it is correct, return 
 *      an empty string.
 *
 *  SEE ALSO
 *      warning and error
 */

Func String nargchk(nmin, nmax, n, fname, ...)
	Integer nmin, nmax, n;
	String fname;
{
	String msg;
	msg = "";
	
	if (nargs < 3) {
		error("nargchk(): Not enough input arguments.\n");
	} else if (4 < nargs) {
		error("nargchk(): Too many input arguments.\n");
	}

	if (n < nmin) {
		if (4 <= nargs && length(fname) != 0) {
			msg = sprintf("%s(): Not enough input arguments.\n", fname);
		} else {
			msg = "Not enough input arguments.\n";
		}
	} else if (n > nmax) {
		if (4 <= nargs && length(fname) != 0) {
			msg = sprintf("%s(): Too many input arguments.\n", fname);
		} else {
			msg = "Too many input arguments.\n";
		}
	}

	return msg;
}
