
/*  -*- MaTX -*-
 *
 *  NAME
 *      mat_demo() - Demonstrations of matrix toolbox
 *
 *  SYNOPSIS
 *      mat_dem()
 *
 *  DESCRIPTION
 *   	mat_demo() brings up a menu of the available demonstrations
 *      for matrix toolbox.
 *
 *  SEE ALSO
 *      sig_demo, demo
 *
 */

Func void mat_demo()
{
	Integer n;
	List demos;

	demos = {"Demo of Matrix Toolbox",
			 "E N D"};

	n = 1;
	while (1) {
		n = menu(demos,n);
		switch (n) {
		  default:
			return;
		}
		n++;
	}
}
