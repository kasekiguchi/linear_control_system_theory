
/*  -*- MaTX -*-
 *
 *  NAME
 *      isempty() - Check if a matrix is empty matrix
 *
 *  SYNOPSIS
 *      result = isempty(x)
 *         Integer result;
 *         Matrix x;
 *
 *  DESCRIPTION
 *      isempty(x) returns 1 if x is an empty matrix and 0 otherwise.
 *      An empty matrix has size 0-by-0.
 *
 *  SEE ALSO
 *      length
 */

Func Integer isempty(x)
	Matrix x;
{
	return (length(x) == 0);
}
