
/*  -*- MaTX -*-
 *
 *  NAME
 *      dec2hex() - Decimal number to hexadecimal number
 *
 *  SYNOPSIS
 *      h = dec2hex(x)
 *         String h;
 *         Integer x;
 *
 *  DESCRIPTION
 *      dec2hex(x) converts a decimal integer to a string in 
 *      hexadecimal form.
 *
 *  EXAMPLE
 *      dec2hex(2748) returns "ABC".
 *
 *	SEE ALSO
 *      hex2dec, hex2num, and Matrix
 */

Func String dec2hex(x)
	Integer x;
{
	Integer i,n,g;
	String h,ABCDEF;
	Index idx;

	if (x == 0) {
		return "0";
	}

	n = 1 + Integer(fix(log(x)/log(16)));
	idx = Index(cumprod([1, 16*ONE(1,n-1)]));

	h = "";
	ABCDEF = "ABCDEF";
	for (i = 1; i <= n; i++) {
		g = Integer(fix(Real(x)/idx(n-i+1)));
		x = rem(x, idx(n-i+1));

		if (g > 9) {
			h = h + ABCDEF(g - 9);
		} else {
			h = h + String(g);
		}
	}
	return h;
}
