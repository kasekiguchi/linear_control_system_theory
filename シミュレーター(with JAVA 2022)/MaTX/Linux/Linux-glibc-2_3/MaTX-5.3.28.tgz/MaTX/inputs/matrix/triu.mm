
/* -*- MaTX -*-
 *
 *  NAME
 *      triu() - Upper triangle
 *
 *  SYNOPSIS
 *      Y = triu(X)
 *         Matrix Y;
 *         Matrix X;
 *
 *      Y = triu(X, k)
 *         Matrix Y;
 *         Matrix X;
 *         Integer k;
 *
 *  DESCRIPTION
 *      triu(X) is the upper triangular part of X.  
 *
 *      triu(X,k) is the elements on and above the k-th diagonal of X.
 *        k = 0 : the main diagonal
 *        k > 0 : above the main diagonal
 *        k < 0 : below the main diagonal
 *
 *  SEE ALSO
 *      tril
 */

Func Matrix triu(X, k, ...)
	Matrix X;
	Integer k;
{
	Integer i, j;
	Matrix Y;

	error(nargchk(1, 2, nargs, "triu"));

	if (nargs == 1) {
		k = 0;
	}

	Y = Z(X);

	for (j = max(1,1+k); j <= Cols(X); j++) {
		for (i = 1; i <= min(Rows(X),j-k); i++) {
			Y(i,j) = X(i,j);
		}
	}
	return Y;
}
