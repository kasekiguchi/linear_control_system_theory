
/*  -*- MaTX -*-
 *
 *  NAME
 *      tcp_demo_server() - Server for TCP demonstration
 *      tcp_demo_client() - Server for TCP demonstration
 *
 *  SYNOPSIS
 *      tcp_demo_server()
 *
 *      tcp_demo_server(port)
 *         Integer port;
 *         
 *      tcp_demo_client(host)
 *         String host;
 *
 *      tcp_demo_server(host, port)
 *         String host;
 *         Integer port;
 *
 *  DESCRIPTION
 *
 *  DEMO
 *      host-A: tcp_demo_server(8000);
 *
 *      host-B: tcp_demo_client("host-A", 8000);
 *
 *	SEE ALSO
 *      tcp_demo_server, tcp_demo_client
 */

Func void tcp_demo_server(port, ...)
	Integer port;
{
  Integer sd, sd2;
  String mess;

  if (2 < nargs) {
	error("tcp_demo_server(): Incorrect number of arguments\n");
  }
  if (nargs < 1) {
	port = 8000;
  }

  if ((sd = socket_open("TCP")) < 0) {
	error("tcp_demo_server(): Can't open socket\n");
  }

  if (socket_bind(sd, port) < 0) {
	error("tcp_demo_server(): Can't bind socket\n");
  }

  if (socket_listen(sd) < 0) {
        error("tcp_demo_server(): Can't listen socket\n");
  }

  if ((sd2 = socket_accept(sd)) < 0) {
	error("tcp_demo_server(): Can't accept socket\n");
  }  

  while (1) {
	   mess = socket_gets(sd2,1024);
	   if (1 <= length(mess)) {
		 printf("mess = %s", mess);
	   }
	   if (5 == length(mess) && mess(1:4) == "quit") {
			break;
	   }
  }
  
  socket_close(sd2);
  socket_close(sd);
}

Func void tcp_demo_client(host, port, ...)
	String host;
	Integer port;
{
  Integer sd;
  String  mess;

  if (nargs < 1 || 2 < nargs) {
	error("tcp_demo_client(): Incorrect number of arguments\n");
  }
  
  if (nargs < 2) {
	port = 8000;
  }

  if ((sd = socket_open("TCP")) < 0) {
	error("tcp_demo_client(): Can't open socket\n");
  }

  if (socket_connect(sd, port, host) < 0) {
	error("tcp_demo_client(): Can't connect socket\n");
  }

  while (1) {
	print "mess = ";
	mess = gets();
	socket_puts(sd, mess + "\n");
	if (mess == "quit") {
	  break;
	}
  }

  socket_close(sd);
}
