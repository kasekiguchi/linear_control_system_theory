
/*  -*- MaTX -*-
 *
 *  NAME
 *      cond() - Condition number in 2-norm
 *
 *  SYNOPSIS
 *     c = cond(A)
 *        Real c;
 *        Matrix A;
 *
 *  DESCRIPTION
 *      cond(A) is the condition number in 2-norm (ratio of the largest 
 *      singular value of A to the smallest).
 *
 *  SEE ALSO
 *      singval, svd, and rank
 */

Func Real cond(A)
	Matrix A;
{
	Real c;
	Matrix sg;

	if (length(A) == 0) {
		warning("cond(): Null matrix of conditional number.\n");
		c = NaN;
	} else {
		sg = singval(A);

		if (any(sg .== 0)) {
			warning("cond(): Conditional number is infinite.\n");
			c = Inf;
		} else {
			c = max(sg)/min(sg);
		}
	}
	
	return c;
}
