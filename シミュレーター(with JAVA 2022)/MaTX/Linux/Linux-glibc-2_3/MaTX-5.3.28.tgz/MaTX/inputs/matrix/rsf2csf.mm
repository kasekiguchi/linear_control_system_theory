
/* -*- MaTX -*-
 *
 *  NAME
 *      rsf2csf() - Real Schur to complex Schur form conversion
 *
 *  SYNOPSIS
 *      {Uo,To} = rsf2csf(Ui,Ti)
 *           Matrix Uo,To;
 *           Matrix Ui,Ti;
 *
 *  DESCRIPTION
 *      rsf2csf() converts a real upper quasi-triangular Schur form 
 *      to a complex upper triangular Schur form.
 *
 *  SEE ALSO
 *      schur
 */

Func List rsf2csf(Ui, Ti)
	Matrix Ui, Ti;
{
	Integer i, n;
	Real r, tol;
	Complex c, s;
	CoMatrix To, Uo, Q, mu;

	n = length(Ti);

	To = (Ti,:);
	Uo = (Ui,:);

	tol = EPS*frobnorm(To);

	for (i = n; i > 1; i--) {
		if (abs(To(i,i-1)) > tol) {
			 mu = eigval(To(i-1:i,i-1:i)) .- To(i,i);
			 r = norm([mu(1), To(i,i-1)]);
			 c = mu(1)/r;
			 s = To(i,i-1)/r;
			 
			 Q = [[c#, s][-s, c]];
			 To(i-1:i,i-1:n) = Q * To(i-1:i,i-1:n);
			 To(1:i,i-1:i)   = To(1:i,i-1:i) * Q#;
			 Uo(1:n,i-1:i)   = Uo(1:n,i-1:i) * Q#;
		}
		
		To(i,i-1) = 0.0;
	}

	return {Uo, To};
}
