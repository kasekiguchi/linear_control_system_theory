
/*  -*- MaTX -*-
 *
 *  NAME
 *      hilbert() - Hilbert matrix
 *
 *  SYNOPSIS
 *      H = hilbert(n)
 *         Matri H;
 *         Integer n;
 *
 *  DESCRIPTION
 *      hilbert(n) returns the n-by-n hilbert matrix.
 *
 *  SEE ALSO
 *      ihilbert
 */

Func Matrix hilbert(n)
	Integer n;
{
	Integer i, j;
	Matrix H;

	H = Z(n);
	for (i = 1; i <= n; i++) {
		for (j = 1; j <= n; j++) {
			H(i,j) = 1.0/(i+j-1);
		}
	}
	return H;
}
