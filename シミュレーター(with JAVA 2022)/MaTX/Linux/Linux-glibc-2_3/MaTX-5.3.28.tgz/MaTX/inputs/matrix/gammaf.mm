
/*  -*- MaTX -*-
 *
 *  NAME
 *      gammaf() -  Complete and incomplete Gamma functions
 *
 *  SYNOPSIS
 *      b = gammaf(a)
 *         Array b;
 *         Array a;
 *
 *      b = gammaf(a, x)
 *         Array b;
 *         Array a;
 *         Array x;
 *
 *  DESCRIPTION
 *      gammaf(a) returns the value of the complete Gamma function
 *      for every element of a.
 *
 *      gammaf(a,x) returns the value of the incomplete Gamma function
 *      of a, integrated to limit X.  a and x must be matrices of the
 *      same size or either one may be a 1x1 matrix.
 *
 *  REFERENCES
 *      [1] W.H. Press et al, "Numerical Recipes", Cambridge Univ.
 *          Press, 1986.
 *
 *  SEE ALSO
 *      gammac() and gammai()
 */

Func Array gammaf(a_, x_, ...)
	Array a_, x_;
{
	Array a, x, b, gam;
	Integer i, m, mm, n, nn;

	error(nargchk(1, 2, nargs, "gammaf"));

	a = a_;
	if (nargs == 2) {
		x = x_;
	}

	b = Z(a);

	if (nargs == 1) {
		 b = gammac(a);
	} else {
		{m, n} = size(a);
		{mm, nn} = size(x);
		if (m != mm || n != nn) {
			if (m == 1 && n == 1) {
				a = [a](1,1)*ONE(x);
			} else if (mm == 1 && nn == 1) {
				x = [x](1,1)*ONE(a);
			} else {
				error("gammaf(): Matrix dimensions must agree.\n");
			}
		}

		for (i = 1; i <= Cols(a)*Rows(a); i++) {
			 gam = gammai([a(i)],x(i));
			 b(i) = [gam](1,1);
		}
	}

	return b;
}

