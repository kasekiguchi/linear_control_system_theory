
/*  -*- MaTX -*-
 *
 *  NAME
 *      gammai() - Incomplete Gamma function
 *
 *  SYNOPSIS
 *     gam = gammai(a, x)
 *       Array gam;
 *       Array a;
 *       Real x;
 *
 *  DESCRIPTION
 *      gammai(a,x) returns the value of the incomplete Gamma function
 *      for the element of a, integrated to scalar limit x.
 *
 *      The incomplete Gamma function is the integral of the following
 *      function integrated between 0 and x:
 *
 *      gammai(a,x) = 1/gammac(a) integral(0,x) exp(-t)*t^(a-1) 
 *
 *      where gammac() is the complete Gamma function
 *
 *  REFERENCES
 *      [1] W.H. Press et al, Numerical Recipes, Cambridge Univ.
 *	        Press, 1986.
 *
 *  SEE ALSO
 *      gammac()
 */

Func Array gammai(a, x)
	 Array a;
	 Real x;
{
	 Integer i, j, m, n;
	 Array gam;
	 Real gamser, gammcf;

	 List gammai_gser(), gammai_gcf();

	 if (x < 0 || any(a <= 0)) {
		  error("gammai(): Invalid arguments");
	 }

	 gam = Z(a);
	 {m,n} = size(a);

	 for (i = 1; i <= m; i++) {
		  for (j = 1; j <= n; j++) {
			   if (x < a(i,j)+1) {
					{gamser} = gammai_gser(a(i,j), x);
					gam(i,j) = gamser;
			   } else {
					{gammcf} = gammai_gcf(a(i,j), x);
					gam(i,j) = 1 - gammcf;
			   }
		  }
	 }

	 return gam;
}


Func List gammai_gser(a, x)
	 Real a, x;
{
	 Integer n, itmax;
	 Real sum_, del, ap, gamser, gln;
	 Array gg;

	 itmax = 100;

	 gg = gammac([a]);
	 gln = log(gg(1,1));

	 if (x <= 0.0) {
		  if (x < 0.0) {
			   error("gammai_gser(): x less than 0");
		  }
		  gamser = 0;
		  return {gamser, gln};
	 } else {
		  ap = a;
		  del = sum_ = 1/a;
		  for (n = 1; n <= itmax; n++) {
			   ap = ap + 1;
			   del = del * (x/ap);
			   sum_ = sum_ + del;
			   if (abs(del) < abs(sum_)*EPS) {
					gamser = sum_ * exp(-x + a*log(x) - gln);
					return {gamser, gln};
			   }
		  }
		  error("gammai_gser(): a too large, itmax too small");
		  return {0.0, 0.0}; /* never reached */
	 }
}

Func List gammai_gcf(a, x)
	 Real a, x;
{
	 Integer n, itmax;
	 Real gold, g, fac, gammcf, gln, ana, anf;
	 Real a0, a1, b0, b1;
	 Array gg;

	 itmax = 100;
	 gold = 0;
	 fac = 1;
	 b1 = 1;
	 b0 = 0;
	 a0 = 1;

	 gg = gammac([a]);
	 gln = log(gg(1,1));

	 a1 = x;
	 for (n = 1; n <= itmax; n++) {
		  ana = n - a;
		  a0 = (a1 + a0*ana)*fac;
		  b0 = (b1 + b0*ana)*fac;
		  anf = n*fac;
		  a1 = x*a0 + anf*a1;
		  b1 = x*b0 + anf*b1;
		  if (a1 != 0) {
			   fac = 1/a1;
			   g = b1*fac;
			   if (abs((g - gold)/g) < EPS) {
					gammcf = exp(-x + a*log(x) - gln)*g;
					return {gammcf, gln};
			   }
			   gold = g;
		  }
	 }
	 error("gammai_gcf(): a too large, itmax too small");
	 return {0.0, 0.0}; /* never reached */
}
