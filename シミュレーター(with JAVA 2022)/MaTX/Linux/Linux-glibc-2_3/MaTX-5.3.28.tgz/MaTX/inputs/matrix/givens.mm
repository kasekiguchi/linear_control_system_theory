
/*  -*- MaTX -*-
 *
 *  NAME
 *      givens() - Givens rotation matrix
 *
 *  SYNOPSIS
 *      G = givens(x, y)
 *         CoMatrix G;
 *         Complex x, y;
 *
 *  DESCRIPTION
 *      givens(x,y) returns the 2-by-2 complex Givens rotation matrix
 *
 *           | c       s |                  | x |     | r | 
 *       G = |           |   such that  G * |   |  =  |   |
 *           |-conj(s) c |                  | y |     | 0 |
 *   	                                
 *      where c is real, s is complex, and c^2 + s^2 = 1. 
 *
 *  REFERENCES
 *      [1] Parlett's method. Golub and VanLoan (1983)
 *
 *  SEE ALSO
 */

Func CoMatrix givens(x, y)
	Complex x, y;
{
	Real xl, p, l;
	Complex c, s;
	Matrix G;

	l = abs(x) + abs(y);

	xl = abs(x);
	if (xl == 0.0) {
		c = (0.0, 0.0);
		s = (1.0, 0.0);
	} else {
		p = l*sqrt(Re((x/l)*(x#/l) + (y/l)*(y#/l)));
		c = (xl/p, 0.0);
		s = (x/xl)*(conj(y)/p);
	}
	G = [[    c   , s  ]
		 [-conj(s), c  ]];
	return G;
}
