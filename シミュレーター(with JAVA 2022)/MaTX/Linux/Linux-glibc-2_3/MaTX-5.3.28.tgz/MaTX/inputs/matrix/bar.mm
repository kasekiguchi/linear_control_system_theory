
/*  -*- MaTX -*-
 *
 *  NAME
 *      bar()  - Data for bar graph
 *      barp() - Plot bar graph
 *
 *  SYNOPSIS
 *      {xx,yy} = bar(x)
 *         Array xx, yy;
 *         Array x;
 *
 *      {xx,yy} = bar(x, y)
 *         Array xx, yy;
 *         Array x;
 *         Array y;
 *
 *      barp(x)
 *         Array x;
 *
 *      barp(x, y)
 *         Array x;
 *         Array y;
 *
 *  DESCRIPTION
 *      bar(x) returns the data for a bar graph of x.
 *
 *      bar(x,y) returns the data for a bar graph in y at the locations 
 *      specified in x.  The values of x must be in ascending order and 
 *      evenly spaced.
 *
 *      barp(x) and barp(x,y) plot a graph.
 *
 *	SEE ALSO
 *      hist
 */

Func List bar(x_, y_, ...)
	Array x_, y_;
{
	Integer nx,n;
	Array x,y,X,Y,zz;
	Real dx;

	error(nargchk(1, 2, nargs, "bar"));

	nx = length(x_);
	if (nargs == 1) {
		x = [1:nx];
		y = x_;
	} else {
		x = x_;
		y = y_;
	}

	dx = (max(x) - min(x)) / (nx-1);
	n = 3*nx;
	X = Y = Z(1,n+1);
	zz = makerowv(x) .- 0.5*dx;

	X(1:3:n) = X(2:3:n) = zz;
	X(3:3:n) = zz .+ dx;
	Y(2:3:n) = Y(3:3:n) = y;
	X(n+1) = X(n);

	return {X,Y};
}

Func void barp(x, y, ...)
	Array x, y;
{
	Integer win;
	Array X,Y;

	error(nargchk(1, 2, nargs, "barp"));

	if (nargs == 1)  {
		{X,Y} = bar(x);
	} else {
		{X,Y} = bar(x,y);
	}

	win = mgplot_cur_win();
	mgplot(win,X,Y,{""});
}
