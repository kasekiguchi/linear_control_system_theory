
/* -*- MaTX -*-
 *
 *  NAME
 *      kronsum() - Kronecker sum
 *
 *  SYNOPSIS
 *      K = kronsum(A, B)
 *         Matrix K;
 *         Matrix A, B;
 *
 *  DESCRIPTION
 *      kronsum(A,B) is the Kronecker tensor sum of matrices A and B.
 *
 *  SEE ALSO
 *      kronprod
 */

Func Matrix kronsum(A, B)
	Matrix A, B;
{
	Matrix K;

	K = kronprod(I(B), A) + kronprod(B, I(A));

	return K;
}
