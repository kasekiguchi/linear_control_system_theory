
/*  -*- MaTX -*-
 *
 *  NAME
 *      makepoly() - Characteristic polynomial
 *
 *  SYNOPSIS
 *      p = makepoly(A)
 *        Polynomial p;
 *        Matrix A;
 *
 *      p = makepoly(A)
 *        Polynomial p;
 *        CoMatrix A;
 *
 *  DESCRIPTION
 *      If A is an n-by-n matrix, makepoly(A) is det(sI - A), i.e., 
 *      the characteristic polynomial of matrix A.
 *
 *      If A is a vector, makepoly(A) returns the polynomial whose 
 *      roots are given in A.
 *
 *  SEE ALSO
 *      charpoly, Polynomial, and Matrix
 */

Func Polynomial makepoly(A)
	Matrix A;
{
	Integer m, n, N;
	Polynomial s, po, po2;
	Matrix eg;

	{m, n} = size(A);
	
	if (m == 0 && n == 0) {
		return Polynomial([1]);
	} else if (m == n) {
		N = m;
		eg = eigval(A);
	} else if (m == 1 || n == 1) {
		N = m*n;
		eg = makecolv(A);
	} else {
		error("makepoly(): Argument must be square matrix or vector.\n");
	}

	s = Polynomial("s");

	if (isreal(A)) {
		po = Re(prod(s*ONE(N,1) - eg));
	} else {
		po = prod(s*ONE(N,1) - eg);
	}
	
	if (m == n && m <= 6) {
		po2 = det(s*I(A) - A);
		if (norm(eval(po2, A),"fro") < norm(eval(po, A),"fro")) {
			po = po2;
		}
	}

	return po;
}

