
/*  -*- MaTX -*-
 *
 *  NAME
 *      fftshift() - FFT Shift
 *
 *  SYNOPSIS
 *      Y = fftshift(X)
 *         Array Y;
 *         Array X;
 *
 *  DESCRIPTION
 *      If X is a vector, fftshift(X) returns a vector with the left and
 *      right halves exchanged.
 *
 *      If X is a matrix, fftshift(X) exchanges the 1st and 3rd 
 *      quadrants and the 2nd and 4th quadrants.
 *
 *  SEE ALSO
 *      fft, fft_row, fft_col
 */

Func Array fftshift(X)
	Array X;
{
	Integer m, n, m2, n2;
	Index idx1, idy1, idx2, idy2;
	Array Y;

	{m, n} = size(X);
	m2 = (m+1)/2;
	n2 = (n+1)/2;

	idx1 = [1:m2];
	idx2 = [m2+1:m];
	idy1 = [1:n2];
	idy2 = [n2+1:n];

	if (m == 1) {
		Y = [X(idy2), X(idy1)];
	} else if (n == 1) {
		Y = [[X(idx2)]
			 [X(idx1)]];
	} else {
		Y = [[X(idx2,idy2), X(idx2,idy1)]
			 [X(idx1,idy2), X(idx1,idy1)]];
	}

	return Y;
}
