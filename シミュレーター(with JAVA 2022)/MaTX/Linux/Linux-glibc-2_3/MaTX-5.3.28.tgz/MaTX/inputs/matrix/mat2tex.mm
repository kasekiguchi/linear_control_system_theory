
/*  -*- MaTX -*-
 *
 *  NAME
 *      mat2tex() - Save a matrix to a file in tex-form
 *      mat2texf() -  Generate the tex-form of a matrix
 *
 *  SYNOPSIS
 *        mat2tex(A, file)
 *           Matrix A;
 *           String file;
 *  
 *        mat2tex(A, file, format)
 *           Matrix A;
 *           String file;
 *           String format;
 *  
 *        tf = mat2texf(A)
 *           String tf;
 *           Matrix A;
 *
 *        tf = mat2texf(A, format)
 *           String tf;
 *           Matrix A;
 *           String format;
 *
 *  SEE ALSO
 *        poly2tex, poly2texf, rat2tex, and rat2texf
 */

Func void mat2tex(A, file, format, ...)
	Matrix A;
	String file, format;
{
	String mat2texf(...);

	error(nargchk(2, 3, nargs, "mat2tex"));

	if (nargs == 2) {
		fprintf(file, "%s", mat2texf(A));
	} else if (nargs == 3) {
		fprintf(file, "%s", mat2texf(A, format));
	}
}

Func String mat2texf(A, format, ...)
	Matrix A;
	String format;
{
	Integer i, j;
	String tex;

	error(nargchk(1, 2, nargs, "mat2texf"));

	tex = "\\left[\\begin{array}{";
	for (i = 1; i <= Cols(A); i++) {
		tex = tex + "r";
	}

	tex = tex + "}\n";
	for (i = 1; i <= Rows(A); i++) {
		tex = tex + "  ";
		for (j = 1; j <= Cols(A); j++) {
			if (nargs == 1) {
				tex = tex + sprintf("%g", A(i,j));
			} else if (nargs == 2) {
				tex = tex + sprintf(format, A(i,j));
			}
			if (j != Cols(A)) {
				tex = tex + " & ";
			}
		}
		if (i != Rows(A)) {
			tex = tex + "\\\\ ";
		}
		tex = tex + "\n";
	}
	return tex + "\\end{array}\\right]\n";
}
