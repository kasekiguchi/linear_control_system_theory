
/*  -*- MaTX -*-
 *
 *  NAME
 *      hist_col() - Data for histograms-plot for each column
 *      hist_row() - Data for histograms-plot for each row
 *      hist()     - Same as hist_row
 *
 *  SYNOPSIS
 *      {N,X} = hist(Y)
 *          Array N,X;
 *          Array Y;
 *
 *      {N,X} = hist(Y,n)
 *          Array N,X;
 *          Array Y;
 *          Integer n;
 *
 *      {N,X} = hist_col(Y)
 *          Array N,X;
 *          Array Y;
 *
 *      {N,X} = hist_col(Y,n)
 *          Array N,X;
 *          Array Y;
 *          Integer n;
 *
 *      {N,X} = hist_row(Y)
 *          Array N,X;
 *          Array Y;
 *
 *      {N,X} = hist_row(Y,n)
 *          Array N,X;
 *          Array Y;
 *          Integer n;
 *
 *  DESCRIPTION
 *      If y is a vector, hist(y) returns vectors to plot a histogram 
 *      with 10 equally spaced bins between the minimum and maximum 
 *      values in  y.
 *
 *      If y is a matrix, 
 *
 *      hist_col(y) calculates for each column
 *      hist_row(y) calculates for each row:
 *
 *      hist(y,n), hist_col(y,n), and hist_row(y,n) uses  n  bins.
 *
 *  SEE ALSO
 *      bar and barp
 */

Func List hist(Y, n, ...)
	Array Y;
	Integer n;
{
	error(nargchk(1, 2, nargs, "hist"));
	
	if (nargs == 1) {
		return hist_row(reshape(Y, 1, Rows(Y)*Cols(Y)));
	} else {
		return hist_row(reshape(Y, 1, Rows(Y)*Cols(Y)), n);
	}
}

Func List hist_col(Y_, n, ...)
	Array Y_;
	Integer n;
{
	Integer i,j;
	Array y,nn,x,N,X,Y;
	Real y_max, y_min, bw;

	error(nargchk(1, 2, nargs, "hist_col"));
	
	if (nargs == 1) {
		n = 10;
	}
	
	if (Rows(Y_) == 1 && Cols(Y_) != 1) {
		Y = makecolv(Y_);
	} else {
		Y = Y_;
	}

	X = N = Z(n,Cols(Y));
	for (i = 1; i <= Cols(Y); i++) {
		y = Y(:,i);

		y_min = min(y);
		y_max = max(y);
		bw = (y_max - y_min)/n;
		x = trans(y_min .+ bw*[0:n]);
		x(length(x)) = y_max;
		
		nn = Z(n+1,1);
		for (j = 2; j <= n + 1; j++) {
			nn(j,1) = length(find(y <= x(j)));
		}

		N(:,i) = nn(2:n+1,1) - nn(1:n,1);
		X(:,i) = x(1:length(x)-1) .+ bw/2;
	}

	if (Rows(Y_) == 1 && Cols(Y_) != 1) {
		N = trans(N);
		X = trans(X);
	}

	return {N, X};
}

Func List hist_row(Y, n, ...)
	Array Y;
	Integer n;
{
	Array N, X;

	error(nargchk(1, 2, nargs, "hist_row"));
	
	if (nargs == 1) {
		{N, X} = hist_col(trans(Matrix(Y)));
	} else {
		{N, X} = hist_col(trans(Matrix(Y)), n);
	}
	N = trans(Matrix(N));
	X = trans(Matrix(X));
	return {N, X};
}
