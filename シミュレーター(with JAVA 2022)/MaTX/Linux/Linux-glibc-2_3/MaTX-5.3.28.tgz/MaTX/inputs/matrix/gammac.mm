/*  -*- MaTX -*-
 *
 *  NAME
 *      gammac() - Complete Gamma function
 *
 *  SYNOPSIS
 *      gam = gammac(x)
 *         Array gam;
 *         Array x;
 *
 *  DESCRIPTION
 *     gammac(X) returns the value of the complete Gamma function
 *     for the element of x.
 *
 *  ALGORITHM
 *      [1] W.H. Press et al, Numerical Recipes, Cambridge Univ.
 *	        Press, 1986.
 *
 *  SEE ALSO
 *      gammai()
 */

Func Array gammac(x)
	 Array x;
{
	 Integer i, j, m, n;
	 Array gam;

	 Real gammac_gammln();

	 gam = Z(x);
	 {m,n} = size(x);
	 for (i = 1; i <= m; i++) {
		  for (j = 1; j <= n; j++) {
			   gam(i,j) = exp(gammac_gammln(x(i,j)));
		  }
	 }
	 
	 return gam;
}

Func Real gammac_gammln(xx)
	 Real xx;
{
	 Integer i;
	 Real x, y, tmp, ser;
	 Array cof;

	 cof = [76.18009172947146, -86.50532032941677,
			24.01409824083091, -1.231739572450155,
			0.1208650973866179e-2, -0.5395239384953e-5];
	 
	 y = x = xx;
	 tmp = x + 5.5;
	 tmp = tmp - ((x+0.5)*log(tmp));
	 ser = 1.000000000190015;
	 for (i = 1; i <= 6; i++) {
		  y = y + 1;
		  ser = ser + cof(i)/y;
	 }

	 return -tmp + log(2.5066282746310005*ser/x);
}
