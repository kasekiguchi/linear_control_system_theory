
/*  -*- MaTX -*-
 *
 *  NAME
 *      corrcoef_col() - Correlation coefficients for each column
 *      corrcoef_row() - Correlation coefficients for each row
 *
 *  SYNOPSIS
 *      cc = corrcoef_col(x)
 *        Array cc;
 *        Array x;
 *        Array y;
 *
 *      cc = corrcoef_col(x,y)
 *        Array cc;
 *        Array x;
 *        Array y;
 *
 *      cc = corrcoef_row(x)
 *        Array cc;
 *        Array x;
 *
 *      cc = corrcoef_row(x,y)
 *        Array cc;
 *        Array x;
 *        Array y;
 *
 *  DESCRIPTION
 *      corrcoef_col(x) is correlation coefficients of the elements of x 
 *      whose each row is an observation, and each column is a variable.
 *
 *      corrcoef_col(x,y) is the same as corrcoef_col([x y]).
 *
 *  SEE ALSO
 *      cov and std
 */

Func Array corrcoef_col(x,y, ...)
	Array x,y;
{
	Array cc;
	Matrix dv,cv;

	error(nargchk(1, 2, nargs, "corrcoef_col"));

	if (nargs == 1) {
		cv = cov_col(x);
	} else if (nargs == 2) {
		cv = cov_col(x,y);
	}

	dv = diag_vec(cv);
	cc = Array(cv) / sqrt(Array(dv*dv#));
	return cc;
}

Func Array corrcoef_row(x,y, ...)
	Array x,y;
{
	error(nargchk(1, 2, nargs, "corrcoef_row"));

	if (nargs == 1) {
		return trans(corrcoef_col(trans(x)));
	} else {
		return trans(corrcoef_col(trans(x), trans(y)));
	}
}

