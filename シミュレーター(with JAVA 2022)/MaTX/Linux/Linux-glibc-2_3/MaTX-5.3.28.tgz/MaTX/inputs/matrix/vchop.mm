
/*  -*- MaTX -*-
 *
 *  NAME
 *      vchop() - Chop a vector to some vectors
 *
 *  SYNOPSIS
 *      {x1, x2, ..., xn} = vchop(X, idx)
 *         Matrix x1, x2, ..., xn;
 *         Matrix X;
 *         List idx;
 *
 *  DESCRIPTION
 *      Chop a long state vector to some states vectors according to the
 *      given list of index.
 *
 *  EXAMPLE
 *      {X, idx} = vconnect({[1], [1 2]', [1 2 3]', [1 2 3 4]'});
 *      {x1, x2, x3, x4} = vchop(X, idx);
 *
 *  SEE ALSO
 *      vconnect
 */


Func List vchop(X, states_idx)
	Matrix X;
	List states_idx;
{
	Integer i, n;
	List states;

	n = length(states_idx);
	states = makelist(n);

	for (i = 1; i <= n; i++) {
		states(i) = X(states_idx(i,Index));
	}

	return states;
}

Func List VecChop(X, states_idx)
	Matrix X;
	List states_idx;
{
	return vchop(X, states_idx);
}
