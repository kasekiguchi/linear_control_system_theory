
/*  -*- MaTX -*-
 *
 *  NAME
 *      hadamard() - Hadamard matrix
 *
 *  SYNOPSIS
 *      H = hadamard(n)
 *         Matrix H;
 *         Integer n;
 *
 *  DESCRIPTION
 *      hadamard(n) is the Hadamard matrix of order 2^n
 */

Func Matrix hadamard(n)
	Integer n;
{
	Matrix H, T;

	if (n < 1) {
		H = ONE(1);
	} else { 
		T = hadamard(n-1);
		H = [[T   T]
			 [T, -T]];
	}
	return H;
}
