
/*  -*- MaTX -*-
 *
 *  NAME
 *      toeplitz() - Toeplitz matrix
 *
 *  SYNOPSIS
 *      T = toeplitz(x)
 *        Matrix T;
 *        Matrix x;
 *
 *      T = toeplitz(x,y)
 *        Matrix T;
 *        Matrix x;
 *        Matrix y;
 *
 *  DESCRIPTION
 *      toeplitz(x,y) returns a non-symmetric Toeplitz matrix with x as its
 *      first column and y as its first row.
 *
 *      toeplitz(x) is a symmetric (or Hermitian) Toeplitz matrix.
 *
 *  SEE ALSO
 *      hankel and vander
 */

Func Matrix toeplitz(x_, y_, ...)
	Matrix x_, y_;
{
	Integer i, n, nx, ny;
	Matrix x,y,T;

	error(nargchk(1, 2, nargs, "toeplitz"));

	T = [];
	if (nargs == 1) {
		n = Cols(x_);
		if (n == 1) {
			x = x_;
			y = trans(x_);
		} else {
			x = trans(x_);
			y = x_;
			if (n > 0) {
				x(1) = y(1);
			}
		}
	} else {
		x = x_;
		y = y_;
		if (all([Cols(y)&&Cols(x),  Rows(y)&&Rows(x)])) {
			if (y(1) != x(1)) {
				warning("toeplitz(): diagonal confliction.\n");
			}
		}
	}

	nx = length(x);
	ny = length(y);
	x = makecolv(x);
	y = makerowv(y);
	T = ONE(nx,ny);

	for (i = 1; i <= min(nx,ny); i++) {
		 T(i,i:ny) = y(1:ny-i+1);
		 T(i:nx,i) = x(1:nx-i+1);
	 }
	return T;
}



