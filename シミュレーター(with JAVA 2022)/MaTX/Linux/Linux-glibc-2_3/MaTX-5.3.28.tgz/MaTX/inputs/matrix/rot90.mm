
/* -*- MaTX -*-
 *
 *  NAME
 *      rot90() - Rotate matrix 90 degrees
 *
 *  SYNOPSIS
 *      X = rot90(A)
 *         Matrix X;
 *         Matrix A;
 *
 *      X = rot90(A, k)
 *         Matrix X;
 *         Matrix A;
 *         Integer k;
 *
 *  DESCRIPTION
 *      rot90(A) is the 90 degree rotation of A.
 *      rot90(A, k) is the k*90 degree rotation of A.
 *
 *  EXAMPLE
 *      A = [[1 2 3]      B = rot90(A) = [[3 6]
 *           [4 5 6]]                     [2 5]
 *                                        [1 4]]
 *
 *  SEE ALSO
 *      trans, fliplr, and flipud
 */

Func Matrix rot90(A, k, ...)
	Matrix A;
	Integer k;
{
	Matrix X;

	error(nargchk(1, 2, nargs, "rot90"));

	if (nargs == 1) {
		k = 1;
	} else if (nargs == 2) {
		k = rem(k, 4);
		if (k < 0) {
			k = k + 4;
		}
	}

	if (k == 1) {
		X = trans(A);
		X = flipud(X);
	} else if (k == 2) {
		X = fliplr(flipud(A));
	} else if (k == 3) {
		X = flipud(A);
		X = trans(X);
	} else {
		X = A;
	}

	return X;
}

