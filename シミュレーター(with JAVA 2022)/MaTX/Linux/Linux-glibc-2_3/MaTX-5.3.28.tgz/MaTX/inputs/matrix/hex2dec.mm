
/*  -*- MaTX -*-
 *
 *  NAME
 *      hex2dec() - Hexadecimal number to decimal number
 *
 *  SYNOPSIS
 *      d = hex2dec(h)
 *         Integer d;
 *         String h;
 *
 *  DESCRIPTION
 *     hex2dec(h) converts a hexadecimal number to an integer in decimal form.
 *
 *  EXAMPLE
 *     hex2dec("7B") and hex2dec("7b") both return 123.
 *
 *	SEE ALSO
 *      dec2hex, hex2num, and Matrix.
 */

Func Integer hex2dec(h)
	String h;
{
	Integer i,m,n,hi,d;
	Matrix pp,hh;

	n = length(h);
	pp = cumprod([1, 16*ONE(1,n-1)]);
	hh = Z(1,n);

	for (i = 1; i <= n; i++) {
		hi = Integer([abs(h(i))](1));
		if (hi > 96) {
			hh(i) = hi - 87;
		} else if (hi > 64) {
			hh(i) = hi - 55;
		} else {
			hh(i) = hi - 48;
		}
	}
	d = Integer([hh*pp(n:-1:1)'](1));

	return d;
}
