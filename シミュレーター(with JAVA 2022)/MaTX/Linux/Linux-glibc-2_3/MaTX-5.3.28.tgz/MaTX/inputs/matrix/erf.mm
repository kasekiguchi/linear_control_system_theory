
/* -*- MaTX -*-
 *
 *  NAME
 *      erf() - Error function
 *
 *  SYNOPSIS
 *      b = erf(x1)
 *         Array b;
 *         Array x1;
 *
 *      b = erf(x1, x2)
 *         Array b;
 *         Array x1;
 *         Array x2;
 *
 *  DESCRIPTION
 *      erf(x) calculates the error function for the element of x. 
 *
 *      The error function is the integral of the normal probability 
 *      distribution function from 0 to X:
 *
 *        erf(x) = 2/sqrt(PI) integral(0,x) exp(-t^2)
 *
 *      erf(x1,x2) returns the value of the error function integrated
 *      between x1 and x2:
 *
 *        erf(x1,x2) = 2/sqrt(PI) integral(x1,x2) exp(-t^2)
 *
 *      Either x1, x2, or both may matrices, in which case the function
 *      is evaluated at all the elements.
 *
 *  REFERENCES
 *      [1] W.H. Press et al, "Numerical Recipes", Cambridge Univ.
 *          Press, 1986.
 *
 *  SEE ALSO
 *      gammaf(), gammac(), gammai() and inverf().
 *
 */

Func Array erf(x1_, x2_, ...)
	Array x1_, x2_;
{
	Integer m1,m2,n1,n2,m,n;
	Array x1,x2,x,er;

	error(nargchk(1, 2, nargs, "erf"));

	if (nargs == 1) {
		x1 = Z(x1_);
		x2 = x1_;
	} else if (nargs == 2) {
		x1 = x1_;
		x2 = x2_;
	}

	{m1,n1} = size(x1);
	{m2,n2} = size(x2);
	if (m1 != m2 || n1 != n2) {
		if (m1 == 1 && n1 == 1) {
			x1 = [x1](1,1) * ONE(x2);
		} else if (m2 == 1 && n2 == 1) {
			x2 = [x2](1,1) * ONE(x1);
		} else {
			error("erf(): Data size must agree.\n");
		}
	}

	x = [x1 x2];
	er = sgn(x) * gammaf([0.5], x^2);
	n = Cols(x)/2;
	er = er(:,n+1:2*n) - er(:,1:n);
	return er;
}
