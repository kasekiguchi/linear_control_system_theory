
/* -*- MaTX -*-
 *
 *  NAME
 *      angle() - Phase angles (in radians)
 *
 *  SYNOPSIS
 *      ph = angle(g)
 *        Array ph;
 *        CoArray g;
 *
 *  DESCRIPTION
 *      angle(g) returns the phase angles (in radians) of a complex 
 *      array.
 *
 *  SEE ALSO
 *      abs
 */

Func Array angle(g)
	CoArray g;
{
	Array ph;

	ph = atan2(Im(g), Re(g));
	return ph;
}
