
/* -*- MaTX -*-
 *
 *  NAME
 *      boxcar() - Rectangular window
 * 
 *  SYNOPSIS
 *      win = boxcar(n)
 *         Array win;
 *         Integer n;
 *
 *  DESCRIPTION
 *      boxcar(n) returns an array (n-point) for Rectangular window
 *
 *  SEE ALSO
 *      bartlett and blackman
 */

Func Array boxcar(n)
	Integer n;
{
	Array win;

	win = ONE(1,n);
	return win;
}
