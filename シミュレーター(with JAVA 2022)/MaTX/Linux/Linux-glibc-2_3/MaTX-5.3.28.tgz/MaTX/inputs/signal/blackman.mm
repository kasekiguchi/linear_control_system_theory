
/* -*- MaTX -*-
 *
 *  NAME
 *      blackman() - Blackman window
 *
 *  SYNOPSIS
 *      win = blackman(n)
 *         Array win;
 *         Integer n;
 *
 *  DESCRIPTION
 *      blackman(n) returns an array (n-point) for Blackman window
 *
 *  SEE ALSO
 *      bartlett and boxcar
 */

Func Array blackman(n)
	Integer n;
{
	Array tt, win;

	tt = [0:n-1]/(n-1);
	win = 0.42 .- 0.5*cos(2*PI*tt) + 0.08*cos(4*PI*tt);
	return win;
}
