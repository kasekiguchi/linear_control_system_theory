
/*  -*- MaTX -*-
 *
 *  NAME
 *      xcov() - Cross-covariance function
 *
 *  SYNOPSIS
 *      c = xcov(x)
 *         Array c;
 *         Array x;
 *
 *      c = xcov(x,y)
 *         Array c;
 *         Array x;
 *         Array y;
 *
 *  DESCRIPTION
 *      xcov(x,y) returns the cross-covariance in a column vector, 
 *      where x and y are m-point vectors.
 *
 *      xcov(x), when x is a vector, is the auto-covariance.
 *
 *      xcov(x), when x is an m-by-n matrix, is a matrix with
 *      2*m-1 rows whose n^2 columns contain the cross-covariance
 *      for all combinations of the columns of x.
 *
 *	SEE ALSO
 *      xcorr and conv
 */

Func Array xcov(x, y, ...)
	Array x, y;
{
	Array c, ox, oy;

	error(nargchk(1, 2, nargs, "xcov"));

	ox = ONE(Rows(x),1);
	
	if (nargs == 1) {
		c = xcorr(x - ox*mean_row(trans(x)));
	} else if (nargs == 2) {
		oy = ONE(Rows(y),1);
		c = xcorr(x - ox*mean_row(trans(x)),
				  y - oy*mean_row(trans(y)));
	}

	return c;
}
