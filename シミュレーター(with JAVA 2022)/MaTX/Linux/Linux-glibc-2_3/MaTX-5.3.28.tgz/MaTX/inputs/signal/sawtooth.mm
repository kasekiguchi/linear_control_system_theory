
/* -*- MaTX -*-
 *
 *  NAME
 *      sawtooth() - Sawtooth wave
 *
 *  SYNOPSIS
 *      wv = sawtooth(t)
 *         Array wv;
 *         Array t;
 *
 *  DESCRIPTION
 *      sawtooth(t) returns a sawtooth wave with period 2*PI for
 *      the values of time array t.
 *
 *  SEE ALSO
 *      square
 */

Func Array sawtooth(t)
	Array t;
{
	Array wv;

	wv = ((t < 0) + rem(t,2*PI)/2/PI .- 0.5)*2;
	return wv;
}
