
/* -*- MaTX -*-
 *
 *  NAME
 *      square() - Square wave
 *
 *  SYNOPSIS
 *      wv = square(t)
 *         Array wv;
 *         Array t;
 *
 *      wv = square(t, duty)
 *         Array wv;
 *         Array t;
 *         Real duty;
 *
 *  DESCRIPTION
 *      square(t) returns a square wave with period 2*PI for the
 *      values of time array t.
 *   
 *      square(t,duty) returns a square wave with specified duty
 *      cycle.  duty is the percent of the period where the signal 
 *      is positive.
 *
 *  EXAMPLE
 *      Generate a 50 Hz square wave:
 *
 *        t = [0:0.001:2.5];
 *        y = square(2*PI*50*t);
 *        mgplot(1,t,y)
 *
 *  SEE ALSO
 *      sawtooth
 */

Func Array square(t, duty, ...)
	Array t;
	Real duty;
{
	Real w0;
	Array wv,nt,no,ne;

	error(nargchk(1, 2, nargs, "square"));
	
	if (nargs < 2) {
		duty = 50.0;
	}

	w0 = 2*PI*duty/100;

	// Normalized t
	nt = rem(t,2*PI);
	no = (nt > w0) || (nt < w0 - 2*PI);
	ne = t < 0;

	wv = 2*rem(ne + no + ONE(t),2) .- 1;

	return wv;
}
