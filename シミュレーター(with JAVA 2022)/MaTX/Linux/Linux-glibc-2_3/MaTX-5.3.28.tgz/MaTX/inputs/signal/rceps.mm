
/*  -*- MaTX -*-
 *
 *  NAME
 *      rceps() - Real cepstrum
 *
 *  SYNOPSIS
 *      {xc,yc} = rceps(x)
 *          Array xc,yc;
 *          Array x;
 *
 *  DESCRIPTION
 *      rceps(x) returns the real cepstrum and a minimum phase signal
 *      of the sequence x.
 *
 *  SEE ALSO
 *      cceps and fft
 *
 */

Func List rceps(x)
	Array x;
{
	Array xc,yc,win;
	Integer n,oe;

	n = length(x);
	xc = Re(ifft(log(abs(fft(x)))));

	oe = rem(n,2);
	win = [[       1           ]
		   [2*ONE((n+oe)/2-1,1)]
		   [       1           ]
		   [  Z((n-oe)/2-1,1)  ]];

	yc = Re(ifft(exp(fft(win * Array(makecolv(xc))))));
	return {xc, yc};
}
