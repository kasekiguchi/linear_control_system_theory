
/*  -*- MaTX -*-
 *
 *  NAME
 *      cceps() - Complex cepstrum
 *
 *  SYNOPSIS
 *      xc = cceps(x)
 *         Array xc;
 *         Array x;
 *
 *  DESCRIPTION
 *      cceps(x) returns the complex cepstrum of the sequence x.
 *
 *	SEE ALSO
 *       rceps and fft
 */

Func Array cceps(x)
	Array x;
{
	Integer n,n2;
	Complex j;
	Array xc;
	CoArray X, Y;
 
	Array cceps_unwrap();

	j = (0,1);
	n = length(x);
	n2 = Integer(fix((n+1)/2.0));

	X = fft(x);
	Y = unwrap(angle(X));
	Y = Y - PI*fix(Y(n2+1)/PI)*[0:n-1]/(n2+1);

	xc = Re(ifft(log(abs(X)) + j*Y));
	return xc;
}

