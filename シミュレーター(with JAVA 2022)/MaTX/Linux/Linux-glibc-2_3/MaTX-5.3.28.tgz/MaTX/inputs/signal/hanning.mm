
/*  -*- MaTX -*-
 *
 *	NAME
 *      hanning() - Hanning window
 *
 *	SYNOPSIS
 *     win = hanning(n)
 *       Array win;
 *       Integer n;
 *
 *  DESCRIPTION
 *      hanning(n) returns an array (n-point) for Hanning window
 *
 *  SEE ALSO
 *     hamming
 */

Func Array hanning(n)
	Integer n;
{
	Array win;

	win = 0.5 .- 0.5*cos(2*PI*[1:n]/(n+1));
	return win;
}
