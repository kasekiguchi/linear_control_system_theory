
/*  -*- MaTX -*-
 *
 *  NAME
 *      bartlett() - Bartlett window
 *
 *  SYNOPSIS
 *      win = bartlett(n)
 *       Array win;
 *       Integer n;
 *
 *  DESCRIPTION
 *      bartlett(n) returns an array (n-point) for Bartlett window
 *
 *  SEE ALSO
 *    blackman and boxcar
 */

Func Array bartlett(n)
	Integer n;
{
	Array win;

	win = 2*[0:(n-1)/2]/(n-1);

	if (rem(n,2)) {
		win = [win, win((n-1)/2:-1:1)];
	} else {
		win = [win, win(n/2:-1:1)];
	}

	return win;
}
