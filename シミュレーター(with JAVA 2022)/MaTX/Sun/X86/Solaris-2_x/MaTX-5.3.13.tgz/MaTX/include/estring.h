
/*
 *
 * Copyright (C) 1989-1994 Masanobu Koga
 *            All Rights Reserved.
 *
 * No part of this software may be used, copied, modified, and distributed
 * in any form or by any means, electronic, mechanical, manual, optical or
 * otherwise, without prior permission of Masanobu Koga.
 *
 */

/*
  estring.h : 

  $Author: koga $
  $Revision: 1.2 $
  $Date: 2000/11/23 04:13:47 $
  $Log: estring.h,v $
  Revision 1.2  2000/11/23 04:13:47  koga
  *** empty log message ***

 * Revision 1.1  1994/06/21  13:21:48  koga
 * Initial revision
 *
*/

#ifndef estring_header
#define estring_header

#ifdef MSC60
#pragma optimize( "t", off )
#endif

#define	STR_NULL		strcpy((char *)emalloc(1), "")

/*
 * String Class Definition
 */

typedef char *String;

#ifdef HAVE_STDARG
String	StringPrintf(char *format, ...);
#else
String	StringPrintf();
#endif
String	StringDef(char *ss);
String	StringDup(String str);
String	StringCharToString(char c);
String	StringAssign(String *str, char *name);
String	StringEdit(String *str, char *name);
int		StringFileWrite(String str, char *filename);
int		StringFileSave(String a, char *filename, char *name,
					   int append, int cr);
String	StringWrite(String str, FILE *fp, char *name);
int		StringRead(String *str, FILE *fp, char *name);
int		StringReadContent(String *str, FILE *fp, StringData *data);
int		StringIndex(String str, String key_word);
int		StringLastIndex(String str, String key_word);
void	StringFree(String str);
String	StringAdd(String str1, String str2);
#ifdef HAVE_STDARG
String	StringCats(int n, ...);
#else
String	StringCats();
#endif
String	StringGetElem(String str1, int n);
String	StringSetElem(String str1, int n, String str2);
String	StringCut(String str1, int n1, int n2);
String	StringPut(String str1, int n, String str2);
String	StringFgets(int fd, unsigned int size);
String	StringGets(unsigned int size);
#endif
