
/* -*- MaTX -*-
 *
 *  NAME
 *      zp2tfn() - Zero-pole to transfer function conversion
 *
 *  SYNOPSIS
 *      g = zp2tf(z,p,k)
 *         Rational g;
 *         CoMatrix z,p;
 *         Matrix k;
 *
 *  DESCRIPTION
 *      zp2tfn(z,p,k) returns the transfer function 
 *
 *                   (s-z1)(s-z2)...(s-zn)
 *         g(s) =  k ---------------------
 *                   (s-p1)(s-p2)...(s-pn)
 *
 *      for the SISO system, given a set of pole and zero in p and z,
 *      and each gain of the numerator of the transfer function in k.
 *
 *  SEE ALSO  
 *      zp2tf, zp2tfm, zp2ss, and tfn2zp
 */

Func Rational zp2tfn(z,p,k)
	CoMatrix z,p;
	Matrix k;
{
	Rational g;
	Matrix num,den;

	if (Cols(z) > 1) {
		error("zp2tfn(): System must be SISO\n");
	}
	
	{num,den} = zp2tf(z,p,k);
	g = tf2tfn(num,den);
	return g;
}
