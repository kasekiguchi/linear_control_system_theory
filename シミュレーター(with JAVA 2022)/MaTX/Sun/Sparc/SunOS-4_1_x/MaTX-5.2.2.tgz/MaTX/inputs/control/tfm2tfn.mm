
/* -*- MaTX -*-
 *
 *  NAME
 *      tfm2tfn() - Transfer function matrix to transfer function conversion
 *
 *  SYNOPSIS
 *     g = tfm2tfn(G)
 *        Rational g;
 *        RaMatrix G;
 *
 *     g = tfm2tf(G,i)
 *        Rational g;
 *        RaMatrix G;
 *        Integer i;
 *
 *     g = tfm2tf(G,i,j)
 *        Rational g;
 *        RaMatrix G;
 *        Integer i;
 *        Integer j;
 *
 *  DESCRIPTION
 *      tfm2tfn(G,i,j) returns the transfer function from the i'th 
 *      input to the j'th output of the MIMO system given by the
 *      transfer function matrix
 *
 *             [G11(s) G12(s) .... G1m(s)]
 *             [G21(s)                   ]
 *      G(s) = [             Gij(s)      ]
 *             [                         ]
 *             [                   Gpm(s)]
 *
 *  SEE ALSO
 *      tfm2tf, tfm2ss, tfm2zp, tfn2tfm
 */

Func Rational tfm2tfn(G, i, j, ...)
	RaMatrix G;
	Integer i;
	Integer j;
{
	Rational g;

	error(nargchk(1, 2, nargs, "tfm2tfn"));

	if (Rows(G) > 1) {
		error("tfm2tfn(): System must be single output\n");
	}
	
	if (nargs == 1) {
		i = 1;
		j = 1;
	} else if (nargs == 2) {
		i = 1;
	}

	g = G(i,j);
	return g;
}
