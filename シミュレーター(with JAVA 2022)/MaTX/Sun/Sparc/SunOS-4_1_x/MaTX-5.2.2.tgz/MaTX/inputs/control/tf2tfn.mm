
/* -*- MaTX -*-
 *
 *  NAME
 *      tf2tfn() -  Transfer function to transfer function conversion
 *
 *  SYNOPSIS
 *      g = tf2tfn(num,den)
 *         Rational g;
 *         Matrix num,den;
 *
 *  DESCRIPTION
 *       tf2tfn(num,den) returns the transfer function
 *
 *                  num(s) 
 *          g(s) = --------
 *                  den(s)
 *
 *      for the SISO system, given the coefficients of the numerator num
 *      and coefficients of the denominator den.
 *
 *  SEE ALSO
 *      tf2tfm, tf2ss, tf2zp, and tfn2tf
 */

Func Rational tf2tfn(num, den)
	Matrix num, den;
{
	Rational g;
	Polynomial nn, dd;

	if (Rows(num) > 1) {
		error("tf2tfn(): System must be SISO\n");
	}

	if (version() == 4) {
		nn = Polynomial(fliplr(num));
		dd = Polynomial(fliplr(den));
	} else {
		nn = Polynomial(num);
		dd = Polynomial(den);
	}

	g = nn/dd;

	return g;
}
