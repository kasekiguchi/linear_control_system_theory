
/* -*- MaTX -*-
 *
 *  NAME
 *      gplot()              - Linear x-y Plot with GNUPLOT
 *      gplot_clear()        - Clear screen
 *      gplot_cmd()          - Send any commands with "\n" to gnuplot
 *      gplot_grid()         - Grid lines (toggle)
 *      gplot_hold()         - Hold command (DOS, Windows95/NT)
 *      gplot_key()          - Key lines (toggle)
 *      gplot_hidden3d()     - Hidden 3D (toggle)
 *      gplot_parametric()   - Parametric lines (toggle)
 *      gplot_loglog()       - loglog x-y plot
 *      gplot_options()      - Set window options
 *      gplot_out()          - Send a string to gnuplot
 *      gplot_psout()        - Save the graph as a postscript file
 *      gplot_figcode()      - Save the graph as a figcode file
 *      gplot_replot()       - Replot lines
 *      gplot_reset()        - Reset window
 *      gplot_semilogx()     - Semi-log x-y plot (x-axis logarithmic)
 *      gplot_semilogy()     - Semi-log x-y plot (y-axis logarithmic)
 *      gplot_text()         - Put text on the screen
 *      gplot_title()        - Graph title
 *      gplot_quit()         - Quit mgplot
 *      gplot_xlabel()       - X-axis label
 *      gplot_x2label()      - 2nd X-axis label
 *      gplot_ylabel()       - Y-axis label
 *      gplot_y2label()      - 2nd Y-axis label
 *      gplot_zlabel()       - Z-axis label
 *      mgplot_view()        - Angle og view
 *      mgplot_view_control()- Angle og view
 *      greplot()            - Linear x-y Plot with GNUPLOT
 *      greplot_loglog()     - loglog x-y plot
 *      greplot_semilogx()   - Semi-log x-y plot (x-axis logarithmic)
 *      greplot_semilogy()   - Semi-log x-y plot (y-axis logarithmic)
 *
 *  SYNOPSIS
 *      gplot(X, Y, titles, cmds, ...)
 *        Array X;
 *        ...
 *        Array Y;
 *        List titles, cmds;
 *        String str;
 *
 *      gplot_clear()
 *
 *      gplot_cmd(cmd)
 *        String cmd;
 *
 *      gplot_grid(onoff, ...)
 *        ...
 *        Integer onoff;
 *
 *      gplot_key(onoff, ...)
 *        ...
 *        Integer onoff;
 *
 *      gplot_parametric(onoff, ...)
 *        ...
 *        Integer onoff;
 *
 *      gplot_hidden3d(onoff, ...)
 *        ...
 *        Integer onoff;
 *
 *      gplot_loglog(X, Y, titles, cmds, ...)
 *        Array X, Y;
 *        ...
 *        List titles;
 *        List cmds;
 *
 *      gplot_options(options)
 *         String options;
 *
 *      gplot_out(str)
 *        String str;
 *
 *      gplot_psout(filename, cmd, ...)
 *        String filename;
 *        ...
 *        String cmd;
 *
 *      gplot_figcode(filename, cmd, ...)
 *        String filename;
 *        ...
 *        String cmd;
 *
 *      gplot_semilogx(X, Y, titles, cmds)
 *        Array X, Y;
 *        ...
 *        List titles;
 *        List cmds;
 *
 *      gplot_semilogy(X, Y, titles, cmds, ...)
 *        Array X, Y;
 *        ...
 *        List titles;
 *        List cmds;
 *
 *      gplot_text(text, x, y, z, ...)
 *        String text;
 *        Real x, y;
 *        ...
 *        Real z;
 *
 *      gplot_title(text)
 *        String text;
 *
 *      gplot_quit()
 *
 *      gplot_replot()
 *
 *      gplot_reset()
 *
 *      gplot_xlabel(text, xoff, yoff, ...)
 *        String text;
 *        ...
 *        Integer xoff = 0;
 *        Integer yoff = 0;
 *
 *      gplot_x2label(text, xoff, yoff, ...)
 *        String text;
 *        ...
 *        Integer xoff = 0;
 *        Integer yoff = 0;
 *
 *      gplot_ylabel(text, xoff, yoff, ...)
 *        String text;
 *        ...
 *        Integer xoff = 0;
 *        Integer yoff = 0;
 *
 *      gplot_y2label(text, xoff, yoff, ...)
 *        String text;
 *        ...
 *        Integer xoff = 0;
 *        Integer yoff = 0;
 *
 *      gplot_zlabel(text, xoff, yoff, ...)
 *        String text;
 *        ...
 *        Integer xoff = 0;
 *        Integer yoff = 0;
 *
 *      gplot_view(rotate_x, rotate_z, scale, scal_z)
 *        Integer rotate_x;
 *        ...
 *        Integer rotate_z;
 *        Integer scale;
 *        Integer scale_z;
 *
 *      gplot_view_control(rotate_x, rotate_z, scale, scal_z)
 *        ...
 *        Integer rotate_x;
 *        Integer rotate_z;
 *        Integer scale;
 *        Integer scale_z;
 *
 *      greplot(X, Y, titles, cmds, ...)
 *        Array X;
 *        ...
 *        Array Y;
 *        List titles, cmds;
 *        String str;
 *
 *      greplot_loglog(X, Y, titles, cmds, ...)
 *        Array X, Y;
 *        ...
 *        List titles;
 *        List cmds;
 *
 *      greplot_semilogx(X, Y, titles, cmds)
 *        Array X, Y;
 *        ...
 *        List titles;
 *        List cmds;
 *
 *      greplot_semilogy(X, Y, titles, cmds)
 *        Array X, Y;
 *        ...
 *        List titles;
 *        List cmds;
 *
 */

Func void gplot(X, Y, titles, cmds, ...)
	Array X;
	Array Y;
	List titles;
	List cmds;
{
	if (nargs == 1) {
		mgplot(mgplot_cur_win(), X);
	} else if (nargs == 2) {
		mgplot(mgplot_cur_win(), X, Y);
	} else if (nargs == 3) {
		mgplot(mgplot_cur_win(), X, Y, titles);
	} else if (nargs == 4) {
		mgplot(mgplot_cur_win(), X, Y, titles, cmds);
	} else {
		error("gplot(): Incorrect number of arguments.\n");
	}
}

Func void greplot(X, Y, titles, cmds, ...)
	Array X;
	Array Y;
	List titles;
	List cmds;
{
	if (nargs == 0) {
		gplot_replot();
	} else if (nargs == 1) {
		mgreplot(mgplot_cur_win(), X);
	} else if (nargs == 2) {
		mgreplot(mgplot_cur_win(), X, Y);
	} else if (nargs == 3) {
		mgreplot(mgplot_cur_win(), X, Y, titles);
	} else if (nargs == 4) {
		mgreplot(mgplot_cur_win(), X, Y, titles, cmds);
	} else {
		error("greplot(): Incorrect number of arguments.\n");
	}
}

Func void gplot_cmd(cmd)
	String cmd;
{
	mgplot_cmd(mgplot_cur_win(), cmd);
}

Func void gplot_clear()
{
	mgplot_clear(mgplot_cur_win());
}

Func void gplot_replot()
{
	mgplot_replot(mgplot_cur_win());
}

Func void gplot_quit()
{
	mgplot_quit(mgplot_cur_win());
}

Func void gplot_reset()
{
	mgplot_reset(mgplot_cur_win());
}

Func void gplot_grid(onoff, ...)
	Integer onoff;
{
	if (nargs == 0) {
		mgplot_grid(mgplot_cur_win());
	} else if (nargs == 1) {
		mgplot_grid(mgplot_cur_win(), onoff);
	} else {
		error("gplot_grid(): Incorrect number of arguments.\n");
	}
}

Func void gplot_key(onoff, ...)
	Integer onoff;
{
	if (nargs == 0) {
		mgplot_key(mgplot_cur_win());
	} else if (nargs == 1) {
		mgplot_key(mgplot_cur_win(), onoff);
	} else {
		error("gplot_key(): Incorrect number of arguments.\n");
	}
}

Func void gplot_parametric(onoff, ...)
	Integer onoff;
{
	if (nargs == 0) {
		mgplot_parametric(mgplot_cur_win());
	} else if (nargs == 1) {
		mgplot_parametric(mgplot_cur_win(), onoff);
	} else {
		error("gplot_parametric(): Incorrect number of arguments.\n");
	}
}

Func void gplot_hidden3d(onoff, ...)
	Integer onoff;
{
	if (nargs == 0) {
		mgplot_hidden3d(mgplot_cur_win());
	} else if (nargs == 1) {
		mgplot_hidden3d(mgplot_cur_win(), onoff);
	} else {
		error("gplot_hidden3d(): Incorrect number of arguments.\n");
	}
}

Func Integer gplot_hold(onoff, ...)
	Integer onoff;
{
	if (nargs == 0) {
		return mgplot_hold(mgplot_cur_win());
	} else if (nargs == 1) {
		return mgplot_hold(mgplot_cur_win(), onoff);
	} else {
		error("gplot_hold(): Incorrect number of arguments.\n");
		return 0;
	}
}

Func void gplot_loglog(X1, Y1, titles, cmds, ...)
	Array X1;
	Array Y1;
	List titles;
	List cmds;
{
	if (nargs == 2) {
		mgplot_loglog(mgplot_cur_win(), X1, Y1);
	} else if (nargs == 3) {
		mgplot_loglog(mgplot_cur_win(), X1, Y1, titles);
	} else if (nargs == 4) {
		mgplot_loglog(mgplot_cur_win(), X1, Y1, titles, cmds);
	} else {
		error("gplot_loglog(): Incorrect number of arguments.\n");
	}
}

Func void greplot_loglog(X1, Y1, titles, cmds, ...)
	Array X1;
	Array Y1;
	List titles;
	List cmds;
{
	if (nargs == 2) {
		mgreplot_loglog(mgplot_cur_win(), X1, Y1);
	} else if (nargs == 3) {
		mgreplot_loglog(mgplot_cur_win(), X1, Y1, titles);
	} else if (nargs == 4) {
		mgreplot_loglog(mgplot_cur_win(), X1, Y1, titles, cmds);
	} else {
		error("greplot_loglog(): Incorrect number of arguments.\n");
	}
}

Func void gplot_psout(filename, cmd, ...)
	String filename;
	String cmd;
{
	if (nargs < 1 || 2 < nargs) {
		error("gplot_psout(): Incorrect number of arguments.\n");
	}
	
	if (nargs == 1) {
		mgplot_psout(mgplot_cur_win(), filename);
	} else if (nargs == 2) {
		mgplot_psout(mgplot_cur_win(), filename, cmd);
	}
}

Func void gplot_figcode(filename, cmd, ...)
	String filename;
	String cmd;
{
	if (nargs < 1 || 2 < nargs) {
		error("gplot_figcode(): Incorrect number of arguments.\n");
	}
	
	if (nargs == 1) {
		mgplot_figcode(mgplot_cur_win(), filename);
	} else if (nargs == 2) {
		mgplot_figcode(mgplot_cur_win(), filename, cmd);
	}
}

Func void gplot_semilogx(X1, Y1, titles, cmds, ...)
	Array X1;
	Array Y1;
	List titles;
	List cmds;
{
	if (nargs == 2) {
		mgplot_semilogx(mgplot_cur_win(), X1, Y1);
	} else if (nargs == 3) {
		mgplot_semilogx(mgplot_cur_win(), X1, Y1, titles);
	} else if (nargs == 4) {
		mgplot_semilogx(mgplot_cur_win(), X1, Y1, titles, cmds);
	} else {
		error("gplot_semilogx(): Incorrect number of arguments.\n");
	}
}

Func void greplot_semilogx(X1, Y1, titles, cmds, ...)
	Array X1;
	Array Y1;
	List titles;
	List cmds;
{
	if (nargs == 2) {
		mgreplot_semilogx(mgplot_cur_win(), X1, Y1);
	} else if (nargs == 3) {
		mgreplot_semilogx(mgplot_cur_win(), X1, Y1, titles);
	} else if (nargs == 4) {
		mgreplot_semilogx(mgplot_cur_win(), X1, Y1, titles, cmds);
	} else {
		error("greplot_semilogx(): Incorrect number of arguments.\n");
	}
}

Func void gplot_semilogy(X, Y, titles, cmds, ...)
	Array X;
	Array Y;
	List titles;
	List cmds;
{
	if (nargs == 2) {
		mgplot_semilogy(mgplot_cur_win(), X, Y);
	} else if (nargs == 3) {
		mgplot_semilogy(mgplot_cur_win(), X, Y, titles);
	} else if (nargs == 4) {
		mgplot_semilogy(mgplot_cur_win(), X, Y, titles, cmds);
	} else {
		error("gplot_semilogy(): Incorrect number of arguments.\n");
	}
}

Func void greplot_semilogy(X1, Y1, titles, cmds, ...)
	Array X1;
	Array Y1;
	List titles;
	List cmds;
{
	if (nargs == 2) {
		mgreplot_semilogy(mgplot_cur_win(), X1, Y1);
	} else if (nargs == 3) {
		mgreplot_semilogy(mgplot_cur_win(), X1, Y1, titles);
	} else if (nargs == 4) {
		mgreplot_semilogy(mgplot_cur_win(), X1, Y1, titles, cmds);
	} else {
		error("greplot_semilogy(): Incorrect number of arguments.\n");
	}
}

Func void gplot_text(text, x, y, z, ...)
	String text;
	Real x, y, z;
{
	if (nargs < 3 || 4 < nargs) {
		error("gplot_text(): Incorrect number of arguments.\n");
	}
	
	if (nargs == 3) {
		mgplot_text(mgplot_cur_win(), text, x, y);
	} else if (nargs == 4) {
		mgplot_text(mgplot_cur_win(), text, x, y, z);
	}
}

Func void gplot_title(text)
	String text;
{
	mgplot_title(mgplot_cur_win(), text);
}

Func void gplot_xlabel(text, xoff, yoff, ...)
	String text;
	Integer xoff;
	Integer yoff;
{
	if (nargs < 1 || 3 < nargs) {
		error("gplot_xlabel(): Incorrect number of arguments\n");
	}
	if (nargs == 1) {
		mgplot_xlabel(mgplot_cur_win(), text);
	} else if (nargs == 2) {
		mgplot_xlabel(mgplot_cur_win(), text, xoff);
	} else {
		mgplot_xlabel(mgplot_cur_win(), text, xoff, yoff);
	}
}

Func void gplot_x2label(text, xoff, yoff, ...)
	String text;
	Integer xoff;
	Integer yoff;
{
	if (nargs < 1 || 3 < nargs) {
		error("gplot_x2label(): Incorrect number of arguments\n");
	}
	if (nargs == 1) {
		mgplot_x2label(mgplot_cur_win(), text);
	} else if (nargs == 2) {
		mgplot_x2label(mgplot_cur_win(), text, xoff);
	} else {
		mgplot_x2label(mgplot_cur_win(), text, xoff, yoff);
	}
}

Func void gplot_ylabel(text, xoff, yoff, ...)
	String text;
	Integer xoff;
	Integer yoff;
{
	if (nargs < 1 || 3 < nargs) {
		error("gplot_ylabel(): Incorrect number of arguments\n");
	}
	if (nargs == 1) {
		mgplot_ylabel(mgplot_cur_win(), text);
	} else if (nargs == 2) {
		mgplot_ylabel(mgplot_cur_win(), text, xoff);
	} else {
		mgplot_ylabel(mgplot_cur_win(), text, xoff, yoff);
	}
}

Func void gplot_y2label(text, xoff, yoff, ...)
	String text;
	Integer xoff;
	Integer yoff;
{
	if (nargs < 1 || 3 < nargs) {
		error("gplot_y2label(): Incorrect number of arguments\n");
	}
	if (nargs == 1) {
		mgplot_y2label(mgplot_cur_win(), text);
	} else if (nargs == 2) {
		mgplot_y2label(mgplot_cur_win(), text, xoff);
	} else {
		mgplot_y2label(mgplot_cur_win(), text, xoff, yoff);
	}
}

Func void gplot_zlabel(text, xoff, yoff, ...)
	String text;
	Integer xoff;
	Integer yoff;
{
	if (nargs < 1 || 3 < nargs) {
		error("gplot_zlabel(): Incorrect number of arguments\n");
	}
	if (nargs == 1) {
		mgplot_zlabel(mgplot_cur_win(), text);
	} else if (nargs == 2) {
		mgplot_zlabel(mgplot_cur_win(), text, xoff);
	} else {
		mgplot_zlabel(mgplot_cur_win(), text, xoff, yoff);
	}
}

Func void gplot_view(rotate_x, rotate_z, scale, scale_z, ...)
	 Integer rotate_x;
	 Integer rotate_z;
	 Integer scale;
	 Integer scale_z;
{
	if (nargs == 1) {
		 gplot_view_control();
		 return;
	}

	if (nargs < 2 || 4 < nargs) {
		error("gplot_view(): Incorrect number of arguments\n");
	}
	if (nargs == 1) {
		mgplot_view(mgplot_cur_win(), rotate_x);
	} else if (nargs == 2) {
		mgplot_view(mgplot_cur_win(), rotate_x, rotate_z);
	} else if (nargs == 3) {
		mgplot_view(mgplot_cur_win(), rotate_x, rotate_z, scale);
	} else {
		mgplot_view(mgplot_cur_win(), rotate_x, rotate_z, scale, scale_z);
	}
}

Func List gplot_view_control(rotate_x, rotate_z, scale, scale_z, ...)
	 Integer rotate_x;
	 Integer rotate_z;
	 Integer scale;
	 Integer scale_z;
{
	if (4 < nargs) {
		error("gplot_view_control(): Incorrect number of arguments\n");
	}
	if (nargs == 1) {
		 return mgplot_view_control(mgplot_cur_win(), rotate_x);
	} else if (nargs == 2) {
		 return mgplot_view_control(mgplot_cur_win(), rotate_x, rotate_z);
	} else if (nargs == 3) {
		 return mgplot_view_control(mgplot_cur_win(), rotate_x, rotate_z, scale);
	} else {
		 return mgplot_view_control(mgplot_cur_win(), rotate_x, rotate_z, scale, scale_z);
	}
}


Func void gplot_options(options)
	String options;
{
	mgplot_options(mgplot_cur_win(), options);
}

Func void gplot_subplot(rows, cols, num, ...)
	Integer rows, cols, num;
{
	String mess;
	
	if (nargs < 2 || 3 < nargs) {
		error("gplot_subplot(): Incorrect number of arguments\n");
	}
	
	if (nargs == 2) {
		num = 1;
	}
	
	if (cols < 0) {
		error("gplot_subplot(): Number of columns must be positive\n");
	}
	if (rows < 0) {
		error("gplot_subplot(): Number of rows must be positive\n");
	}
	if (num < 0 || cols*rows < num) {
		mess = sprintf("Number must be between 1 and %d\n", rows*cols);
		error("gplot_subplot): " + mess);
	}

	mgplot_subplot(mgplot_cur_win(), rows, cols, num);
}

