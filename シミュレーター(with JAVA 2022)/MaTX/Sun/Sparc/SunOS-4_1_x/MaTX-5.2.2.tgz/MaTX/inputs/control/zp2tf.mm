
/* -*- MaTX -*-
 *
 *  NAME
 *      zp2tf() - Zero-pole to transfer function conversion
 *
 *  SYNOPSIS
 *      {NUM,den} = zp2tf(z,p,k)
 *         Matrix NUM,den;
 *         CoMatrix z,p;
 *         Matrix k;
 *
 *  DESCRIPTION
 *      zp2tf(z,p,k) returns the numerator coefficients NUM and the
 *      denominator coefficients den of the transfer function
 *
 *                NUM(s)     (s-z1)(s-z2)...(s-zn)
 *        G(s) =  ------ = k ---------------------
 *                den(s)     (s-p1)(s-p2)...(s-pn)
 *
 *      for SIMO system, given a set of pole and zero locations in p and z,
 *      and the gains for each transfer function in vector k.
 *
 *      NUM is Rows(z)-by-(length(p)-1) and den is 1-by-(length(p)-1).
 *
 *  SEE ALSO  
 *      zp2tfm, zp2tfn, zp2ss, and tf2zp
 */

Func List zp2tf(z,po,k)
	CoMatrix z,po;
	Matrix k;
{
	Integer i,n,p;
	Matrix den,NUM,nu;

	den = Re(Matrix(makepoly(po)));

	if (isempty(z)) {
		NUM = makecolv(k);
		return {NUM,den};
	}

	{n,p} = size(z);
	if (p != length(k)) {
		error("zp2tf(): k must have as many elements as Cols(z).\n");
	}

	NUM = Z(p,n);
	for (i = 1; i <= n; i++) {
		nu = Re(Matrix(makepoly(z(i,:)))) * k(i);
		NUM(i,:) = [Z(1,n-length(nu)), nu];
	}
	return {NUM,den};
}
