
/* -*- MaTX -*-
 *
 *  NAME
 *      tfm2zp() - Transfer function matrix to zero-pole conversion
 *
 *  SYNOPSIS
 *      {z,p,k} = tfm2zp(G)
 *         CoMatrix z, p;
 *         Matrix k;
 *         RaMatrix G;
 *
 *      {z,p,k} = tfm2zp(G,i)
 *         CoMatrix z, p;
 *         Matrix k;
 *         RaMatrix G;
 *         Integer i;
 *
 *  DESCRIPTION
 *      tfm2zp(G,i) returns the zeros, poles and gains of the system
 *      whose transfer function matrix is given by
 *
 *                   (s-z1)(s-z2)...(s-zn)
 *     	    G(s) = k ---------------------
 *                   (s-p1)(s-p2)...(s-pn)
 *
 *      from the i-th input.
 *
 *      p and z contain poles and zeros, and k contains the gains
 *      for each numerator of transfer function.
 *
 *  SEE ALSO
 *      tfm2tf, tfm2tf, tfm2ss, and zp2tfm
 */

Func List tfm2zp(G, i, ...)
	RaMatrix G;
	Integer i;
{
	Matrix A,B,C,D,k;
	CoMatrix p,z;
	
	error(nargchk(1, 2, nargs, "tfm2zp"));

	if (nargs == 1) {
		i = 1;
	}

	{A,B,C,D} = tfm2ss(G,i);
	{z,p,k} = ss2zp(A,B,C,D,1);
	return {z,p,k};
}
