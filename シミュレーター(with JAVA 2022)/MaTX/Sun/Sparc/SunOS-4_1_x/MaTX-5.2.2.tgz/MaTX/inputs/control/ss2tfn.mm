
/* -*- MaTX -*-
 *
 *  NAME
 *      ss2tfn() -  State-space to transfer function conversion
 *
 *  SYNOPSIS
 *      g = ss2tfn(A,B,C,D)
 *         Rational g;
 *         Matrix A,B,C,D;
 *
 *      g = ss2tfn(A,B,C,D,i)
 *         Rational g;
 *         Matrix A,B,C,D;
 *         Integer i;
 *
 *  DESCRIPTION
 *      ss2tfn(A,B,C,D) returns the transfer function:
 *
 *                       -1
 *          g(s) = C(sI-A) B + D
 *
 *      of the MISO system:
 *          .
 *          x = Ax + Bu
 *          y = Cx + Du
 *
 *      from the i'th input.  
 *
 *  SEE ALSO
 *      ss2tf, ss2tfm, ss2zp, and tfn2ss
 */

Func Rational ss2tfn(A,B,C,D,i, ...)
	Matrix A,B,C,D;
	Integer i;
{
	Matrix num,den;
	Rational g;
	String msg;
	
	error(nargchk(4, 5, nargs, "ss2tfn"));

	if (length((msg = abcdchk(A, B, C, D))) > 0) {
		error("ss2tfn(): " + msg);
	}
	
	if (Rows(C) > 1) {
		error("ss2tfn(): System must be single output\n");
	}

	if (nargs == 4) { 
		{num,den} = ss2tf(A,B,C,D);
	} else {
		{num,den} = ss2tf(A,B,C,D,i);
	}

	g = tf2tfn(num,den);
	return g;
}
