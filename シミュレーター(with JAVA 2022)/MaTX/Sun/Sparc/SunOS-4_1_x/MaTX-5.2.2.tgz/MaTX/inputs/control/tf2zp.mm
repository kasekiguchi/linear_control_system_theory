
/* -*- MaTX -*-
 *
 *  NAME
 *      tf2zp() - Transfer function to zero-pole conversion
 *
 *  SYNOPSIS
 *      {z,p,k} = tf2zp(NUM,den)
 *         CoMatrix z, p;
 *         Matrix k;
 *         Matrix NUM,den;
 *
 *  DESCRIPTION
 *       tf2zp(NUM,den) returns the zeros, poles, and gains of the system
 *
 *                      NUM(s)     (s-z1)(s-z2)...(s-zn)
 *              G(s) =  ------ = K ---------------------
 *                      den(s)     (s-p1)(s-p2)...(s-pn)
 *
 *      from a SIMO system.
 *
 *      den is the coefficients of the denominator and NUM is the
 *      coefficients of the numerator.
 *
 *      The zero and pole are returned in z and p, and the gain for
 *      each transfer function are in k.
 *
 *  SEE ALSO
 *      tf2tfn, tf2ss, tf2tfm, and zp2tf
 */

Func List tf2zp(NUM,den)
	Matrix NUM,den;
{
	CoMatrix z, p;
	Matrix A, B, C, D, k;

	{A,B,C,D} = tf2ss(NUM,den);
	{z,p,k} = ss2zp(A,B,C,D,1);
	return {z,p,k};
}
