
/*
 *
 * Copyright (C) 1989, 1990, 1991 Masanobu Koga
 *            All Rights Reserved.
 *
 * No part of this software may be used, copied, modified, and distributed
 * in any form or by any means, electronic, mechanical, manual, optical or
 * otherwise, without prior permission of Masanobu Koga.
 *
 */

/*
  complex.h : 

  $Author: koga $
  $Revision: 2.4 $
  $Date: 2000/11/23 03:49:19 $
  $Log: complex.h,v $
  Revision 2.4  2000/11/23 03:49:19  koga
  *** empty log message ***

 * Revision 2.3  1992/06/10  12:18:54  koga
 *  Optimization
 *
 * Revision 2.2  1992/03/25  12:07:42  koga
 * *** empty log message ***
 *
*/

#ifndef complex_header
#define complex_header

#include <matxconf.h>

/* Next line is for the ComplexData */
#include <datafile.h>

#define	COMP_TMP					0
#define	COMP_VAR					1
#define COMP_LIST					2
#define COMP_MATX					3

#define COMP_NULL					CompDef("", 0.0, 0.0)
#define COMP_DEF					CompSetType(COMP_NULL, COMP_VAR)
#define COMP_STC					CompSetType(COMP_NULL, COMP_MATX)

#define	CompGetClass(a)			((a)->class)
#define	CompClass(a)			CompGetClass(a)
#define	CompGetType(a)			((a)->type)
#define	CompType(a)				CompGetType(a)
#define	CompGetName(a)			((a)->name)
#define	CompName(a)				CompGetName(a)

#define CompIsVar(a)			(CompType(a) == COMP_VAR)
#define CompIsTmp(a)			(CompType(a) == COMP_TMP)

#define CompIsSameClass(a, b)	(CompClass(a) == CompClass(b))

#define CompErrorName(a)		(a)->name, (a)->real, (a)->imag

typedef struct __Complex _Complex, *Complex;
  
struct __Complex {
	char  *name;	/* Name of Complex             */	
	int    type;	/* Data Type ( VAR, TMP )      */
	double real;	/* Real Part                   */
	double imag;	/* Imaginary Part              */
	Complex prev;	/* To link to previous Complex */
	Complex next;	/* To link to nest Complex     */
};

typedef struct __ComplexValue _ComplexValue, *ComplexValue;

struct __ComplexValue {
	double real;	/* Real Part                   */
	double imag;	/* Imaginary Part              */
};

#define CompRealPart(a)		((a)->real)
#define CompImagPart(a)		((a)->imag)
#define	CompIsZero(a)		((a)->real == 0.0 && (a)->imag == 0.0)
#define	CompIsEqual(a,b)	((a)->real == (b)->real && (a)->imag == (b)->imag)
#define	CompIsNotEqual(a,b)	((a)->real != (b)->real || (a)->imag != (b)->imag)

#define COMP_ERR_LENGTH 256

extern char	*complex_err_src;				/* Error source code */

/* ------------------------------------------------------------------------- */
void 		CompError(char *func, char *mess, Complex a);
void 		CompError2(char *func, char *mess, Complex a, Complex b);
void 		CompWarning(char *func, char *mess, Complex a);
void 		CompWarning2(char *func, char *mess, Complex a, Complex b);
void		CompInit(void);
void		CompFree(Complex a);
void		CompFrees(Complex a);
void		CompInstall(Complex a);
void		CompDestroy(Complex a);
void		CompUndef(Complex a);
void		CompUndefs(Complex a);
void		CompTmpUndef(void);
void		CompAllPrint(void);
void		CompPrint(Complex a);
void		CompSwap(Complex b, Complex a);

Complex		CompSetName(Complex a, char *name);
Complex		CompSetType(Complex a, int type);

Complex		CompInput(char *name);
Complex		CompEdit(Complex a);
Complex		CompCopy(Complex b, Complex a);
Complex		CompElementCopy(Complex b, Complex a);
Complex		CompElementChange(Complex b, Complex a);
Complex		CompMove(Complex b, Complex a);
Complex		CompDup(Complex a);
Complex		CompAssign(Complex b, Complex a);
Complex		CompAssignOnly(Complex b, Complex a);
Complex		CompFileRead(char *filename);
Complex		CompFileSave(Complex a, char *filename, int append, int cr);
Complex		CompFileWrite(Complex a, char *filename);
Complex		CompWrite(Complex a, FILE *fp);
Complex		CompRead(Complex a, FILE *fp);
int			CompReadContent(Complex a, FILE *fp, ComplexData *data);

Complex		CompDef(char *name, double r, double i);
Complex		CompDef2(Complex c1, Complex c2);
Complex		CompRequest(void);

Complex	CompSetRealPart(Complex a, double d);
Complex	CompSetImagPart(Complex a, double d);
Complex	CompSetValue(Complex a, double dr, double di);
Complex CompSetZero(Complex a);
Complex CompSetOne(Complex a);
Complex CompSetInf(Complex a);
Complex CompSetNaN(Complex a);

char *CompToString(Complex a, char *str, char *fmt);

ComplexValue ComplexValueDef(double r, double i);
ComplexValue ComplexValueCopy(ComplexValue b, ComplexValue a);
ComplexValue ComplexValueSetRe(ComplexValue a, double x);
ComplexValue ComplexValueSetIm(ComplexValue a, double x);
ComplexValue ComplexValueSetZero(ComplexValue a);
ComplexValue ComplexValueSetOne(ComplexValue a);
ComplexValue ComplexValueSetNaN(ComplexValue a);
ComplexValue ComplexValueSetInf(ComplexValue a);
ComplexValue ComplexValueConj(ComplexValue ans, ComplexValue a);
ComplexValue ComplexValueAdd(ComplexValue c, ComplexValue a, ComplexValue b);
ComplexValue ComplexValueSub(ComplexValue c, ComplexValue a, ComplexValue b);
ComplexValue ComplexValueAddSelf(ComplexValue a, ComplexValue b);
ComplexValue ComplexValueSubSelf(ComplexValue a, ComplexValue b);
ComplexValue ComplexValueMulSelf(ComplexValue a, ComplexValue b);
ComplexValue ComplexValueDivSelf(ComplexValue a, ComplexValue b);
ComplexValue ComplexValueInv(ComplexValue b, ComplexValue a);
ComplexValue ComplexValueMulSelf2(ComplexValue a, double b);
ComplexValue ComplexValueNegate(ComplexValue b, ComplexValue a);
ComplexValue ComplexValueNegateSelf(ComplexValue a);
ComplexValue ComplexValueMul(ComplexValue c, ComplexValue a, ComplexValue b);
ComplexValue ComplexValueMul1(ComplexValue c, double a, ComplexValue b);
ComplexValue ComplexValueMul2(ComplexValue c, ComplexValue a, double b);
ComplexValue ComplexValueDiv(ComplexValue c, ComplexValue a, ComplexValue b);
ComplexValue ComplexValueConjSelf(ComplexValue a);
ComplexValue ComplexValueSqrt(ComplexValue b, ComplexValue a);
ComplexValue ComplexValueLog(ComplexValue b, ComplexValue a);
ComplexValue ComplexValueExp(ComplexValue b, ComplexValue a);
ComplexValue ComplexValueExpSelf(ComplexValue a);
ComplexValue ComplexValuePow2(ComplexValue c, ComplexValue a, ComplexValue b);
ComplexValue ComplexValueSetValue(ComplexValue a, double dr, double di);
ComplexValue ComplexValueDup(ComplexValue a);
ComplexValue CompToComplexValue(Complex x);
Complex ComplexValueToComp(ComplexValue x);
char *ComplexValueToString(ComplexValue a, char *str, char *fmt);
double ComplexValueAbs(ComplexValue a);
double ComplexValueArg(ComplexValue a);
void ComplexValueSwap(ComplexValue b, ComplexValue a);
void ComplexValueDestroy(ComplexValue a);
int ComplexValueIsZero(ComplexValue a);
int ComplexValueIsInf(ComplexValue a);
int ComplexValueIsNaN(ComplexValue a);
int ComplexValueIsFinite(ComplexValue a);

Complex	CompAdd(Complex a, Complex b);
Complex	CompAddSelf(Complex a, Complex b);
Complex	CompAddSelf1(double a, Complex b);
Complex	CompAddSelf2(Complex a, double b);
Complex	CompAdd1(double a, Complex b);
Complex	CompAdd2(Complex a, double b);
Complex	CompSub(Complex a, Complex b);
Complex	CompSubSelf(Complex a, Complex b);
Complex	CompSubSelf1(double a, Complex b);
Complex	CompSubSelf2(Complex a, double b);
Complex	CompSub1(double a, Complex b);
Complex	CompSub2(Complex a, double b);
Complex	CompMul(Complex a, Complex b);
Complex	CompMulSelf(Complex a, Complex b);
Complex	CompMulSelf1(double a, Complex b);
Complex	CompMulSelf2(Complex a, double b);
Complex	CompMul1(double a, Complex b);
Complex	CompMul2(Complex a, double b);
Complex	CompDiv(Complex a, Complex b);
Complex	CompDivSelf(Complex a, Complex b);
Complex	CompDivSelf1(double a, Complex b);
Complex	CompDivSelf2(Complex a, double b);
Complex	CompDiv1(double a, Complex b);
Complex	CompDiv2(Complex a, double b);
Complex	CompInv(Complex a);
Complex	CompInvSelf(Complex a);
Complex	CompConj(Complex a);
Complex	CompConjSelf(Complex a);
Complex	CompNegate(Complex a);
Complex	CompNegateSelf(Complex a);
Complex	CompPow(Complex	a, int m);
Complex	CompPow2(Complex a, Complex b);
Complex CompLog(Complex a);
Complex CompLogSelf(Complex a);
Complex CompLog10(Complex a);
Complex	CompExp(Complex a);
Complex	CompExpSelf(Complex a);
Complex	CompSin(Complex a);
Complex CompSinSelf(Complex a);
Complex	CompSinh(Complex a);
Complex CompSinhSelf(Complex a);
Complex	CompAsin(Complex a);
Complex	CompAsinh(Complex a);
Complex	CompCos(Complex a);
Complex CompCosSelf(Complex a);
Complex	CompCosh(Complex a);
Complex CompCoshSelf(Complex a);
Complex	CompAcos(Complex a);
Complex	CompAcosh(Complex a);
Complex	CompTan(Complex a);
Complex	CompAtan(Complex a);
Complex	CompTanh(Complex a);
Complex	CompAtanh(Complex a);
Complex	CompSqrt(Complex a);
Complex	CompSqrtSelf(Complex a);
Complex CompCeil(Complex a);
Complex CompFloor(Complex a);
Complex CompRint(Complex a);
Complex CompFixToZero(Complex a);
Complex CompRoundToZero(Complex a, double tol);
Complex CompSgn(Complex a);

double	CompAbs(Complex a);
double	CompArg(Complex a);

int		CompIsFinite(Complex a);
int		CompIsNaN(Complex a);
int		CompIsInf(Complex a);
#endif
