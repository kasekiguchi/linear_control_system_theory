
/*
 *
 * Copyright (C) 1999 Masanobu Koga
 *            All Rights Reserved.
 *
 * No part of this software may be used, copied, modified, and distributed
 * in any form or by any means, electronic, mechanical, manual, optical or
 * otherwise, without prior permission of Masanobu Koga.
 *
 */

/*
  mxstring.h : 

  $Author: koga $
  $Revision: 1.1 $
  $Date: 2000/11/23 03:43:12 $
  $Log: mxstring.h,v $
  Revision 1.1  2000/11/23 03:43:12  koga
  Initial revision

*/

#ifndef mxstring_header
#define mxstring_header

#include <matxconf.h>

/* Next line is for StringDataType */
#include <stdio.h>
#include <datafile.h>

/* ------------------------------------------------------------------------- */

#define	STRING_TMP					0
#define	STRING_VAR					1
#define STRING_LIST					2
#define STRING_MATX					3

#define STRING_NULL					mxStringDef("", -1)
#define STRING_DEF					mxStringSetType(STRING_NULL, STRING_VAR)
#define STRING_STC					mxStringSetType(mxStringNull(), STRING_MATX)

#define	mxStringGetClass(a)			((a)->class)
#define	mxStringClass(a)			mxStringGetClass(a)
#define	mxStringGetType(a)			((a)->type)
#define	mxStringType(a)				mxStringGetType(a)
#define	mxStringGetName(a)			((a)->name)
#define	mxStringName(a)				mxStringGetName(a)
#define	mxStringLength(a)			mxStringGetLength(a)
#define mxStringGetString(a)		((a)->string)
#define mxStringString(a)			mxStringGetString(a)

#define mxStringIsVar(a)			(mxStringType(a) == STRING_VAR)
#define mxStringIsTmp(a)			(mxStringType(a) == STRING_TMP)
#define mxStringIsUndef(a)			(mxStringLength(a) == -1)

#define mxStringIsSameClass(a, b)	(mxStringClass(a) == mxStringClass(b))
#define mxStringIsSameLength(a, b)	(mxStringLength(a) == mxStringLength(b))
#define mxStringIsLonger(a,b)		(mxStringLength(a) > mxStringLength(b))
#define mxStringIsShorter(a,b)		(mxStringLength(a) < mxStringLength(b))

#define mxStringErrorName(a)		(a)->name, mxStringLength(a)

typedef struct __mxString _mxString, *mxString;

struct __mxString {	 /* mxString                   */
	char	*name;	 /* Name of String             */	
	int		type;	 /* Data Type ( VAR, TMP )     */
	int		length;	 /* Length of String           */
	char	*string; /* Content of String          */
	mxString prev;	 /* To link to previous String */
	mxString next;	 /* To link to nest String     */
};

#define MXSTRING_ERR_LENGTH 256

extern char	*mxstring_err_src;				/* Error source code */

/* ------------------------------------------------------------------------- */

void	mxStringError(char *func, char *mess, mxString a);
void 	mxStringError2(char *func, char *mess, mxString a, mxString b);
void 	mxStringWarning(char *func, char *mess, mxString a);
void 	mxStringWarning2(char *func, char *mess, mxString a, mxString b);
void	mxStringUndefCheck(mxString a, char *name);
void	mxStringUndefCheck2(mxString a, mxString b, char *name);
void	mxStringInit(void);
void	mxStringFree(mxString a);
void	mxStringFrees(mxString a);
void	mxStringInstall(mxString a);
void	mxStringDestroy(mxString a);
void	mxStringUndef(mxString a);
void	mxStringUndefs(mxString a);
void	mxStringTmpUndef(void);
#ifdef MATX_RT
void	mxStringTmpUndefs(void);
#endif
void	mxStringAllPrint(void);
void	mxStringPrint(mxString a);
void	mxStringSwap(mxString b, mxString a);

mxString	mxStringSetName(mxString a, char *name);
mxString	mxStringSetType(mxString a, int type);
mxString	mxStringSetString(mxString a, char *str);
mxString	mxStringSetLength(mxString a, unsigned int length);
mxString	mxStringSetChar(mxString a, int number, char c);
mxString	mxStringCharToString(char c);

mxString	mxStringInput(char *name);
mxString	mxStringEdit(mxString a);
mxString	mxStringCopy(mxString b, mxString a);
mxString	mxStringPartCopy(mxString b, int b1, int b2,
							 mxString a, int a1, int a2);
mxString	mxStringPut(mxString b, int b1, mxString a);
mxString	mxStringElementCopy(mxString b, mxString a);
mxString	mxStringElementChange(mxString b, mxString a);
mxString	mxStringMove(mxString b, mxString a);
mxString	mxStringDup(mxString a);
mxString	mxStringAssign(mxString b, mxString a);
mxString	mxStringAssignOnly(mxString b, mxString a);
mxString	mxStringFileRead(char *filename);
mxString	mxStringFileSave(mxString a, char *filename, int append, int cr);
mxString	mxStringFileWrite(mxString a, char	*filename);
mxString	mxStringWrite(mxString a, FILE *fp);
mxString	mxStringRead(mxString a, FILE *fp);
int			mxStringReadContent(mxString a, FILE *fp, mxStringData *data);
int			mxStringCompare(mxString a, mxString b);
int			mxStringIndex(mxString a, mxString b);
int			mxStringLastIndex(mxString a, mxString b);
int			mxStringIsEqual(mxString a, mxString b);
int			mxStringIsNotEqual(mxString a, mxString b);
int			mxStringGetLength(mxString a);

mxString	mxStringDef(char *name, int m);
mxString	mxStringRequest(int length);
mxString	mxStringStringDef(char *str);
mxString	mxStringNull(void);
mxString	mxStringSameDef(mxString a);
mxString	mxStringGetElem(mxString a, int n);
mxString	mxStringSetElem(mxString a, int n, mxString b);
mxString	mxStringCut(mxString a, int n1, int n2);
mxString	mxStringFgets(int fd, unsigned int size);
mxString	mxStringGets(unsigned int size);
#ifdef HAVE_STDARG
mxString	mxStringSprintf(char *format, ...);
#else
mxString	mxStringSprintf();
#endif /* HAVE_STDARG */

mxString	mxStringReverse(mxString a);
mxString	mxStringAdd(mxString a, mxString b);
mxString	mxStringMul(mxString a, int n);

#ifndef HAVE_NO_SOCKET
mxString mxStringSocketGets(int sockfd, int max_size);
#endif

#endif
