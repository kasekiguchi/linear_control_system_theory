Matrix	MatDef(char *name, int m, int n);
Matrix	MatNonNameDef(int m, int n);
Matrix	MatIDef(int n);
Matrix	MatIDef2(int m, int n);
Matrix	MatOneDef(int m, int n);
Matrix	MatSameSizeFillDef(Matrix a, double d);
Matrix	MatFillDef(int m, int n, double d);
Matrix	MatZDef(int n);
Matrix	MatZDef2(int m, int n);

Matrix	Mat_Add(Matrix c, Matrix a, Matrix b);
Matrix	Mat_Add_double(Matrix c, Matrix a, double sc);
Matrix	Mat_AddSelf(Matrix a, Matrix b);
Matrix	Mat_Sub(Matrix c, Matrix a, Matrix b);
Matrix	Mat_Sub_double(Matrix c, Matrix a, double sc, int flag);
Matrix	Mat_SubSelf(Matrix a, Matrix b);
Matrix	Mat_Mul(Matrix c, Matrix a, Matrix b);
Matrix	Mat_MulElem(Matrix c, Matrix a, Matrix b);
Matrix	Mat_MulElemSelf(Matrix a, Matrix b);
Matrix	Mat_HousePreMul(Matrix a, Matrix v);
Matrix	Mat_HousePostMul(Matrix a, Matrix v);
Matrix	Mat_DivElem(Matrix c, Matrix a, Matrix b);
Matrix	Mat_DivElemSelf(Matrix a, Matrix b);
Matrix	Mat_Inv(Matrix b, Matrix a, double *det, double tol);
Matrix	Mat_InvElem(Matrix b, Matrix a);
Matrix	Mat_InvElemSelf(Matrix a);
Matrix	Mat_PseudoInv(Matrix b, Matrix a, double tol);
Matrix	Mat_Negate(Matrix b, Matrix a);
Matrix	Mat_Decrement(Matrix b, Matrix a);
Matrix	Mat_Increment(Matrix b, Matrix a);
Matrix	Mat_Trans(Matrix b, Matrix a);
Matrix	Mat_FlipLR(Matrix b, Matrix a);
Matrix	Mat_FlipUD(Matrix b, Matrix a);
Matrix	Mat_ShiftLeft(Matrix b, Matrix a, int m);
Matrix	Mat_ShiftRight(Matrix b, Matrix a, int m);
Matrix	Mat_ShiftUp(Matrix b, Matrix a, int m);
Matrix	Mat_ShiftDown(Matrix b, Matrix a, int m);
Matrix	Mat_RotateLeft(Matrix b, Matrix a, int m);
Matrix	Mat_RotateRight(Matrix b, Matrix a, int m);
Matrix	Mat_RotateUp(Matrix b, Matrix a, int m);
Matrix	Mat_RotateDown(Matrix b, Matrix a, int m);
Matrix	Mat_ChangeColumn(Matrix a, int i, int j);
Matrix	Mat_ChangeRow(Matrix a, int i, int j);
Matrix	Mat_Sort(Matrix b, Matrix idx, Matrix a, int all_row);
Matrix	Mat_SetZero(Matrix a);
Matrix	Mat_RoundToZero(Matrix b, Matrix a, double tol);
Matrix	Mat_Exp(Matrix b, Matrix a);
Matrix	Mat_Pow(Matrix b, Matrix	a, int m);
Matrix	Mat_PowElem(Matrix b, Matrix	a, int m);
Matrix	Mat_PowElemToReal(Matrix b, Matrix a, double dd);
Matrix	Mat_PowElemEach(Matrix c, Matrix a, Matrix b);
Matrix	Mat_RemElem(Matrix b, Matrix a, double dd);
Matrix	Mat_RemElemEach(Matrix c, Matrix a, Matrix b);

Matrix	Mat_Scale(Matrix b, Matrix a, double scale);
Matrix	Mat_ScaleSelf(Matrix a, double scale);
Matrix	Mat_CatColumn(Matrix c, Matrix a, Matrix b);
Matrix	Mat_CatRow(Matrix c, Matrix a, Matrix b);
Matrix	Mat_Cat4(Matrix e, Matrix a, Matrix b, Matrix c, Matrix d);
Matrix	Mat_Cut(Matrix b, Matrix	a, int sr, int sc, int er, int ec);
Matrix	Mat_Put(Matrix a, int sr, int sc, Matrix	b);
Matrix	Mat_SetValue(Matrix a, int row, int column, double d);
Matrix	Mat_SetVecValue(Matrix a, int number, double d);
Matrix	Mat_SetSubMatrix(Matrix a, Matrix rows, Matrix columns, Matrix c);
Matrix	Mat_GetSubMatrix(Matrix a, Matrix rows, Matrix columns, Matrix c);
Matrix	Mat_SetVecSubMatrix(Matrix a, Matrix cols, Matrix c);
Matrix	Mat_GetVecSubMatrix(Matrix a, Matrix cols, Matrix c);
Matrix	Mat_SetBlockSubMatrix(Matrix a, Matrix rows, Matrix columns,
							  int pr, int pc, Matrix c);
Matrix	Mat_GetBlockSubMatrix(Matrix a, Matrix rows, Matrix columns,
							  int pr, int pc, Matrix c);
Matrix	Mat_AreaCopy(Matrix a, int ar, int ac, 
					 Matrix b, int br1, int bc1, int br2, int bc2);
Matrix	Mat_Copy(Matrix b, Matrix a);
Matrix	Mat_VectorProduct(Matrix c, Matrix a, Matrix b);
Matrix	Mat_VectorSquare(Matrix c, Matrix a);
Matrix	Mat_Integral(Matrix c, Matrix a, int m);
Matrix	Mat_HigherShift(Matrix c, Matrix a, int m);
Matrix	Mat_Apply(Matrix b, Matrix a, double (*func)(double d));
Matrix	Mat_ApplyTwo(Matrix c, Matrix a, Matrix b, double (*func)(double d1, double d2));
Matrix	Mat_ApplyPolyFunc(Matrix b, Matrix a, Polynomial poly);
Matrix	Mat_ApplyC_PolyFunc(Matrix b, Matrix a, Polynomial poly);
Matrix	Mat_ApplyRatFunc(Matrix b, Matrix a, Rational rat);
Matrix	Mat_ApplyC_RatFunc(Matrix b, Matrix a, Rational rat);
Matrix	Mat_CompareElem(Matrix c, Matrix a, Matrix b, char *opt);
Matrix	Mat_NotElem(Matrix b, Matrix a);
Matrix	Mat_FiniteElem(Matrix b, Matrix a);
Matrix	Mat_NaNElem(Matrix b, Matrix a);
Matrix	Mat_InfElem(Matrix b, Matrix a);
Matrix	Mat_RungeKutta4(Matrix yout, double x, Matrix y, Matrix (*diff)(),
						Matrix u, double h, int void_flag);
Matrix	Mat_RungeKutta4Link(Matrix yout, double x, Matrix y, Matrix (*diff)(),
							Matrix (*link)(), double h,	int void_flag);
Matrix	Mat_RKF45(Matrix yout, double x, Matrix y, Matrix (*diff)(),
				  Matrix u, double h, int void_flag);
Matrix	Mat_RKF45Link(Matrix yout, double x, Matrix y, Matrix (*diff)(),
					  Matrix (*link)(), double h, int void_flag);
Matrix	Mat_ForSub(Matrix x, Matrix l, Matrix b, double tol);
Matrix	Mat_BackSub(Matrix x, Matrix u, Matrix b, double tol);
Matrix	Mat_LUSolve(Matrix x, Matrix a, Matrix b, double tol);
Matrix	Mat_FFT(Matrix b, Matrix a);
Matrix	Mat_IFFT(Matrix b, Matrix a);
Matrix	Mat_All(Matrix b, Matrix a);
Matrix	Mat_Any(Matrix b, Matrix a);
Matrix	Mat_Max(Matrix b, Matrix a);
Matrix	Mat_Min(Matrix b, Matrix a);
Matrix	Mat_Maximum(Matrix b, Matrix a, Matrix idx);
Matrix	Mat_Minimum(Matrix b, Matrix a, Matrix idx);
Matrix	Mat_Sum(Matrix b, Matrix a);
Matrix	Mat_Prod(Matrix b, Matrix a);
Matrix	Mat_CumSum(Matrix b, Matrix a);
Matrix	Mat_CumSumElem(Matrix b, Matrix a);
Matrix	Mat_CumProd(Matrix b, Matrix a);
Matrix	Mat_CumProdElem(Matrix b, Matrix a);
Matrix	Mat_Mean(Matrix b, Matrix a);
Matrix	Mat_StdDev(Matrix b, Matrix a);
Matrix	Mat_FrobNorms(Matrix b, Matrix a);
Matrix	Mat_HouseVector(Matrix x);

void Mat_Eig(Matrix a, Matrix val, Matrix vec);
void Mat_GEig(Matrix a, Matrix b, Matrix val, Matrix vec);
void Mat_LU(Matrix a, Matrix l, Matrix u, Matrix p);
void Mat_LU_piv(Matrix a, Matrix l, Matrix u, int *piv);
void Mat_Hessenberg(Matrix a, Matrix h, Matrix q);
void Mat_Schur(Matrix a, Matrix t, Matrix u);
void Mat_SVD(Matrix a, Matrix val, Matrix lvec, Matrix rvec);
void Mat_QR(Matrix a, Matrix q, Matrix r, Matrix p, int pflag);
void Mat_QR_piv(Matrix a, Matrix q, Matrix r, int *piv, int *rrkk, int pflag);
void Mat_QZ(Matrix a, Matrix b, Matrix s, Matrix t, Matrix q,
			Matrix z, Matrix vec);
void Mat_Balance(Matrix a, Matrix d, Matrix b);
int	 Mat_Ode(Matrix x_out, Matrix y_out, Matrix u_out, double x1, double x2,
			 Matrix y, Matrix (*diff)(), Matrix (*link)(), double eps_h,
			 double dxmin, double dxmax, double dxsav, int auto_step,
			 int void_flag);
int	 Mat_Ode45(Matrix x_out, Matrix y_out, Matrix u_out, double x1,
			   double x2, Matrix y, Matrix (*diff)(), Matrix (*link)(),
			   double eps_h, double dxmin, double dxmax, double dxsav,
			   int auto_step, int void_flag);
int	 Mat_OdeHybrid(Matrix x_out, Matrix y_out, Matrix u_out, double x1,
				   double x2, double dx, Matrix y, Matrix (*diff)(),
				   Matrix (*link)(), double eps_h, double dxmin,
				   double dxmax, double dxsav, int auto_step, int void_flag);
int	 Mat_Ode45Hybrid(Matrix x_out, Matrix y_out, Matrix u_out, double x1,
					 double x2, double dx, Matrix y, Matrix (*diff)(),
					 Matrix (*link)(), double eps_h, double dxmin,
					 double dxmax, double dxsav, int auto_step, int void_flag);
int	 Mat_OdeGetXY(double x, Matrix *y, Matrix *u);

Matrix	Mat_EigVal(Matrix val, Matrix a);
Matrix	Mat_EigVec(Matrix vec, Matrix a);
Matrix	Mat_EigValVec(Matrix b, Matrix a);
Matrix	Mat_GEigVal(Matrix val, Matrix a, Matrix b);
Matrix	Mat_GEigVec(Matrix vec, Matrix a, Matrix b);
Matrix	Mat_GEigValVec(Matrix c, Matrix a, Matrix b);
void Mat_Swap(Matrix b, Matrix a);
void Mat_Print(Matrix a);

Matrix	MatSetValue(Matrix a, int row, int column, double d);
Matrix	MatSetValueC(Matrix a, int row, int column, Complex c);
Matrix	MatSetValueP(Matrix a, int row, int column, Polynomial p);
Matrix	MatSetValueR(Matrix a, int row, int column, Rational r);
Matrix	MatFillValue(Matrix a, double d);
Matrix	MatSetVecValue(Matrix a, int number, double d);
Matrix	MatSetVecValueC(Matrix a, int number, Complex c);
Matrix	MatSetVecValueP(Matrix a, int number, Polynomial p);
Matrix	MatSetVecValueR(Matrix a, int number, Rational r);

double	MatGetValue(Matrix a, int row, int column);
double	MatGetValueOne(Matrix a, int row, int column);
double	*MatGetPtr(Matrix a, int row, int column);
double	MatGetVecValue(Matrix a, int number);
double	*MatGetVecPtr(Matrix a, int number);

double	MatDeterm(Matrix a);
double	MatScalarProduct(Matrix a, Matrix b);
double	MatFrobNorm(Matrix a);
double	MatInfNorm(Matrix a);
double	MatNorm(Matrix a, int p);
double	MatTrace(Matrix a);
double	MatMaxElem(Matrix a);
double	MatMinElem(Matrix a);
double	MatMaximumElem(Matrix a, int *ii, int *jj);
double	MatMinimumElem(Matrix a, int *ii, int *jj);
double	MatSumElem(Matrix a);
double	MatProdElem(Matrix a);
double	MatMeanElem(Matrix a);
double	MatStdDevElem(Matrix a);
