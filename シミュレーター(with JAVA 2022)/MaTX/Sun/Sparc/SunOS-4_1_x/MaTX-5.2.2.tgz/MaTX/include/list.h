
/*
 *
 * Copyright (C) 1989, 1990, 1991 Masanobu Koga
 *            All Rights Reserved.
 *
 * No part of this software may be used, copied, modified, and distributed
 * in any form or by any means, electronic, mechanical, manual, optical or
 * otherwise, without prior permission of Masanobu Koga.
 *
 */

/*
  list.h : 

  $Author: koga $
  $Revision: 1.5 $
  $Date: 2000/11/23 03:57:32 $
  $Log: list.h,v $
  Revision 1.5  2000/11/23 03:57:32  koga
  *** empty log message ***

 * Revision 1.4  1994/06/21  13:23:05  koga
 * *** empty log message ***
 *
 * Revision 1.3  1992/06/10  12:19:04  koga
 *  Optimization
 *
 * Revision 1.2  1992/03/25  12:09:11  koga
 * Optimization
 *
*/

#ifndef list_header
#define list_header

#include <matxconf.h>

#include <matrix.h>

#ifdef MXSTR
#include <mxstring.h>
#endif

#ifdef POLY
#ifdef HAVE_SHORT_FILENAME
#include <poly.h>
#else
#include <polynomial.h>
#endif
#endif

#ifdef RAT
#include <rational.h>
#endif

#ifdef FNC
#include "function.h"
#endif

#include <object.h>

/*****************************************************************************/

#define	LIST_TMP				0
#define	LIST_VAR				1
#define	LIST_MATX				2
#define	LIST_LIST				3

#define LIST_NULL				ListDef("", 0)
#define LIST_DEF				ListSetType(LIST_NULL, LIST_VAR)
#define LIST_STC				ListSetType(LIST_NULL, LIST_MATX)

#define	ListElement(a,i,c)		ListGetElement(a,i,c)
#define	ListElementP(a,i,c)		ListGetElementP(a,i,c)
#define	ListObject(a,i)			ListGetObject(a,i)
#define ListObjectP(a,i)		((a)->elm + (i) - 1)

#define	ListClass(a,i)			(*((a)->class + (i) - 1))
#define	ListGetType(a)			((a)->type)
#define	ListType(a)				ListGetType(a)
#define	ListGetName(a)			((a)->name)
#define	ListName(a)				ListGetName(a)
#define	ListGetLength(a)		((a)->length)
#define	ListLength(a)			ListGetLength(a)

#define ListIsVar(a)			(ListType(a) == LIST_VAR)
#define ListIsTmp(a)			(ListType(a) == LIST_TMP)

#define ListIsSameLength(a,b)	(ListLength(a) == ListLength(b))

typedef struct __List _List, *List;

struct __List {
	char	*name;	/* Name of List        */
	short	type;	/* List type           */
	int		length;	/* Length of the List  */
	short	*class;	/* Element Class       */
	Object	elm;	/* Element             */
	List 	prev;	/* to link to prev one */
	List 	next;	/* to link to next one */
};

#if 0
extern List matx_list;			/* For multiple output function */
#endif

#define LIST_ERR_LENGTH 256

typedef void *VOIDP;

/*****************************************************************************/

void	ListInit(void);
void 	ListError(char *func, char *mess, List a);
void 	ListError2(char *func, char *mess, List a, List b);
void 	ListWarning(char *func, char *mess, List a);
void 	ListWarning2(char *func, char *mess, List a, List b);
void	ListFree(List a);
void	ListFrees(List a);
void	ListElementDestroy(List a, int number);
void	ListDestroy(List a);
void	ListInstall(List a);
void	ListUndef(List a);
void	ListUndefs(List a);
void	ListTmpUndef(void);
#ifdef MATX_RT
void	ListTmpUndefs(List a);
#endif
void	ListAllPrint(void);
void	ListPrint(List a);
void	ListElementPrint(List a, int number);
void	ListElementSave(List a, int i, char *filename);
void	ListSwap(List b, List a);

List	ListSetName(List a, char *name);
List	ListSetType(List a, int type);
List	ListSetClass(List a, int i, int class);
#ifdef HAVE_STDARG
List	ListSetElement(List a, ...);
List	ListSetDeepElement(List a, ...);
List	ListSetDeepElement2(List a, ...);
List	ListSetDeepObject(List a, ...);
List	ListGetDeepSubElement(List a, ...);
List	ListSetDeepSubElement(List a, ...);
#else
List	ListSetElement();
List	ListSetDeepElement();
List	ListSetDeepElement2();
List	ListSetDeepObject();
List	ListGetDeepSubElement();
List	ListSetDeepSubElement();
#endif

List	ListGetDeepListP(List a, int depth, int *number);
List	ListSetObject(List a, int number, int class, Object obj);
List	ListSetDeepObject2(List a, int depth, int *number,
						   int class, Object obj);
List	ListGetSubElements(List a, Matrix idx);
List	ListGetSubElements2(List a, int from, int to, int by);
List	ListSetSubElements(List a, Matrix idx, List b);
List	ListSetSubElements2(List a, int from, int to, int by, List b);
List	ListGetDeepSubElement2(List a, int depth, Matrix *idxes);
List	ListSetDeepSubElement2(List a, int depth, Matrix *idxes, List b);
List	ListAppendObject(List a, int class, Object obj);
List	ListSetLength(List a, int length);
List	ListFileSave(List a, char *filename, int append, int cr);
List	ListScanf(char *format);
List	ListFileScanf(int fd, char *format);
List	ListFileNameScanf(char *path, char *format);
List	ListStringScanf(char *str, char *format);
List	ListWrite(List ll, FILE *fp);
List	ListRead(List ll, FILE *fp);
void	ListReadContent(List ll, FILE *fp, ListData *data, int ver);

List	ListCopy(List b, List a);
List	ListElementCopy(List b, List a);
List	ListElementChange(List b, List a);
List	ListMove(List b, List a);
List	ListDup(List a);
List	ListAssign(List b, List a);
List	ListAssignOnly(List b, List a);

List	ListDef(char *name, int m);
List	ListRequest(int length);
List	ListReDef(List a, int m);
List	ListSameDef(List a);
#ifdef HAVE_STDARG
List	ListElementsDef(int n, ...);
List	ListObjectsDef(int n, ...);
#else
List	ListElementsDef();
List	ListObjectsDef();
#endif
List	ListMul(List a, int n);

List	ListCat(List a, List b);
List	ListCut(List a, int start, int end);
List	ListPut(List a, int number, List b);
List	ListInsert(List a, int number, List b);

Object	ListGetObject(List a, int number);
VOIDP	ListGetElement(List a, int number, int class);
VOIDP	ListGetElementP(List a, int number, int class);
#ifdef HAVE_STDARG
VOIDP	ListGetDeepElementP(List a, ...);
VOIDP	ListGetDeepElement(List a, ...);
#else
VOIDP	ListGetDeepElementP();
VOIDP	ListGetDeepElement();
#endif
VOIDP	ListGetDeepElement2(List a, int depth, int *number, int class);
VOIDP	ListGetDeepElementP2(List a, int depth, int *number, int class);

int		ListGetClass(List a, int i);
int		ListIsEqual(List a, List b);
int		ListIsNotEqual(List a, List b);
Matrix	ListCompareElem(List a, List b, char *op);
Matrix	ListNotElem(List a);
#ifdef HAVE_STDARG
Matrix	ListCompareElem2(List a, ...);
#else
Matrix	ListCompareElem2();
#endif
Matrix	ListIsClass(List a, int class);
Matrix	ListIsNotClass(List a, int class);

#ifdef HAVE_STDARG
int		ListGetDeepLength(List a, ...);
int		ListGetDeepClass(List a, ...);
#else
int		ListGetDeepLength();
int		ListGetDeepClass();
#endif
int		ListGetDeepLength2(List a, int depth, int *number);
int		ListGetDeepClass2(List a, int depth, int *number);

List	ListMatSize(Matrix a);
List	ListMatBalance(Matrix a);
List	ListMatEig(Matrix a);
List	ListMatGEig(Matrix a, Matrix b);
List	ListMatSVD(Matrix a);
List	ListMatLU(Matrix a, int pflag);
List	ListMatHessenberg(Matrix a);
List	ListMatSchur(Matrix a);
List	ListMatQR(Matrix a, int pflag);
List	ListMatQZ(Matrix a, Matrix b);

#ifdef MAT_RUNGE
List	ListMatOdeGetXY(double t);
List	ListMatOde();
List	ListMatOde45();
List	ListMatOdeHybrid();
List	ListMatOde45Hybrid();

/*
List	ListMatOde(double t1, double t2, Matrix x,
				   Matrix (*diff)(), Matrix (*link)(), double eps_h,
				   double dtmin, double dtmax, double dtsav, int auto_step,
				   int void_flag);
List	ListMatOde45(double t1, double t2, Matrix x, 
					 Matrix (*diff)(), Matrix (*link)(), double eps_h,
					 double dtmin, double dtmax, double dtsav, int auto_step,
					 int void_flag);
List	ListMatOdeHybrid(double t1, double t2, double dt, Matrix x,
						 Matrix (*diff)(), Matrix (*link)(), double eps_h,
						 double dtmin, double dtmax, double dtsav,
						 int auto_step, int void_flag);
List	ListMatOde45Hybrid(double t1, double t2, double dt, Matrix x,
						   Matrix (*diff)(), Matrix (*link)(), double eps_h,
						   double dtmin, double dtmax, double dtsav,
						   int auto_step, int void_flag);
*/
#endif

List	ListMatSort(Matrix a, int class, int row_col_all);
List	ListMatMaximum(Matrix a, int row_col);
List	ListMatMaximumElem(Matrix a);
List	ListMatMinimum(Matrix a, int row_col);
List	ListMatMinimumElem(Matrix a);
List	ListGetClasses(List a);
#ifdef HAVE_STDARG
List	ListMakeList(int depth, ...);
#else
List	ListMakeList();
#endif

List	ListMakeList2(int depth, int *number);

char	*ListClassName(int class);
int		ListMenu(List a, int mem0);
#endif

#ifndef HAVE_NO_SOCKET
List ListSocketRecvfrom(int sockfd);
#endif
