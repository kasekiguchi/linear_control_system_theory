
/*
 *
 * Copyright (C) 1989, 1990, 1991 Masanobu Koga
 *            All Rights Reserved.
 *
 * No part of this software may be used, copied, modified, and distributed
 * in any form or by any means, electronic, mechanical, manual, optical or
 * otherwise, without prior permission of Masanobu Koga.
 *
 */

/*
  polynomial.h : 

  $Author: koga $
  $Revision: 2.4 $
  $Date: 2000/11/23 03:55:17 $
  $Log: polynomial.h,v $
  Revision 2.4  2000/11/23 03:55:17  koga
  *** empty log message ***

 * Revision 2.3  1992/06/10  12:21:22  koga
 *  Optimization
 *
 * Revision 2.2  1992/03/25  12:16:14  koga
 * Optimization
 *
*/

#ifndef polynomial_header
#define polynomial_header

#include <matxconf.h>

/* ------------------------------------------------------------------------- */

#define	POLY_TMP				0
#define	POLY_VAR				1
#define	POLY_RAT				2
#define	POLY_MAT				3
#define	POLY_LIST				4
#define	POLY_MATX				5

#define POLY_REAL				0
#define POLY_COMPLEX			1

#define POLY_NULL				PolyDef("", -1, (char *)0)
#define C_POLY_NULL				C_PolyDef("", -1, (char *)0)
#define POLY_DEF				PolySetType(POLY_NULL, POLY_VAR)
#define POLY_STC				PolySetType(PolyConst(0.0), POLY_MATX)
#define C_POLY_DEF				PolySetType(C_POLY_NULL, POLY_VAR)
#define C_POLY_STC				PolySetType(C_PolyConst(COMP_NULL), POLY_MATX)

#define	PolyPtr(a,i)			MatPtr(PolyCoefficient(a), 1, (i)+1)
#define	PolyValue(a,i)			MatValue(PolyCoefficient(a), 1, (i)+1)
#define PolyCoefficient(a)		((a)->coef)
#define PolyGetCoef(a)			PolyCoefficient(a)
#define	PolyGetClass(a)			((a)->class)
#define	PolyClass(a)			PolyGetClass(a)
#define	PolyGetType(a)			((a)->type)
#define	PolyType(a)				PolyGetType(a)
#define	PolyGetName(a)			((a)->name)
#define	PolyName(a)				PolyGetName(a)
#define	PolyGetDegree(a)		((a)->degree)
#define	PolyDegree(a)			PolyGetDegree(a)
#define PolyGetVar(a)			((a)->var)
#define PolyVar(a)				PolyGetVar(a)

#define PolyIsReal(a)			(PolyClass(a) == POLY_REAL)
#define PolyIsComplex(a)		(PolyClass(a) == POLY_COMPLEX)

#define PolyIsVar(a)			(PolyType(a) == POLY_VAR)
#define PolyIsTmp(a)			(PolyType(a) == POLY_TMP)
#define PolyIsRat(a)			(PolyType(a) == POLY_RAT)
#define PolyIsMat(a)			(PolyType(a) == POLY_MAT)

#define PolyIsConst(a)			(PolyDegree(a) == 0)
#define PolyIsUndef(a)			(PolyDegree(a) == -1)
#define PolyIsSameClass(a, b)	(PolyClass(a) == PolyClass(b))
#define PolyIsSameDegree(a, b)	(PolyDegree(a) == PolyDegree(b))
#define PolyIsLarger(a,b)		(PolyDegree(a) > PolyDegree(b))
#define PolyIsSmaller(a,b)		(PolyDegree(a) < PolyDegree(b))
#define PolyIsNonZero(a)		(! PolyIsZero(a))
#define	PolyIsEqual(a,b)		(MatIsEqual((a)->coef, (b)->coef))
#define	PolyIsNotEqual(a,b)		(MatIsNotEqual((a)->coef, (b)->coef))

#define C_PolyPtr(a, i)			C_MatPtr(PolyCoefficient(a), 1, (i)+1)
#define	C_PolyValue(a, i)		C_MatValue(PolyCoefficient(a), 1, (i)+1)

#define PolyErrorName(a)		(a)->name, (a)->var?(a)->var:"s", PolyDegree(a)

typedef struct __Polynomial _Polynomial, *Polynomial;

#include <matrix.h>

struct __Polynomial {	/* Polynomial                       */
	char	*name;		/* Name of Polynomial               */	
	char	*var;		/* Name of variable                 */	
	int		type;		/* Data Type ( VAR, TMP, RAT, MAT ) */
	int		class;		/* Data Class ( COMPLEX, REAL )     */
	int		degree;		/* Degree of Polynomial             */
	Matrix	coef;		/* Coefficient of Polynomial        */
	Polynomial prev;	/* To link to previous Polynomial   */
	Polynomial next;	/* To link to nest Polynomial       */
};

#define POLY_ERR_LENGTH 256
#define POLY_STRING_LENGTH 1024

extern char	*poly_err_src;				/* Error source code */

/* ------------------------------------------------------------------------- */

void 	PolyError(char *func, char *mess, Polynomial a);
void 	PolyError2(char *func, char *mess, Polynomial a, Polynomial b);
void 	PolyWarning(char *func, char *mess, Polynomial a);
void 	PolyWarning2(char *func, char *mess, Polynomial a, Polynomial b);
void	PolyVarCheck(Polynomial a, Polynomial b, char *name);
void	PolyUndefCheck(Polynomial a, char *name);
void	PolyUndefCheck2(Polynomial a, Polynomial b, char *name);
void	PolyInit(void);
void	PolyFree(Polynomial a);
void	PolyFrees(Polynomial a);
void	PolyInstall(Polynomial a);
void	PolyDestroy(Polynomial a);
void	PolyUndef(Polynomial a);
void	PolyUndefs(Polynomial a);
void	PolyTmpUndef(void);
#ifdef MATX_RT
void	PolyTmpUndefs(void);
#endif
void	PolyAllPrint(void);
void	PolyPrint(Polynomial a);
void	PolySwap(Polynomial b, Polynomial a);
char	*PolyToString(Polynomial a, char **str4, int save, char *var);
char	*C_PolyToString(Polynomial a, char **str4, int save, char *var);

Polynomial	PolySetName(Polynomial a, char *name);
Polynomial	PolySetVar(Polynomial a, char *var);
Polynomial	PolySetType(Polynomial a, int type);
Polynomial	PolySetClass(Polynomial a, int class);
Polynomial	PolySetValue(Polynomial a, int degree, double d);
Polynomial	C_PolySetValue(Polynomial a, int degree, Complex c);
Polynomial	PolySetCoef(Polynomial a, Matrix coef);
Polynomial	PolySetZero(Polynomial a);
Polynomial	PolyCeil(Polynomial a);
Polynomial	PolyFloor(Polynomial a);
Polynomial	PolyRint(Polynomial a);
Polynomial	PolyFixToZero(Polynomial a);
Polynomial	PolyRoundToZero(Polynomial a, double tol);

Polynomial	PolyInput(char *name);
Polynomial	PolyEdit(Polynomial a);
Polynomial	PolyCopy(Polynomial b, Polynomial a);
Polynomial	PolyPartCopy(Polynomial b, int bl, int bh,
						 Polynomial a, int al, int ah);
Polynomial	PolyElementCopy(Polynomial b, Polynomial a);
Polynomial	PolyElementChange(Polynomial b, Polynomial a);
Polynomial	PolyMove(Polynomial b, Polynomial a);
Polynomial	PolyDup(Polynomial a);
Polynomial	PolyAssign(Polynomial b, Polynomial a);
Polynomial	PolyAssignOnly(Polynomial b, Polynomial a);
Polynomial	PolyFileRead(char *filename);
Polynomial	PolyFileSave(Polynomial a, char *filename, int append, int cr);
Polynomial	PolyFileWrite(Polynomial a, char *filename);
Polynomial	PolyWrite(Polynomial pp, FILE *fp);
Polynomial	PolyRead(Polynomial pl, FILE *fp);
int	PolyReadContent(Polynomial pl, FILE *fp, PolynomialData *data, int ver);
int	PolyIsZero(Polynomial a);

Polynomial	PolyDef(char *name, int m, char *var);
Polynomial	PolyRequest(int degree, int class);
Polynomial	PolyCoefDef(Matrix coef, char *var);
Polynomial	C_PolyDef(char *name, int m, char *var);
Polynomial	PolySameClassDef(Polynomial a, int m);
Polynomial	PolySameDef(Polynomial a);
Polynomial	PolyMulDef(Polynomial a, Polynomial b);
Polynomial	PolyIDef(int n, char *var);
Polynomial	C_PolyIDef(int n, char *var);
Polynomial	PolyFirst(double d, char *var);
Polynomial	C_PolyFirst(Complex c, char *var);
Polynomial	PolyConst(double d);
Polynomial	C_PolyConst(Complex c);

Polynomial	PolyAdd(Polynomial a, Polynomial b);
Polynomial	PolyAdd_double(Polynomial a, double sc);
Polynomial	PolyAdd_Complex(Polynomial a, Complex sc);
Polynomial	PolySub(Polynomial a, Polynomial b);
Polynomial	PolySub_double(Polynomial a, double sc, int flag);
Polynomial	PolySub_Complex(Polynomial a, Complex sc, int flag);
Polynomial	PolyMul(Polynomial a, Polynomial b);
Polynomial	PolyScale(Polynomial a, double scale);
Polynomial	PolyScaleSelf(Polynomial a, double scale);
Polynomial	PolyScaleC(Polynomial a, Complex scale);
Polynomial	PolyPow(Polynomial a, int m);
Polynomial	PolyNegate(Polynomial a);
Polynomial	PolyConj(Polynomial a);
Polynomial	PolyRealPart(Polynomial a);
Polynomial	PolyImagPart(Polynomial a);
Polynomial	PolyCut(Polynomial a, int nl, int nh);
Polynomial	PolyRealAndImag(Polynomial a, Polynomial b);
Polynomial	PolyRealToComp(Polynomial a);
Polynomial	PolyExpand(Polynomial a, int m);
Polynomial	PolySimplify(Polynomial a, double tol);
Polynomial	PolyDerivative(Polynomial a, int m);
Polynomial	PolyIntegral(Polynomial a, int m);
Polynomial	PolyLowerShift(Polynomial a, int m);
Polynomial	PolyHigherShift(Polynomial a, int m);
double		PolyEval(Polynomial a, double d);
Complex		PolyEvalC(Polynomial a, Complex c);
Polynomial	PolyEvalP(Polynomial a, Polynomial b);
Matrix		PolyEvalM(Polynomial a, Matrix b);
Complex		C_PolyEval(Polynomial a, double d);
Complex		C_PolyEvalC(Polynomial a, Complex c);
Matrix		PolyRoots(Polynomial a);
Matrix		PolyCoef(Polynomial a);
double		*PolyGetPtr(Polynomial a, int m);
double		PolyGetValue(Polynomial a, int m);
ComplexValue C_PolyGetPtr(Polynomial a, int m);
Complex		C_PolyGetValue(Polynomial a, int m);
char *PolyStringWrap(char **str, unsigned int margin,
					 unsigned int width, char *eol);
double		PolyCoefFrobNorm(Polynomial a);

#endif
